# Paquetes y prototipos

| Archivo | Qué es | Estado |
|---|---|---|
| `MovimientoDAO_corregido.zip` | Corrección antigua que agregaba `configurarBloqueo()` y `adquirirBloqueoEscritura()` | **Superado**: la versión activa ya los incluye; este archivo, puesto en la activa, da 5 errores de compilación. |
| `MovimientoDAO_corregido_entrega.zip` | Mismo contenido que el anterior | Superado. |
| `REVISION_COMPLETA.zip` | Los 3 informes de revisión de la rama Login (módulos, servicios/DAO, vistas) | Ya están sueltos en `02_DOCUMENTACION/revisiones/login`. |
| `SistemaInventario_ModuloProducto.zip` | Prototipo mínimo de solo Productos (9 archivos) con otra estructura de paquetes | Histórico; no es compatible con la versión activa. |
