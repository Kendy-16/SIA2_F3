# Informe de organización de `Proyectos.zip`

## Punto de partida

* 1 782 entradas, 1 304 archivos, 46,4 MB descomprimidos; **solo 270 contenidos distintos (20,3 MB)**: 1 034 archivos eran copias exactas.
* El mismo proyecto aparecía 3 veces como carpeta (`SistemaInventario_T1`, `Instalacion_Login`, `Instalacion_Temporal`), otra vez dentro de
  `_verificacion_zip_20261117`, otra dentro de un paquete de 9 MB y otra dentro de un ZIP aplanado por iLoveZIP (archivos renombrados `(4)`, `(67)`…).
* 22 archivos vacíos en la raíz del proyecto con nombres como `0`, `7`, `cd`, `dir`, `mvn`, `findstr`, `type`, `{`, `JLabel`, `registrarProveedor()`:
  restos de comandos de CMD con `>` mal escapado. Además, `revision_validaciones_movimientos.txtdir` (211 KB) era copia exacta de `revision_validaciones_movimientos.txt`.
* Carpetas `target/` (artefactos de compilación) en 3 sitios.

## Cómo se eligió la versión activa

Se compiló cada versión con `javac` 21:

| Versión | Resultado | Roles (V005) | Movimientos |
|---|---|---|---|
| `SistemaInventario_T1` (principal) | **0 errores** | Sí | `MovimientoView` con 3 pestañas + `MovimientoController` con rol |
| `Instalacion_Login` | 117 errores (2 archivos dañados) | No | Vistas separadas + historial |
| `Instalacion_Temporal` | 0 errores | No | Versión inicial |

La principal es la más reciente (16–17 nov) y la más completa de las que compilan, por eso es la activa. Su código se copió **byte a byte**, sin ediciones.
Lo valioso de las otras dos se conservó aparte y documentado (`04_VERSIONES_ANTERIORES/LEEME.md`).

## Qué se hizo

1. Proyecto activo limpio en `01_PROYECTO_ACTIVO`.
2. Informes, auditorías y listados agrupados en `02_DOCUMENTACION`.
3. Respaldos de BD y código agrupados en `03_RESPALDOS`; las instantáneas `antes_*` se conservaron completas.
4. De las versiones anteriores solo se guardaron los archivos que difieren de la activa.
5. Ninguna carpeta quedó vacía: las carpetas de módulos pendientes llevan un `README.md`.
6. `docs/DIAGRAMA_ER.md` (estaba vacío) se generó desde la base de datos real; se añadió `docs/ESTADO_DEL_PROYECTO.md`.

## Comprobación de que no se perdió nada

Se calculó la huella (MD5 + tamaño) de cada archivo con contenido del ZIP original, incluido el interior de los dos ZIP descartados (1 118 archivos con contenido).
Los únicos contenidos que **no** están en el paquete organizado son: los dos ZIP contenedores, el índice de uno de ellos y dos listas de Maven (`createdFiles.lst`, `inputFiles.lst`),
todos regenerables o redundantes.

## Trazabilidad

* `MAPA_ORIGEN_DESTINO.csv`: dónde quedó cada archivo conservado.
* `MANIFIESTO_DESCARTADOS.csv`: cada archivo no conservado y el motivo.
