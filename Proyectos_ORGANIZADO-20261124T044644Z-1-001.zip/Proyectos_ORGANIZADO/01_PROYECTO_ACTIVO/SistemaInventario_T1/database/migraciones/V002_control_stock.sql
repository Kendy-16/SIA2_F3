
-- =========================================================
-- MIGRACION V002: CONTROL DE ESTADO DE CATALOGOS
-- SistemaInventario_T1
-- =========================================================

-- Productos activos o inactivos.
ALTER TABLE productos
ADD COLUMN activo INTEGER NOT NULL DEFAULT 1
CHECK (activo IN (0, 1));

-- Almacenes activos o inactivos.
ALTER TABLE almacenes
ADD COLUMN activo INTEGER NOT NULL DEFAULT 1
CHECK (activo IN (0, 1));

-- Indices para consultas de catalogos activos.
CREATE INDEX IF NOT EXISTS idx_productos_activo
ON productos(activo);

CREATE INDEX IF NOT EXISTS idx_almacenes_activo
ON almacenes(activo);
