
-- =========================================================
-- MIGRACION V001: INVENTARIO FISICO
-- =========================================================

CREATE TABLE IF NOT EXISTS tomas_inventario_fisico (
    id_toma INTEGER PRIMARY KEY AUTOINCREMENT,
    id_almacen INTEGER NOT NULL,
    fecha TEXT NOT NULL DEFAULT (datetime('now','localtime')),

    modo TEXT NOT NULL
        CHECK (modo IN ('GENERAL', 'PARCIAL', 'CICLICO')),

    estado TEXT NOT NULL DEFAULT 'ABIERTO'
        CHECK (estado IN ('ABIERTO', 'PROCESADO', 'ANULADO')),

    observacion TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    procesado_en TEXT,

    FOREIGN KEY (id_almacen)
        REFERENCES almacenes(id_almacen)
);

CREATE TABLE IF NOT EXISTS detalle_toma_inventario (
    id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
    id_toma INTEGER NOT NULL,
    id_producto INTEGER NOT NULL,

    stock_sistema REAL NOT NULL DEFAULT 0
        CHECK (stock_sistema >= 0),

    cantidad_fisica REAL
        CHECK (cantidad_fisica IS NULL OR cantidad_fisica >= 0),

    diferencia REAL,
    costo_promedio REAL NOT NULL DEFAULT 0
        CHECK (costo_promedio >= 0),

    impacto_valorizado REAL,
    observacion TEXT,

    FOREIGN KEY (id_toma)
        REFERENCES tomas_inventario_fisico(id_toma),

    FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto),

    UNIQUE (id_toma, id_producto)
);

CREATE INDEX IF NOT EXISTS idx_toma_almacen_fecha
ON tomas_inventario_fisico(id_almacen, fecha);

CREATE INDEX IF NOT EXISTS idx_detalle_toma
ON detalle_toma_inventario(id_toma);

CREATE INDEX IF NOT EXISTS idx_detalle_producto
ON detalle_toma_inventario(id_producto);
