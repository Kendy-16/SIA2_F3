-- V006: IGV en detalle de movimientos + administrador inicial
-- (la aplica automáticamente MigracionV006IgvYAdministrador al arrancar)
ALTER TABLE detalle_movimientos ADD COLUMN igv_tasa     REAL NOT NULL DEFAULT 0 CHECK (igv_tasa >= 0 AND igv_tasa <= 1);
ALTER TABLE detalle_movimientos ADD COLUMN igv_monto    REAL NOT NULL DEFAULT 0 CHECK (igv_monto >= 0);
ALTER TABLE detalle_movimientos ADD COLUMN precio_venta REAL NOT NULL DEFAULT 0 CHECK (precio_venta >= 0);

UPDATE usuarios SET rol = 'ADMINISTRADOR'
WHERE id_usuario = (SELECT MIN(id_usuario) FROM usuarios)
  AND NOT EXISTS (SELECT 1 FROM usuarios WHERE rol = 'ADMINISTRADOR');
