
-- =========================================================
-- MIGRACION V003: UNICA TOMA ABIERTA POR ALMACEN
-- SistemaInventario_T1
-- =========================================================

-- Impide que un almacen tenga mas de una toma
-- de inventario fisico en estado ABIERTO.
--
-- Los conteos PROCESADO y ANULADO se conservan
-- como registros historicos.

CREATE UNIQUE INDEX IF NOT EXISTS
    idx_toma_abierta_unica_por_almacen
ON tomas_inventario_fisico(id_almacen)
WHERE estado = 'ABIERTO';

-- Indice para consultar el historial de tomas.
CREATE INDEX IF NOT EXISTS
    idx_tomas_estado_fecha
ON tomas_inventario_fisico(estado, fecha);
