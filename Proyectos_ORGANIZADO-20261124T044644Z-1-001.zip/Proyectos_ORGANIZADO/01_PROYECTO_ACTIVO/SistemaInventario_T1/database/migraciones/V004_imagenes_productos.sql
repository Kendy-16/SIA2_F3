CREATE TABLE IF NOT EXISTS imagenes_productos (
    id_imagen INTEGER PRIMARY KEY AUTOINCREMENT,
    id_producto INTEGER NOT NULL UNIQUE,
    pixabay_id INTEGER NOT NULL,
    ruta_local TEXT NOT NULL,
    fuente TEXT NOT NULL DEFAULT 'Pixabay',
    pagina_fuente TEXT NOT NULL,
    autor TEXT,
    fecha_guardado TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_imagenes_productos_producto
ON imagenes_productos(id_producto);

CREATE TABLE IF NOT EXISTS cache_busqueda_imagenes (
    termino TEXT PRIMARY KEY COLLATE NOCASE,
    respuesta_json TEXT NOT NULL,
    fecha_consulta INTEGER NOT NULL
);