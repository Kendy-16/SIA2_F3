CREATE TABLE categorias (
    id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,
    descripcion TEXT
);
CREATE TABLE sqlite_sequence(name,seq);
CREATE TABLE proveedores (
    id_proveedor INTEGER PRIMARY KEY AUTOINCREMENT,
    razon_social TEXT NOT NULL,
    ruc TEXT UNIQUE,
    telefono TEXT,
    correo TEXT,
    direccion TEXT
);
CREATE TABLE almacenes (
    id_almacen INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,
    ubicacion TEXT
);
CREATE TABLE productos (
    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    descripcion TEXT,
    id_categoria INTEGER,
    id_proveedor INTEGER,
    unidad_medida TEXT NOT NULL,
    stock_minimo REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (id_categoria)
        REFERENCES categorias(id_categoria),
    FOREIGN KEY (id_proveedor)
        REFERENCES proveedores(id_proveedor)
);
CREATE TABLE inventario (
    id_inventario INTEGER PRIMARY KEY AUTOINCREMENT,
    id_producto INTEGER NOT NULL,
    id_almacen INTEGER NOT NULL,
    cantidad REAL NOT NULL DEFAULT 0,
    costo_promedio REAL NOT NULL DEFAULT 0,
    UNIQUE(id_producto, id_almacen),
    FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto),
    FOREIGN KEY (id_almacen)
        REFERENCES almacenes(id_almacen)
);
CREATE TABLE movimientos (
    id_movimiento INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT NOT NULL CHECK (
        tipo IN ('ENTRADA', 'SALIDA', 'AJUSTE')
    ),
    fecha TEXT NOT NULL,
    documento TEXT,
    observacion TEXT,
    id_almacen INTEGER NOT NULL,
    FOREIGN KEY (id_almacen)
        REFERENCES almacenes(id_almacen)
);
CREATE TABLE detalle_movimientos (
    id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
    id_movimiento INTEGER NOT NULL,
    id_producto INTEGER NOT NULL,
    cantidad REAL NOT NULL CHECK(cantidad > 0),
    costo_unitario REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (id_movimiento)
        REFERENCES movimientos(id_movimiento),
    FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto)
);
CREATE TABLE kardex (
    id_kardex INTEGER PRIMARY KEY AUTOINCREMENT,
    id_producto INTEGER NOT NULL,
    id_almacen INTEGER NOT NULL,
    fecha TEXT NOT NULL,
    tipo TEXT NOT NULL,
    documento TEXT,
    entrada REAL NOT NULL DEFAULT 0,
    salida REAL NOT NULL DEFAULT 0,
    saldo REAL NOT NULL,
    costo_unitario REAL NOT NULL,
    costo_promedio REAL NOT NULL,
    valor_saldo REAL NOT NULL,
    FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto),
    FOREIGN KEY (id_almacen)
        REFERENCES almacenes(id_almacen)
);
CREATE UNIQUE INDEX idx_productos_codigo_nocase
ON productos(codigo COLLATE NOCASE)
;
CREATE INDEX idx_productos_nombre
ON productos(nombre COLLATE NOCASE)
;
CREATE INDEX idx_inventario_producto
ON inventario(id_producto)
;
CREATE INDEX idx_detalles_producto
ON detalle_movimientos(id_producto)
;
CREATE INDEX idx_kardex_producto_fecha
ON kardex(id_producto, fecha)
;
CREATE TABLE usuarios (

    id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,

    usuario TEXT NOT NULL COLLATE NOCASE UNIQUE
        CHECK (
            length(trim(usuario)) BETWEEN 3 AND 50
        ),

    password_hash TEXT NOT NULL
        CHECK (length(trim(password_hash)) > 0),

    password_salt TEXT NOT NULL
        CHECK (length(trim(password_salt)) > 0),

    activo INTEGER NOT NULL DEFAULT 1
        CHECK (activo IN (0, 1)),

    intentos_fallidos INTEGER NOT NULL DEFAULT 0
        CHECK (
            intentos_fallidos BETWEEN 0 AND 5
        ),

    bloqueado_hasta INTEGER
        CHECK (
            bloqueado_hasta IS NULL
            OR bloqueado_hasta >= 0
        ),

    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    ultimo_acceso TEXT
);
CREATE INDEX idx_movimientos_almacen_fecha
ON movimientos(id_almacen, fecha)
;
