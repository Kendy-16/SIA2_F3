-- Datos de prueba FICTICIOS (Ley N.º 29733: sin datos personales reales).
-- Solo catálogos; los movimientos se registran desde la aplicación
-- para que se generen el kardex y el costo promedio.
-- Uso:  sqlite3 database/inventario.db < database/datos_prueba.sql
INSERT OR IGNORE INTO categorias (nombre, descripcion) VALUES
  ('Construcción', 'Materiales de construcción'),
  ('Ferretería',   'Herramientas y accesorios');

INSERT OR IGNORE INTO proveedores (razon_social, ruc, telefono, correo, direccion) VALUES
  ('Distribuidora Andina S.A.C.', '20000000001', '054-000001', 'ventas@andina.example', 'Arequipa'),
  ('Comercial Misti E.I.R.L.',    '20000000002', '054-000002', 'ventas@misti.example',  'Arequipa');

INSERT OR IGNORE INTO almacenes (nombre, ubicacion) VALUES
  ('Principal', 'Arequipa - Sede central'),
  ('Secundario', 'Arequipa - Sucursal');

INSERT OR IGNORE INTO productos
  (codigo, nombre, descripcion, id_categoria, id_proveedor, unidad_medida, stock_minimo)
VALUES
  ('CEM-001', 'Cemento 42.5 kg', 'Bolsa de cemento',
     (SELECT id_categoria FROM categorias WHERE nombre='Construcción'),
     (SELECT id_proveedor FROM proveedores WHERE ruc='20000000001'), 'UNIDAD', 20),
  ('LAD-001', 'Ladrillo King Kong', 'Millar de ladrillos',
     (SELECT id_categoria FROM categorias WHERE nombre='Construcción'),
     (SELECT id_proveedor FROM proveedores WHERE ruc='20000000002'), 'UNIDAD', 100),
  ('MAR-001', 'Martillo 16 oz', 'Martillo de carpintero',
     (SELECT id_categoria FROM categorias WHERE nombre='Ferretería'),
     (SELECT id_proveedor FROM proveedores WHERE ruc='20000000002'), 'UNIDAD', 5);