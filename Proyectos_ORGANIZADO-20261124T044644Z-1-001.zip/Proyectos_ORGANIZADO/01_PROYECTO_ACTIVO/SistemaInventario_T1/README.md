

## Actualización integrada: migraciones e imágenes Pixabay

Esta versión incorpora:

- `AdministradorMigraciones`: aplica V001, V002, V003 y V004 en orden.
- Registro de versiones en `schema_migrations`.
- Ejecución transaccional: si una migración falla, se revierte la transacción.
- V002 comprueba si ya existe la columna `activo` antes de agregarla.
- V003 comprueba que no haya más de una toma `ABIERTO` por almacén antes de crear el índice único.
- V004 crea las tablas `imagenes_productos` y `cache_busqueda_imagenes`.
- `Main` ejecuta las migraciones después de inicializar el esquema base.
- `ProductoView` incorpora el botón **Buscar imagen**, habilitado al seleccionar un producto.
- La descarga de imágenes limita la lectura a 15 MB y restringe las URL a HTTPS de dominios Pixabay.

### Cómo iniciar en Windows

1. Abra CMD en la carpeta del proyecto.
2. Ejecute `EJECUTAR_SISTEMA.cmd`.
3. La primera ejecución guarda una copia de la base de datos en `database\respaldos\inventario_antes_migraciones.db` antes de compilar e iniciar.
4. Las migraciones se ejecutan automáticamente al arrancar. No ejecute manualmente V002 o V003 por separado.

También puede ejecutar manualmente:

```cmd
mvn clean compile
mvn exec:java
```

### Configuración de Pixabay

El programa lee la clave desde la variable de entorno `PIXABAY_API_KEY`. No se almacena la clave en el código fuente ni en el ZIP. Si ya configuró la variable en Windows, cierre y vuelva a abrir CMD para que la sesión la reciba. Si todavía no está configurada, abra CMD y ejecute:

```cmd
setx PIXABAY_API_KEY "PEGUE_AQUI_SU_NUEVA_CLAVE"
```

Después cierre CMD, abra una ventana nueva y ejecute el iniciador. No comparta la clave ni la escriba dentro de los archivos Java.

### Uso de la búsqueda de imágenes

1. Inicie sesión en el sistema.
2. Abra el módulo Productos.
3. Seleccione una fila de producto en la tabla.
4. Pulse **Buscar imagen**.
5. Busque el producto, seleccione un resultado y guárdelo.

Las imágenes descargadas se almacenan en `data\imagenes-productos`. La caché de resultados tiene una vigencia de 24 horas.

### Alcance de las pruebas realizadas al paquete

Se verificó la integridad SQLite del archivo incluido y se confirmó que las tablas base no contienen registros en esta copia. Se probaron las sentencias equivalentes de las cuatro migraciones sobre una copia temporal de la base, con resultado de integridad `ok`. Las clases `Main`, `AdministradorMigraciones`, `MigracionV004ImagenesProductos` y `ProductoView` compilaron mediante `javac` usando las clases compiladas previas del proyecto. No se pudo ejecutar `mvn clean compile` en el entorno de preparación porque Maven no está instalado allí; debe ejecutarse con Maven 3.10 y Java 21 en Windows.
