# Módulo visual de Inventario Físico — Java Swing

Proyecto de demostración en Java 21. Esta entrega separa en archivos propios las clases internas y los paneles que ya existían dentro del `InventarioFisicoFrame` original. El objetivo fue reorganizar el código sin agregar ventanas ficticias ni lógica de negocio nueva.

## Estructura visual resultante

```text
vista/inventariofisico/
├── InventarioFisicoView.java
├── InventarioFisicoFrame.java
├── dialog/
│   ├── NuevaTomaInventarioDialog.java
│   ├── SeleccionProductosDialog.java
│   ├── RegistroConteoView.java
│   ├── DetalleDiferenciasDialog.java
│   ├── AjusteInventarioDialog.java
│   └── DetalleTomaInventarioDialog.java
├── componentes/
│   ├── ConciliacionInventarioView.java
│   ├── HistorialInventarioFisicoView.java
│   ├── ReporteInventarioFisicoView.java
│   └── PanelResumenInventario.java
├── renderer/
│   └── EstadoTomaRenderer.java
└── util/
    └── InventarioFisicoUI.java
```

Los DTO de la interfaz permanecen en `pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels`; el controlador permanece en `pe.edu.inventario.controlador.InventarioFisicoController`.

## Correspondencia y respaldo

Consulta `docs/REFactor-mapping.md` para ver de qué clase o método original salió cada archivo. `docs/original/InventarioFisicoFrame-original-712-lineas.java.txt` conserva una copia exacta del Frame original para auditoría y reversión manual.

## Lo que no se ha creado

No se han creado `DetalleConteoDialog`, `RevisionDiferenciasDialog`, `VistaPreviaReporteDialog` ni `ExportadorVistaInventario`, porque no existía código que respaldara esas piezas. El segundo conteo sigue siendo el checkbox que ya estaba en el diálogo de registro. No se ha inventado un paquete de modelos de tabla: el código original utiliza `DefaultTableModel` internos.

## Compilación

Requiere JDK 21. Para compilar sin depender de Maven ni de Internet, desde la raíz ejecuta en CMD:

```cmd
if not exist target\classes mkdir target\classes
dir /s /b src\main\java\*.java > sources.txt
javac --release 21 -encoding UTF-8 -d target\classes @sources.txt
```

Para empaquetar con Maven en un entorno que tenga los plugins correspondientes disponibles:

```cmd
mvn clean package
mvn exec:java
```

La clase de entrada de demostración es `pe.edu.inventario.demo.InventarioFisicoDemo`.

## Límites de integración

`DemoInventarioFisicoController` trabaja con datos en memoria. Esta entrega no se conecta a SQLite y no modifica existencias, Kardex ni costo promedio. Antes de integrarla en el proyecto productivo, conecta el contrato del controlador con los servicios/DAO reales y coteja los DTO con los modelos existentes; no dupliques servicios ni inventes nombres de tablas.
