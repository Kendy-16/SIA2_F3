# Refactor de la vista de Inventario Físico: mapa de extracción

## Criterio aplicado

Se extrajeron las implementaciones que existían en el `InventarioFisicoFrame.java` original de 712 líneas. Se conservaron las operaciones y las llamadas al `InventarioFisicoController`; no se implementaron capacidades ausentes.

## Correspondencia antes/después

| Código original | Ubicación nueva | Observación |
|---|---|---|
| `InventarioFisicoFrame` | `vista/inventariofisico/InventarioFisicoFrame.java` | Mantiene la ventana raíz y la pestaña Resumen. Se redujo de 712 a 309 líneas en esta versión. |
| `NuevaTomaDialog` | `vista/inventariofisico/dialog/NuevaTomaInventarioDialog.java` | Misma implementación extraída; constructor público. |
| `SeleccionProductosDialog` | `vista/inventariofisico/dialog/SeleccionProductosDialog.java` | Misma implementación extraída; constructor público. |
| `RegistroConteoDialog` | `vista/inventariofisico/dialog/RegistroConteoView.java` | Misma implementación extraída. El segundo conteo sigue siendo el checkbox que ya existía. |
| `DetalleDiferenciasDialog` | `vista/inventariofisico/dialog/DetalleDiferenciasDialog.java` | Misma implementación extraída. |
| `AjusteInventarioDialog` | `vista/inventariofisico/dialog/AjusteInventarioDialog.java` | Solicitar, aprobar y rechazar permanecen reunidos en la misma ventana existente. |
| `DetalleTomaDialog` | `vista/inventariofisico/dialog/DetalleTomaInventarioDialog.java` | Conserva pestañas General, Productos y conteos, Diferencias y Auditoría. |
| `ReportPanel` | `vista/inventariofisico/componentes/ReporteInventarioFisicoView.java` | Panel de reportes extraído. |
| `ChartPanel` | `vista/inventariofisico/componentes/PanelResumenInventario.java` | Gráfico existente extraído. |
| `buildReconciliationPanel` y sus campos/acciones | `vista/inventariofisico/componentes/ConciliacionInventarioView.java` | Se separó el panel que antes estaba como pestaña y sus acciones. |
| `buildHistoryPanel` y sus campos/acciones | `vista/inventariofisico/componentes/HistorialInventarioFisicoView.java` | Se separó el panel que antes estaba como pestaña y sus acciones. |
| `ZebraRenderer` | `vista/inventariofisico/renderer/EstadoTomaRenderer.java` | Mismo renderizador zebra y de estados, extraído. |
| Helpers estáticos de presentación | `vista/inventariofisico/util/InventarioFisicoUI.java` | Colores, formatos, botones, mensajes, pares de etiquetas, tabla y ejecución SwingWorker compartida. |
| `InventarioFisicoView` | `vista/inventariofisico/InventarioFisicoView.java` | Se mantiene como envoltorio de integración de 10 líneas. |

## Elementos que NO se inventaron

No se crearon `DetalleConteoDialog`, `RevisionDiferenciasDialog`, `VistaPreviaReporteDialog` ni `ExportadorVistaInventario`, porque no tenían implementación en el Frame original. Tampoco se creó un `SegundoConteoDialog`: el segundo conteo era un checkbox dentro de `RegistroConteoDialog`.

No se creó `vista/inventariofisico/modelo/` para modelos de tabla porque el código original no tenía clases `AbstractTableModel` separadas: utilizaba `DefaultTableModel` declarado dentro de los componentes. Los DTO actuales continúan en `pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels`.

## Respaldo

`docs/original/InventarioFisicoFrame-original-712-lineas.java.txt` contiene el archivo original sin refactor para comparar o revertir manualmente.

## Límites

Esta extracción no modifica `InventarioFisicoController`, `InventarioFisicoModels`, la demostración ni el esquema SQLite. La demo sigue usando datos en memoria; no se conecta al inventario productivo ni modifica stock, costo promedio o Kardex.
