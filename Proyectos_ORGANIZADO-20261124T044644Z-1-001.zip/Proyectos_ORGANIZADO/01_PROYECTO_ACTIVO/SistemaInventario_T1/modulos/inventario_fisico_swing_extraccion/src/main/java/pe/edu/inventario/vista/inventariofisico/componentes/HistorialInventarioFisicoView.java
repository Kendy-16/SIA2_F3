package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import pe.edu.inventario.vista.inventariofisico.renderer.EstadoTomaRenderer;
import pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.function.LongConsumer;

/** Panel de historial extraído del método buildHistoryPanel del Frame. */
public final class HistorialInventarioFisicoView extends JPanel {
    private final InventarioFisicoController controller;
    private final JLabel statusBar;
    private final LongConsumer onOpenDetail;
    private final DefaultTableModel historyModel = model(
            "ID", "Código", "Almacén", "Inicio", "Responsable", "Productos", "Diferencias", "Estado");
    private final JTable historyTable = table(historyModel);
    private final JTextField filter = new JTextField(22);

    public HistorialInventarioFisicoView(InventarioFisicoController controller,
                                         JLabel statusBar,
                                         LongConsumer onOpenDetail) {
        super(new BorderLayout(10, 10));
        this.controller = controller;
        this.statusBar = statusBar;
        this.onOpenDetail = onOpenDetail;
        buildView();
        configureTable();
        loadHistory("");
    }

    private void buildView() {
        setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        JButton refresh = secondaryButton("Buscar / actualizar");
        JButton details = primaryButton("Ver toma seleccionada");
        top.add(new JLabel("Código, almacén o responsable:"));
        top.add(filter);
        top.add(refresh);
        top.add(details);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(historyTable), BorderLayout.CENTER);
        refresh.addActionListener(e -> loadHistory(filter.getText()));
        filter.addActionListener(e -> loadHistory(filter.getText()));
        details.addActionListener(e -> openDetails(historySelectedId()));
        historyTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) openDetails(historySelectedId());
            }
        });
    }

    private void configureTable() {
        historyTable.setRowHeight(29);
        historyTable.setFillsViewportHeight(true);
        historyTable.setShowVerticalLines(false);
        historyTable.setGridColor(new Color(235, 238, 243));
        historyTable.setSelectionBackground(new Color(222, 235, 252));
        historyTable.setSelectionForeground(TEXT);
        historyTable.getTableHeader().setReorderingAllowed(false);
        historyTable.getTableHeader().setBackground(new Color(240, 244, 249));
        historyTable.getTableHeader().setForeground(TEXT);
        historyTable.getTableHeader().setFont(historyTable.getTableHeader().getFont().deriveFont(Font.BOLD, 11f));
        historyTable.setFont(historyTable.getFont().deriveFont(12f));
        historyTable.getColumnModel().getColumn(0).setMinWidth(0);
        historyTable.getColumnModel().getColumn(0).setMaxWidth(0);
        historyTable.setDefaultRenderer(Object.class, new EstadoTomaRenderer());
    }

    public void refresh() { loadHistory(""); }

    private void loadHistory(String searchText) {
        InventarioFisicoUI.async(statusBar, "Cargando historial",
                () -> controller.listarTomas(searchText, null), items -> {
                    historyModel.setRowCount(0);
                    for (Toma t : items) {
                        historyModel.addRow(new Object[]{t.id(), t.codigo(), t.almacen(),
                                format(t.fechaInicio()), t.responsable(), t.totalProductos(),
                                t.productosDiferencia(), t.estado()});
                    }
                });
    }

    private long historySelectedId() {
        int row = historyTable.getSelectedRow();
        if (row < 0) return -1;
        return ((Number) historyModel.getValueAt(historyTable.convertRowIndexToModel(row), 0)).longValue();
    }

    private void openDetails(long id) {
        if (id != -1) onOpenDetail.accept(id);
    }
}
