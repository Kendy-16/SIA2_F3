package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class EstadoTomaRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
            Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
            if (!selected) c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 253));
            setBorder(new EmptyBorder(2, 7, 2, 7));
            if (value instanceof EstadoToma || value instanceof TipoDiferencia) {
                String s = value.toString();
                setForeground(s.contains("FALTANTE") || s.equals("CANCELADA") ? RED : s.contains("SOBRANTE") || s.equals("EN_REVISION") ? AMBER : s.contains("CONFORME") || s.equals("CERRADA") || s.equals("APROBADA") ? GREEN : TEXT);
                setFont(getFont().deriveFont(Font.BOLD));
            } else if (!selected) setForeground(TEXT);
            return c;
        }
    }
