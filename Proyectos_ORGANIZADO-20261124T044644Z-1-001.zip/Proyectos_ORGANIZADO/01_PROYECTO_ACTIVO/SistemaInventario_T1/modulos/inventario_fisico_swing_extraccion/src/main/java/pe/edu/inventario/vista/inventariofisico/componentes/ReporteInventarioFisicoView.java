package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.Resumen;
import pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public final class ReporteInventarioFisicoView extends JPanel {
        private final InventarioFisicoController controller;
        private final JLabel statusBar;
        private final JLabel totalTakes = new JLabel("—"), totalOpen = new JLabel("—"), totalDiff = new JLabel("—"), totalPending = new JLabel("—");
        public ReporteInventarioFisicoView(InventarioFisicoController controller, JLabel statusBar) {
            super(new BorderLayout(12, 12));
            this.controller = controller;
            this.statusBar = statusBar; setOpaque(false);
            JPanel cards = new JPanel(new GridLayout(1, 4, 10, 10)); cards.setOpaque(false);
            cards.add(reportMetric("Tomas", totalTakes)); cards.add(reportMetric("Abiertas", totalOpen)); cards.add(reportMetric("Productos con diferencia", totalDiff)); cards.add(reportMetric("Ajustes pendientes", totalPending));
            add(cards, BorderLayout.NORTH);
            PanelResumenInventario chart = new PanelResumenInventario(); add(chart, BorderLayout.CENTER);
            JButton refresh = secondaryButton("Actualizar indicadores"); JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); bottom.setOpaque(false); bottom.add(refresh); add(bottom, BorderLayout.SOUTH);
            refresh.addActionListener(e -> loadReport(chart)); loadReport(chart);
        }
        private JPanel reportMetric(String title, JLabel value) { JPanel p = new JPanel(new BorderLayout(4, 8)); p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(15, 15, 15, 15)); JLabel l = new JLabel(title); l.setForeground(MUTED); value.setFont(value.getFont().deriveFont(Font.BOLD, 25f)); value.setForeground(NAVY); p.add(l, BorderLayout.NORTH); p.add(value, BorderLayout.CENTER); return p; }
        private void loadReport(PanelResumenInventario chart) { InventarioFisicoUI.async(statusBar, "Actualizando reporte", controller::obtenerResumen, r -> { totalTakes.setText(String.valueOf(r.tomasRealizadas())); totalOpen.setText(String.valueOf(r.tomasAbiertas())); totalDiff.setText(String.valueOf(r.productosConDiferencias())); totalPending.setText(String.valueOf(r.ajustesPendientes())); chart.setData(r); }); }
    }
