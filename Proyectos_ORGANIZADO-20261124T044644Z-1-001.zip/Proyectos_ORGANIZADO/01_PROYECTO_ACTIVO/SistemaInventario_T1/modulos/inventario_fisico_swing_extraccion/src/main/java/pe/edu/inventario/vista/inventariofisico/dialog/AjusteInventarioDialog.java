package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;
import pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.ThrowingRunnable;

public final class AjusteInventarioDialog extends JDialog {
    public AjusteInventarioDialog(Frame owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable onChanged) {
            super(owner, "Solicitud y aprobación de ajuste", true); setSize(640, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
            JPanel info = new JPanel(new GridLayout(0, 2, 8, 7)); info.setBorder(new EmptyBorder(16, 18, 8, 18));
            addPair(info, "Producto", d.producto().codigo() + " · " + d.producto().nombre()); addPair(info, "Stock del sistema", fmt(d.stockSistema())); addPair(info, "Cantidad física", fmt(d.cantidadFisica())); addPair(info, "Diferencia", fmt(d.diferencia())); addPair(info, "Valor referencial", money(d.valorDiferencia())); addPair(info, "Estado del ajuste", d.estadoRevision());
            add(info, BorderLayout.NORTH);
            JPanel form = new JPanel(new GridBagLayout()); form.setBorder(new EmptyBorder(0, 18, 8, 18));
            JComboBox<String> reason = new JComboBox<>(new String[]{"Pérdida", "Deterioro", "Error de registro", "Error de recepción", "Error de despacho", "Producto mal ubicado", "Unidad de medida", "Sobrante no registrado", "Otro"});
            JTextArea note = new JTextArea(4, 34); note.setLineWrap(true); note.setWrapStyleWord(true);
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(5, 4, 5, 4); g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
            g.gridx = 0; g.gridy = 0; form.add(new JLabel("Motivo:"), g); g.gridx = 1; form.add(reason, g);
            g.gridx = 0; g.gridy = 1; form.add(new JLabel("Observaciones:"), g); g.gridx = 1; form.add(new JScrollPane(note), g); add(form, BorderLayout.CENTER);
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton request = secondaryButton("Solicitar ajuste"), approve = primaryButton("Aprobar"), reject = secondaryButton("Rechazar"), close = secondaryButton("Cerrar"); actions.add(request); actions.add(approve); actions.add(reject); actions.add(close); add(actions, BorderLayout.SOUTH);
            request.addActionListener(e -> run(() -> controller.solicitarAjuste(idToma, d.producto().id(), (String) reason.getSelectedItem(), note.getText()), "Solicitud de ajuste registrada.", onChanged));
            approve.addActionListener(e -> { if (!"PENDIENTE".equalsIgnoreCase(d.estadoRevision())) { warn("Primero debe existir una solicitud pendiente."); return; } int yes = JOptionPane.showConfirmDialog(this, "¿Aprobar el ajuste? La actualización real de inventario debe ejecutarse en el servicio transaccional.", "Aprobar ajuste", JOptionPane.YES_NO_OPTION); if (yes == JOptionPane.YES_OPTION) run(() -> controller.aprobarAjuste(idToma, d.producto().id()), "Ajuste aprobado.", onChanged); });
            reject.addActionListener(e -> run(() -> controller.rechazarAjuste(idToma, d.producto().id(), note.getText()), "Ajuste rechazado.", onChanged));
            close.addActionListener(e -> dispose());
        }
        private void run(ThrowingRunnable action, String message, Runnable changed) {
            new SwingWorker<Void, Void>() { @Override protected Void doInBackground() throws Exception { action.run(); return null; } @Override protected void done() { try { get(); info(message); changed.run(); dispose(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } } }.execute();
        }
    }
