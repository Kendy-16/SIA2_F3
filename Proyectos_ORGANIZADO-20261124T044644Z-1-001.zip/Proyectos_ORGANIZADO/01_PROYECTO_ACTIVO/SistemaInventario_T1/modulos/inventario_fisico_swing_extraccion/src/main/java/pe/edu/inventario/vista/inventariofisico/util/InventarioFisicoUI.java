package pe.edu.inventario.vista.inventariofisico.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/** Utilidades compartidas de presentación. No contiene persistencia ni reglas de negocio. */
public final class InventarioFisicoUI {
    private InventarioFisicoUI() { }

    public static final Color NAVY = new Color(25, 45, 75);
    public static final Color BLUE = new Color(43, 105, 190);
    public static final Color BG = new Color(245, 247, 251);
    public static final Color TEXT = new Color(45, 55, 72);
    public static final Color MUTED = new Color(110, 122, 140);
    public static final Color GREEN = new Color(29, 145, 95);
    public static final Color RED = new Color(195, 65, 65);
    public static final Color AMBER = new Color(190, 125, 25);
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    public static final NumberFormat MONEY = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-PE"));

    public static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
    }

    public static JTable table(DefaultTableModel model) { return new JTable(model); }

    public static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(BLUE);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 13, 8, 13));
        return b;
    }

    public static JButton secondaryButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(238, 243, 249));
        b.setForeground(TEXT);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 12, 8, 12));
        return b;
    }

    public static String format(LocalDateTime date) { return date == null ? "—" : DATE.format(date); }
    public static String fmt(java.math.BigDecimal value) { return value == null ? "—" : value.stripTrailingZeros().toPlainString(); }
    public static String money(java.math.BigDecimal value) { return value == null ? "—" : MONEY.format(value); }

    public static void warn(String message) {
        JOptionPane.showMessageDialog(null, message, "Validación", JOptionPane.WARNING_MESSAGE);
    }

    public static void info(String message) {
        JOptionPane.showMessageDialog(null, message, "Inventario físico", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Throwable throwable) {
        JOptionPane.showMessageDialog(null,
                throwable.getMessage() == null ? throwable.toString() : throwable.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void addPair(JPanel panel, String label, String value) {
        JLabel l = new JLabel(label + ":");
        l.setForeground(MUTED);
        JLabel v = new JLabel(value == null ? "—" : value);
        v.setForeground(TEXT);
        panel.add(l);
        panel.add(v);
    }

    /** Ejecuta una tarea fuera del EDT y entrega el resultado en done(), dentro del EDT. */
    public static <T> void async(JLabel statusBar, String message, Callable<T> task, Consumer<T> success) {
        statusBar.setText(message + "...");
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return task.call(); }
            @Override protected void done() {
                try {
                    T result = get();
                    success.accept(result);
                    statusBar.setText(message + " · completado");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    statusBar.setText("No se pudo completar la operación");
                    error(cause);
                }
            }
        }.execute();
    }

    @FunctionalInterface
    public interface ThrowingRunnable { void run() throws Exception; }
}
