package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import pe.edu.inventario.vista.inventariofisico.dialog.AjusteInventarioDialog;
import pe.edu.inventario.vista.inventariofisico.dialog.DetalleDiferenciasDialog;
import pe.edu.inventario.vista.inventariofisico.renderer.EstadoTomaRenderer;
import pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** Panel de conciliación extraído del método buildReconciliationPanel del Frame. */
public final class ConciliacionInventarioView extends JPanel {
    private final InventarioFisicoController controller;
    private final JLabel statusBar;
    private final Runnable onChanged;
    private final DefaultTableModel reconciliationModel = model(
            "Código", "Producto", "Sistema", "Físico", "Diferencia",
            "Costo prom.", "Valor diferencia", "Tipo", "Revisión");
    private final JTable reconciliationTable = table(reconciliationModel);
    private final JComboBox<Toma> reconciliationTake = new JComboBox<>();

    public ConciliacionInventarioView(InventarioFisicoController controller,
                                      JLabel statusBar,
                                      Runnable onChanged) {
        super(new BorderLayout(12, 12));
        this.controller = controller;
        this.statusBar = statusBar;
        this.onChanged = onChanged;
        buildView();
        configureTable();
    }

    private void buildView() {
        setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        top.add(new JLabel("Toma física:"));
        reconciliationTake.setPrototypeDisplayValue(new Toma(999, "IF-2026-0000",
                "Almacén muy largo", null, null, "Responsable", 0, 0, 0, EstadoToma.ABIERTA));
        top.add(reconciliationTake);
        JButton load = secondaryButton("Cargar diferencias");
        JButton run = primaryButton("Ejecutar conciliación");
        JButton detail = secondaryButton("Detalle de diferencia");
        JButton adjustment = secondaryButton("Gestionar ajuste");
        JButton close = secondaryButton("Cerrar toma");
        top.add(load); top.add(run); top.add(detail); top.add(adjustment); top.add(close);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(reconciliationTable), BorderLayout.CENTER);
        JLabel note = new JLabel("La conciliación compara el conteo con el saldo del sistema. La vista no actualiza existencias ni costos.");
        note.setForeground(MUTED);
        add(note, BorderLayout.SOUTH);
        load.addActionListener(e -> loadDifferences());
        run.addActionListener(e -> executeReconciliation());
        detail.addActionListener(e -> openDifferenceDetail());
        adjustment.addActionListener(e -> manageAdjustment());
        close.addActionListener(e -> closeTake());
        reconciliationTake.addActionListener(e -> loadDifferences());
    }

    private void configureTable() {
        reconciliationTable.setRowHeight(29);
        reconciliationTable.setFillsViewportHeight(true);
        reconciliationTable.setShowVerticalLines(false);
        reconciliationTable.setGridColor(new Color(235, 238, 243));
        reconciliationTable.setSelectionBackground(new Color(222, 235, 252));
        reconciliationTable.setSelectionForeground(TEXT);
        reconciliationTable.getTableHeader().setReorderingAllowed(false);
        reconciliationTable.getTableHeader().setBackground(new Color(240, 244, 249));
        reconciliationTable.getTableHeader().setForeground(TEXT);
        reconciliationTable.getTableHeader().setFont(reconciliationTable.getTableHeader().getFont().deriveFont(Font.BOLD, 11f));
        reconciliationTable.setFont(reconciliationTable.getFont().deriveFont(12f));
        reconciliationTable.setDefaultRenderer(Object.class, new EstadoTomaRenderer());
    }

    public void refreshTomas() { loadTakeOptions(); }

    public void seleccionarToma(long idToma) {
        for (int i = 0; i < reconciliationTake.getItemCount(); i++) {
            if (reconciliationTake.getItemAt(i).id() == idToma) {
                reconciliationTake.setSelectedIndex(i);
                loadDifferences();
                return;
            }
        }
        loadTakeOptions();
    }

    private void loadTakeOptions() {
        InventarioFisicoUI.async(statusBar, "Cargando tomas para conciliación",
                () -> controller.listarTomas("", null), items -> {
                    reconciliationTake.removeAllItems();
                    for (Toma t : items) reconciliationTake.addItem(t);
                    reconciliationTake.setRenderer(new DefaultListCellRenderer() {
                        @Override public Component getListCellRendererComponent(JList<?> list, Object value,
                                int index, boolean selected, boolean focus) {
                            super.getListCellRendererComponent(list, value, index, selected, focus);
                            if (value instanceof Toma t) setText(t.codigo() + " · " + t.almacen() + " · " + t.estado());
                            return this;
                        }
                    });
                });
    }

    private void loadDifferences() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) return;
        InventarioFisicoUI.async(statusBar, "Cargando diferencias",
                () -> controller.listarDiferencias(t.id()), this::showDifferences);
    }

    private void showDifferences(List<Diferencia> list) {
        reconciliationModel.setRowCount(0);
        for (Diferencia d : list) {
            reconciliationModel.addRow(new Object[]{d.producto().codigo(), d.producto().nombre(),
                    fmt(d.stockSistema()), fmt(d.cantidadFisica()), fmt(d.diferencia()),
                    money(d.costoPromedio()), money(d.valorDiferencia()), d.tipo(), d.estadoRevision()});
        }
        statusBar.setText("Registros de conciliación: " + list.size());
    }

    private void executeReconciliation() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) { warn("Selecciona una toma."); return; }
        int yes = JOptionPane.showConfirmDialog(this, "¿Ejecutar conciliación de " + t.codigo() + "?",
                "Confirmar conciliación", JOptionPane.YES_NO_OPTION);
        if (yes != JOptionPane.YES_OPTION) return;
        InventarioFisicoUI.async(statusBar, "Conciliando inventario",
                () -> controller.conciliar(t.id()), list -> {
                    showDifferences(list);
                    onChanged.run();
                    JOptionPane.showMessageDialog(this,
                            "Conciliación realizada. Revisa los productos con diferencias.",
                            "Conciliación", JOptionPane.INFORMATION_MESSAGE);
                });
    }

    private void openDifferenceDetail() {
        int row = reconciliationTable.getSelectedRow();
        if (row < 0) { warn("Selecciona un producto."); return; }
        String code = String.valueOf(reconciliationModel.getValueAt(reconciliationTable.convertRowIndexToModel(row), 0));
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) return;
        InventarioFisicoUI.async(statusBar, "Buscando diferencia",
                () -> controller.listarDiferencias(t.id()).stream()
                        .filter(d -> d.producto().codigo().equals(code)).findFirst().orElse(null),
                d -> {
                    if (d != null) new DetalleDiferenciasDialog(ownerFrame(), controller, t.id(), d, this::loadDifferences).setVisible(true);
                });
    }

    private void manageAdjustment() {
        int row = reconciliationTable.getSelectedRow();
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (row < 0 || t == null) { warn("Selecciona una diferencia."); return; }
        String code = String.valueOf(reconciliationModel.getValueAt(reconciliationTable.convertRowIndexToModel(row), 0));
        InventarioFisicoUI.async(statusBar, "Buscando producto",
                () -> controller.listarDiferencias(t.id()).stream()
                        .filter(d -> d.producto().codigo().equals(code)).findFirst().orElse(null),
                d -> {
                    if (d != null) new AjusteInventarioDialog(ownerFrame(), controller, t.id(), d,
                            () -> { loadDifferences(); onChanged.run(); }).setVisible(true);
                });
    }

    private void closeTake() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) { warn("Selecciona una toma."); return; }
        int yes = JOptionPane.showConfirmDialog(this,
                "Cerrar " + t.codigo() + "? Una toma cerrada queda en consulta.",
                "Cerrar toma", JOptionPane.YES_NO_OPTION);
        if (yes == JOptionPane.YES_OPTION) {
            InventarioFisicoUI.async(statusBar, "Cerrando toma", () -> {
                controller.cerrarToma(t.id());
                return true;
            }, ok -> {
                onChanged.run();
                loadDifferences();
                info("Toma cerrada correctamente.");
            });
        }
    }

    private Frame ownerFrame() {
        Window window = SwingUtilities.getWindowAncestor(this);
        return window instanceof Frame frame ? frame : null;
    }
}
