package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public final class SeleccionProductosDialog extends JDialog {
        private final InventarioFisicoController controller;
        private final String warehouse;
        private final String category;
        private final Set<Long> selected;
        private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Seleccionar", "Código", "Producto", "Categoría", "Unidad", "Stock", "ID"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c == 0; }
            @Override public Class<?> getColumnClass(int c) { return c == 0 ? Boolean.class : Object.class; }
        };
        private final JTable table = new JTable(model);
        private final JTextField search = new JTextField(18);
    public SeleccionProductosDialog(Dialog owner, InventarioFisicoController controller, String warehouse, String category, Set<Long> selected) {
            super(owner, "Seleccionar productos para la toma", true);
            this.controller = controller; this.warehouse = warehouse; this.category = category; this.selected = selected;
            setSize(780, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
            JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Buscar:")); top.add(search); JButton find = secondaryButton("Buscar"); top.add(find); add(top, BorderLayout.NORTH);
            model.setRowCount(0); table.setRowHeight(27); table.getColumnModel().getColumn(0).setMaxWidth(85); table.getColumnModel().getColumn(6).setMinWidth(0); table.getColumnModel().getColumn(6).setMaxWidth(0); table.getColumnModel().getColumn(6).setWidth(0);
            add(new JScrollPane(table), BorderLayout.CENTER);
            JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton cancel = secondaryButton("Cancelar"), accept = primaryButton("Aplicar selección"); bottom.add(cancel); bottom.add(accept); add(bottom, BorderLayout.SOUTH);
            find.addActionListener(e -> load()); search.addActionListener(e -> load());
            cancel.addActionListener(e -> dispose()); accept.addActionListener(e -> { updateSelection(); dispose(); });
            load();
        }
        private void load() {
            new SwingWorker<List<Producto>, Void>() {
                @Override protected List<Producto> doInBackground() throws Exception { return controller.listarProductosDisponibles(search.getText(), category, warehouse); }
                @Override protected void done() { try { model.setRowCount(0); for (Producto p : get()) model.addRow(new Object[]{selected.contains(p.id()), p.codigo(), p.nombre(), p.categoria(), p.unidad(), p.stockSistema(), p.id()}); } catch (Exception ex) { error(ex); } }
            }.execute();
        }
        private void updateSelection() {
            // Solo se actualizan los productos visibles; las selecciones de búsquedas anteriores se conservan.
            for (int i = 0; i < model.getRowCount(); i++) {
                try {
                    long id = ((Number) model.getValueAt(i, 6)).longValue();
                    if (Boolean.TRUE.equals(model.getValueAt(i, 0))) selected.add(id);
                    else selected.remove(id);
                } catch (Exception ignored) { }
            }
        }
    }
