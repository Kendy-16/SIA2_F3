package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public final class RegistroConteoView extends JDialog {
        private final InventarioFisicoController controller;
        private final long idToma;
        private final Runnable onChanged;
        private final DefaultTableModel model = model("ID", "Código", "Producto", "Unidad", "Ubicación", "Stock sistema", "Conteo 1", "Conteo 2", "Estado", "Observación");
        private final JTable table = table(model);
        private final JTextField quantity = new JTextField(10);
        private final JTextField observation = new JTextField(28);
        private final JCheckBox second = new JCheckBox("Registrar segundo conteo");
        private boolean secondAllowed = true;
        private boolean blindMode = true;
        private final JLabel countTitle = new JLabel();
        private final JProgressBar progress = new JProgressBar(0, 100);
        private final JLabel selectedProduct = new JLabel("Selecciona un producto de la tabla");
    public RegistroConteoView(Frame owner, InventarioFisicoController controller, long idToma, Runnable onChanged) {
            super(owner, "Registro de conteo físico", true);
            this.controller = controller; this.idToma = idToma; this.onChanged = onChanged;
            setSize(1120, 650); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
            JPanel north = new JPanel(new BorderLayout()); north.setBorder(new EmptyBorder(12, 14, 0, 14));
            countTitle.setText("REGISTRO DE CONTEO · Toma ID " + idToma); countTitle.setFont(countTitle.getFont().deriveFont(Font.BOLD, 17f)); north.add(countTitle, BorderLayout.NORTH); north.add(progress, BorderLayout.SOUTH); add(north, BorderLayout.NORTH);
            table.setRowHeight(27); table.getColumnModel().getColumn(0).setMaxWidth(0); table.getColumnModel().getColumn(0).setMinWidth(0);
            add(new JScrollPane(table), BorderLayout.CENTER);
            JPanel editor = new JPanel(new GridBagLayout()); editor.setBorder(new EmptyBorder(8, 14, 8, 14));
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(4, 5, 4, 5); g.anchor = GridBagConstraints.WEST;
            g.gridx = 0; g.gridy = 0; editor.add(selectedProduct, g); g.gridx = 1; editor.add(new JLabel("Cantidad física:"), g); g.gridx = 2; editor.add(quantity, g); g.gridx = 3; editor.add(second, g);
            g.gridx = 0; g.gridy = 1; editor.add(new JLabel("Observación:"), g); g.gridx = 1; g.gridwidth = 3; editor.add(observation, g); g.gridwidth = 1;
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton save = primaryButton("Guardar conteo"), reload = secondaryButton("Actualizar"), reconcile = secondaryButton("Ir a conciliación"), close = secondaryButton("Cerrar"); buttons.add(save); buttons.add(reload); buttons.add(reconcile); buttons.add(close);
            JPanel south = new JPanel(new BorderLayout()); south.add(editor, BorderLayout.CENTER); south.add(buttons, BorderLayout.SOUTH); add(south, BorderLayout.SOUTH);
            table.getSelectionModel().addListSelectionListener(e -> showSelected());
            save.addActionListener(e -> saveCount()); reload.addActionListener(e -> load()); close.addActionListener(e -> dispose());
            reconcile.addActionListener(e -> { onChanged.run(); dispose(); JOptionPane.showMessageDialog(owner, "Selecciona la toma en la pestaña Conciliación para comparar los resultados."); });
            second.setEnabled(true); load();
        }
        private void load() {
            new SwingWorker<List<Producto>, Void>() {
                @Override protected List<Producto> doInBackground() throws Exception { secondAllowed = controller.permiteSegundoConteo(idToma); blindMode = controller.esConteoCiego(idToma); return controller.listarProductosToma(idToma, blindMode); }
                @Override protected void done() { try { List<Producto> ps = get(); second.setEnabled(secondAllowed); countTitle.setText((blindMode ? "REGISTRO DE CONTEO CIEGO" : "REGISTRO DE CONTEO") + " · Toma ID " + idToma); model.setRowCount(0); int counted = 0; for (Producto p : ps) { if (p.cantidadFinal() != null) counted++; model.addRow(new Object[]{p.id(), p.codigo(), p.nombre(), p.unidad(), p.ubicacion(), blindMode ? "OCULTO" : fmt(p.stockSistema()), fmt(p.cantidadContada()), fmt(p.segundoConteo()), p.estado(), p.observacion()}); } progress.setMaximum(Math.max(1, ps.size())); progress.setValue(counted); progress.setStringPainted(true); progress.setString(counted + " / " + ps.size() + " productos contados"); } catch (Exception ex) { error(ex); } }
            }.execute();
        }
        private void showSelected() { int r = table.getSelectedRow(); if (r < 0) return; selectedProduct.setText(model.getValueAt(r, 1) + " · " + model.getValueAt(r, 2)); quantity.setText(second.isSelected() ? String.valueOf(model.getValueAt(r, 7)).replace("—", "") : String.valueOf(model.getValueAt(r, 6)).replace("—", "")); observation.setText(String.valueOf(model.getValueAt(r, 9))); }
        private void saveCount() {
            int r = table.getSelectedRow(); if (r < 0) { warn("Selecciona un producto."); return; }
            BigDecimal qty;
            try { qty = new BigDecimal(quantity.getText().trim().replace(',', '.')); } catch (Exception ex) { warn("Ingresa una cantidad válida."); return; }
            if (qty.signum() < 0 || qty.scale() > 3) { warn("La cantidad debe ser cero o mayor y no superar 3 decimales."); return; }
            String unidad = String.valueOf(model.getValueAt(table.convertRowIndexToModel(r), 3)).toUpperCase(Locale.ROOT);
            if (Set.of("UNIDAD", "CAJA", "PAQUETE").contains(unidad) && qty.stripTrailingZeros().scale() > 0) { warn("La unidad " + unidad + " solo admite cantidades enteras."); return; }
            if (second.isSelected() && !secondAllowed) { warn("El segundo conteo no está habilitado para esta toma."); return; }
            long id = ((Number) model.getValueAt(table.convertRowIndexToModel(r), 0)).longValue();
            boolean isSecond = second.isSelected();
            new SwingWorker<Void, Void>() {
                @Override protected Void doInBackground() throws Exception { controller.registrarConteo(idToma, id, qty, observation.getText(), isSecond); return null; }
                @Override protected void done() { try { get(); load(); onChanged.run(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }
    }
