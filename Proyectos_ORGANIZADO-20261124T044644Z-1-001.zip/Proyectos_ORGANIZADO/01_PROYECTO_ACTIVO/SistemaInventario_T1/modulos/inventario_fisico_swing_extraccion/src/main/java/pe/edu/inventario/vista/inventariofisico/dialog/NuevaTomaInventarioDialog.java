package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;
import pe.edu.inventario.vista.inventariofisico.dialog.SeleccionProductosDialog;

public final class NuevaTomaInventarioDialog extends JDialog {
        private final InventarioFisicoController controller;
        private final Consumer<Toma> onCreated;
        private final JComboBox<String> warehouse = new JComboBox<>();
        private final JComboBox<String> scope = new JComboBox<>(new String[]{"Todos los productos", "Productos seleccionados"});
        private final JComboBox<String> category = new JComboBox<>();
        private final JCheckBox zero = new JCheckBox("Incluir productos con stock cero", true);
        private final JCheckBox blind = new JCheckBox("Conteo ciego (ocultar stock del sistema)", true);
        private final JCheckBox second = new JCheckBox("Permitir segundo conteo", true);
        private final JCheckBox partial = new JCheckBox("Permitir conteo parcial", false);
        private final JTextArea notes = new JTextArea(3, 30);
        private final Set<Long> selectedProducts = new LinkedHashSet<>();
        private final JLabel selectionLabel = new JLabel("No se han seleccionado productos");
    public NuevaTomaInventarioDialog(Frame owner, InventarioFisicoController controller, Consumer<Toma> onCreated) {
            super(owner, "Nueva toma de inventario físico", true);
            this.controller = controller; this.onCreated = onCreated;
            setSize(650, 620); setLocationRelativeTo(owner); setLayout(new BorderLayout(12, 12));
            JPanel form = new JPanel(new GridBagLayout()); form.setBorder(new EmptyBorder(18, 22, 10, 22)); form.setBackground(Color.WHITE);
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(6, 5, 6, 5); g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
            addField(form, g, 0, "Almacén", warehouse);
            addField(form, g, 1, "Alcance", scope);
            addField(form, g, 2, "Categoría (referencia de filtro)", category);
            JPanel selectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); selectPanel.setOpaque(false);
            JButton select = secondaryButton("Seleccionar productos..."); selectPanel.add(select); selectPanel.add(selectionLabel);
            addField(form, g, 3, "Selección", selectPanel);
            JPanel options = new JPanel(new GridLayout(0, 1, 3, 3)); options.setOpaque(false);
            options.add(zero); options.add(blind); options.add(second); options.add(partial);
            addField(form, g, 4, "Configuración", options);
            notes.setLineWrap(true); notes.setWrapStyleWord(true);
            JScrollPane noteScroll = new JScrollPane(notes);
            addField(form, g, 5, "Observaciones", noteScroll);
            add(form, BorderLayout.CENTER);
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT)); buttons.setBorder(new EmptyBorder(0, 12, 12, 12));
            JButton cancel = secondaryButton("Cancelar"), create = primaryButton("Crear toma"); buttons.add(cancel); buttons.add(create); add(buttons, BorderLayout.SOUTH);
            scope.addActionListener(e -> select.setEnabled(scope.getSelectedIndex() == 1));
            select.setEnabled(false);
            select.addActionListener(e -> new SeleccionProductosDialog(this, controller, warehouse.getSelectedItem() == null ? "" : warehouse.getSelectedItem().toString(), (String) category.getSelectedItem(), selectedProducts).setVisible(true));
            cancel.addActionListener(e -> dispose());
            create.addActionListener(e -> createTake());
            loadOptions();
        }

        private void loadOptions() {
            warehouse.addItem("Cargando...");
            new SwingWorker<List<List<String>>, Void>() {
                @Override protected List<List<String>> doInBackground() throws Exception { return List.of(controller.listarAlmacenes(), controller.listarCategorias()); }
                @Override protected void done() { try { List<List<String>> r = get(); warehouse.removeAllItems(); r.get(0).forEach(warehouse::addItem); category.removeAllItems(); r.get(1).forEach(category::addItem); } catch (Exception ex) { error(ex); } }
            }.execute();
        }

        private void createTake() {
            String almacen = (String) warehouse.getSelectedItem();
            String alcance = (String) scope.getSelectedItem();
            if (almacen == null || almacen.isBlank() || almacen.equals("Cargando...")) { warn("Selecciona un almacén."); return; }
            if (alcance.equals("Productos seleccionados") && selectedProducts.isEmpty()) { warn("Selecciona al menos un producto."); return; }
            NuevaToma command = new NuevaToma(almacen, alcance, (String) category.getSelectedItem(), zero.isSelected(), blind.isSelected(), second.isSelected(), partial.isSelected(), notes.getText(), new ArrayList<>(selectedProducts));
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            new SwingWorker<Toma, Void>() {
                @Override protected Toma doInBackground() throws Exception { return controller.crearToma(command); }
                @Override protected void done() { setCursor(Cursor.getDefaultCursor()); try { Toma t = get(); dispose(); onCreated.accept(t); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }

        private static void addField(JPanel p, GridBagConstraints g, int row, String label, Component component) {
            g.gridx = 0; g.gridy = row; g.weightx = 0; p.add(new JLabel(label + ":"), g);
            g.gridx = 1; g.weightx = 1; p.add(component, g);
        }
    }
