package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public final class DetalleTomaInventarioDialog extends JDialog {
    public DetalleTomaInventarioDialog(Frame owner, InventarioFisicoController controller, long idToma) {
            super(owner, "Detalle de toma física · " + idToma, true); setSize(930, 650); setLocationRelativeTo(owner); setLayout(new BorderLayout());
            JTabbedPane panes = new JTabbedPane();
            JPanel productPanel = new JPanel(new BorderLayout()); DefaultTableModel pm = model("Código", "Producto", "Ubicación", "Unidad", "Stock sistema", "Conteo 1", "Conteo 2", "Estado", "Observación"); JTable pt = table(pm); productPanel.add(new JScrollPane(pt), BorderLayout.CENTER);
            JPanel diffPanel = new JPanel(new BorderLayout()); DefaultTableModel dm = model("Código", "Producto", "Sistema", "Físico", "Diferencia", "Valor", "Tipo", "Ajuste"); JTable dt = table(dm); diffPanel.add(new JScrollPane(dt), BorderLayout.CENTER);
            JTextArea audit = new JTextArea(); audit.setEditable(false); audit.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            JPanel general = new JPanel(new GridLayout(0, 2, 10, 10)); general.setBorder(new EmptyBorder(20, 20, 20, 20));
            JLabel code = new JLabel("Código: cargando..."); JLabel warehouse = new JLabel("Almacén: —"); JLabel responsible = new JLabel("Responsable: —"); JLabel start = new JLabel("Inicio: —"); JLabel status = new JLabel("Estado: —"); JLabel progress = new JLabel("Avance: —");
            general.add(code); general.add(warehouse); general.add(responsible); general.add(start); general.add(status); general.add(progress);
            panes.addTab("General", general); panes.addTab("Productos y conteos", productPanel); panes.addTab("Diferencias", diffPanel); panes.addTab("Auditoría", new JScrollPane(audit)); add(panes, BorderLayout.CENTER);
            JButton close = secondaryButton("Cerrar"); JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); bottom.add(close); add(bottom, BorderLayout.SOUTH); close.addActionListener(e -> dispose());
            new SwingWorker<Object[], Void>() {
                @Override protected Object[] doInBackground() throws Exception { Toma t = controller.listarTomas("", null).stream().filter(x -> x.id() == idToma).findFirst().orElse(null); return new Object[]{t, controller.listarProductosToma(idToma, false), controller.listarDiferencias(idToma), controller.listarAuditoria(idToma)}; }
                @SuppressWarnings("unchecked") @Override protected void done() { try { Object[] r = get(); Toma toma = (Toma) r[0]; if (toma != null) { code.setText("Código: " + toma.codigo()); warehouse.setText("Almacén: " + toma.almacen()); responsible.setText("Responsable: " + toma.responsable()); start.setText("Inicio: " + format(toma.fechaInicio())); status.setText("Estado: " + toma.estado()); progress.setText("Avance: " + toma.avancePorcentaje() + "%"); } for (Producto p : (List<Producto>) r[1]) pm.addRow(new Object[]{p.codigo(), p.nombre(), p.ubicacion(), p.unidad(), "OCULTO", fmt(p.cantidadContada()), fmt(p.segundoConteo()), p.estado(), p.observacion()}); for (Diferencia d : (List<Diferencia>) r[2]) dm.addRow(new Object[]{d.producto().codigo(), d.producto().nombre(), fmt(d.stockSistema()), fmt(d.cantidadFisica()), fmt(d.diferencia()), money(d.valorDiferencia()), d.tipo(), d.estadoRevision()}); audit.setText(String.join("\n", (List<String>) r[3])); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }
    }
