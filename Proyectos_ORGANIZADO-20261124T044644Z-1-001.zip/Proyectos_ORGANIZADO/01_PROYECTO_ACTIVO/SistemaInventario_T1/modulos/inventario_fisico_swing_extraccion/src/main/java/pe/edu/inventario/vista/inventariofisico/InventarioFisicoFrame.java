package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.componentes.ReporteInventarioFisicoView;
import pe.edu.inventario.vista.inventariofisico.componentes.ConciliacionInventarioView;
import pe.edu.inventario.vista.inventariofisico.componentes.HistorialInventarioFisicoView;
import pe.edu.inventario.vista.inventariofisico.renderer.EstadoTomaRenderer;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * Interfaz Swing completa del módulo de inventario físico.
 * No contiene SQL ni modifica directamente existencias o costos.
 */
public class InventarioFisicoFrame extends JFrame {

    private final InventarioFisicoController controller;
    private final JTabbedPane tabs = new JTabbedPane();
    private final DefaultTableModel dashboardModel = model("ID", "Código", "Almacén", "Inicio", "Responsable", "Productos", "Contados", "Diferencias", "Avance", "Estado");
    private final JTable dashboardTable = table(dashboardModel);
    private final JTextField searchDashboard = new JTextField(18);
    private final JComboBox<String> stateDashboard = new JComboBox<>(new String[]{"Todos", "ABIERTA", "EN_CONTEO", "EN_REVISION", "CONCILIADA", "APROBADA", "CERRADA", "CANCELADA"});
    private final JLabel[] metricValues = new JLabel[5];
    private ConciliacionInventarioView reconciliationView;
    private HistorialInventarioFisicoView historyView;
    private final JLabel statusBar = new JLabel("Listo");

    public InventarioFisicoFrame(InventarioFisicoController controller) {
        this.controller = Objects.requireNonNull(controller, "El controlador es obligatorio.");
        setTitle("Sistema de Inventario · Inventario físico");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1120, 720));
        setSize(1380, 850);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());
        add(buildHeader(), BorderLayout.NORTH);
        add(buildTabs(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
        configureTables();
        refreshAll();
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(15, 5));
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 24, 18, 24));
        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("INVENTARIO FÍSICO");
        title.setForeground(Color.WHITE);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        JLabel subtitle = new JLabel("Conteo, conciliación y control de diferencias por almacén");
        subtitle.setForeground(new Color(205, 216, 232));
        subtitle.setFont(subtitle.getFont().deriveFont(13f));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(4));
        titleBox.add(subtitle);
        JPanel userBox = new JPanel(new GridLayout(2, 1, 0, 3));
        userBox.setOpaque(false);
        JLabel user = new JLabel("Usuario: sesión autenticada");
        user.setForeground(Color.WHITE);
        user.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel role = new JLabel("Los permisos se validan también en el servicio");
        role.setForeground(new Color(205, 216, 232));
        role.setFont(role.getFont().deriveFont(11f));
        role.setHorizontalAlignment(SwingConstants.RIGHT);
        userBox.add(user);
        userBox.add(role);
        header.add(titleBox, BorderLayout.WEST);
        header.add(userBox, BorderLayout.EAST);
        return header;
    }

    private JComponent buildTabs() {
        tabs.setBorder(new EmptyBorder(12, 18, 8, 18));
        tabs.setFont(tabs.getFont().deriveFont(Font.BOLD, 13f));
        tabs.addTab("Resumen", buildDashboardPanel());
        reconciliationView = new ConciliacionInventarioView(controller, statusBar, this::refreshAll);
        historyView = new HistorialInventarioFisicoView(controller, statusBar, this::openDetails);
        tabs.addTab("Conciliación", reconciliationView);
        tabs.addTab("Historial", historyView);
        tabs.addTab("Reportes", new ReporteInventarioFisicoView(controller, statusBar));
        return tabs;
    }

    private JComponent buildDashboardPanel() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setOpaque(false);
        JPanel north = new JPanel(new BorderLayout(10, 12));
        north.setOpaque(false);
        JPanel cards = new JPanel(new GridLayout(1, 5, 10, 0));
        cards.setOpaque(false);
        String[] names = {"Tomas realizadas", "Tomas abiertas", "Tomas conciliadas", "Productos con diferencias", "Ajustes pendientes"};
        for (int i = 0; i < names.length; i++) {
            JPanel card = metricCard(names[i]);
            metricValues[i] = (JLabel) card.getClientProperty("valueLabel");
            cards.add(card);
        }
        north.add(cards, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        actions.setOpaque(false);
        JButton create = primaryButton("Nueva toma física");
        JButton count = secondaryButton("Registrar conteo");
        JButton reconcile = secondaryButton("Conciliar");
        JButton detail = secondaryButton("Ver detalles");
        JButton history = secondaryButton("Historial completo");
        JButton report = secondaryButton("Reporte");
        actions.add(create); actions.add(count); actions.add(reconcile); actions.add(detail); actions.add(history); actions.add(report);
        north.add(actions, BorderLayout.SOUTH);
        root.add(north, BorderLayout.NORTH);

        JPanel tableBox = panelCard("Tomas físicas", new BorderLayout(8, 8));
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filters.setOpaque(false);
        filters.add(new JLabel("Buscar:"));
        filters.add(searchDashboard);
        filters.add(new JLabel("Estado:"));
        filters.add(stateDashboard);
        JButton refresh = secondaryButton("Actualizar");
        filters.add(refresh);
        tableBox.add(filters, BorderLayout.NORTH);
        tableBox.add(new JScrollPane(dashboardTable), BorderLayout.CENTER);
        root.add(tableBox, BorderLayout.CENTER);

        create.addActionListener(e -> openNewTake());
        count.addActionListener(e -> openCountForSelected());
        reconcile.addActionListener(e -> openReconciliationForSelected());
        detail.addActionListener(e -> openDetailsForSelected());
        history.addActionListener(e -> tabs.setSelectedIndex(2));
        report.addActionListener(e -> tabs.setSelectedIndex(3));
        refresh.addActionListener(e -> refreshAll());
        searchDashboard.addActionListener(e -> refreshTakes());
        stateDashboard.addActionListener(e -> refreshTakes());
        dashboardTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { if (e.getClickCount() == 2) openDetailsForSelected(); }
        });
        return root;
    }

    private JComponent buildStatusBar() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 230, 238)));
        statusBar.setBorder(new EmptyBorder(7, 18, 7, 18));
        statusBar.setForeground(MUTED);
        statusBar.setFont(statusBar.getFont().deriveFont(11f));
        p.add(statusBar, BorderLayout.CENTER);
        return p;
    }

    private JPanel metricCard(String title) {
        JPanel card = new JPanel(new BorderLayout(4, 7));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(13, 14, 13, 14)));
        JLabel name = new JLabel(title);
        name.setForeground(MUTED);
        name.setFont(name.getFont().deriveFont(11f));
        JLabel value = new JLabel("—");
        value.setForeground(NAVY);
        value.setFont(value.getFont().deriveFont(Font.BOLD, 25f));
        card.add(name, BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        card.putClientProperty("valueLabel", value);
        return card;
    }

    private JPanel panelCard(String title, LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(12, 12, 12, 12)));
        JLabel label = new JLabel(title);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 15f));
        label.setForeground(TEXT);
        panel.add(label, BorderLayout.BEFORE_FIRST_LINE);
        return panel;
    }

    private void configureTables() {
        dashboardTable.setRowHeight(29);
        dashboardTable.setFillsViewportHeight(true);
        dashboardTable.setShowVerticalLines(false);
        dashboardTable.setGridColor(new Color(235, 238, 243));
        dashboardTable.setSelectionBackground(new Color(222, 235, 252));
        dashboardTable.setSelectionForeground(TEXT);
        dashboardTable.getTableHeader().setReorderingAllowed(false);
        dashboardTable.getTableHeader().setBackground(new Color(240, 244, 249));
        dashboardTable.getTableHeader().setForeground(TEXT);
        dashboardTable.getTableHeader().setFont(dashboardTable.getTableHeader().getFont().deriveFont(Font.BOLD, 11f));
        dashboardTable.setFont(dashboardTable.getFont().deriveFont(12f));
        dashboardTable.getColumnModel().getColumn(0).setMinWidth(0);
        dashboardTable.getColumnModel().getColumn(0).setMaxWidth(0);
        dashboardTable.setDefaultRenderer(Object.class, new EstadoTomaRenderer());
    }

    private void refreshAll() {
        async("Actualizando panel", controller::obtenerResumen, resumen -> {
            metricValues[0].setText(String.valueOf(resumen.tomasRealizadas()));
            metricValues[1].setText(String.valueOf(resumen.tomasAbiertas()));
            metricValues[2].setText(String.valueOf(resumen.tomasConciliadas()));
            metricValues[3].setText(String.valueOf(resumen.productosConDiferencias()));
            metricValues[4].setText(String.valueOf(resumen.ajustesPendientes()));
        });
        refreshTakes();
        if (historyView != null) historyView.refresh();
        if (reconciliationView != null) reconciliationView.refreshTomas();
    }

    private void refreshTakes() {
        EstadoToma state = stateDashboard.getSelectedIndex() <= 0 ? null : EstadoToma.valueOf((String) stateDashboard.getSelectedItem());
        async("Cargando tomas", () -> controller.listarTomas(searchDashboard.getText(), state), items -> {
            dashboardModel.setRowCount(0);
            for (Toma t : items) dashboardModel.addRow(new Object[]{t.id(), t.codigo(), t.almacen(), format(t.fechaInicio()), t.responsable(), t.totalProductos(), t.productosContados(), t.productosDiferencia(), t.avancePorcentaje() + "%", t.estado()});
            statusBar.setText("Tomas encontradas: " + items.size());
        });
    }

    private void openNewTake() {
        new NuevaTomaInventarioDialog(this, controller, t -> { refreshAll(); openCount(t.id()); }).setVisible(true);
    }

    private void openCountForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        openCount(id);
    }

    private void openCount(long id) { new RegistroConteoView(this, controller, id, this::refreshAll).setVisible(true); }

    private void openReconciliationForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        tabs.setSelectedIndex(1);
        reconciliationView.seleccionarToma(id);
    }

    private void openDetailsForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        openDetails(id);
    }

    private void openDetails(long id) { if (id != -1) new DetalleTomaInventarioDialog(this, controller, id).setVisible(true); }

    private long dashboardSelectedId() { int r = dashboardTable.getSelectedRow(); return r < 0 ? -1 : ((Number) dashboardModel.getValueAt(dashboardTable.convertRowIndexToModel(r), 0)).longValue(); }

    private <T> void async(String message, Callable<T> task, Consumer<T> success) {
        statusBar.setText(message + "...");
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return task.call(); }
            @Override protected void done() {
                try { T result = get(); success.accept(result); statusBar.setText(message + " · completado"); }
                catch (Exception ex) { Throwable cause = ex.getCause() == null ? ex : ex.getCause(); statusBar.setText("No se pudo completar la operación"); error(cause); }
            }
        }.execute();
    }






}
