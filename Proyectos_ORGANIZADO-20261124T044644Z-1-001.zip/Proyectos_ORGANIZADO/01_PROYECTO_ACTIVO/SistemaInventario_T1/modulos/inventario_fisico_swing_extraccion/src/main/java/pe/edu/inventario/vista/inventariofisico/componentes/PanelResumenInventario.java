package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.Resumen;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Arrays;

public final class PanelResumenInventario extends JPanel {
        private Resumen data = new Resumen(0, 0, 0, 0, 0);
        public PanelResumenInventario() { setBackground(Color.WHITE); setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(18, 18, 18, 18))); }
        void setData(Resumen data) { this.data = data; repaint(); }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g); Graphics2D g2 = (Graphics2D) g.create(); g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT); g2.setFont(getFont().deriveFont(Font.BOLD, 15f)); g2.drawString("Indicadores del inventario físico", 20, 28);
            String[] labels = {"Tomas abiertas", "Conciliadas", "Productos con diferencias", "Ajustes pendientes"};
            int[] values = {data.tomasAbiertas(), data.tomasConciliadas(), data.productosConDiferencias(), data.ajustesPendientes()};
            int max = Math.max(1, Arrays.stream(values).max().orElse(1)); int y = 70; int maxWidth = Math.max(100, getWidth() - 290);
            for (int i = 0; i < values.length; i++) {
                g2.setColor(MUTED); g2.setFont(getFont().deriveFont(12f)); g2.drawString(labels[i], 22, y + 17);
                int w = (int) (maxWidth * (values[i] / (double) max)); g2.setColor(new Color[]{BLUE, GREEN, AMBER, RED}[i]); g2.fillRoundRect(230, y, Math.max(3, w), 24, 8, 8);
                g2.setColor(TEXT); g2.drawString(String.valueOf(values[i]), 240 + w, y + 17); y += 62;
            }
            g2.dispose();
        }
    }
