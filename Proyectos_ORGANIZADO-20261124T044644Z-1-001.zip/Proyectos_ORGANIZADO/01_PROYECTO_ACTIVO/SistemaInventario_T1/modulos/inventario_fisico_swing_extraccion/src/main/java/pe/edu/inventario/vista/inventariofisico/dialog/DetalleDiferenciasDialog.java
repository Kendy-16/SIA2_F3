package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import static pe.edu.inventario.vista.inventariofisico.util.InventarioFisicoUI.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public final class DetalleDiferenciasDialog extends JDialog {
    public DetalleDiferenciasDialog(Frame owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable onSaved) {
            super(owner, "Detalle de diferencia", true); setSize(590, 500); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
            JPanel details = new JPanel(new GridLayout(0, 2, 8, 8)); details.setBorder(new EmptyBorder(18, 20, 8, 20));
            addPair(details, "Código", d.producto().codigo()); addPair(details, "Producto", d.producto().nombre()); addPair(details, "Almacén / ubicación", d.producto().ubicacion());
            addPair(details, "Stock del sistema", fmt(d.stockSistema())); addPair(details, "Cantidad física", fmt(d.cantidadFisica())); addPair(details, "Diferencia", fmt(d.diferencia()));
            addPair(details, "Costo promedio", money(d.costoPromedio())); addPair(details, "Valor de diferencia", money(d.valorDiferencia())); addPair(details, "Clasificación", d.tipo().toString());
            add(details, BorderLayout.NORTH);
            JTextArea note = new JTextArea(d.motivo() == null ? "" : d.motivo(), 5, 35); note.setLineWrap(true); note.setWrapStyleWord(true);
            JPanel notePanel = new JPanel(new BorderLayout(5, 5)); notePanel.setBorder(new EmptyBorder(0, 20, 8, 20)); notePanel.add(new JLabel("Observaciones / explicación:"), BorderLayout.NORTH); notePanel.add(new JScrollPane(note), BorderLayout.CENTER); add(notePanel, BorderLayout.CENTER);
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton save = primaryButton("Guardar observación"), close = secondaryButton("Cerrar"); actions.add(save); actions.add(close); add(actions, BorderLayout.SOUTH);
            save.addActionListener(e -> new SwingWorker<Void, Void>() { @Override protected Void doInBackground() throws Exception { controller.guardarObservacion(idToma, d.producto().id(), note.getText()); return null; } @Override protected void done() { try { get(); onSaved.run(); dispose(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } } }.execute());
            close.addActionListener(e -> dispose());
        }
    }
