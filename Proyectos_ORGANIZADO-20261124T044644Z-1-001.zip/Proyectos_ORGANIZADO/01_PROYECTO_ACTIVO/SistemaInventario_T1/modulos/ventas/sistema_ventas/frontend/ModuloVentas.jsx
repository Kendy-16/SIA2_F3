import React, { useState, useEffect } from 'react';

// Hook simulado que trae los permisos del usuario logueado
const useUserPermissions = () => {
    return ['VENTAS_REGISTRAR', 'PRODUCTOS_BUSCAR', 'INVENTARIO_CONSULTAR', 'VENTAS_CONFIRMAR']; 
    // Nota que NO tiene 'PRECIOS_CAMBIAR' ni 'VENTAS_ANULAR'
};

export const ModuloVentas = () => {
    const permisos = useUserPermissions();
    const [carrito, setCarrito] = useState([{ id: 1, nombre: 'Laptop', producto: 'Laptop', cantidad: 1, precioOriginal: 1500, precioAutorizado: 1500 }]);

    const puedeCambiarPrecio = permisos.includes('PRECIOS_CAMBIAR');
    const puedeAnular = permisos.includes('VENTAS_ANULAR');

    return (
        <div className="pos-system">
            <h2>Registro de Ventas</h2>

            {/* Búsquedas permitidas */}
            <div className="buscadores">
                <button disabled={!permisos.includes('CLIENTES_BUSCAR')}>Buscar Cliente</button>
                <button disabled={!permisos.includes('PRODUCTOS_BUSCAR')}>Buscar Producto</button>
            </div>

            {/* Carrito con restricciones */}
            <table className="tabla-carrito">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Cantidad (Editable)</th>
                        <th>Precio (Bloqueado)</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    {carrito.map((item, idx) => (
                        <FilaProductoCarrito key={idx} item={item} estadoVenta="BORRADOR" permisos={permisos} />
                    ))}
                </tbody>
            </table>

            {/* Acciones Finales */}
            <div className="acciones-venta">
                <button 
                    className="btn-confirmar"
                    disabled={!permisos.includes('VENTAS_CONFIRMAR')}>
                    Confirmar Venta
                </button>
                
                {/* Botón de anular oculto o deshabilitado si no tiene permiso */}
                {puedeAnular && (
                    <button className="btn-anular">
                        Anular Venta
                    </button>
                )}
            </div>

            <hr />
            <PanelVentas usuario={{ almacen_asignado: 1 }} permisos={permisos} />
        </div>
    );
};

export const FilaProductoCarrito = ({ item, estadoVenta, permisos }) => {
    const handleActualizarCantidad = (id, val) => console.log("Actualizar:", id, val);
    
    // Evaluar reglas booleanas
    const esBorrador = estadoVenta === 'BORRADOR';
    const puedeCambiarPrecio = permisos.includes('PRECIOS_CAMBIAR');
    
    // REGLA: Modificar cantidades antes de confirmar
    const habilitarCantidad = esBorrador; 
    
    // REGLA PROHIBIDA: Cambiar precios libremente
    const habilitarPrecio = esBorrador && puedeCambiarPrecio; 

    return (
        <tr>
            <td>{item.nombre || item.producto}</td>
            
            {/* INPUT DE CANTIDAD */}
            <td>
                <input 
                    type="number" 
                    defaultValue={item.cantidad}
                    min="1"
                    readOnly={!habilitarCantidad}
                    className={!habilitarCantidad ? "bg-gray-200 cursor-not-allowed" : "bg-white"}
                    onChange={(e) => handleActualizarCantidad(item.id, e.target.value)}
                />
            </td>
            
            {/* INPUT DE PRECIO */}
            <td>
                <input 
                    type="number" 
                    defaultValue={item.precioAutorizado || item.precioOriginal}
                    disabled={!puedeCambiarPrecio}
                    readOnly={!habilitarPrecio}
                    className={!habilitarPrecio ? "bg-gray-200 cursor-not-allowed" : "bg-white"}
                    title={!puedeCambiarPrecio ? "Requiere permiso de administrador para modificar precio" : ""}
                />
            </td>
            
            {/* ACCIONES (Eliminar fila) */}
            <td>
                {esBorrador && (
                    <button className="text-red-500">Quitar Producto</button>
                )}
            </td>
        </tr>
    );
};

export const PanelVentas = ({ usuario, permisos }) => {
    const confirmarVenta = () => console.log("Confirmando venta...");

    return (
        <div>
            {/* REGLA: Consultar disponibilidad del almacén asignado */}
            <div className="info-almacen">
                Operando en Almacén ID: {usuario.almacen_asignado} 
                (Restringido a stock local)
            </div>

            {/* SELECCIÓN DE PAGOS */}
            {/* REGLA: Seleccionar medios de pago habilitados */}
            <select name="metodoPago" required>
                <option value="EFECTIVO">Efectivo</option>
                <option value="TARJETA">Tarjeta (POS)</option>
                <option value="TRANSFERENCIA">Transferencia</option>
            </select>

            {/* BOTON DE CONFIRMAR */}
            <button 
                onClick={confirmarVenta}
                disabled={!permisos.includes('VENTAS_CONFIRMAR')}
                className="btn-success">
                Confirmar e Imprimir Comprobante
            </button>
            
            {/* BOTONES OCULTOS (Reglas Prohibidas) */}
            {permisos.includes('VENTAS_ANULAR') && (
                <button className="btn-danger">Anular Venta</button>
            )}
        </div>
    );
};
