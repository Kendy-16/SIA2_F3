package com.sistema.ventas.backend.dao;

import com.sistema.ventas.backend.model.Venta;
import com.sistema.ventas.backend.model.DetalleVenta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    // Insertar cabecera (Recibe la conexión externa para la transacción)
    public int insertarVenta(Connection conn, Venta venta) throws SQLException {
        String sql = "INSERT INTO venta (numeroVenta, fecha, idCliente, idUsuario, idAlmacen, tipoVenta, estado, subtotal, descuentoTotal, impuestoTotal, total, observacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, venta.getNumeroVenta());
            stmt.setObject(2, venta.getFecha());
            stmt.setInt(3, venta.getIdCliente());
            stmt.setInt(4, venta.getIdUsuario());
            stmt.setInt(5, venta.getIdAlmacen());
            stmt.setString(6, venta.getTipoVenta());
            stmt.setString(7, venta.getEstado());
            stmt.setBigDecimal(8, venta.getSubtotal());
            stmt.setBigDecimal(9, venta.getDescuentoTotal());
            stmt.setBigDecimal(10, venta.getImpuestoTotal());
            stmt.setBigDecimal(11, venta.getTotal());
            stmt.setString(12, venta.getObservacion());
            
            stmt.executeUpdate();
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1); // Retorna el ID generado
                }
            }
        }
        throw new SQLException("Error al insertar la cabecera de la venta.");
    }

    // Insertar detalles (Parte de la misma transacción)
    public void insertarDetalle(Connection conn, DetalleVenta detalle) throws SQLException {
        String sql = "INSERT INTO detalle_venta (idVenta, idProducto, cantidad, unidadMedida, precioUnitario, descuento, subtotal, costoUnitario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, detalle.getIdVenta());
            stmt.setInt(2, detalle.getIdProducto());
            stmt.setBigDecimal(3, detalle.getCantidad());
            stmt.setString(4, detalle.getUnidadMedida());
            stmt.setBigDecimal(5, detalle.getPrecioUnitario());
            stmt.setBigDecimal(6, detalle.getDescuento());
            stmt.setBigDecimal(7, detalle.getSubtotal());
            stmt.setBigDecimal(8, detalle.getCostoUnitario()); // Costo histórico congelado
            stmt.executeUpdate();
        }
    }

    // Registrar anulación (Actualizar estado)
    public void registrarAnulacion(Connection conn, int idVenta, String motivo, int idUsuario) throws SQLException {
        String sql = "UPDATE venta SET estado = 'ANULADA', motivoAnulacion = ?, usuarioAnulacion = ?, fechaAnulacion = CURRENT_TIMESTAMP WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, motivo);
            stmt.setInt(2, idUsuario);
            stmt.setInt(3, idVenta);
            stmt.executeUpdate();
        }
    }

    // Ejemplo de búsqueda: Consultar por identificador (Solo lectura, puede abrir su propia conexión si no hay transacción)
    public Venta buscarPorId(Connection conn, int id) throws SQLException {
        String sql = "SELECT * FROM venta WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Venta v = new Venta();
                    v.setId(rs.getInt("id"));
                    v.setNumeroVenta(rs.getString("numeroVenta"));
                    v.setTotal(rs.getBigDecimal("total"));
                    // ... mapear el resto ...
                    return v;
                }
            }
        }
        return null;
    }
    
    // ... Implementar buscarPorNumero, buscarPorCliente, consultarVentasMayoristas, etc., usando PreparedStatement ...
}
