package com.sistema.ventas.backend.controller;

import com.sistema.ventas.backend.model.*;
import com.sistema.ventas.backend.service.VentaService;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/ventas")
public class VentaController {

    private VentaService ventaService = new VentaService();
    private AuthManager authManager = new AuthManager(); // Gestor de sesión HTTP

    @POST
    @Path("/realizar")
    @Consumes("application/json")
    @Produces("application/json")
    public Response realizarVenta(@Context HttpServletRequest request, VentaDTO ventaRequest) {
        
        // 1. Recibir la solicitud y 2. Verificar que exista una sesión válida
        SesionUsuario sesion = authManager.obtenerSesion(request);
        if (sesion == null || !sesion.esValida()) {
            return Response.status(Response.Status.UNAUTHORIZED)
                           .entity(new RespuestaHttp(false, "Sesión inválida o expirada."))
                           .build();
        }

        // 3. Identificar al usuario autenticado (Ya viene en el objeto SesionUsuario)
        // 4. Comprobar el permiso de la operación (El Controlador hace una barrera inicial, el Service hace la profunda)
        if (!sesion.getRoles().contains("CAJERO") && !sesion.getRoles().contains("ADMIN")) {
            return Response.status(Response.Status.FORBIDDEN)
                           .entity(new RespuestaHttp(false, "No tienes permisos de cajero."))
                           .build();
        }

        // 5. Recibir los datos de la venta (Mapeado automáticamente en ventaRequest por el framework)
        if (ventaRequest == null || ventaRequest.getVenta() == null || ventaRequest.getDetalles() == null || ventaRequest.getDetalles().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST)
                           .entity(new RespuestaHttp(false, "Datos de venta incompletos o vacíos."))
                           .build();
        }

        // Asignar el usuario responsable desde la sesión (Seguridad: No confiar en el ID del JSON frontal)
        ventaRequest.getVenta().setIdUsuario(sesion.getIdUsuario());

        // 6. Enviar la solicitud al servicio y 7. Gestionar los resultados
        try {
            ResultadoVenta resultado = ventaService.procesarVenta(ventaRequest, sesion);
            
            // 8. Devolver mensajes apropiados
            if (resultado.isExito()) {
                return Response.ok(new RespuestaHttp(true, resultado.getMensaje())).build();
            } else {
                return Response.status(Response.Status.BAD_REQUEST)
                               .entity(new RespuestaHttp(false, resultado.getMensaje()))
                               .build();
            }
        } catch (Exception e) {
            // Manejo de errores no controlados
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity(new RespuestaHttp(false, "Error interno del servidor."))
                           .build();
        }
    }

    @GET
    @Path("/historial")
    @Produces("application/json")
    public Response consultarHistorial(@Context HttpServletRequest request, 
                                       @QueryParam("fechaInicio") String fechaInicio, 
                                       @QueryParam("fechaFin") String fechaFin) {
        
        // Verificar sesión (Reutilizamos lógica)
        SesionUsuario sesion = authManager.obtenerSesion(request);
        if (sesion == null) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

        // 9. Coordinar la consulta del historial (Deriva al servicio, el controlador no toca SQL)
        try {
            List<Venta> historial = ventaService.obtenerHistorial(fechaInicio, fechaFin);
            return Response.ok(historial).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity(new RespuestaHttp(false, "Error al consultar historial."))
                           .build();
        }
    }
}
