package com.sistema.ventas.servicios;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.List;

public class VentaValidadorDominio {

    public static class LineaVentaRequest {
        public int productoId;
        public BigDecimal cantidad;
        public BigDecimal precioUnitarioEnviado;
        public BigDecimal descuentoEnviado;
    }

    public static class ResultadoCalculoLinea {
        public int productoId;
        public BigDecimal cantidad;
        public BigDecimal precioReal;
        public BigDecimal descuentoReal;
        public BigDecimal subtotalReal;
    }

    /**
     * Valida y recalcula toda la venta con BigDecimal (ignora totales manipulados en la Vista - Prueba #18)
     */
    public BigDecimal validarYRecalcularVenta(
            Connection conn,
            Integer clienteId,
            boolean requiereClienteObligatorio, // Ej: FACTURA o VENTA MAYORISTA
            String tipoVenta,                   // NORMAL | MAYORISTA
            String rolUsuario,                  // ADMINISTRADOR | USUARIO
            BigDecimal maxDescuentoUsuarioPct,  // Ej: 5.00% para USUARIO, 50.00% para ADMINISTRADOR
            List<LineaVentaRequest> lineas,
            BigDecimal totalEnviadoPorVista) throws Exception {

        // Prueba #17: Venta sin detalles
        if (lineas == null || lineas.isEmpty()) {
            throw new IllegalArgumentException("La venta debe contener al menos un producto en el detalle.");
        }

        // Pruebas #1, #2, #3, #4: Validación de Cliente
        if (requiereClienteObligatorio && clienteId == null) {
            throw new IllegalArgumentException("El cliente es obligatorio para este tipo de comprobante o venta mayorista.");
        }
        if (clienteId != null) {
            try (PreparedStatement ps = conn.prepareStatement("SELECT activo FROM clientes WHERE id = ?")) {
                ps.setInt(1, clienteId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalArgumentException("El cliente especificado no existe."); // Prueba #3
                    }
                    if (rs.getInt("activo") != 1) {
                        throw new IllegalStateException("El cliente se encuentra inactivo según política comercial."); // Prueba #4
                    }
                }
            }
        }

        BigDecimal totalRecalculado = BigDecimal.ZERO;

        for (LineaVentaRequest item : lineas) {
            // Pruebas #9 y #10: Cantidad cero o negativa
            if (item.cantidad == null || item.cantidad.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor a cero.");
            }

            // Pruebas #14: Precio negativo
            if (item.precioUnitarioEnviado == null || item.precioUnitarioEnviado.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException("El precio unitario no puede ser negativo.");
            }

            // Pruebas #5, #6, #7 y #11: Producto existente, activo, precios y unidad entera/fraccionaria
            String sqlProd = "SELECT nombre, activo, precio_normal, precio_mayorista, permite_fraccion FROM productos WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlProd)) {
                ps.setInt(1, item.productoId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalArgumentException("Producto inexistente ID: " + item.productoId); // Prueba #6
                    }
                    String nombre = rs.getString("nombre");
                    if (rs.getInt("activo") != 1) {
                        throw new IllegalStateException("Producto inactivo: " + nombre); // Prueba #7
                    }

                    boolean permiteFraccion = rs.getInt("permite_fraccion") == 1;
                    // Prueba #11: Cantidad fraccionaria en unidad entera
                    if (!permiteFraccion && item.cantidad.stripTrailingZeros().scale() > 0) {
                        throw new IllegalArgumentException("El producto '" + nombre + "' no admite cantidades fraccionarias.");
                    }

                    // Precio oficial según tipo de venta (Normal vs Mayorista)
                    BigDecimal precioCatalogo = "MAYORISTA".equals(tipoVenta)
                            ? rs.getBigDecimal("precio_mayorista")
                            : rs.getBigDecimal("precio_normal");

                    BigDecimal brutoLinea = precioCatalogo.multiply(item.cantidad).setScale(2, RoundingMode.HALF_UP);
                    BigDecimal descuento = item.descuentoEnviado != null ? item.descuentoEnviado : BigDecimal.ZERO;

                    if (descuento.compareTo(BigDecimal.ZERO) < 0 || descuento.compareTo(brutoLinea) > 0) {
                        throw new IllegalArgumentException("Descuento fuera de rango permitido."); // Prueba #15
                    }

                    // Prueba #15 y #16: Validar porcentaje de descuento según rol
                    if (brutoLinea.compareTo(BigDecimal.ZERO) > 0 && descuento.compareTo(BigDecimal.ZERO) > 0) {
                        BigDecimal pctAplicado = descuento.multiply(new BigDecimal("100"))
                                .divide(brutoLinea, 2, RoundingMode.HALF_UP);
                        if (!"ADMINISTRADOR".equals(rolUsuario) && pctAplicado.compareTo(maxDescuentoUsuarioPct) > 0) {
                            throw new SecurityException("Usuario sin permiso para aplicar descuentos superiores al " + maxDescuentoUsuarioPct + "%.");
                        }
                    }

                    BigDecimal netoLinea = brutoLinea.subtract(descuento).setScale(2, RoundingMode.HALF_UP);
                    totalRecalculado = totalRecalculado.add(netoLinea);
                }
            }
        }

        // Prueba #18: Si la vista envió un total manipulado, el servicio prevalece con totalRecalculado
        return totalRecalculado.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Prueba #8: Búsqueda rápida por código de barras
     */
    public Integer buscarProductoPorCodigoBarras(Connection conn, String codigoBarras) throws SQLException {
        if (codigoBarras == null || codigoBarras.isBlank()) return null;
        try (PreparedStatement ps = conn.prepareStatement("SELECT id FROM productos WHERE codigo_barras = ? AND activo = 1")) {
            ps.setString(1, codigoBarras.trim());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt("id") : null;
            }
        }
    }
}
