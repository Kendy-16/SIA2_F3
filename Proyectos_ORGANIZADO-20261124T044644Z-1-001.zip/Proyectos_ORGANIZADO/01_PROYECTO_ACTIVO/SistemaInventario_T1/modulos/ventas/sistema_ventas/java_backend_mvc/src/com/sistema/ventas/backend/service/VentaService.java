package com.sistema.ventas.backend.service;

import com.sistema.ventas.backend.dao.*;
import com.sistema.ventas.backend.model.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.List;

public class VentaService {
    
    private VentaDAO ventaDAO = new VentaDAO();
    private DatabaseManager dbManager = new DatabaseManager(); // Gestor de conexiones
    
    // DAOs auxiliares imaginarios para representar el ecosistema
    private UsuarioDAO usuarioDAO = new UsuarioDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    private ProductoDAO productoDAO = new ProductoDAO();
    private InventarioDAO inventarioDAO = new InventarioDAO();
    private KardexDAO kardexDAO = new KardexDAO();
    private CajaDAO cajaDAO = new CajaDAO();
    private ComprobanteService comprobanteService = new ComprobanteService();

    public ResultadoVenta procesarVenta(VentaDTO dto, SesionUsuario sesion) throws Exception {
        Connection conn = null;
        
        try {
            // 1. Validación del usuario y 2. Validación del permiso
            if (!usuarioDAO.esUsuarioActivo(sesion.getIdUsuario())) throw new Exception("Usuario inválido o inactivo.");
            if (!usuarioDAO.tienePermiso(sesion.getIdUsuario(), "VENTA_CREAR")) throw new Exception("Sin permisos para vender.");

            // 3. Validación del cliente y 4. Validación del almacén
            if (!clienteDAO.existeCliente(dto.getVenta().getIdCliente())) throw new Exception("Cliente no registrado.");
            if (!inventarioDAO.existeAlmacen(dto.getVenta().getIdAlmacen())) throw new Exception("Almacén inválido.");

            // Inicio de validaciones de productos
            BigDecimal totalCalculado = BigDecimal.ZERO;

            for (DetalleVenta detalle : dto.getDetalles()) {
                // 5. Validación de productos
                Producto prod = productoDAO.buscarPorId(detalle.getIdProducto());
                if (prod == null || !prod.isActivo()) throw new Exception("Producto inválido: " + detalle.getIdProducto());

                // 6. Validación de cantidades y 7. Validación de stock
                if (detalle.getCantidad().compareTo(BigDecimal.ZERO) <= 0) throw new Exception("Cantidad inválida.");
                if (!inventarioDAO.hayStock(prod.getId(), dto.getVenta().getIdAlmacen(), detalle.getCantidad())) {
                    throw new Exception("Stock insuficiente para el producto: " + prod.getNombre());
                }

                // 8. Validación de precios y 9. Validación de descuentos
                if (detalle.getPrecioUnitario().compareTo(prod.getPrecioMinimo()) < 0) throw new Exception("Precio por debajo del mínimo permitido.");
                if (detalle.getDescuento().compareTo(detalle.getPrecioUnitario().multiply(detalle.getCantidad())) > 0) {
                    throw new Exception("Descuento supera el subtotal en línea.");
                }

                // Calculamos el subtotal de la línea
                BigDecimal subtotalLinea = detalle.getCantidad().multiply(detalle.getPrecioUnitario()).subtract(detalle.getDescuento());
                if (subtotalLinea.compareTo(detalle.getSubtotal()) != 0) {
                    throw new Exception("Inconsistencia en los cálculos de la línea.");
                }
                
                // Fijamos el costo histórico al momento de la venta
                detalle.setCostoUnitario(prod.getCostoPromedioActual());

                totalCalculado = totalCalculado.add(subtotalLinea);
            }

            // 10. Cálculo de totales (Validamos que el controlador no haya enviado montos falsos)
            if (totalCalculado.compareTo(dto.getVenta().getTotal()) != 0) {
                throw new Exception("El total de la venta no coincide con la suma de los detalles.");
            }

            // 11. Validación de pagos
            if (!cajaDAO.cajaAbierta(sesion.getIdCaja())) throw new Exception("La caja debe estar abierta para proceder.");

            // ==========================================
            // INICIO DE LA TRANSACCIÓN COMPARTIDA (SQLite)
            // ==========================================
            conn = dbManager.getConnection();
            conn.setAutoCommit(false); // 19. Preparar confirmación o reversión

            dto.getVenta().setEstado("COMPLETADA");
            
            // 12. Registro de la venta (Cabecera)
            int idVentaGenerado = ventaDAO.insertarVenta(conn, dto.getVenta());

            for (DetalleVenta detalle : dto.getDetalles()) {
                detalle.setIdVenta(idVentaGenerado);
                
                // 13. Registro de los detalles
                ventaDAO.insertarDetalle(conn, detalle);

                // 14. Actualización de inventario
                inventarioDAO.descontarStock(conn, detalle.getIdProducto(), dto.getVenta().getIdAlmacen(), detalle.getCantidad());

                // 15. Registro de Kardex
                kardexDAO.registrarSalida(conn, detalle.getIdProducto(), dto.getVenta().getIdAlmacen(), detalle.getCantidad(), detalle.getCostoUnitario(), "VENTA", idVentaGenerado);
            }

            // 16. Registro de caja
            cajaDAO.registrarIngreso(conn, sesion.getIdCaja(), dto.getVenta().getTotal(), "VENTA", idVentaGenerado);

            // 17. Generación del comprobante
            String numeroComprobante = comprobanteService.generarTicket(conn, idVentaGenerado);
            
            // 18. Auditoría
            AuditoriaDAO.registrarAccion(conn, sesion.getIdUsuario(), "VENTA_CREADA", "Se creó la venta ID " + idVentaGenerado);

            // 19. Confirmación de la transacción (COMMIT)
            conn.commit();
            
            return new ResultadoVenta(true, "Venta procesada con éxito. Comprobante: " + numeroComprobante);

        } catch (Exception e) {
            // 19. Reversión de la transacción (ROLLBACK)
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { /* Loguear error crítico de DB */ }
            }
            return new ResultadoVenta(false, "Error al procesar venta: " + e.getMessage());
        } finally {
            if (conn != null) {
                try { 
                    conn.setAutoCommit(true);
                    conn.close(); 
                } catch (SQLException ex) { /* Loguear cierre fallido */ }
            }
        }
    }

    public List<Venta> obtenerHistorial(String fechaInicio, String fechaFin) throws Exception {
        // Implementación delegada desde VentaController
        return null;
    }
}
