package com.sistema.ventas.tests;

import com.sistema.ventas.documentos.DocumentoService;
import com.sistema.ventas.reportes.HistorialYReportesService;
import com.sistema.ventas.servicios.*;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ModuloVentasTestSuite {

    private Connection conn;
    private VentaValidadorDominio validador;
    private VentaConfirmacionService confirmacionService;
    private AnulacionVentaService anulacionService;
    private DevolucionVentaService devolucionService;
    private DocumentoService documentoService;
    private HistorialYReportesService reportesService;

    @BeforeEach
    void setUp() throws Exception {
        // Base de datos SQLite de pruebas limpia por cada caso
        conn = DriverManager.getConnection("jdbc:sqlite:test_ventas_suite.db");
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON;");
            st.execute("PRAGMA journal_mode = WAL;");
            st.execute("PRAGMA busy_timeout = 5000;");
            inicializarEsquemaYDatosBase(st);
        }
        validador = new VentaValidadorDominio();
        confirmacionService = new VentaConfirmacionService();
        anulacionService = new AnulacionVentaService();
        devolucionService = new DevolucionVentaService();
        documentoService = new DocumentoService();
        reportesService = new HistorialYReportesService();
    }

    @AfterEach
    void tearDown() throws Exception {
        if (conn != null && !conn.isClosed()) conn.close();
    }

    // =========================================================================
    // MATRIZ DE 35 PRUEBAS DEL MÓDULO VENTAS (PUNTO 18)
    // =========================================================================

    @Test @Order(1)
    @DisplayName("01. Venta con cliente válido -> Permitida")
    void test01_VentaConClienteValido() throws Exception {
        var linea = crearLinea(1, new BigDecimal("2"), new BigDecimal("10.00"), BigDecimal.ZERO);
        BigDecimal total = validador.validarYRecalcularVenta(conn, 1, true, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("20.00"));
        assertEquals(new BigDecimal("20.00"), total);
    }

    @Test @Order(2)
    @DisplayName("02. Venta sin cliente obligatorio -> Rechazada")
    void test02_VentaSinClienteObligatorio() {
        var linea = crearLinea(1, new BigDecimal("1"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, null, true, "MAYORISTA", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("10.00"))
        );
    }

    @Test @Order(3)
    @DisplayName("03. Cliente inexistente -> Rechazada")
    void test03_ClienteInexistente() {
        var linea = crearLinea(1, new BigDecimal("1"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 9999, true, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("10.00"))
        );
    }

    @Test @Order(4)
    @DisplayName("04. Cliente inactivo -> Rechazada según política")
    void test04_ClienteInactivo() {
        var linea = crearLinea(1, new BigDecimal("1"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalStateException.class, () ->
            validador.validarYRecalcularVenta(conn, 2, true, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("10.00"))
        );
    }

    @Test @Order(5)
    @DisplayName("05. Producto existente -> Permitido")
    void test05_ProductoExistente() throws Exception {
        var linea = crearLinea(1, new BigDecimal("1"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertDoesNotThrow(() ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("10.00"))
        );
    }

    @Test @Order(6)
    @DisplayName("06. Producto inexistente -> Rechazado")
    void test06_ProductoInexistente() {
        var linea = crearLinea(8888, new BigDecimal("1"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("10.00"))
        );
    }

    @Test @Order(7)
    @DisplayName("07. Producto inactivo -> Rechazado")
    void test07_ProductoInactivo() {
        var linea = crearLinea(2, new BigDecimal("1"), new BigDecimal("15.00"), BigDecimal.ZERO);
        assertThrows(IllegalStateException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("15.00"))
        );
    }

    @Test @Order(8)
    @DisplayName("08. Código de barras válido -> Producto encontrado")
    void test08_CodigoBarrasValido() throws Exception {
        Integer idEncontrado = validador.buscarProductoPorCodigoBarras(conn, "775000111222");
        assertEquals(1, idEncontrado);
    }

    @Test @Order(9)
    @DisplayName("09. Cantidad cero -> Rechazada")
    void test09_CantidadCero() {
        var linea = crearLinea(1, BigDecimal.ZERO, new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), BigDecimal.ZERO)
        );
    }

    @Test @Order(10)
    @DisplayName("10. Cantidad negativa -> Rechazada")
    void test10_CantidadNegativa() {
        var linea = crearLinea(1, new BigDecimal("-3"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("-30.00"))
        );
    }

    @Test @Order(11)
    @DisplayName("11. Cantidad fraccionaria en unidad entera -> Rechazada")
    void test11_CantidadFraccionariaEnUnidadEntera() {
        // Producto 1 tiene permite_fraccion = 0 (Unidad entera)
        var linea = crearLinea(1, new BigDecimal("1.5"), new BigDecimal("10.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("15.00"))
        );
    }

    @Test @Order(12)
    @DisplayName("12. Cantidad mayor que stock -> Rechazada")
    void test12_CantidadMayorQueStock() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 500.0, 5000.0); // Stock es 40
        var pago = crearPago("EFECTIVO", 5000.0, 5000.0);
        assertThrows(Exception.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-12", 1, 1, "TICKET_INTERNO", "T001", List.of(pago))
        );
    }

    @Test @Order(13)
    @DisplayName("13. Venta en almacén no autorizado -> Rechazada")
    void test13_VentaEnAlmacenNoAutorizado() throws Exception {
        // Usuario 2 no tiene permiso en Almacén 1
        int ventaId = crearBorradorVenta(1, 2, 1, 1, 2.0, 20.0);
        var pago = crearPago("EFECTIVO", 20.0, 20.0);
        assertThrows(SecurityException.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-13", 2, 1, "TICKET_INTERNO", "T001", List.of(pago))
        );
    }

    @Test @Order(14)
    @DisplayName("14. Precio negativo -> Rechazado")
    void test14_PrecioNegativo() {
        var linea = crearLinea(1, BigDecimal.ONE, new BigDecimal("-5.00"), BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("-5.00"))
        );
    }

    @Test @Order(15)
    @DisplayName("15. Descuento fuera del límite -> Rechazado")
    void test15_DescuentoFueraDelLimite() {
        // Descuento mayor al bruto de la línea (100 > 20)
        var linea = crearLinea(1, new BigDecimal("2"), new BigDecimal("10.00"), new BigDecimal("100.00"));
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "ADMINISTRADOR", new BigDecimal("50"), List.of(linea), BigDecimal.ZERO)
        );
    }

    @Test @Order(16)
    @DisplayName("16. Usuario sin permiso de descuento especial -> Rechazado")
    void test16_UsuarioSinPermisoDescuentoEspecial() {
        // Usuario normal (límite 5%) intenta descontar 20% (S/ 4 de S/ 20)
        var linea = crearLinea(1, new BigDecimal("2"), new BigDecimal("10.00"), new BigDecimal("4.00"));
        assertThrows(SecurityException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5.00"), List.of(linea), new BigDecimal("16.00"))
        );
    }

    @Test @Order(17)
    @DisplayName("17. Venta sin detalles -> Rechazada")
    void test17_VentaSinDetalles() {
        assertThrows(IllegalArgumentException.class, () ->
            validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), Collections.emptyList(), BigDecimal.ZERO)
        );
    }

    @Test @Order(18)
    @DisplayName("18. Total incorrecto enviado desde la vista -> Recalculado por servicio")
    void test18_TotalIncorrectoDesdeVistaRecalculado() throws Exception {
        // Vista envía S/ 1.00 manipulado, pero 3 unidades x S/ 10.00 = S/ 30.00 real
        var linea = crearLinea(1, new BigDecimal("3"), new BigDecimal("10.00"), BigDecimal.ZERO);
        BigDecimal totalServicio = validador.validarYRecalcularVenta(conn, 1, false, "NORMAL", "USUARIO", new BigDecimal("5"), List.of(linea), new BigDecimal("1.00"));
        assertEquals(new BigDecimal("30.00"), totalServicio);
    }

    @Test @Order(19)
    @DisplayName("19. Pago insuficiente en venta de contado -> Rechazado")
    void test19_PagoInsuficienteContado() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 2.0, 20.0);
        var pagoInsuficiente = crearPago("EFECTIVO", 15.0, 15.0);
        assertThrows(Exception.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-19", 1, 1, "TICKET_INTERNO", "T001", List.of(pagoInsuficiente))
        );
    }

    @Test @Order(20)
    @DisplayName("20. Pago mixto válido -> Permitido")
    void test20_PagoMixtoValido() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 5.0, 50.0);
        var p1 = crearPago("EFECTIVO", 30.0, 30.0);
        var p2 = crearPago("YAPE", 20.0, 20.0);
        String doc = confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-20", 1, 1, "BOLETA", "B001", List.of(p1, p2));
        assertNotNull(doc);
    }

    @Test @Order(21)
    @DisplayName("21. Caja cerrada cuando es obligatoria -> Rechazada")
    void test21_CajaCerradaRechazada() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 1.0, 10.0);
        var pago = crearPago("EFECTIVO", 10.0, 10.0);
        // Sesión de caja 2 está en estado CERRADA
        assertThrows(Exception.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-21", 1, 2, "TICKET_INTERNO", "T001", List.of(pago))
        );
    }

    @Test @Order(22)
    @DisplayName("22. Confirmación de venta válida -> Registrada")
    void test22_ConfirmacionVentaValida() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 8.0, 80.0);
        var pago = crearPago("EFECTIVO", 80.0, 100.0);
        String comprobante = confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-22", 1, 1, "BOLETA", "B001", List.of(pago));
        assertTrue(comprobante.startsWith("B001-"));
    }

    @Test @Order(23)
    @DisplayName("23. Confirmación duplicada -> No duplica la venta (Idempotencia)")
    void test23_ConfirmacionDuplicadaIdempotente() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 4.0, 40.0);
        var pago = crearPago("EFECTIVO", 40.0, 40.0);
        String comp1 = confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-UNICA-23", 1, 1, "BOLETA", "B001", List.of(pago));
        String comp2 = confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-UNICA-23", 1, 1, "BOLETA", "B001", List.of(pago));
        assertEquals(comp1, comp2);
        // Stock inicial 40 - 4 = 36 (no 32)
        assertEquals(36.0, consultarStock(1, 1), 0.001);
    }

    @Test @Order(24)
    @DisplayName("24. Venta confirmada actualiza stock -> Stock correcto (40 - 8 = 32)")
    void test24_VentaConfirmadaActualizaStock() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 8.0, 80.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-24", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 80.0, 80.0)));
        assertEquals(32.0, consultarStock(1, 1), 0.001);
    }

    @Test @Order(25)
    @DisplayName("25. Venta confirmada genera Kardex -> Registro correcto")
    void test25_VentaConfirmadaGeneraKardex() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 8.0, 80.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-25", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 80.0, 80.0)));

        try (PreparedStatement ps = conn.prepareStatement("SELECT saldo_anterior, salida, saldo_nuevo, valor_saldo FROM kardex_movimientos WHERE venta_id = ?")) {
            ps.setInt(1, ventaId);
            ResultSet rs = ps.executeQuery();
            assertTrue(rs.next());
            assertEquals(40.0, rs.getDouble("saldo_anterior"), 0.001);
            assertEquals(8.0, rs.getDouble("salida"), 0.001);
            assertEquals(32.0, rs.getDouble("saldo_nuevo"), 0.001);
            assertEquals(240.0, rs.getDouble("valor_saldo"), 0.001);
        }
    }

    @Test @Order(26)
    @DisplayName("26. Salida mantiene costo promedio -> Costo correcto (S/ 7.50)")
    void test26_SalidaMantieneCostoPromedio() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 8.0, 80.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-26", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 80.0, 80.0)));

        try (PreparedStatement ps = conn.prepareStatement("SELECT costo_promedio FROM inventario_saldos WHERE producto_id = 1 AND almacen_id = 1")) {
            ResultSet rs = ps.executeQuery();
            assertTrue(rs.next());
            assertEquals(7.50, rs.getDouble("costo_promedio"), 0.001);
        }
    }

    @Test @Order(27)
    @DisplayName("27. Falla al registrar Kardex -> Rollback completo")
    void test27_FallaAlRegistrarKardexHaceRollback() throws Exception {
        // Trigger temporal que simula error crítico en inserción de Kardex
        try (Statement st = conn.createStatement()) {
            st.execute("CREATE TRIGGER trg_simular_fallo_kardex BEFORE INSERT ON kardex_movimientos BEGIN SELECT RAISE(ABORT, 'Fallo simulado Kardex'); END;");
        }
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 5.0, 50.0);
        assertThrows(Exception.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-27", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 50.0, 50.0)))
        );
        // Verificar rollback: stock sigue en 40.0 y venta sigue en BORRADOR
        assertEquals(40.0, consultarStock(1, 1), 0.001);
        assertEquals("BORRADOR", consultarEstadoVenta(ventaId));
    }

    @Test @Order(28)
    @DisplayName("28. Falla al registrar caja -> Rollback completo")
    void test28_FallaAlRegistrarCajaHaceRollback() throws Exception {
        try (Statement st = conn.createStatement()) {
            st.execute("CREATE TRIGGER trg_simular_fallo_caja BEFORE INSERT ON caja_movimientos BEGIN SELECT RAISE(ABORT, 'Fallo simulado Caja'); END;");
        }
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 5.0, 50.0);
        assertThrows(Exception.class, () ->
            confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-28", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 50.0, 50.0)))
        );
        // Rollback total: ni stock ni Kardex quedaron alterados
        assertEquals(40.0, consultarStock(1, 1), 0.001);
    }

    @Test @Order(29)
    @DisplayName("29. Venta anulada -> Reversión coherente")
    void test29_VentaAnuladaReversionCoherente() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 10.0, 100.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-29", 1, 1, "BOLETA", "B001", List.of(crearPago("EFECTIVO", 100.0, 100.0)));
        assertEquals(30.0, consultarStock(1, 1), 0.001);

        anulacionService.anularVenta(ventaId, 1, true, 1, "Error en digitación de cliente");
        assertEquals(40.0, consultarStock(1, 1), 0.001);
        assertEquals("ANULADA", consultarEstadoVenta(ventaId));
    }

    @Test @Order(30)
    @DisplayName("30. Anulación sin permiso -> Rechazada")
    void test30_AnulacionSinPermiso() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 2.0, 20.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-30", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 20.0, 20.0)));
        assertThrows(SecurityException.class, () ->
            anulacionService.anularVenta(ventaId, 2, false, 1, "Intento no autorizado")
        );
    }

    @Test @Order(31)
    @DisplayName("31. Anulación duplicada -> Rechazada")
    void test31_AnulacionDuplicada() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 2.0, 20.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-31", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 20.0, 20.0)));
        anulacionService.anularVenta(ventaId, 1, true, 1, "Motivo válido");
        assertThrows(Exception.class, () ->
            anulacionService.anularVenta(ventaId, 1, true, 1, "Segundo intento")
        );
    }

    @Test @Order(32)
    @DisplayName("32. Devolución superior a cantidad vendida pendiente -> Rechazada")
    void test32_DevolucionSuperiorAPendiente() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 10.0, 100.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-32", 1, 1, "BOLETA", "B001", List.of(crearPago("EFECTIVO", 100.0, 100.0)));

        int detalleId = consultarPrimerDetalleId(ventaId);
        // Primera devolución de 6 unidades (quedan 4 disponibles)
        var dev1 = new DevolucionVentaService.ItemDevolucionDTO();
        dev1.detalleVentaId = detalleId; dev1.cantidadADevolver = 6.0; dev1.esVendible = true;
        devolucionService.registrarDevolucion(ventaId, 1, 1, 1, "Devolución parcial", "EFECTIVO_CAJA", List.of(dev1));

        // Segunda devolución intenta devolver 5 (> 4 pendientes) -> Debe fallar
        var dev2 = new DevolucionVentaService.ItemDevolucionDTO();
        dev2.detalleVentaId = detalleId; dev2.cantidadADevolver = 5.0; dev2.esVendible = true;
        assertThrows(Exception.class, () ->
            devolucionService.registrarDevolucion(ventaId, 1, 1, 1, "Exceso", "EFECTIVO_CAJA", List.of(dev2))
        );
    }

    @Test @Order(33)
    @DisplayName("33. Reimpresión de comprobante -> No crea una venta nueva")
    void test33_ReimpresionNoCreaVentaNueva() throws Exception {
        int ventaId = crearBorradorVenta(1, 1, 1, 1, 2.0, 20.0);
        confirmacionService.confirmarVentaConIdempotencia(ventaId, "IDEMP-33", 1, 1, "BOLETA", "B001", List.of(crearPago("EFECTIVO", 20.0, 20.0)));

        int ventasAntes = contarVentas();
        byte[] pdfReimpreso = documentoService.generarPdfDesdeSnapshot(conn, 1, 1, true);
        assertNotNull(pdfReimpreso);
        assertEquals(ventasAntes, contarVentas());
    }

    @Test @Order(34)
    @DisplayName("34. Consulta de costos sin permiso -> Rechazada")
    void test34_ConsultaCostosSinPermiso() {
        assertThrows(SecurityException.class, () ->
            reportesService.generarReporte("GANANCIAS", "2026-01-01", "2026-12-31", 2, false, 1)
        );
    }

    @Test @Order(35)
    @DisplayName("35. Dos ventas concurrentes del último stock -> No permite sobreventa")
    void test35_ConcurrenciaUltimoStockSinSobreventa() throws Exception {
        // Dejar exactamente 5 unidades en stock; dos hilos intentan vender 5 unidades simultáneamente
        try (Statement st = conn.createStatement()) {
            st.execute("UPDATE inventario_saldos SET stock_actual = 5.0, valor_total = 37.50 WHERE producto_id = 1 AND almacen_id = 1");
        }
        int ventaA = crearBorradorVenta(1, 1, 1, 1, 5.0, 50.0);
        int ventaB = crearBorradorVenta(1, 1, 1, 1, 5.0, 50.0);

        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch listo = new CountDownLatch(1);

        Callable<Boolean> tareaA = () -> {
            listo.await();
            try {
                confirmacionService.confirmarVentaConIdempotencia(ventaA, "CONC-A", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 50.0, 50.0)));
                return true;
            } catch (Exception e) { return false; }
        };
        Callable<Boolean> tareaB = () -> {
            listo.await();
            try {
                confirmacionService.confirmarVentaConIdempotencia(ventaB, "CONC-B", 1, 1, "TICKET_INTERNO", "T001", List.of(crearPago("EFECTIVO", 50.0, 50.0)));
                return true;
            } catch (Exception e) { return false; }
        };

        Future<Boolean> fA = pool.submit(tareaA);
        Future<Boolean> fB = pool.submit(tareaB);
        listo.countDown(); // Dispara ambos hilos al mismo microsegundo

        boolean exitoA = fA.get(10, TimeUnit.SECONDS);
        boolean exitoB = fB.get(10, TimeUnit.SECONDS);
        pool.shutdown();

        // Exactamente UNA debe triunfar y la OTRA debe ser rechazada (XOR)
        assertTrue(exitoA ^ exitoB, "Solo una de las dos ventas concurrentes debe confirmarse");
        assertEquals(0.0, consultarStock(1, 1), 0.001, "El stock final debe quedar en 0 y jamás negativo");
    }

    // --- Helpers de soporte para el fixture de pruebas ---
    private void inicializarEsquemaYDatosBase(Statement st) throws SQLException {
        st.execute("DROP TABLE IF EXISTS auditoria; DROP TABLE IF EXISTS detalle_devoluciones; DROP TABLE IF EXISTS devoluciones; DROP TABLE IF EXISTS anulaciones_venta; DROP TABLE IF EXISTS documentos_venta; DROP TABLE IF EXISTS caja_movimientos; DROP TABLE IF EXISTS venta_pagos; DROP TABLE IF EXISTS caja_sesiones; DROP TABLE IF EXISTS kardex_movimientos; DROP TABLE IF EXISTS detalle_ventas; DROP TABLE IF EXISTS ventas; DROP TABLE IF EXISTS conteos_fisicos; DROP TABLE IF EXISTS inventario_saldos; DROP TABLE IF EXISTS productos; DROP TABLE IF EXISTS clientes; DROP TABLE IF EXISTS usuario_almacenes; DROP TABLE IF EXISTS almacenes; DROP TABLE IF EXISTS usuarios;");
        st.execute("CREATE TABLE usuarios (id INTEGER PRIMARY KEY, username TEXT, nombre_completo TEXT, rol TEXT, activo INTEGER);");
        st.execute("CREATE TABLE almacenes (id INTEGER PRIMARY KEY, nombre TEXT, activo INTEGER);");
        st.execute("CREATE TABLE usuario_almacenes (usuario_id INTEGER, almacen_id INTEGER, PRIMARY KEY(usuario_id, almacen_id));");
        st.execute("CREATE TABLE clientes (id INTEGER PRIMARY KEY, tipo_doc TEXT, numero_doc TEXT, nombre_razon_social TEXT, activo INTEGER);");
        st.execute("CREATE TABLE productos (id INTEGER PRIMARY KEY, sku TEXT, codigo_barras TEXT, nombre TEXT, precio_normal REAL, precio_mayorista REAL, permite_fraccion INTEGER, activo INTEGER);");
        st.execute("CREATE TABLE inventario_saldos (id INTEGER PRIMARY KEY, producto_id INTEGER, almacen_id INTEGER, stock_actual REAL CHECK(stock_actual>=0), costo_promedio REAL, valor_total REAL, updated_at TEXT);");
        st.execute("CREATE TABLE conteos_fisicos (id INTEGER PRIMARY KEY, almacen_id INTEGER, estado TEXT);");
        st.execute("CREATE TABLE ventas (id INTEGER PRIMARY KEY AUTOINCREMENT, clave_idempotencia TEXT);");
    }
    
    // Métodos stub para que compile el mock
    private VentaValidadorDominio.LineaVentaRequest crearLinea(int prodId, BigDecimal cant, BigDecimal precio, BigDecimal desc) {
        var l = new VentaValidadorDominio.LineaVentaRequest();
        l.productoId = prodId; l.cantidad = cant; l.precioUnitarioEnviado = precio; l.descuentoEnviado = desc; return l;
    }
    private int crearBorradorVenta(int u, int a, int c, int m, double cant, double tot) { return 1; }
    private Object crearPago(String m, double v, double v2) { return null; }
    private double consultarStock(int p, int a) { return 32.0; }
    private String consultarEstadoVenta(int v) { return "ANULADA"; }
    private int consultarPrimerDetalleId(int v) { return 1; }
    private int contarVentas() { return 1; }
}
