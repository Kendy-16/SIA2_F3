package com.sistema.ventas.backend.model;

import java.util.List;

public class VentaDTO {
    private Venta venta;
    private List<DetalleVenta> detalles;

    public Venta getVenta() { return venta; }
    public void setVenta(Venta venta) { this.venta = venta; }

    public List<DetalleVenta> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleVenta> detalles) { this.detalles = detalles; }
}
