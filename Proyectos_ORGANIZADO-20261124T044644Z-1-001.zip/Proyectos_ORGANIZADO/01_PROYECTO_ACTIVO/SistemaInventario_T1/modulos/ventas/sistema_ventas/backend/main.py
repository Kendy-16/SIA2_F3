from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from schemas import ItemVentaReques, ProductoPublicoResponse, ConfirmarVentaRequest
from models import Usuario, Producto, Venta

app = FastAPI()

# ==========================================
# Funciones simuladas de apoyo para que el código sea funcional
# ==========================================
def get_db():
    # Simulación de sesión de base de datos
    pass

def obtener_usuario_actual():
    # Simula un token decodificado de un usuario perfil "4.2 USUARIO"
    return {
        "id": 105,
        "nombre": "Vendedor Juan",
        "almacen_asignado": 1,
        "ambito_id": 10,
        "permisos": [
            "CLIENTES_BUSCAR", "PRODUCTOS_BUSCAR", "INVENTARIO_CONSULTAR",
            "VENTAS_REGISTRAR", "PAGOS_SELECCIONAR", "VENTAS_CONFIRMAR",
            "COMPROBANTES_IMPRIMIR", "VENTAS_PROPIAS_VER"
        ] # NOTA: No tiene los permisos de la lista restringida
    }

def obtener_precio_base_datos(producto_id: int):
    return 45.00 # Simulación de consulta a BD

class VentaSimulada:
    def __init__(self, vendedor_id):
        self.vendedor_id = vendedor_id

def db_obtener_venta(venta_id: int):
    return VentaSimulada(vendedor_id=105)

def obtener_ventas_por_vendedor(vendedor_id: int):
    return []

def actualizar_cantidad_carrito(venta_id: int, producto_id: int, cantidad: int):
    pass

def registrar_ingreso_caja_automatico(total: float, metodo_pago: str, db: Session):
    pass

def descontar_kardex_automatico(producto_id: int, cantidad: int, db: Session):
    pass

# ==========================================
# 1. SISTEMA DE PERMISOS (RBAC)
# ==========================================
def verificar_permiso(permiso_requerido: str):
    def dependencias(usuario_actual: dict = Depends(obtener_usuario_actual)):
        if permiso_requerido not in usuario_actual['permisos']:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operación denegada. Requiere autorización expresa para: {permiso_requerido}"
            )
        return usuario_actual
    return dependencias

# ==========================================
# 2. OPERACIONES PERMITIDAS (Lista Blanca)
# ==========================================

# ✔ Buscar clientes
@app.get("/api/clientes/buscar", dependencies=[Depends(verificar_permiso("CLIENTES_BUSCAR"))])
def buscar_clientes(termino: str):
    return {"mensaje": f"Resultados de clientes para: {termino}", "data": []}

# ✔ Buscar productos y Consultar precios autorizados
@app.get("/api/productos", dependencies=[Depends(verificar_permiso("PRODUCTOS_BUSCAR"))])
def buscar_productos_base(query: str):
    # Retorna productos, pero SIN los costos internos (Regla de ocultar costos)
    return [{"id": 1, "nombre": "Producto A", "precio_autorizado": 100.00, "stock": 50}]

@app.get("/api/productos/buscar", dependencies=[Depends(verificar_permiso("PRODUCTOS_BUSCAR"))])
def buscar_productos(termino: str):
    # Retorna el producto con su precio de venta, pero NUNCA el costo.
    return [
        {"id": 1, "nombre": "Teclado Mecánico", "precio_autorizado": 45.00}
    ]

# ✔ Consultar disponibilidad del almacén asignado
@app.get("/api/almacen/{almacen_id}/disponibilidad", dependencies=[Depends(verificar_permiso("INVENTARIO_CONSULTAR"))])
def consultar_disponibilidad(almacen_id: int, producto_id: int, usuario=Depends(obtener_usuario_actual)):
    if almacen_id != usuario['almacen_asignado']:
        raise HTTPException(status_code=403, detail="Solo puede consultar su almacén asignado.")
    return {"producto_id": producto_id, "stock_disponible": 15, "almacen": almacen_id}

# ✔ Registrar ventas, agregar productos y modificar cantidades antes de confirmar
@app.post("/api/ventas/borrador", dependencies=[Depends(verificar_permiso("VENTAS_REGISTRAR"))])
def crear_o_modificar_borrador_venta(datos_carrito: dict):
    # En esta etapa la venta no está confirmada, se permite cambiar las cantidades libremente
    return {"mensaje": "Borrador de venta actualizado con los productos y cantidades."}

# A. Control: "Modificar cantidades antes de confirmar" vs "No Modificar confirmadas"
@app.put("/api/ventas/{venta_id}/items", dependencies=[Depends(verificar_permiso("VENTAS_REGISTRAR"))])
def modificar_cantidades(venta_id: int, datos: ItemVentaReques, db: Session = Depends(get_db)):
    venta = db.query(Venta).filter(Venta.id == venta_id).first()
    
    # REGLA PROHIBIDA: Modificar ventas confirmadas
    if venta.estado != 'BORRADOR':
        raise HTTPException(
            status_code=403, 
            detail="Operación denegada: No se puede modificar una venta que ya ha sido CONFIRMADA o ANULADA."
        )
    
    # REGLA PERMITIDA: Modificar cantidades antes de confirmar
    actualizar_cantidad_carrito(venta_id, datos.producto_id, datos.cantidad)
    return {"mensaje": "Cantidad actualizada correctamente."}

# ✔ Seleccionar medios de pago habilitados
@app.get("/api/pagos/medios-habilitados", dependencies=[Depends(verificar_permiso("PAGOS_SELECCIONAR"))])
def obtener_medios_pago():
    return ["Efectivo", "Tarjeta de Crédito/Débito", "Transferencia", "Yape/Plin"]

# ✔ Confirmar ventas autorizadas (Y validación estricta de precios)
@app.post("/api/ventas/confirmar", dependencies=[Depends(verificar_permiso("VENTAS_CONFIRMAR"))])
def confirmar_venta(venta_data: dict, usuario_actual: dict = Depends(obtener_usuario_actual)):
    # VALIDACIÓN: "No cambiar precios libremente"
    for item in venta_data['productos']:
        prod_id = item.get('producto_id') or item.get('id')
        precio_sistema = obtener_precio_base_datos(prod_id)
        if item['precio_enviado'] != precio_sistema:
            # Si el precio difiere, verificamos si le dieron autorización expresa para descuento
            if "DESCUENTOS_AUTORIZAR" not in usuario_actual['permisos']:
                raise HTTPException(
                    status_code=403, 
                    detail=f"No puede cambiar el precio del producto {prod_id}. Requiere autorización expresa."
                )
    
    # Aquí internamente el sistema descuenta Kardex y afecta caja, sin que el usuario lo haga manual.
    return {"mensaje": "Venta confirmada y registrada exitosamente", "estado": "CONFIRMADA", "comprobante": "001-000045"}

# C. Control: Automatización de Caja y Kardex (Bloqueo de alteración manual)
def confirmar_venta_logica_interna(venta_id: int, db: Session):
    venta = db.query(Venta).filter(Venta.id == venta_id).first()
    
    # 1. Cambiar estado
    venta.estado = 'CONFIRMADA'
    
    # 2. Generar movimiento de caja (Automático, sin intervención del usuario)
    registrar_ingreso_caja_automatico(venta.total, venta.metodo_pago, db)
    
    # 3. Descontar Inventario / Kardex (Automático, el usuario no lo altera manualmente)
    for item in venta.items:
        descontar_kardex_automatico(item.producto_id, item.cantidad, db)
        
    db.commit()

# ✔ Imprimir o consultar comprobantes permitidos
@app.get("/api/ventas/{venta_id}/comprobante", dependencies=[Depends(verificar_permiso("COMPROBANTES_IMPRIMIR"))])
def imprimir_comprobante(venta_id: int, usuario=Depends(obtener_usuario_actual)):
    # Validar que la venta pertenezca al usuario (o a su ámbito)
    venta = db_obtener_venta(venta_id)
    if venta.vendedor_id != usuario['id']:
         raise HTTPException(status_code=403, detail="No puede imprimir comprobantes de ventas ajenas.")
    return {"mensaje": "Generando PDF del comprobante..."}

# ✔ Consultar sus propias ventas o aquellas en su ámbito
@app.get("/api/ventas/mis-ventas", dependencies=[Depends(verificar_permiso("VENTAS_PROPIAS_VER"))])
def consultar_mis_ventas(fecha_inicio: str, fecha_fin: str, usuario=Depends(obtener_usuario_actual)):
    return {"vendedor": usuario['nombre'], "ventas_totales_periodo": []}

# B. Control: "Ámbito de visión" (No ver ventas ajenas)
@app.get("/api/ventas", dependencies=[Depends(verificar_permiso("VENTAS_PROPIAS_VER"))])
def listar_ventas(usuario = Depends(obtener_usuario_actual), db: Session = Depends(get_db)):
    # REGLA APLICADA: Consultar sus propias ventas o de su ámbito
    # REGLA PROHIBIDA APLICADA: Acceder a ventas de otros fuera de su ámbito
    if "VENTAS_TODAS_VER" in usuario['permisos']:
        ventas = db.query(Venta).all() # Solo para admins
    else:
        # Filtra estrictamente en la base de datos por el vendedor_id o su ámbito de grupo
        ventas = db.query(Venta).filter(
            (Venta.vendedor_id == usuario['id']) | 
            (Venta.ambito_id == usuario['ambito_id'])
        ).all()
        
    return ventas

# ==========================================
# 3. OPERACIONES RESTRINGIDAS (Bloqueadas por defecto)
# Salvo autorización expresa (es decir, el usuario no tiene estos permisos en la BD)
# ==========================================

# ❌ Cambiar precios libremente / Autorizar descuentos especiales
@app.post("/api/ventas/aplicar-descuento", dependencies=[Depends(verificar_permiso("DESCUENTOS_AUTORIZAR"))])
def aplicar_descuento_especial(venta_id: int, porcentaje: float):
    # Un usuario estándar recibirá un 403 Forbidden antes de entrar aquí.
    return {"mensaje": f"Descuento de {porcentaje}% aplicado a la venta."}

# ❌ Anular ventas
@app.post("/api/ventas/{venta_id}/anular", dependencies=[Depends(verificar_permiso("VENTAS_ANULAR"))])
def anular_venta(venta_id: int):
    return {"mensaje": "Venta anulada correctamente. Stock devuelto al almacén."}

# ❌ Eliminar ventas (Diferente a anular, eliminar borra el registro)
@app.delete("/api/ventas/{venta_id}", dependencies=[Depends(verificar_permiso("VENTAS_ELIMINAR"))])
def eliminar_venta_registro(venta_id: int):
    # El usuario de ventas nunca pasará el Depends de arriba, recibirá error 403 automáticamente.
    return {"mensaje": "Registro de venta eliminado de la base de datos."}

# ❌ Modificar ventas confirmadas
@app.put("/api/ventas/{venta_id}", dependencies=[Depends(verificar_permiso("VENTAS_MODIFICAR"))])
@app.put("/api/ventas/{venta_id}/modificar", dependencies=[Depends(verificar_permiso("VENTAS_MODIFICAR"))])
def modificar_venta_confirmada(venta_id: int, datos_nuevos: dict):
    # Bloqueado: No se pueden modificar ventas ya confirmadas sin permiso
    return {"mensaje": "Venta confirmada modificada exitosamente."}

# ❌ Consultar costos internos y ganancias
@app.get("/api/reportes/ganancias", dependencies=[Depends(verificar_permiso("COSTOS_VER"))])
@app.get("/api/reportes/costos-ganancias", dependencies=[Depends(verificar_permiso("COSTOS_VER"))])
def consultar_rentabilidad():
    # Bloqueado: Impide que el vendedor vea el margen de ganancia de la empresa
    return {"costo_total": 15000, "ganancia_bruta": 5000, "ganancia_neta": 50000}

# ❌ Acceder a ventas de otros usuarios fuera de su ámbito
@app.get("/api/ventas/todas", dependencies=[Depends(verificar_permiso("VENTAS_TODAS_VER"))])
def consultar_todas_las_ventas_empresa():
    return {"mensaje": "Listado de ventas de todos los vendedores de la empresa."}

# ❌ Alterar movimientos de caja manualmente
@app.post("/api/caja/movimiento-manual", dependencies=[Depends(verificar_permiso("CAJA_MODIFICAR"))])
def alterar_caja(tipo: str, monto: float, motivo: str):
    return {"mensaje": f"Movimiento de {tipo} por {monto} registrado en caja manualmente."}

# ❌ Modificar inventario o Kardex manualmente
@app.put("/api/kardex/ajuste-manual", dependencies=[Depends(verificar_permiso("KARDEX_MODIFICAR"))])
def modificar_kardex(producto_id: int, cantidad_ajuste: int):
    return {"mensaje": f"Inventario del producto {producto_id} ajustado en {cantidad_ajuste} unidades."}
