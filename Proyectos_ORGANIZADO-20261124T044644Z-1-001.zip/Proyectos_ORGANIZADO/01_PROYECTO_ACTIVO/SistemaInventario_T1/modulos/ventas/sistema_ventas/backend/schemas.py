from pydantic import BaseModel, Field
from typing import List

# ==========================================
# FILTRO DE SALIDA: Bloquear costos y ganancias
# ==========================================
class ProductoPublicoResponse(BaseModel):
    id: int
    nombre: str
    precio_venta: float
    # NOTA: Omitimos intencionalmente 'costo_interno'
    # REGLA APLICADA: No debe consultar costos internos.

# ==========================================
# FILTRO DE ENTRADA: Validar cantidades y precios
# ==========================================
class ItemVentaReques(BaseModel):
    producto_id: int
    cantidad: int = Field(gt=0, description="Debe ser mayor a 0")
    precio_enviado: float # Se comparará estrictamente en el backend

class ConfirmarVentaRequest(BaseModel):
    cliente_id: int
    metodo_pago: str # REGLA: Medios de pago habilitados (Efectivo, Tarjeta, etc)
    items: List[ItemVentaReques]
