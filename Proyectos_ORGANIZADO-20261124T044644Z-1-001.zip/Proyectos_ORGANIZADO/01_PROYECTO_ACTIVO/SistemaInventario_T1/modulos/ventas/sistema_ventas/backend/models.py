from sqlalchemy import Column, Integer, String, Float, ForeignKey, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True)
    rol = Column(String) # Ejemplo: 'USUARIO_VENTAS'
    almacen_id = Column(Integer, ForeignKey("almacenes.id")) # REGLA: Almacén asignado
    ambito_id = Column(Integer, ForeignKey("grupos_ventas.id")) # REGLA: Ámbito de visión

class Producto(Base):
    __tablename__ = "productos"
    id = Column(Integer, primary_key=True)
    nombre = Column(String)
    precio_venta = Column(Float) # REGLA: Precio autorizado
    costo_interno = Column(Float) # REGLA PROHIBIDA: Consultar costos (Se oculta en los esquemas)

class Venta(Base):
    __tablename__ = "ventas"
    id = Column(Integer, primary_key=True)
    vendedor_id = Column(Integer, ForeignKey("usuarios.id"))
    ambito_id = Column(Integer, ForeignKey("grupos_ventas.id"))
    estado = Column(Enum('BORRADOR', 'CONFIRMADA', 'ANULADA')) # REGLA: Control de modificaciones
    metodo_pago = Column(String)
    total = Column(Float)
