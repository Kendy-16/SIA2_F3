import { PoolClient } from 'pg';
import { db } from './database'; // Pool de conexiones PostgreSQL

// Interfaces de entrada
interface ItemVentaDTO {
  productoId: number;
  cantidad: number;
  precioUnitario: number;
}

interface PagoVentaDTO {
  metodoPago: 'EFECTIVO' | 'TARJETA' | 'YAPE' | 'PLIN' | 'TRANSFERENCIA';
  monto: number;
  referenciaOperacion?: string;
}

interface ConfirmarVentaDTO {
  ventaId: number;
  usuarioId: number;
  cajaSesionId: number;
  pagos: PagoVentaDTO[];
}

export class VentaInventarioService {

  /**
   * 8.1 VALIDACIÓN PREVIA (Lectura rápida antes de abrir bloqueo transaccional)
   */
  async validarPrecondicionesVenta(ventaId: number, usuarioId: number): Promise<void> {
    // Obtener cabecera de venta
    const ventaRes = await db.query(
      `SELECT id, almacen_id, estado FROM ventas WHERE id = $1`,
      [ventaId]
    );
    if (ventaRes.rowCount === 0) throw new Error('La venta no existe.');
    const venta = ventaRes.rows[0];
    if (venta.estado !== 'BORRADOR') throw new Error(`La venta ya está en estado ${venta.estado}.`);

    // 3. Verificar que el almacén exista y esté activo
    const almRes = await db.query(
      `SELECT activo FROM almacenes WHERE id = $1`,
      [venta.almacen_id]
    );
    if (almRes.rowCount === 0 || !almRes.rows[0].activo) {
      throw new Error('El almacén no existe o se encuentra inactivo.');
    }

    // 4. Comprobar que el usuario tenga acceso al almacén
    const permisoRes = await db.query(
      `SELECT 1 FROM usuario_almacenes WHERE usuario_id = $1 AND almacen_id = $2`,
      [usuarioId, venta.almacen_id]
    );
    if (permisoRes.rowCount === 0) {
      throw new Error('El usuario no tiene permisos para operar en este almacén.');
    }

    // 7. Comprobar que no exista un conteo físico abierto que impida la operación
    const conteoRes = await db.query(
      `SELECT id FROM conteos_fisicos WHERE almacen_id = $1 AND estado = 'ABIERTO'`,
      [venta.almacen_id]
    );
    if (conteoRes.rowCount > 0) {
      throw new Error('Operación bloqueada: Existe un conteo físico abierto en este almacén.');
    }

    // Validar ítems (1, 2, 5, 6)
    const itemsRes = await db.query(
      `SELECT vd.producto_id, vd.cantidad, p.nombre, p.activo, COALESCE(s.stock_actual, 0) as stock_actual
       FROM venta_detalles vd
       LEFT JOIN productos p ON p.id = vd.producto_id
       LEFT JOIN inventario_saldos s ON s.producto_id = vd.producto_id AND s.almacen_id = $2
       WHERE vd.venta_id = $1`,
      [ventaId, venta.almacen_id]
    );

    if (itemsRes.rowCount === 0) throw new Error('La venta no tiene productos.');

    for (const item of itemsRes.rows) {
      // 1. Verificar que el producto exista
      if (!item.nombre) throw new Error(`El producto ID ${item.producto_id} no existe.`);
      // 2. Verificar que esté activo
      if (!item.activo) throw new Error(`El producto "${item.nombre}" está inactivo.`);
      // 5 y 6. Consultar saldo disponible y comprobar cantidad <= stock
      if (Number(item.cantidad) > Number(item.stock_actual)) {
        throw new Error(
          `Stock insuficiente para "${item.nombre}". Solicitado: ${item.cantidad}, Disponible: ${item.stock_actual}.`
        );
      }
    }
  }

  /**
   * CONFIRMACIÓN DE VENTA CON BLOQUEO TRANSACCIONAL (8.1.8, 8.2, 8.3, 8.4 y 9)
   */
  async confirmarVenta(payload: ConfirmarVentaDTO): Promise<{ mensaje: string; ventaId: number }> {
    // Ejecutar validación previa rápida
    await this.validarPrecondicionesVenta(payload.ventaId, payload.usuarioId);

    const client: PoolClient = await db.connect();

    try {
      // INICIO DE TRANSACCIÓN ATÓMICA
      await client.query('BEGIN');

      // Bloquear fila de la venta para evitar doble confirmación simultánea
      const ventaLock = await client.query(
        `SELECT id, numero_documento, almacen_id, total_venta, estado 
         FROM ventas WHERE id = $1 FOR UPDATE`,
        [payload.ventaId]
      );
      const venta = ventaLock.rows[0];

      if (venta.estado !== 'BORRADOR') {
        throw new Error('La venta ya fue procesada por otra transacción.');
      }

      // 8.1.8 REVALIDAR DENTRO DE LA OPERACIÓN TRANSACCIONAL (Conteo físico y permisos)
      const conteoLock = await client.query(
        `SELECT id FROM conteos_fisicos WHERE almacen_id = $1 AND estado = 'ABIERTO' FOR SHARE`,
        [venta.almacen_id]
      );
      if (conteoLock.rowCount > 0) {
        throw new Error('Se abrió un conteo físico durante el proceso. Operación abortada.');
      }

      // Obtener detalles ordenados por producto_id (previene Deadlocks entre transacciones)
      const detallesRes = await client.query(
        `SELECT vd.id, vd.producto_id, vd.cantidad, p.activo, p.nombre
         FROM venta_detalles vd
         JOIN productos p ON p.id = vd.producto_id
         WHERE vd.venta_id = $1
         ORDER BY vd.producto_id ASC`,
        [venta.id]
      );

      for (const item of detallesRes.rows) {
        if (!item.activo) {
          throw new Error(`El producto "${item.nombre}" fue desactivado antes de confirmar.`);
        }

        // BLOQUEO PESIMISTA (FOR UPDATE) EN EL SALDO DEL PRODUCTO
        // Garantiza que ninguna otra venta lea o modifique este stock hasta que hagamos COMMIT
        const saldoRes = await client.query(
          `SELECT id, stock_actual, costo_promedio, valor_total 
           FROM inventario_saldos 
           WHERE producto_id = $1 AND almacen_id = $2 
           FOR UPDATE`,
          [item.producto_id, venta.almacen_id]
        );

        if (saldoRes.rowCount === 0) {
          throw new Error(`No existe registro de saldo para "${item.nombre}" en este almacén.`);
        }

        const saldo = saldoRes.rows[0];
        const stockActual = Number(saldo.stock_actual);       // Ej: 40
        const cantidadVendida = Number(item.cantidad);        // Ej: 8
        const costoPromedioVigente = Number(saldo.costo_promedio); // Ej: 7.50

        // Revalidación final de stock negativo (8.1.6 y 8.2)
        if (cantidadVendida > stockActual) {
          throw new Error(
            `Concurrencia detectada: Stock insuficiente para "${item.nombre}". Disponible: ${stockActual}`
          );
        }

        // =========================================================================
        // 8.2 ACTUALIZACIÓN DEL INVENTARIO
        // StockNuevo = StockActual - CantidadVendida
        // =========================================================================
        const stockNuevo = Number((stockActual - cantidadVendida).toFixed(4)); // 40 - 8 = 32
        if (stockNuevo < 0) {
          throw new Error('Error crítico: El stock resultante no puede ser negativo.');
        }

        // =========================================================================
        // 8.3 COSTO PROMEDIO PONDERADO MÓVIL
        // En salida por venta, el costo promedio se conserva intacto.
        // =========================================================================
        const costoSalida = Number((cantidadVendida * costoPromedioVigente).toFixed(4)); // 8 * 7.50 = 60.00
        const valorNuevoInventario = Number((stockNuevo * costoPromedioVigente).toFixed(4)); // 32 * 7.50 = 240.00
        const costoPromedioFinal = costoPromedioVigente; // Sigue siendo 7.50

        // Actualizar tabla maestra de saldos
        await client.query(
          `UPDATE inventario_saldos 
           SET stock_actual = $1, 
               valor_total = $2, 
               costo_promedio = $3,
               updated_at = NOW()
           WHERE id = $4`,
          [stockNuevo, valorNuevoInventario, costoPromedioFinal, saldo.id]
        );

        // Guardar costo unitario histórico en el detalle de la venta
        await client.query(
          `UPDATE venta_detalles SET costo_unitario_salida = $1 WHERE id = $2`,
          [costoPromedioFinal, item.id]
        );

        // =========================================================================
        // 8.4 REGISTRO EN KARDEX
        // Garantiza que no exista descuento sin Kardex ni Kardex sin descuento
        // =========================================================================
        await client.query(
          `INSERT INTO kardex_movimientos (
            producto_id, almacen_id, tipo_movimiento, documento_referencia, venta_id,
            saldo_anterior, entrada, salida, saldo_nuevo,
            costo_unitario, costo_promedio, valor_saldo
          ) VALUES ($1, $2, 'SALIDA_VENTA', $3, $4, $5, 0, $6, $7, $8, $9, $10)`,
          [
            item.producto_id,
            venta.almacen_id,
            venta.numero_documento, // Referencia comercial (Ej: F001-000045)
            venta.id,               // FK directa a la venta
            stockActual,            // Saldo anterior: 40
            cantidadVendida,        // Salida: 8
            stockNuevo,             // Saldo nuevo: 32
            costoPromedioFinal,     // Costo unitario: S/ 7.50
            costoPromedioFinal,     // Costo promedio: S/ 7.50
            valorNuevoInventario    // Valor del saldo: S/ 240.00
          ]
        );
      }

      // =========================================================================
      // 9. INTEGRACIÓN CON CAJA Y PAGOS (Múltiples pagos por venta)
      // =========================================================================
      await this.registrarPagosVenta(client, venta, payload.cajaSesionId, payload.pagos);

      // Cambiar estado de la venta a CONFIRMADA
      await client.query(
        `UPDATE ventas 
         SET estado = 'CONFIRMADA', fecha_confirmacion = NOW() 
         WHERE id = $1`,
        [venta.id]
      );

      // CONFIRMAR TODA LA OPERACIÓN ATÓMICAMENTE
      await client.query('COMMIT');

      return {
        mensaje: `Venta ${venta.numero_documento} confirmada, inventario descontado y Kardex registrado.`,
        ventaId: venta.id
      };

    } catch (error) {
      // SI FALLA KARDEX, STOCK O CAJA -> SE REVIERTE ABSOLUTAMENTE TODO
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * 9. Lógica de validación y registro de uno o varios pagos en Caja
   */
  private async registrarPagosVenta(
    client: PoolClient,
    venta: any,
    cajaSesionId: number,
    pagos: PagoVentaDTO[]
  ): Promise<void> {
    if (!pagos || pagos.length === 0) {
      throw new Error('Debe registrar al menos un pago para confirmar la venta.');
    }

    // Verificar que la sesión de caja esté abierta
    const cajaRes = await client.query(
      `SELECT estado FROM caja_sesiones WHERE id = $1 FOR SHARE`,
      [cajaSesionId]
    );
    if (cajaRes.rowCount === 0 || cajaRes.rows[0].estado !== 'ABIERTA') {
      throw new Error('La sesión de caja no existe o está cerrada.');
    }

    // Validar que la suma de los pagos coincida con el total de la venta
    const sumaPagos = pagos.reduce((acc, p) => acc + Number(p.monto), 0);
    const totalVenta = Number(venta.total_venta);

    if (Math.abs(sumaPagos - totalVenta) > 0.01) {
      throw new Error(
        `El monto pagado (${sumaPagos.toFixed(2)}) no coincide con el total de la venta (${totalVenta.toFixed(2)}).`
      );
    }

    // Insertar cada pago (soporta pagos mixtos: Ej. S/ 50 Efectivo + S/ 30 Yape)
    for (const pago of pagos) {
      await client.query(
        `INSERT INTO venta_pagos (venta_id, caja_sesion_id, metodo_pago, monto, referencia_operacion)
         VALUES ($1, $2, $3, $4, $5)`,
        [venta.id, cajaSesionId, pago.metodoPago, pago.monto, pago.referenciaOperacion || null]
      );
    }
  }
}
