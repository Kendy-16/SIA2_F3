package com.sistema.ventas.validadores;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.modelos.Cliente;
import com.sistema.ventas.modelos.TipoComprobante;
import com.sistema.ventas.dao.ClienteDAO;

public class ValidadorClienteVista {
    
    private ClienteDAO clienteDAO;

    public Cliente validarCliente(String documentoIngresado, TipoComprobante comprobanteSeleccionado) 
            throws VistaValidationException {
        
        // 1. Debe seleccionarse cuando sea obligatorio
        if (comprobanteSeleccionado.requiereCliente() && (documentoIngresado == null || documentoIngresado.trim().isEmpty())) {
            throw new VistaValidationException("El cliente es obligatorio para un comprobante de tipo: " + comprobanteSeleccionado.getNombre());
        }

        // Si no es obligatorio y está vacío, retorna un cliente genérico/público en general
        if (documentoIngresado == null || documentoIngresado.trim().isEmpty()) {
            return clienteDAO.obtenerClientePublicoGeneral();
        }

        // 2. Identificador: Debe corresponder a un cliente existente
        Cliente cliente = clienteDAO.buscarPorDocumento(documentoIngresado);
        if (cliente == null) {
            throw new VistaValidationException("El documento ingresado no corresponde a un cliente existente.");
        }

        // 3. Documento: Validar formato según tipo de documento (La regla viene del objeto, no se inventa en la vista)
        String regexFormato = cliente.getTipoDocumento().getRegexValidacion(); 
        if (!documentoIngresado.matches(regexFormato)) {
            throw new VistaValidationException("El formato del documento es incorrecto para el tipo: " + cliente.getTipoDocumento().getNombre());
        }

        // 4. Nombre o razón social: No debe quedar vacío
        if (cliente.getRazonSocial() == null || cliente.getRazonSocial().trim().isEmpty()) {
            throw new VistaValidationException("Inconsistencia de datos: El cliente no posee nombre o razón social registrada.");
        }

        // 5. Estado: No permitir clientes inhabilitados
        if (!cliente.isActivo() || cliente.isInhabilitadoPorPoliticas()) {
            throw new VistaValidationException("El cliente se encuentra INHABILITADO según las políticas de la empresa.");
        }

        // 6. Dirección: Validar si el comprobante la requiere (Ej: Facturas)
        if (comprobanteSeleccionado.requiereDireccion() && 
           (cliente.getDireccion() == null || cliente.getDireccion().trim().isEmpty())) {
            throw new VistaValidationException("Este comprobante exige una dirección fiscal válida. Actualice los datos del cliente.");
        }

        // 7. Tipo de cliente: Verificar condiciones comerciales
        if (!comprobanteSeleccionado.esCompatibleConCondicionComercial(cliente.getTipoCliente())) {
            throw new VistaValidationException("Las condiciones comerciales del cliente (" + cliente.getTipoCliente().getNombre() + ") no permiten esta operación.");
        }

        return cliente;
    }
}
