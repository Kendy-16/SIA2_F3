package com.sistema.ventas.ui;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.validadores.*;
import com.sistema.ventas.modelos.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;

public class ControladorVistaVentas {

    private ValidadorDetalleVista validadorDetalle;
    private ValidadorFinancieroVista validadorFinanciero;
    private ValidadorDescuentoGlobalVista validadorDescuentoGlobal;
    private ValidadorCierreVentaVista validadorCierre;
    
    private List<DetalleVenta> carritoList = new ArrayList<>();
    private Almacen almacenActivo;
    private ModalidadVenta modalidad;
    private Usuario usuarioActivo;
    private VentaDTO ventaActiva;

    public void btnAgregarAlCarrito_Click() {
        try {
            Producto prod = validadorDetalle.validarDatosProducto(txtCodigo.getText(), txtBarras.getText(), almacenActivo);
            BigDecimal cant = validadorDetalle.validarCantidad(txtCantidad.getText(), prod, carritoList);
            BigDecimal prec = validadorFinanciero.validarPrecio(txtPrecio.getText(), prod, modalidad, usuarioActivo);
            
            // Consolidación en UI
            DetalleVenta lineaExistente = buscarLineaEnCarrito(prod);
            if (lineaExistente != null) {
                // Actualiza sumando cantidad (El validador de cantidad ya autorizó que el stock soporta la suma)
                lineaExistente.setCantidad(lineaExistente.getCantidad().add(cant));
            } else {
                // Crea nueva línea
                DetalleVenta nuevaLinea = new DetalleVenta(prod, cant, prec);
                carritoList.add(nuevaLinea);
            }
            
            refrescarGrilla();
            
        } catch (VistaValidationException ex) {
            // Muestra el error de captura en un Modal/Tooltip SIN ir al backend controlador general aún
            MessageBox.showError(ex.getMessage()); 
        }
    }

    public void btnCobrarVenta_Click() {
        try {
            validadorCierre.validarVentaListaParaEnviar(ventaActiva);
        } catch (VistaValidationException ex) {
            MessageBox.showError(ex.getMessage());
        }
    }

    private DetalleVenta buscarLineaEnCarrito(Producto prod) {
        return carritoList.stream()
                .filter(d -> d.getProducto().getId().equals(prod.getId()))
                .findFirst()
                .orElse(null);
    }

    private void refrescarGrilla() {}
}
