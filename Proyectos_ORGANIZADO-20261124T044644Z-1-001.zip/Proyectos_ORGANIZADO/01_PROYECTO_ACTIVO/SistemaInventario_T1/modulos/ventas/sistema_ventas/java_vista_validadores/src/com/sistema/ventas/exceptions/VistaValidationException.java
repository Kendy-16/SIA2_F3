package com.sistema.ventas.exceptions;

// Excepción personalizada para la Vista
public class VistaValidationException extends Exception {
    public VistaValidationException(String mensaje) { super(mensaje); }
}
