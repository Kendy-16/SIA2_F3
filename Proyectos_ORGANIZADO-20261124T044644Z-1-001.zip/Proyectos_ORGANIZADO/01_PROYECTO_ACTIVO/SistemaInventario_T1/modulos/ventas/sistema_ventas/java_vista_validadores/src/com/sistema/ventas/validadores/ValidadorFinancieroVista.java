package com.sistema.ventas.validadores;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.modelos.Producto;
import com.sistema.ventas.modelos.ModalidadVenta;
import com.sistema.ventas.modelos.Usuario;
import com.sistema.ventas.modelos.TipoDescuento;
import com.sistema.ventas.modelos.DetalleVenta;
import com.sistema.ventas.modelos.DetalleDescuento;
import java.math.BigDecimal;

public class ValidadorFinancieroVista {

    public BigDecimal validarPrecio(String precioIngresadoStr, Producto producto, ModalidadVenta modalidad, Usuario usuarioLogueado) 
            throws VistaValidationException {
        
        // 1. Recuperar precio de la fuente autorizada (Vista no determina unilateralmente)
        BigDecimal precioVigente = producto.getPrecioVigente(modalidad); // Validar la modalidad normal o mayorista

        // 2. Valores nulos
        if (precioIngresadoStr == null || precioIngresadoStr.trim().isEmpty()) {
            throw new VistaValidationException("El precio no puede estar vacío.");
        }

        BigDecimal precioFinal = new BigDecimal(precioIngresadoStr);

        // 3. No aceptar precios negativos
        if (precioFinal.compareTo(BigDecimal.ZERO) < 0) {
            throw new VistaValidationException("No se permiten precios negativos.");
        }

        // 4. Validar modificaciones de precio
        if (precioFinal.compareTo(precioVigente) != 0) {
            // Verificar permisos
            if (!usuarioLogueado.tienePermiso("MODIFICAR_PRECIOS")) {
                throw new VistaValidationException("No tiene los permisos necesarios para modificar el precio base del producto.");
            }
            
            // 5. Restricciones comerciales (Ej: no vender por debajo del costo + margen mínimo)
            BigDecimal precioMinimoPermitido = producto.getPrecioMinimoComercial();
            if (precioFinal.compareTo(precioMinimoPermitido) < 0) {
                throw new VistaValidationException("El precio modificado incumple las restricciones comerciales (Menor al mínimo permitido: " + precioMinimoPermitido + ").");
            }
        }

        // Retorna el precio que luego se guardará obligatoriamente en la entidad DetalleVenta (registrar precio aplicado)
        return precioFinal;
    }

    public DetalleDescuento validarDescuento(String descuentoStr, TipoDescuento tipo, BigDecimal subtotal, 
                                             Usuario usuario, DetalleVenta lineaActual, String motivo) 
            throws VistaValidationException {
        
        // Evitar valores nulos
        if (descuentoStr == null || descuentoStr.trim().isEmpty()) return null;

        BigDecimal valorDescuento = new BigDecimal(descuentoStr);

        // 1. No aceptar descuentos negativos
        if (valorDescuento.compareTo(BigDecimal.ZERO) < 0) {
            throw new VistaValidationException("Los descuentos no pueden ser negativos.");
        }
        if (valorDescuento.compareTo(BigDecimal.ZERO) == 0) return null;

        // 2. Evitar aplicar dos veces un mismo descuento
        if (lineaActual.tieneDescuentoActivo()) {
            throw new VistaValidationException("Esta línea de producto ya tiene un descuento individual aplicado.");
        }

        // 3. Validar si es porcentual o monetario y calcular
        BigDecimal montoADescontar;
        if (tipo == TipoDescuento.PORCENTUAL) {
            montoADescontar = subtotal.multiply(valorDescuento).divide(new BigDecimal("100"));
        } else { // MONETARIO
            montoADescontar = valorDescuento;
        }

        // 4. Evitar que el descuento supere el subtotal
        if (montoADescontar.compareTo(subtotal) >= 0) {
            throw new VistaValidationException("El descuento aplicado no puede ser igual o mayor al subtotal de la línea.");
        }

        // 5. Comprobar permisos y límite autorizado
        BigDecimal limiteUsuario = usuario.getLimiteDescuento(tipo);
        if (valorDescuento.compareTo(limiteUsuario) > 0) {
            throw new VistaValidationException("El descuento supera el límite autorizado para su perfil (" + limiteUsuario + (tipo == TipoDescuento.PORCENTUAL ? "%" : "$") + ").");
        }

        // 6. Mostrar el motivo cuando sea requerido
        if (montoADescontar.compareTo(usuario.getUmbralDescuentoSinMotivo()) > 0) {
            if (motivo == null || motivo.trim().isEmpty()) {
                throw new VistaValidationException("Se requiere obligatoriamente redactar un motivo para descuentos superiores a " + usuario.getUmbralDescuentoSinMotivo() + ".");
            }
        }

        // 7. Guardar el descuento efectivamente aplicado (Retorna el DTO que será inyectado a la línea)
        return new DetalleDescuento(tipo, valorDescuento, montoADescontar, motivo);
    }
}
