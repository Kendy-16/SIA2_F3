package com.sistema.ventas.validadores;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.modelos.DescuentoGlobal;
import com.sistema.ventas.modelos.TipoDescuento;
import com.sistema.ventas.modelos.DetalleVenta;
import com.sistema.ventas.modelos.Usuario;
import java.math.BigDecimal;
import java.util.List;

public class ValidadorDescuentoGlobalVista {

    public DescuentoGlobal validarDescuentoGlobal(String descuentoStr, TipoDescuento tipo, 
                                                  List<DetalleVenta> carritoActual, Usuario usuario, 
                                                  String motivo) throws VistaValidationException {
        
        if (descuentoStr == null || descuentoStr.trim().isEmpty()) {
            throw new VistaValidationException("Ingrese un valor para el descuento global.");
        }

        BigDecimal valorDescuento = new BigDecimal(descuentoStr);

        // 1. No aceptar descuentos negativos ni en cero
        if (valorDescuento.compareTo(BigDecimal.ZERO) <= 0) {
            throw new VistaValidationException("El descuento global debe ser mayor a cero.");
        }

        // 2. Interacción: Validar el descuento individual y el global
        // Regla de negocio típica: Si ya hay productos con descuento individual, advertir o bloquear el global.
        boolean tieneDescuentosIndividuales = carritoActual.stream().anyMatch(DetalleVenta::tieneDescuentoActivo);
        if (tieneDescuentosIndividuales && !usuario.tienePermiso("ACUMULAR_DESCUENTOS")) {
            throw new VistaValidationException("El carrito ya contiene productos con descuentos individuales. Su perfil no permite acumular un descuento global sobre los individuales.");
        }

        // 3. Calcular el total actual sin el descuento global
        BigDecimal totalParcial = calcularTotalCarrito(carritoActual);
        
        // 4. Calcular el monto monetario a descontar
        BigDecimal montoADescontarGlobal;
        if (tipo == TipoDescuento.PORCENTUAL) {
            montoADescontarGlobal = totalParcial.multiply(valorDescuento).divide(new BigDecimal("100"));
        } else {
            montoADescontarGlobal = valorDescuento;
        }

        // 5. Evitar que el descuento global supere el total de la venta
        if (montoADescontarGlobal.compareTo(totalParcial) >= 0) {
            throw new VistaValidationException("El descuento global (" + montoADescontarGlobal + ") no puede ser igual o mayor al total de la venta (" + totalParcial + ").");
        }

        // 6. Comprobar permisos para descuentos globales especiales
        BigDecimal limiteGlobalUsuario = usuario.getLimiteDescuentoGlobal(tipo);
        if (valorDescuento.compareTo(limiteGlobalUsuario) > 0) {
            throw new VistaValidationException("El descuento global supera su límite autorizado (" + limiteGlobalUsuario + (tipo == TipoDescuento.PORCENTUAL ? "%" : "$") + ").");
        }

        // 7. Mostrar el motivo cuando sea requerido
        if (montoADescontarGlobal.compareTo(usuario.getUmbralDescuentoGlobalSinMotivo()) > 0) {
            if (motivo == null || motivo.trim().isEmpty()) {
                throw new VistaValidationException("Debe ingresar un motivo para aplicar un descuento global de esta magnitud.");
            }
        }

        // 8. Guardar el descuento efectivamente aplicado
        return new DescuentoGlobal(tipo, valorDescuento, montoADescontarGlobal, motivo);
    }

    private BigDecimal calcularTotalCarrito(List<DetalleVenta> carrito) {
        return carrito.stream()
                .map(DetalleVenta::getSubtotalFinal) // Asume que ya restó los descuentos individuales
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
