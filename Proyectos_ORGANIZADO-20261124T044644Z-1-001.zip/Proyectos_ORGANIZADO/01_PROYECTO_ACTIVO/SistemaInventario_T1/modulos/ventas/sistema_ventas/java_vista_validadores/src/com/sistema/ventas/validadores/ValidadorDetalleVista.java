package com.sistema.ventas.validadores;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.modelos.Producto;
import com.sistema.ventas.modelos.Almacen;
import com.sistema.ventas.modelos.DetalleVenta;
import com.sistema.ventas.modelos.UnidadMedida;
import com.sistema.ventas.dao.ProductoDAO;
import com.sistema.ventas.config.ConfiguracionProyecto;
import java.math.BigDecimal;
import java.util.List;

public class ValidadorDetalleVista {

    private ProductoDAO productoDAO;
    private ConfiguracionProyecto config; // Trae límites globales

    public Producto validarDatosProducto(String codigoIngresado, String codigoBarras, Almacen almacen) 
            throws VistaValidationException {
        
        // 1. Código: Buscar producto existente
        Producto producto = productoDAO.buscarPorCodigo(codigoIngresado);
        if (producto == null) {
            throw new VistaValidationException("El código no corresponde a un producto existente.");
        }

        // 2. Nombre: Mostrar descripción (se delega a la UI tras retornar el objeto)
        
        // 3. Código de barras: No asociar un código a otro producto
        if (codigoBarras != null && !codigoBarras.isEmpty()) {
            if (!producto.getCodigoBarras().equals(codigoBarras)) {
                throw new VistaValidationException("El código de barras escaneado no corresponde al producto seleccionado.");
            }
        }

        // 4. Estado: No vender productos inactivos
        if (!producto.isActivo()) {
            throw new VistaValidationException("El producto '" + producto.getNombre() + "' se encuentra inactivo y no puede ser vendido.");
        }

        // 5. Almacén: Debe estar activo y autorizado
        if (!almacen.isActivo() || !almacen.isAutorizadoParaVentas()) {
            throw new VistaValidationException("El almacén seleccionado está inactivo o no autorizado para operar.");
        }

        return producto;
    }

    public BigDecimal validarCantidad(String cantidadStr, Producto producto, List<DetalleVenta> carritoActual) 
            throws VistaValidationException {
        
        // 1. Obligatoria y no vacía
        if (cantidadStr == null || cantidadStr.trim().isEmpty()) {
            throw new VistaValidationException("La cantidad es obligatoria.");
        }

        BigDecimal cantidad;
        try {
            // 2. Numérica. Al usar BigDecimal en Java evitamos automáticamente valores Infinity o NaN.
            cantidad = new BigDecimal(cantidadStr);
        } catch (NumberFormatException e) {
            throw new VistaValidationException("La cantidad debe ser un número válido (No se aceptan letras, NaN ni valores infinitos).");
        }

        // 3 y 4. Mayor que cero y no negativa
        if (cantidad.compareTo(BigDecimal.ZERO) <= 0) {
            throw new VistaValidationException("La cantidad debe ser estrictamente mayor a cero.");
        }

        // 5. Respetar la precisión de la unidad y evitar fracciones en enteros
        UnidadMedida unidad = producto.getUnidadMedida();
        if (!unidad.permiteFracciones()) {
            // Verifica si tiene decimales (ej: 1.5 % 1 != 0)
            if (cantidad.remainder(BigDecimal.ONE).compareTo(BigDecimal.ZERO) != 0) {
                throw new VistaValidationException("La unidad '" + unidad.getAbreviatura() + "' no permite fracciones. Ingrese números enteros.");
            }
        }

        // 6. Respetar límites máximos del proyecto
        if (cantidad.compareTo(config.getLimiteCantidadPorLinea()) > 0) {
            throw new VistaValidationException("La cantidad supera el límite máximo permitido por operación (" + config.getLimiteCantidadPorLinea() + ").");
        }

        // 7. Consolidación de líneas y Stock Real
        BigDecimal stockReal = productoDAO.obtenerStockReal(producto.getId());
        BigDecimal cantidadPreviaEnCarrito = calcularCantidadExistente(producto, carritoActual);
        BigDecimal cantidadTotalRequerida = cantidad.add(cantidadPreviaEnCarrito);

        // 8. No aceptar cantidades superiores a la disponibilidad
        if (cantidadTotalRequerida.compareTo(stockReal) > 0) {
            throw new VistaValidationException("Stock insuficiente. Disponible: " + stockReal + 
                " (Ya tiene " + cantidadPreviaEnCarrito + " en el carrito).");
        }

        return cantidad;
    }

    // Método de soporte para "Establecer cómo se consolidan las líneas" (5.3)
    private BigDecimal calcularCantidadExistente(Producto producto, List<DetalleVenta> carritoActual) {
        return carritoActual.stream()
                .filter(d -> d.getProducto().getId().equals(producto.getId()))
                .map(DetalleVenta::getCantidad)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
