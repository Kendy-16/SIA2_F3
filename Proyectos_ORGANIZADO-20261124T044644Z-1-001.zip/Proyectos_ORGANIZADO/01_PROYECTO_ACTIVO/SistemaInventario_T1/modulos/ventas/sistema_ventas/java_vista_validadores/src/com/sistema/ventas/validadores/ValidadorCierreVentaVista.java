package com.sistema.ventas.validadores;

import com.sistema.ventas.exceptions.VistaValidationException;
import com.sistema.ventas.modelos.VentaDTO;
import com.sistema.ventas.modelos.DetalleVenta;
import java.math.BigDecimal;

public class ValidadorCierreVentaVista {

    public void validarVentaListaParaEnviar(VentaDTO ventaActiva) throws VistaValidationException {
        
        // 1. Validar que el carrito no esté vacío
        if (ventaActiva.getDetalles() == null || ventaActiva.getDetalles().isEmpty()) {
            throw new VistaValidationException("No se puede procesar la venta: El detalle está vacío.");
        }

        // 2. Validar que la cabecera tenga cliente si el comprobante lo exige
        if (ventaActiva.getComprobante().requiereCliente() && ventaActiva.getCliente() == null) {
            throw new VistaValidationException("No se puede procesar la venta: El comprobante seleccionado exige un cliente registrado.");
        }

        // 3. Confirmar que la vista no determinó unilateralmente el precio final (Consistencia matemática)
        // Se recalculan los totales iterando los DTOs para asegurar que los cálculos de la UI coinciden
        BigDecimal totalCalculado = BigDecimal.ZERO;
        for (DetalleVenta detalle : ventaActiva.getDetalles()) {
            BigDecimal subtotalLinea = detalle.getCantidad().multiply(detalle.getPrecioAplicado());
            if (detalle.getDescuento() != null) {
                subtotalLinea = subtotalLinea.subtract(detalle.getDescuento().getMontoDescontado());
            }
            totalCalculado = totalCalculado.add(subtotalLinea);
        }

        if (ventaActiva.getDescuentoGlobal() != null) {
            totalCalculado = totalCalculado.subtract(ventaActiva.getDescuentoGlobal().getMontoDescontado());
        }

        // Se permite una mínima diferencia de centavos por redondeos técnicos, pero no manipulación de la UI
        BigDecimal diferencia = totalCalculado.subtract(ventaActiva.getTotalFinalVista()).abs();
        if (diferencia.compareTo(new BigDecimal("0.05")) > 0) { 
            throw new VistaValidationException("Inconsistencia financiera detectada. Los totales de la vista (" 
                    + ventaActiva.getTotalFinalVista() + ") no cuadran con el cálculo de los productos (" 
                    + totalCalculado + ").");
        }
        
        // 4. Comprobar que el total a pagar nunca sea negativo o cero absoluto (A menos que sea una bonificación 100% controlada)
        if (totalCalculado.compareTo(BigDecimal.ZERO) <= 0 && !ventaActiva.isBonificacionTotalAutorizada()) {
            throw new VistaValidationException("El total de la venta no puede ser cero o negativo.");
        }
    }
}
