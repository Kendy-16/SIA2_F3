-- =============================================================================
-- ESTRUCTURA DE BASE DE DATOS (DDL) - Inventario, Kardex, Ventas y Caja
-- Motor: PostgreSQL
--
-- Para evitar que dos ventas simultáneas dejen el stock en negativo o corrompan
-- el costo promedio, el esquema exige restricciones CHECK, llaves foráneas
-- estrictas y bloqueo pesimista (FOR UPDATE) desde la capa de servicio.
-- =============================================================================

-- 1. Almacenes y permisos de usuario
CREATE TABLE almacenes (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE usuario_almacenes (
    usuario_id INT NOT NULL,
    almacen_id INT NOT NULL REFERENCES almacenes(id),
    PRIMARY KEY (usuario_id, almacen_id)
);

-- 2. Productos
CREATE TABLE productos (
    id SERIAL PRIMARY KEY,
    sku VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);

-- 3. Saldos de Inventario por Almacén (Estado actual y Costo Promedio Móvil)
CREATE TABLE inventario_saldos (
    id SERIAL PRIMARY KEY,
    producto_id INT NOT NULL REFERENCES productos(id),
    almacen_id INT NOT NULL REFERENCES almacenes(id),
    stock_actual DECIMAL(12, 4) NOT NULL DEFAULT 0 CHECK (stock_actual >= 0),
    costo_promedio DECIMAL(12, 4) NOT NULL DEFAULT 0 CHECK (costo_promedio >= 0),
    valor_total DECIMAL(14, 4) NOT NULL DEFAULT 0 CHECK (valor_total >= 0),
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (producto_id, almacen_id)
);

-- 4. Conteos Físicos (Para bloquear movimientos mientras hay inventario abierto)
CREATE TABLE conteos_fisicos (
    id SERIAL PRIMARY KEY,
    almacen_id INT NOT NULL REFERENCES almacenes(id),
    estado VARCHAR(20) NOT NULL CHECK (estado IN ('ABIERTO', 'CERRADO', 'ANULADO')),
    fecha_inicio TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 5. Cabecera y Detalle de Ventas
CREATE TABLE ventas (
    id SERIAL PRIMARY KEY,
    numero_documento VARCHAR(30) UNIQUE NOT NULL, -- Ej: F001-000045
    almacen_id INT NOT NULL REFERENCES almacenes(id),
    usuario_id INT NOT NULL,
    total_venta DECIMAL(12, 2) NOT NULL,
    estado VARCHAR(20) NOT NULL CHECK (estado IN ('BORRADOR', 'CONFIRMADA', 'ANULADA')),
    fecha_confirmacion TIMESTAMP NULL
);

CREATE TABLE venta_detalles (
    id SERIAL PRIMARY KEY,
    venta_id INT NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
    producto_id INT NOT NULL REFERENCES productos(id),
    cantidad DECIMAL(12, 4) NOT NULL CHECK (cantidad > 0),
    precio_unitario DECIMAL(12, 4) NOT NULL,
    costo_unitario_salida DECIMAL(12, 4) NULL -- Se llena al confirmar (Costo Promedio vigente)
);

-- 6. Kardex (Libro mayor de movimientos de inventario)
CREATE TABLE kardex_movimientos (
    id SERIAL PRIMARY KEY,
    producto_id INT NOT NULL REFERENCES productos(id),
    almacen_id INT NOT NULL REFERENCES almacenes(id),
    tipo_movimiento VARCHAR(20) NOT NULL CHECK (tipo_movimiento IN ('ENTRADA_COMPRA', 'SALIDA_VENTA', 'AJUSTE_INV', 'ANULACION_VENTA')),
    documento_referencia VARCHAR(30) NOT NULL, -- Referencia al comprobante (F001-000045)
    venta_id INT NULL REFERENCES ventas(id),       -- Relación directa por FK
    fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Columnas exactas solicitadas en 8.4
    saldo_anterior DECIMAL(12, 4) NOT NULL,
    entrada DECIMAL(12, 4) NOT NULL DEFAULT 0,
    salida DECIMAL(12, 4) NOT NULL DEFAULT 0,
    saldo_nuevo DECIMAL(12, 4) NOT NULL,
    costo_unitario DECIMAL(12, 4) NOT NULL,
    costo_promedio DECIMAL(12, 4) NOT NULL,
    valor_saldo DECIMAL(14, 4) NOT NULL
);

-- 7. Integración con Caja y Pagos (Punto 9)
CREATE TABLE caja_sesiones (
    id SERIAL PRIMARY KEY,
    usuario_id INT NOT NULL,
    estado VARCHAR(15) NOT NULL CHECK (estado IN ('ABIERTA', 'CERRADA'))
);

CREATE TABLE venta_pagos (
    id SERIAL PRIMARY KEY,
    venta_id INT NOT NULL REFERENCES ventas(id),
    caja_sesion_id INT NOT NULL REFERENCES caja_sesiones(id),
    metodo_pago VARCHAR(30) NOT NULL, -- EFECTIVO, TARJETA, YAPE, TRANSFERENCIA
    monto DECIMAL(12, 2) NOT NULL CHECK (monto > 0),
    referencia_operacion VARCHAR(100) NULL,
    fecha_pago TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
