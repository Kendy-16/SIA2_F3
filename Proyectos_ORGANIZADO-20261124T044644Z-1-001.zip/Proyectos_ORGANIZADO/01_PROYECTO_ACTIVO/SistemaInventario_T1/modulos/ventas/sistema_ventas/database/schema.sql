-- Tabla de Roles
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) UNIQUE NOT NULL
);

-- Tabla de Permisos
CREATE TABLE permisos (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    descripcion VARCHAR(100)
);

-- Relación Rol - Permiso
CREATE TABLE rol_permisos (
    rol_id INT REFERENCES roles(id),
    permiso_id INT REFERENCES permisos(id),
    PRIMARY KEY (rol_id, permiso_id)
);

-- Insertar el Rol de Usuario Vendedor
INSERT INTO roles (nombre) VALUES ('USUARIO_VENTAS');

-- Insertar Permisos Permitidos (Whitelist)
INSERT INTO permisos (codigo, descripcion) VALUES 
('VENTAS_REGISTRAR', 'Registrar ventas y agregar productos al carrito'),
('CLIENTES_BUSCAR', 'Buscar clientes en la base de datos'),
('PRODUCTOS_BUSCAR', 'Buscar productos y ver precios autorizados'),
('INVENTARIO_CONSULTAR', 'Consultar disponibilidad del almacén asignado'),
('PAGOS_SELECCIONAR', 'Seleccionar medios de pago habilitados'),
('VENTAS_CONFIRMAR', 'Confirmar ventas autorizadas'),
('COMPROBANTES_IMPRIMIR', 'Imprimir o consultar comprobantes permitidos'),
('VENTAS_PROPIAS_VER', 'Consultar sus propias ventas');

-- Permisos Restringidos (Solo para Administradores o Supervisores)
INSERT INTO permisos (codigo, descripcion) VALUES 
('PRECIOS_CAMBIAR', 'Cambiar precios libremente'),
('DESCUENTOS_AUTORIZAR', 'Autorizar descuentos especiales'),
('VENTAS_ANULAR', 'Anular ventas'),
('VENTAS_ELIMINAR', 'Eliminar ventas'),
('VENTAS_MODIFICAR', 'Modificar ventas confirmadas'),
('COSTOS_VER', 'Consultar costos internos y ganancias'),
('VENTAS_TODAS_VER', 'Acceder a ventas de otros usuarios'),
('CAJA_MODIFICAR', 'Alterar movimientos de caja'),
('KARDEX_MODIFICAR', 'Modificar inventario o Kardex manualmente');

-- Asignar SOLO los permisos permitidos al USUARIO_VENTAS (ID 1)
INSERT INTO rol_permisos (rol_id, permiso_id)
SELECT 1, id FROM permisos WHERE codigo IN (
    'VENTAS_REGISTRAR', 'CLIENTES_BUSCAR', 'PRODUCTOS_BUSCAR', 
    'INVENTARIO_CONSULTAR', 'PAGOS_SELECCIONAR', 'VENTAS_CONFIRMAR', 
    'COMPROBANTES_IMPRIMIR', 'VENTAS_PROPIAS_VER'
);
