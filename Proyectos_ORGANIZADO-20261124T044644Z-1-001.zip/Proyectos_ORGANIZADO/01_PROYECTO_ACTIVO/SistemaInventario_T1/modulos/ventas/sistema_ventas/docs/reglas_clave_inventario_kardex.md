# Inventario, Kardex y Caja: reglas clave de la implementación

Archivos relacionados:

- Esquema SQL: `database/inventario_kardex_schema.sql`
- Servicio transaccional (TypeScript / Node.js): `backend_node/src/services/VentaInventarioService.ts`

El servicio implementa paso a paso los subpuntos 8.1, 8.2, 8.3, 8.4 y la integración con el punto 9 (Caja y Pagos) dentro de una única transacción ACID.

## Reglas clave garantizadas

### Inmutabilidad del costo promedio en salidas (8.3)

Al calcular `valorNuevoInventario = stockNuevo * costoPromedioVigente` se evitan errores de redondeo acumulado y el costo promedio permanece exactamente igual (S/ 7.50). En cambio, las entradas por compra (en otro método) sí recalculan el costo:

```
CostoPromedioNuevo = (ValorAnterior + ValorCompra) / (StockAnterior + CantidadComprada)
```

### Prevención de race conditions y deadlocks

- El uso de `SELECT ... FOR UPDATE` en `inventario_saldos` obliga a que, si dos cajeros venden el último producto al mismo milisegundo, el segundo espere a que el primero termine. Al desbloquearse, leerá el stock actualizado (0) y lanzará el error de stock insuficiente.
- Ordenar los ítems con `ORDER BY vd.producto_id ASC` antes de bloquear filas evita interbloqueos cruzados (deadlocks) cuando dos ventas tienen los mismos productos en distinto orden.

### Coherencia absoluta Venta ↔ Kardex ↔ Caja

Gracias al bloque `BEGIN ... COMMIT / ROLLBACK`, es físicamente imposible que exista una venta confirmada sin salida de Kardex, un Kardex sin actualización de saldo, o una venta confirmada sin su ingreso en caja.
