import java.math.BigDecimal;

public class CalculadorImpuestoExonerado implements CalculadorImpuestos {
    @Override
    public BigDecimal calcularImpuesto(BigDecimal baseImponible) {
        return BigDecimal.ZERO;
    }
}