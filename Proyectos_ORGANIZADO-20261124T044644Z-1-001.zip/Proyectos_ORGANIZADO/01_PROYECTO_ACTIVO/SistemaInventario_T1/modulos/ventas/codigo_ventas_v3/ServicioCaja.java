public class ServicioCaja {
    public static void main(String[] args) {
        // 1. Cargar configuración tributaria del sistema (ej: 18% IVA/IGV)
        CalculadorImpuestos impuestoConfigurado = new CalculadorImpuestoEstandar("18");
        
        // 2. Iniciar venta
        Venta venta = new Venta(impuestoConfigurado);
        
        // 3. Agregar productos: (ID, Cantidad, Precio, % Descuento, Costo Historico)
        venta.agregarDetalle(new DetalleVenta("PROD-001", "5", "12.50", "0", "8.00")); // Sin descuento
        venta.agregarDetalle(new DetalleVenta("PROD-002", "1", "40.00", "0", "25.00")); // Sin descuento
        
        // 4. Aplicar descuento global (Como los items tienen "0" de descuento, esto es válido)
        venta.aplicarDescuentoGlobal("5.00");
        
        // 5. Mostrar resultados
        System.out.println("7.4 Total Bruto: S/ " + venta.getSubtotalGeneral());     // 102.50
        System.out.println("7.5 Descuentos: S/ " + venta.getDescuentoGeneral());     // 5.00
        System.out.println("--- Base Imponible: S/ " + venta.getBaseImponible());    // 97.50
        
        System.out.println("7.6 Total Venta: S/ " + venta.getTotalVenta());          // 115.05 (97.50 + 17.55 de impuesto)
        
        System.out.println("7.7 Vuelto (Efectivo S/150): S/ " + venta.calcularVuelto("150.00", "EFECTIVO")); // 34.95
        
        // Base(97.50) - Costos(40 + 25 = 65) = 32.50
        System.out.println("7.8 Ganancia Bruta: S/ " + venta.getGananciaBruta());    // 32.50
    }
}