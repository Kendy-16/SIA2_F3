public class ResultadoVenta {
    private boolean exito;
    private String mensaje;

    public ResultadoVenta(boolean exito, String mensaje) {
        this.exito = exito;
        this.mensaje = mensaje;
    }

    public boolean isExito() { return exito; }
    public String getMensaje() { return mensaje; }
}