import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

public class Venta {
    private List<DetalleVenta> detalles;
    private BigDecimal descuentoGlobal;
    private BigDecimal otrosCargos;
    private CalculadorImpuestos configuracionTributaria; // Regla 7.6

    // Constructor sin args requerido por el VentaDAO
    public Venta() {
        this.detalles = new ArrayList<>();
        this.descuentoGlobal = BigDecimal.ZERO;
        this.otrosCargos = BigDecimal.ZERO;
    }

    public Venta(CalculadorImpuestos configuracionTributaria) {
        this.detalles = new ArrayList<>();
        this.descuentoGlobal = BigDecimal.ZERO;
        this.otrosCargos = BigDecimal.ZERO;
        this.configuracionTributaria = configuracionTributaria;
    }

    public void setConfiguracionTributaria(CalculadorImpuestos config) {
        this.configuracionTributaria = config;
    }

    public void agregarDetalle(DetalleVenta detalle) {
        this.detalles.add(detalle);
    }

    public void setOtrosCargos(String otrosCargos) {
        this.otrosCargos = new BigDecimal(otrosCargos);
    }

    // Validación Regla 7.5: Evitar descontar dos veces
    public void aplicarDescuentoGlobal(String descuentoGlobalStr) {
        boolean hayItemsConDescuento = detalles.stream().anyMatch(DetalleVenta::tieneDescuento);
        if (hayItemsConDescuento) {
            throw new IllegalStateException("Regla 7.5 violada: No se puede aplicar descuento global si ya existen productos con descuentos individuales.");
        }
        this.descuentoGlobal = new BigDecimal(descuentoGlobalStr);
    }

    // 7.4 Total bruto (Subtotal General)
    public BigDecimal getSubtotalGeneral() {
        return detalles.stream()
                .map(DetalleVenta::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // 7.5 Total de descuentos
    public BigDecimal getDescuentoGeneral() {
        BigDecimal descuentoDetalles = detalles.stream()
                .map(DetalleVenta::getDescuento)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        return descuentoDetalles.add(this.descuentoGlobal).setScale(2, RoundingMode.HALF_UP);
    }

    // Base imponible
    public BigDecimal getBaseImponible() {
        return getSubtotalGeneral().subtract(getDescuentoGeneral());
    }

    // 7.6 Total de venta
    public BigDecimal getTotalVenta() {
        BigDecimal baseImponible = getBaseImponible();
        
        // Manejo por si configuracionTributaria es null (cuando se trae del DAO)
        BigDecimal impuestos = BigDecimal.ZERO;
        if (this.configuracionTributaria != null) {
            impuestos = configuracionTributaria.calcularImpuesto(baseImponible);
        }
        
        // BaseImponible + Impuestos + OtrosCargos
        return baseImponible.add(impuestos).add(this.otrosCargos)
                .setScale(2, RoundingMode.HALF_UP);
    }

    // 7.7 Pago y vuelto
    public BigDecimal calcularVuelto(String importeRecibidoStr, String metodoPago) {
        // Validar que solo aplique a efectivo
        if (!metodoPago.equalsIgnoreCase("EFECTIVO")) {
            return BigDecimal.ZERO; 
        }

        BigDecimal importeRecibido = new BigDecimal(importeRecibidoStr);
        BigDecimal totalVenta = getTotalVenta();

        if (importeRecibido.compareTo(totalVenta) > 0) {
            return importeRecibido.subtract(totalVenta).setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    // 7.8 Ganancia bruta
    public BigDecimal getGananciaBruta() {
        BigDecimal totalNetoVenta = getBaseImponible(); 
        
        BigDecimal costoMercaderiaVendida = detalles.stream()
                .map(DetalleVenta::getCostoTotalItem)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return totalNetoVenta.subtract(costoMercaderiaVendida)
                .setScale(2, RoundingMode.HALF_UP);
    }
    
    // Setters requeridos por el DAO para mapear desde SQLite
    public void setId(Integer id) {}
    public void setNumeroVenta(String numero) {}
    public void setFecha(LocalDateTime fecha) {}
    public void setIdCliente(Integer id) {}
    public void setIdUsuario(Integer id) {}
    public void setIdAlmacen(Integer id) {}
    public void setTipoVenta(String tipo) {}
    public void setEstado(String estado) {}
    public void setSubtotal(BigDecimal sub) {}
    public void setDescuentoTotal(BigDecimal desc) {}
    public void setImpuestoTotal(BigDecimal imp) {}
    public void setTotal(BigDecimal total) {}
    public void setObservacion(String obs) {}
}