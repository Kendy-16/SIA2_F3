import java.util.List;

public class SesionUsuario {
    private Integer idUsuario;
    private String token;
    private List<String> roles;
    private Integer idCaja; // ID de la caja registradora que tiene abierta
    private boolean valida;

    // Getters
    public Integer getIdUsuario() { return idUsuario; }
    public List<String> getRoles() { return roles; }
    public Integer getIdCaja() { return idCaja; }
    public boolean esValida() { return valida; }
    
    // Setters
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }
    public void setRoles(List<String> roles) { this.roles = roles; }
    public void setIdCaja(Integer idCaja) { this.idCaja = idCaja; }
    public void setValida(boolean valida) { this.valida = valida; }
}