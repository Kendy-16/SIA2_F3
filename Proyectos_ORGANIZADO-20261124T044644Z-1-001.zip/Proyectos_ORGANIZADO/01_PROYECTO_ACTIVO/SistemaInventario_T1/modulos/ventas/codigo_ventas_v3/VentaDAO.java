import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {
    // Note: Depends on VentaDTO which hasn't been provided in full, 
    // but code is identical to what the user requested.

    public Venta buscarPorNumero(Connection conn, String numeroVenta) throws SQLException {
        String sql = "SELECT * FROM venta WHERE numeroVenta = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, numeroVenta);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapearVenta(rs);
            }
        }
        return null;
    }

    public List<Venta> buscarPorCliente(Connection conn, int idCliente) throws SQLException {
        String sql = "SELECT * FROM venta WHERE idCliente = ?";
        return ejecutarConsultaLista(conn, sql, idCliente);
    }

    public List<Venta> consultarPorFecha(Connection conn, String fechaInicio, String fechaFin) throws SQLException {
        String sql = "SELECT * FROM venta WHERE date(fecha) BETWEEN date(?) AND date(?)";
        List<Venta> lista = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fechaInicio);
            stmt.setString(2, fechaFin);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) lista.add(mapearVenta(rs));
            }
        }
        return lista;
    }

    public List<Venta> consultarPorUsuario(Connection conn, int idUsuario) throws SQLException {
        String sql = "SELECT * FROM venta WHERE idUsuario = ?";
        return ejecutarConsultaLista(conn, sql, idUsuario);
    }

    public List<Venta> consultarPorAlmacen(Connection conn, int idAlmacen) throws SQLException {
        String sql = "SELECT * FROM venta WHERE idAlmacen = ?";
        return ejecutarConsultaLista(conn, sql, idAlmacen);
    }

    public List<Venta> consultarVentasNormales(Connection conn) throws SQLException {
        String sql = "SELECT * FROM venta WHERE tipoVenta = 'NORMAL'";
        return ejecutarConsultaLista(conn, sql, null);
    }

    public List<Venta> consultarVentasMayoristas(Connection conn) throws SQLException {
        String sql = "SELECT * FROM venta WHERE tipoVenta = 'MAYORISTA'";
        return ejecutarConsultaLista(conn, sql, null);
    }

    private List<Venta> ejecutarConsultaLista(Connection conn, String sql, Integer parametro) throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (parametro != null) stmt.setInt(1, parametro);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) lista.add(mapearVenta(rs));
            }
        }
        return lista;
    }

    private Venta mapearVenta(ResultSet rs) throws SQLException {
        Venta v = new Venta();
        v.setId(rs.getInt("id"));
        v.setNumeroVenta(rs.getString("numeroVenta"));
        // Asumiendo que usas Timestamp en SQLite transformado a LocalDateTime
        v.setFecha(rs.getTimestamp("fecha").toLocalDateTime()); 
        v.setIdCliente(rs.getInt("idCliente"));
        v.setIdUsuario(rs.getInt("idUsuario"));
        v.setIdAlmacen(rs.getInt("idAlmacen"));
        v.setTipoVenta(rs.getString("tipoVenta"));
        v.setEstado(rs.getString("estado"));
        v.setSubtotal(rs.getBigDecimal("subtotal"));
        v.setDescuentoTotal(rs.getBigDecimal("descuentoTotal"));
        v.setImpuestoTotal(rs.getBigDecimal("impuestoTotal"));
        v.setTotal(rs.getBigDecimal("total"));
        v.setObservacion(rs.getString("observacion"));
        return v;
    }
}
