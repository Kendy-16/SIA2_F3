import java.math.BigDecimal;
import java.math.RoundingMode;

public class DetalleVenta {
    private String idProducto;
    private BigDecimal cantidad;
    private BigDecimal precioUnitario;
    private BigDecimal porcentajeDescuento;
    private BigDecimal costoHistorico; 

    public DetalleVenta(String idProducto, String cantidad, String precioUnitario, String porcentajeDescuento, String costoHistorico) {
        this.idProducto = idProducto;
        this.cantidad = new BigDecimal(cantidad);
        this.precioUnitario = new BigDecimal(precioUnitario);
        this.porcentajeDescuento = new BigDecimal(porcentajeDescuento);
        this.costoHistorico = new BigDecimal(costoHistorico);
    }

    // 7.1 Subtotal por producto (Cantidad * PrecioUnitario)
    public BigDecimal getSubtotal() {
        return this.cantidad.multiply(this.precioUnitario)
                .setScale(2, RoundingMode.HALF_UP);
    }

    // 7.2 Descuento porcentual
    public BigDecimal getDescuento() {
        if (this.porcentajeDescuento.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        BigDecimal subtotal = getSubtotal();
        BigDecimal divisor = new BigDecimal("100");
        return subtotal.multiply(this.porcentajeDescuento)
                .divide(divisor, 2, RoundingMode.HALF_UP);
    }

    // 7.3 Total por detalle (Subtotal - Descuento)
    public BigDecimal getTotalDetalle() {
        return getSubtotal().subtract(getDescuento())
                .setScale(2, RoundingMode.HALF_UP);
    }

    // Costo total del ítem (Cantidad * Costo Histórico)
    public BigDecimal getCostoTotalItem() {
        return this.cantidad.multiply(this.costoHistorico)
                .setScale(2, RoundingMode.HALF_UP);
    }

    public boolean tieneDescuento() {
        return this.porcentajeDescuento.compareTo(BigDecimal.ZERO) > 0;
    }
    
    // Getters y Setters requeridos para integracion con DAO y base de datos
    private Integer id;
    private Integer idVenta;
    private Integer idProductoDb;
    
    public void setId(Integer id) { this.id = id; }
    public void setIdVenta(Integer idVenta) { this.idVenta = idVenta; }
    public void setIdProducto(Integer idProductoDb) { this.idProductoDb = idProductoDb; }
    public void setCantidad(BigDecimal cantidad) { this.cantidad = cantidad; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }
    public void setSubtotal(BigDecimal subtotal) { /* Set if needed by framework */ }
}