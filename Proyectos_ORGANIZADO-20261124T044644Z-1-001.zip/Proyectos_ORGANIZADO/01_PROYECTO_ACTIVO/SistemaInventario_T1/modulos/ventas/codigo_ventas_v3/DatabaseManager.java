import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseManager {
    
    private static final String URL = "jdbc:sqlite:ruta/a/tu/base_de_datos.db";

    public Connection getConnection() throws SQLException {
        // En SQLite es importante habilitar pragma foreign_keys si usas claves foráneas
        Connection conn = DriverManager.getConnection(URL);
        try (java.sql.Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
        }
        return conn;
    }
}