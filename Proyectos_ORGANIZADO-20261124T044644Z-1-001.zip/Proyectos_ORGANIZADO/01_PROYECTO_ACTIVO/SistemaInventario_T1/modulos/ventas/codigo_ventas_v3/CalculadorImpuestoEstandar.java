import java.math.BigDecimal;
import java.math.RoundingMode;

public class CalculadorImpuestoEstandar implements CalculadorImpuestos {
    private final BigDecimal tasaImpuesto;

    public CalculadorImpuestoEstandar(String porcentajeTasa) {
        // Ejemplo: "18" para 18%
        this.tasaImpuesto = new BigDecimal(porcentajeTasa).divide(new BigDecimal("100"));
    }

    @Override
    public BigDecimal calcularImpuesto(BigDecimal baseImponible) {
        return baseImponible.multiply(tasaImpuesto).setScale(2, RoundingMode.HALF_UP);
    }
}