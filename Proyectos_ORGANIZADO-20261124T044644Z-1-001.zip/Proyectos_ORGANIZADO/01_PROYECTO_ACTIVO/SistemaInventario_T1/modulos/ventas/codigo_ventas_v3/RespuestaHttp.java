public class RespuestaHttp {
    private boolean success;
    private String message;

    public RespuestaHttp(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    // Getters y Setters
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
}