import java.math.BigDecimal;

public interface CalculadorImpuestos {
    BigDecimal calcularImpuesto(BigDecimal baseImponible);
}