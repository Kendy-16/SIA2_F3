package pe.edu.inventario.demo;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/** Datos en memoria exclusivamente para probar las ventanas; no usa la BD real. */
public final class DemoInventarioFisicoController implements InventarioFisicoController {
    private static final class TomaData {
        Toma toma;
        final Map<Long, Producto> productos = new LinkedHashMap<>();
        final Map<Long, String> estadosAjuste = new HashMap<>();
        final List<String> auditoria = new ArrayList<>();
        boolean conteoCiego = true;
        boolean permiteSegundoConteo = true;
        boolean permiteConteoParcial = false;
        TomaData(Toma toma) { this.toma = toma; }
    }

    private final Map<Long, TomaData> tomas = new LinkedHashMap<>();
    private final List<Producto> catalogo = new ArrayList<>();
    private long siguienteToma = 3;

    public DemoInventarioFisicoController() {
        catalogo.add(producto(1, "PRD-001", "775000000001", "Cable UTP CAT6", "Redes", "METRO", "A-01", "120", "2.50"));
        catalogo.add(producto(2, "PRD-002", "775000000002", "Conector RJ45", "Redes", "UNIDAD", "A-02", "80", "0.45"));
        catalogo.add(producto(3, "PRD-003", "775000000003", "Switch 24 puertos", "Equipos", "UNIDAD", "B-01", "12", "280.00"));
        catalogo.add(producto(4, "PRD-004", "775000000004", "Canaleta 20x10", "Accesorios", "METRO", "C-04", "0", "3.80"));
        catalogo.add(producto(5, "PRD-005", "775000000005", "Patch cord 2 m", "Redes", "UNIDAD", "A-05", "25", "8.90"));

        Toma t1 = new Toma(1, "IF-2026-0001", "Almacén principal", LocalDateTime.now().minusDays(3), null,
                "Administrador", 5, 5, 2, EstadoToma.EN_REVISION);
        TomaData d1 = new TomaData(t1);
        d1.productos.put(1L, contado(catalogo.get(0), "118", null, "Dos metros faltantes"));
        d1.productos.put(2L, contado(catalogo.get(1), "80", null, ""));
        d1.productos.put(3L, contado(catalogo.get(2), "13", null, "Una unidad adicional"));
        d1.productos.put(4L, contado(catalogo.get(3), "0", null, ""));
        d1.productos.put(5L, catalogo.get(4));
        d1.auditoria.add("Toma creada por Administrador");
        d1.auditoria.add("Conteo inicial registrado");
        tomas.put(1L, d1);

        Toma t2 = new Toma(2, "IF-2026-0002", "Almacén secundario", LocalDateTime.now().minusDays(1), null,
                "Supervisor", 3, 1, 0, EstadoToma.EN_CONTEO);
        TomaData d2 = new TomaData(t2);
        d2.productos.put(11L, producto(11, "PRD-011", "775000000011", "Router empresarial", "Equipos", "UNIDAD", "R-01", "7", "420.00"));
        d2.productos.put(12L, producto(12, "PRD-012", "775000000012", "Bobina fibra óptica", "Redes", "METRO", "R-02", "300", "1.90"));
        d2.productos.put(13L, producto(13, "PRD-013", "775000000013", "SFP monomodo", "Accesorios", "UNIDAD", "R-03", "18", "65.00"));
        d2.productos.put(11L, contado(d2.productos.get(11L), "7", null, ""));
        d2.auditoria.add("Toma creada por Supervisor");
        tomas.put(2L, d2);
    }

    private static Producto producto(long id, String codigo, String barras, String nombre, String categoria,
                                     String unidad, String ubicacion, String stock, String costo) {
        return new Producto(id, codigo, barras, nombre, categoria, unidad, ubicacion,
                new BigDecimal(stock), null, null, new BigDecimal(costo), "", EstadoConteo.PENDIENTE);
    }

    private static Producto contado(Producto p, String cantidad, String segundo, String observacion) {
        return new Producto(p.id(), p.codigo(), p.codigoBarras(), p.nombre(), p.categoria(), p.unidad(), p.ubicacion(),
                p.stockSistema(), new BigDecimal(cantidad), segundo == null ? null : new BigDecimal(segundo),
                p.costoPromedio(), observacion, EstadoConteo.CONTADO);
    }

    private TomaData obtener(long id) {
        TomaData d = tomas.get(id);
        if (d == null) throw new IllegalArgumentException("No existe la toma seleccionada.");
        return d;
    }

    private void actualizarToma(TomaData d, EstadoToma estado) {
        int contados = (int) d.productos.values().stream().filter(p -> p.cantidadFinal() != null).count();
        int diferencias = 0;
        for (Producto p : d.productos.values()) {
            if (p.cantidadFinal() != null && p.cantidadFinal().compareTo(p.stockSistema()) != 0) diferencias++;
        }
        Toma a = d.toma;
        d.toma = new Toma(a.id(), a.codigo(), a.almacen(), a.fechaInicio(), a.fechaCierre(), a.responsable(),
                d.productos.size(), contados, diferencias, estado);
    }

    @Override public Resumen obtenerResumen() {
        int abiertas = (int) tomas.values().stream().filter(d -> d.toma.estado() == EstadoToma.ABIERTA || d.toma.estado() == EstadoToma.EN_CONTEO).count();
        int conciliadas = (int) tomas.values().stream().filter(d -> d.toma.estado() == EstadoToma.CONCILIADA || d.toma.estado() == EstadoToma.APROBADA || d.toma.estado() == EstadoToma.CERRADA).count();
        int dif = tomas.values().stream().mapToInt(d -> d.toma.productosDiferencia()).sum();
        int pendientes = tomas.values().stream().mapToInt(d -> (int) d.estadosAjuste.values().stream().filter("PENDIENTE"::equals).count()).sum();
        return new Resumen(tomas.size(), abiertas, conciliadas, dif, pendientes);
    }

    @Override public List<Toma> listarTomas(String texto, EstadoToma estado) {
        String q = texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT);
        return tomas.values().stream().map(d -> d.toma)
                .filter(t -> estado == null || t.estado() == estado)
                .filter(t -> q.isEmpty() || t.codigo().toLowerCase(Locale.ROOT).contains(q) || t.almacen().toLowerCase(Locale.ROOT).contains(q) || t.responsable().toLowerCase(Locale.ROOT).contains(q))
                .sorted(Comparator.comparing(Toma::fechaInicio).reversed()).toList();
    }

    @Override public List<String> listarAlmacenes() { return List.of("Almacén principal", "Almacén secundario", "Depósito de equipos"); }
    @Override public List<String> listarCategorias() { return List.of("Todas", "Redes", "Equipos", "Accesorios"); }

    @Override public List<Producto> listarProductosDisponibles(String texto, String categoria, String almacen) {
        String q = texto == null ? "" : texto.toLowerCase(Locale.ROOT);
        return catalogo.stream().filter(p -> categoria == null || categoria.equals("Todas") || p.categoria().equals(categoria))
                .filter(p -> q.isBlank() || p.codigo().toLowerCase(Locale.ROOT).contains(q) || p.nombre().toLowerCase(Locale.ROOT).contains(q) || p.codigoBarras().contains(q))
                .toList();
    }

    @Override public Toma crearToma(NuevaToma solicitud) {
        if (solicitud.almacen() == null || solicitud.almacen().isBlank()) throw new IllegalArgumentException("Selecciona un almacén.");
        List<Producto> seleccion = solicitud.alcance().equals("Todos los productos")
                ? catalogo
                : catalogo.stream().filter(p -> solicitud.productosSeleccionados().contains(p.id())).toList();
        if (!solicitud.incluirStockCero()) seleccion = seleccion.stream().filter(p -> p.stockSistema().signum() > 0).toList();
        if (seleccion.isEmpty()) throw new IllegalArgumentException("La toma debe incluir al menos un producto.");
        long id = siguienteToma++;
        Toma t = new Toma(id, String.format("IF-2026-%04d", id), solicitud.almacen(), LocalDateTime.now(), null,
                "Usuario de demostración", seleccion.size(), 0, 0, EstadoToma.ABIERTA);
        TomaData d = new TomaData(t);
        seleccion.forEach(p -> d.productos.put(p.id(), new Producto(p.id(), p.codigo(), p.codigoBarras(), p.nombre(), p.categoria(), p.unidad(), p.ubicacion(), p.stockSistema(), null, null, p.costoPromedio(), "", EstadoConteo.PENDIENTE)));
        d.conteoCiego = solicitud.conteoCiego();
        d.permiteSegundoConteo = solicitud.permitirSegundoConteo();
        d.permiteConteoParcial = solicitud.permitirConteoParcial();
        d.auditoria.add("Toma creada. Alcance: " + solicitud.alcance());
        d.auditoria.add("Conteo ciego: " + (solicitud.conteoCiego() ? "sí" : "no"));
        tomas.put(id, d);
        return t;
    }

    @Override public List<Producto> listarProductosToma(long idToma, boolean ocultarStockSistema) {
        return obtener(idToma).productos.values().stream().map(p -> ocultarStockSistema
                ? new Producto(p.id(), p.codigo(), p.codigoBarras(), p.nombre(), p.categoria(), p.unidad(), p.ubicacion(), null, p.cantidadContada(), p.segundoConteo(), p.costoPromedio(), p.observacion(), p.estado())
                : p).toList();
    }

    @Override public boolean esConteoCiego(long idToma) { return obtener(idToma).conteoCiego; }
    @Override public boolean permiteSegundoConteo(long idToma) { return obtener(idToma).permiteSegundoConteo; }

    @Override public void registrarConteo(long idToma, long idProducto, BigDecimal cantidad, String observacion, boolean segundoConteo) {
        if (cantidad == null || cantidad.signum() < 0) throw new IllegalArgumentException("La cantidad contada debe ser cero o mayor.");
        TomaData d = obtener(idToma);
        if (segundoConteo && !d.permiteSegundoConteo) throw new IllegalStateException("Esta toma no permite segundo conteo.");
        Producto p = d.productos.get(idProducto);
        if (p == null) throw new IllegalArgumentException("El producto no pertenece a esta toma.");
        if (d.toma.estado() == EstadoToma.CERRADA || d.toma.estado() == EstadoToma.CANCELADA) throw new IllegalStateException("La toma ya no admite modificaciones.");
        Producto nuevo = new Producto(p.id(), p.codigo(), p.codigoBarras(), p.nombre(), p.categoria(), p.unidad(), p.ubicacion(), p.stockSistema(),
                segundoConteo ? p.cantidadContada() : cantidad, segundoConteo ? cantidad : p.segundoConteo(), p.costoPromedio(),
                observacion == null ? "" : observacion.trim(), segundoConteo ? EstadoConteo.SEGUNDO_CONTEO : EstadoConteo.CONTADO);
        d.productos.put(idProducto, nuevo);
        actualizarToma(d, EstadoToma.EN_CONTEO);
        d.auditoria.add((segundoConteo ? "Segundo conteo" : "Conteo") + " registrado para " + p.codigo());
    }

    @Override public List<Diferencia> conciliar(long idToma) {
        TomaData d = obtener(idToma);
        List<Diferencia> resultado = calcularDiferencias(d);
        boolean pendientes = d.productos.values().stream().anyMatch(p -> p.cantidadFinal() == null);
        if (pendientes) throw new IllegalStateException("No se puede conciliar: todavía hay productos sin contar.");
        boolean hayDiferencias = resultado.stream().anyMatch(x -> x.tipo() != TipoDiferencia.CONFORME);
        actualizarToma(d, hayDiferencias ? EstadoToma.EN_REVISION : EstadoToma.CONCILIADA);
        d.auditoria.add("Conciliación ejecutada. Diferencias: " + resultado.stream().filter(x -> x.tipo() != TipoDiferencia.CONFORME).count());
        return resultado;
    }

    private List<Diferencia> calcularDiferencias(TomaData d) {
        List<Diferencia> out = new ArrayList<>();
        for (Producto p : d.productos.values()) {
            BigDecimal fisica = p.cantidadFinal();
            if (fisica == null) {
                out.add(new Diferencia(p, p.stockSistema(), null, null, p.costoPromedio(), null, TipoDiferencia.PENDIENTE, "PENDIENTE", ""));
                continue;
            }
            BigDecimal delta = fisica.subtract(p.stockSistema());
            TipoDiferencia tipo = delta.signum() == 0 ? TipoDiferencia.CONFORME : delta.signum() < 0 ? TipoDiferencia.FALTANTE : TipoDiferencia.SOBRANTE;
            out.add(new Diferencia(p, p.stockSistema(), fisica, delta, p.costoPromedio(), delta.multiply(p.costoPromedio()), tipo,
                    d.estadosAjuste.getOrDefault(p.id(), "SIN AJUSTE"), p.observacion()));
        }
        return out;
    }

    @Override public List<Diferencia> listarDiferencias(long idToma) { return calcularDiferencias(obtener(idToma)); }
    @Override public void guardarObservacion(long idToma, long idProducto, String observacion) {
        TomaData d = obtener(idToma); Producto p = d.productos.get(idProducto);
        if (p == null) throw new IllegalArgumentException("Producto no encontrado.");
        d.productos.put(idProducto, new Producto(p.id(), p.codigo(), p.codigoBarras(), p.nombre(), p.categoria(), p.unidad(), p.ubicacion(), p.stockSistema(), p.cantidadContada(), p.segundoConteo(), p.costoPromedio(), observacion, p.estado()));
        d.auditoria.add("Observación actualizada para " + p.codigo());
    }
    @Override public void solicitarAjuste(long idToma, long idProducto, String motivo, String observacion) {
        if (motivo == null || motivo.isBlank()) throw new IllegalArgumentException("Selecciona un motivo.");
        TomaData d = obtener(idToma); Producto p = d.productos.get(idProducto);
        if (p == null || p.cantidadFinal() == null || p.cantidadFinal().compareTo(p.stockSistema()) == 0) throw new IllegalStateException("No existe una diferencia contada para ajustar.");
        d.estadosAjuste.put(idProducto, "PENDIENTE");
        d.auditoria.add("Ajuste solicitado para " + p.codigo() + ". Motivo: " + motivo + ". " + observacion);
    }
    @Override public void aprobarAjuste(long idToma, long idProducto) {
        TomaData d = obtener(idToma); String estado = d.estadosAjuste.get(idProducto);
        if (!"PENDIENTE".equals(estado)) throw new IllegalStateException("El ajuste no está pendiente de aprobación.");
        d.estadosAjuste.put(idProducto, "APROBADO");
        d.auditoria.add("Ajuste aprobado para producto ID " + idProducto + " (demostración; no modifica una BD real)");
        Set<Long> productosConDiferencia = calcularDiferencias(d).stream()
                .filter(x -> x.tipo() == TipoDiferencia.FALTANTE || x.tipo() == TipoDiferencia.SOBRANTE)
                .map(x -> x.producto().id()).collect(Collectors.toSet());
        boolean todosResueltos = productosConDiferencia.stream().allMatch(id -> {
            String estadoAjuste = d.estadosAjuste.get(id);
            return "APROBADO".equals(estadoAjuste) || "RECHAZADO".equals(estadoAjuste);
        });
        if (todosResueltos) actualizarToma(d, EstadoToma.APROBADA);
    }
    @Override public void rechazarAjuste(long idToma, long idProducto, String motivo) {
        TomaData d = obtener(idToma); d.estadosAjuste.put(idProducto, "RECHAZADO");
        d.auditoria.add("Ajuste rechazado para producto ID " + idProducto + ". Motivo: " + motivo);
        Set<Long> productosConDiferencia = calcularDiferencias(d).stream()
                .filter(x -> x.tipo() == TipoDiferencia.FALTANTE || x.tipo() == TipoDiferencia.SOBRANTE)
                .map(x -> x.producto().id()).collect(Collectors.toSet());
        if (productosConDiferencia.stream().allMatch(id -> Set.of("APROBADO", "RECHAZADO").contains(d.estadosAjuste.get(id)))) actualizarToma(d, EstadoToma.APROBADA);
    }
    @Override public void cerrarToma(long idToma) {
        TomaData d = obtener(idToma);
        if (!(d.toma.estado() == EstadoToma.CONCILIADA || d.toma.estado() == EstadoToma.APROBADA)) throw new IllegalStateException("Solo se puede cerrar una toma conciliada o aprobada.");
        Toma a = d.toma;
        d.toma = new Toma(a.id(), a.codigo(), a.almacen(), a.fechaInicio(), LocalDateTime.now(), a.responsable(), a.totalProductos(), a.productosContados(), a.productosDiferencia(), EstadoToma.CERRADA);
        d.auditoria.add("Toma cerrada");
    }
    @Override public List<String> listarAuditoria(long idToma) { return List.copyOf(obtener(idToma).auditoria); }
}
