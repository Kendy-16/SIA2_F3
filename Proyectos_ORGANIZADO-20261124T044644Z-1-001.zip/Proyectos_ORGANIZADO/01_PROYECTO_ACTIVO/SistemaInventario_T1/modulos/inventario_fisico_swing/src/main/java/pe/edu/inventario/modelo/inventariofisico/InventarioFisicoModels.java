package pe.edu.inventario.modelo.inventariofisico;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/** DTO y enumeraciones utilizadas por la interfaz del inventario físico. */
public final class InventarioFisicoModels {
    private InventarioFisicoModels() { }

    public enum EstadoToma {
        ABIERTA, EN_CONTEO, EN_REVISION, CONCILIADA, APROBADA, CERRADA, CANCELADA
    }

    public enum EstadoConteo { PENDIENTE, CONTADO, SEGUNDO_CONTEO, REVISADO }
    public enum TipoDiferencia { CONFORME, FALTANTE, SOBRANTE, PENDIENTE }

    public record Resumen(
            int tomasRealizadas,
            int tomasAbiertas,
            int tomasConciliadas,
            int productosConDiferencias,
            int ajustesPendientes) { }

    public record Toma(
            long id,
            String codigo,
            String almacen,
            LocalDateTime fechaInicio,
            LocalDateTime fechaCierre,
            String responsable,
            int totalProductos,
            int productosContados,
            int productosDiferencia,
            EstadoToma estado) {
        public int avancePorcentaje() {
            if (totalProductos <= 0) return 0;
            return Math.min(100, Math.max(0, (int) Math.round(productosContados * 100.0 / totalProductos)));
        }
    }

    public record Producto(
            long id,
            String codigo,
            String codigoBarras,
            String nombre,
            String categoria,
            String unidad,
            String ubicacion,
            BigDecimal stockSistema,
            BigDecimal cantidadContada,
            BigDecimal segundoConteo,
            BigDecimal costoPromedio,
            String observacion,
            EstadoConteo estado) {
        public BigDecimal cantidadFinal() {
            return segundoConteo != null ? segundoConteo : cantidadContada;
        }
    }

    public record Diferencia(
            Producto producto,
            BigDecimal stockSistema,
            BigDecimal cantidadFisica,
            BigDecimal diferencia,
            BigDecimal costoPromedio,
            BigDecimal valorDiferencia,
            TipoDiferencia tipo,
            String estadoRevision,
            String motivo) { }

    public record NuevaToma(
            String almacen,
            String alcance,
            String categoria,
            boolean incluirStockCero,
            boolean conteoCiego,
            boolean permitirSegundoConteo,
            boolean permitirConteoParcial,
            String observaciones,
            List<Long> productosSeleccionados) {
        public NuevaToma {
            productosSeleccionados = productosSeleccionados == null ? List.of() : List.copyOf(productosSeleccionados);
        }
    }
}
