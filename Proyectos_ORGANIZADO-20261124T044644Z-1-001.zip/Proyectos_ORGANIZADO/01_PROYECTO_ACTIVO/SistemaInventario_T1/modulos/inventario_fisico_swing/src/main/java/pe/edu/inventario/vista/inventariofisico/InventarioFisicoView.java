package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.InventarioFisicoController;

/** Nombre de entrada de vista para integrar el módulo desde la ventana principal existente. */
public class InventarioFisicoView extends InventarioFisicoFrame {
    public InventarioFisicoView(InventarioFisicoController controller) {
        super(controller);
    }
}
