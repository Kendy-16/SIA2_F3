package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;
import java.math.BigDecimal;
import java.util.List;

/**
 * Contrato que la vista utiliza para comunicarse con el controlador real.
 * La implementación productiva debe delegar en servicios y DAOs existentes.
 */
public interface InventarioFisicoController {
    Resumen obtenerResumen() throws Exception;
    List<Toma> listarTomas(String texto, EstadoToma estado) throws Exception;
    List<String> listarAlmacenes() throws Exception;
    List<String> listarCategorias() throws Exception;
    List<Producto> listarProductosDisponibles(String texto, String categoria, String almacen) throws Exception;
    Toma crearToma(NuevaToma solicitud) throws Exception;
    List<Producto> listarProductosToma(long idToma, boolean ocultarStockSistema) throws Exception;
    boolean esConteoCiego(long idToma) throws Exception;
    boolean permiteSegundoConteo(long idToma) throws Exception;
    void registrarConteo(long idToma, long idProducto, BigDecimal cantidad, String observacion, boolean segundoConteo) throws Exception;
    List<Diferencia> conciliar(long idToma) throws Exception;
    List<Diferencia> listarDiferencias(long idToma) throws Exception;
    void guardarObservacion(long idToma, long idProducto, String observacion) throws Exception;
    void solicitarAjuste(long idToma, long idProducto, String motivo, String observacion) throws Exception;
    void aprobarAjuste(long idToma, long idProducto) throws Exception;
    void rechazarAjuste(long idToma, long idProducto, String motivo) throws Exception;
    void cerrarToma(long idToma) throws Exception;
    List<String> listarAuditoria(long idToma) throws Exception;
}
