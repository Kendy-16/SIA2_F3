@echo off
setlocal
cd /d "%~dp0"
where mvn >nul 2>nul
if errorlevel 1 (
  echo ERROR: Maven no esta disponible en PATH.
  exit /b 1
)
mvn exec:java
endlocal
