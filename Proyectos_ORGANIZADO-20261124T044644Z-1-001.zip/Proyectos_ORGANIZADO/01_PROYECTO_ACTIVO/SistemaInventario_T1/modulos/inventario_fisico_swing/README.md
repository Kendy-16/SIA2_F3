# Módulo visual de Inventario Físico — Java Swing

Entrega de interfaz Swing para Java 21, dentro del paquete base `pe.edu.inventario`.

## Funcionalidades visuales incluidas

- Panel principal con indicadores, búsqueda, filtro por estado y tabla de tomas.
- Formulario de nueva toma: almacén, alcance, categoría, productos seleccionados, stock cero, conteo ciego, segundo conteo, conteo parcial y observaciones.
- Ventana de selección de productos.
- Registro de conteo, segundo conteo, observaciones y avance.
- Conciliación de existencias y tabla de diferencias.
- Detalle de diferencias y registro de observaciones.
- Gestión visual de solicitudes de ajuste, aprobación y rechazo.
- Historial, detalle con pestañas y auditoría.
- Reporte gráfico de indicadores.
- Operaciones de consulta y escritura de interfaz ejecutadas mediante `SwingWorker`.

## Ejecutar la demostración

Requiere JDK 21 y Maven:

```cmd
mvn clean package
mvn exec:java
```

También se puede ejecutar desde Eclipse o IntelliJ con esta clase principal:

```text
pe.edu.inventario.demo.InventarioFisicoDemo
```

La demostración utiliza `DemoInventarioFisicoController`, que guarda datos únicamente en memoria.

## Integración en `SistemaInventario_T1`

Paquete base: `pe.edu.inventario`.

1. Revisa los paquetes actuales antes de copiar archivos para evitar duplicar modelos, controladores o vistas.
2. Copia los archivos que no tengan equivalentes existentes.
3. Implementa `InventarioFisicoController` en tu capa de controladores y haz que delegue en los servicios reales del proyecto.
4. Abre la vista desde tu ventana principal con:

```java
InventarioFisicoView vista = new InventarioFisicoView(inventarioFisicoController);
vista.setVisible(true);
```

5. No incorpores `DemoInventarioFisicoController` en producción; es solo un adaptador de demostración.

## Límite importante de esta entrega

El documento adjunto que acompañó la solicitud describe principalmente ventas, caja, inventario y Kardex; no proporciona el DDL real de las tablas de tomas físicas, detalles de conteo ni ajustes de `SistemaInventario_T1`. Por ello, la entrega no incluye SQL inventado. El controlador real debe reutilizar los servicios/DAO existentes y aplicar permisos, bloqueos por toma física, transacciones y auditoría.

La demostración no modifica una base de datos ni el stock real. En producción, aprobar un ajuste debe invocar un servicio transaccional que actualice inventario y Kardex conjuntamente, registre auditoría y respete la política existente de costo promedio.
