# Módulo visual de Inventario Físico — Java Swing

Proyecto demostrativo compilable para Java 21, con paquete base `pe.edu.inventario`.

## Contenido del código fuente

- `controlador/InventarioFisicoController.java`: contrato que consume la vista.
- `modelo/inventariofisico/InventarioFisicoModels.java`: DTO y enumeraciones usadas por la interfaz.
- `vista/inventariofisico/InventarioFisicoFrame.java`: ventana principal, paneles, tablas y diálogos auxiliares (nueva toma, selector de productos, registro de conteo, diferencias, ajustes, detalle e informes).
- `vista/inventariofisico/InventarioFisicoView.java`: punto de integración para abrir la vista desde el sistema.
- `demo/DemoInventarioFisicoController.java`: implementación de demostración en memoria.
- `demo/InventarioFisicoDemo.java`: punto de entrada de la demostración.

Las ventanas auxiliares están consolidadas como clases internas de `InventarioFisicoFrame` para reducir archivos y evitar duplicar componentes reutilizables. La especificación de diseño puede dividirse en clases independientes si el árbol real de `SistemaInventario_T1` así lo requiere.

## Ejecutar en Windows (CMD)

Requisitos: JDK 21 y Maven instalado.

```cmd
mvn clean package
mvn exec:java
```

O ejecutar desde Eclipse/IntelliJ la clase:

```text
pe.edu.inventario.demo.InventarioFisicoDemo
```

## Integración en `SistemaInventario_T1`

1. Revisa primero los paquetes y clases existentes. No dupliques modelos, controladores, validadores ni componentes compartidos.
2. Reutiliza el contrato de controlador solo si no existe uno equivalente. La implementación productiva debe delegar en los servicios/DAO reales.
3. Abre la interfaz con:

```java
InventarioFisicoView vista = new InventarioFisicoView(inventarioFisicoController);
vista.setVisible(true);
```

4. No incluyas `DemoInventarioFisicoController` en producción.

## Límites de esta entrega

La demostración utiliza datos en memoria: no consulta ni modifica SQLite, existencias, Kardex, costo promedio, permisos reales ni caja. El archivo de contexto entregado para esta conversación describe principalmente ventas/inventario/Kardex y no proporciona el DDL real de las tomas físicas y sus detalles. Por ello no se inventan tablas ni columnas.

Antes de producción, conecta el controlador con los servicios reales y conserva los mecanismos existentes de permisos, ámbito por almacén, corte de inventario, bloqueo o control de movimientos, transacciones, auditoría, Kardex y costo promedio. Una aprobación de ajuste debe ejecutar una operación transaccional desde el servicio; la vista solo solicita y muestra el resultado.
