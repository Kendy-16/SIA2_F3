@echo off
setlocal
cd /d "%~dp0"
where mvn >nul 2>nul
if errorlevel 1 (
  echo ERROR: Maven no esta disponible en PATH.
  echo Instala Maven y vuelve a ejecutar este archivo.
  exit /b 1
)
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: JDK no esta disponible en PATH.
  exit /b 1
)
javac -version
mvn clean package
if errorlevel 1 exit /b 1
echo.
echo Compilacion terminada correctamente.
endlocal
