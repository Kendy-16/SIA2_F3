@echo off
setlocal
cd /d "%~dp0"

echo ==============================================
echo   SISTEMA DE INVENTARIO - INICIO
echo ==============================================

if not exist "database\inventario.db" (
    echo ERROR: No se encontro database\inventario.db
    pause
    exit /b 1
)

if not exist "database\respaldos" mkdir "database\respaldos"

if not exist "database\respaldos\inventario_antes_migraciones.db" (
    echo Creando respaldo inicial de la base de datos...
    copy /Y "database\inventario.db" "database\respaldos\inventario_antes_migraciones.db" >nul
    if errorlevel 1 (
        echo ERROR: No se pudo crear el respaldo.
        pause
        exit /b 1
    )
)

echo.
echo Compilando el proyecto...
call mvn clean compile
if errorlevel 1 (
    echo.
    echo ERROR: La compilacion fallo. La base de datos original sigue respaldada.
    pause
    exit /b 1
)

echo.
echo Iniciando el sistema...
call mvn exec:java
if errorlevel 1 (
    echo.
    echo El sistema termino con un error. Revise el mensaje anterior.
    pause
    exit /b 1
)

endlocal
