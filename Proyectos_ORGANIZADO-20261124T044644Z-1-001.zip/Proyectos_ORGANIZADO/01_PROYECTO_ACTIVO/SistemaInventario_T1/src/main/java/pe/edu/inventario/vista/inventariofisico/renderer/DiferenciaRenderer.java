package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Colorea diferencias: faltante en rojo, sobrante en ámbar, conforme en verde. Acepta BigDecimal o TipoDiferencia. */
public class DiferenciaRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
        Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
        setBorder(new EmptyBorder(2, 7, 2, 7));
        FormatoInventarioFisico.aplicarCebra(c, table, row, selected);
        setHorizontalAlignment(SwingConstants.LEFT);
        Color f = FormatoInventarioFisico.TEXT;
        if (value instanceof BigDecimal b) {
            setText(FormatoInventarioFisico.cantidad(b));
            setHorizontalAlignment(SwingConstants.RIGHT);
            f = b.signum() < 0 ? FormatoInventarioFisico.RED : b.signum() > 0 ? FormatoInventarioFisico.AMBER : FormatoInventarioFisico.GREEN;
        } else if (value instanceof TipoDiferencia t) {
            f = switch (t) {
                case FALTANTE -> FormatoInventarioFisico.RED;
                case SOBRANTE -> FormatoInventarioFisico.AMBER;
                case CONFORME -> FormatoInventarioFisico.GREEN;
                case PENDIENTE -> FormatoInventarioFisico.MUTED;
            };
        } else if (value == null) {
            setText(FormatoInventarioFisico.SIN_DATO);
        }
        if (!selected) setForeground(f);
        setFont(getFont().deriveFont(Font.BOLD));
        return c;
    }
}
