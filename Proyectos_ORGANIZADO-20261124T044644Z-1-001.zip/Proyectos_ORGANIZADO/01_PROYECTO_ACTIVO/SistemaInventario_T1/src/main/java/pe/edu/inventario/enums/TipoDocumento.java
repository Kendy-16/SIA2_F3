
package pe.edu.inventario.enums;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Defines the commercial and inventory documents
 * used to support inventory movements.
 */
public enum TipoDocumento {

    FACTURA(
            "Factura",
            "^F[0-9]{3}-[0-9]{1,8}$",
            "F001-00001234"
    ),

    BOLETA(
            "Boleta de Venta",
            "^B[0-9]{3}-[0-9]{1,8}$",
            "B001-00001234"
    ),

    GUIA_REMISION(
            "Guia de Remision",
            "^(T|G)[0-9]{3}-[0-9]{1,8}$",
            "T001-00001234 o G001-00001234"
    ),

    NOTA_CREDITO(
            "Nota de Credito",
            "^(FC|BC)[0-9]{2,3}-[0-9]{1,8}$",
            "FC01-00001234 o BC01-00001234"
    ),

    TICKET(
            "Ticket de Venta",
            "^[0-9]{1,10}$",
            "00012345"
    ),

    DOCUMENTO_INTERNO(
            "Documento Interno / Ajuste",
            "^[A-Z0-9][A-Z0-9_-]{2,14}$",
            "AJUSTE-001"
    );

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final int LONGITUD_MAXIMA = 30;

    // ==========================================
    // 2. ATRIBUTOS
    // ==========================================

    private final String descripcion;
    private final String regexPatron;
    private final String formatoEjemplo;
    private final Pattern pattern;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    private TipoDocumento(
            String descripcion,
            String regexPatron,
            String formatoEjemplo
    ) {

        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "La descripcion del documento es obligatoria."
            );
        }

        if (regexPatron == null || regexPatron.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El patron de validacion es obligatorio."
            );
        }

        if (formatoEjemplo == null || formatoEjemplo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El formato de ejemplo es obligatorio."
            );
        }

        this.descripcion = descripcion.trim();
        this.regexPatron = regexPatron;
        this.formatoEjemplo = formatoEjemplo.trim();

        this.pattern = Pattern.compile(
                regexPatron,
                Pattern.CASE_INSENSITIVE
        );
    }

    // ==========================================
    // 4. OBTENER DESCRIPCION
    // ==========================================

    public String getDescripcion() {
        return descripcion;
    }

    // ==========================================
    // 5. OBTENER CODIGO PARA BASE DE DATOS
    // ==========================================

    public String getCodigo() {
        return name();
    }

    // ==========================================
    // 6. OBTENER EXPRESION REGULAR
    // ==========================================

    public String getRegexPatron() {
        return regexPatron;
    }

    // ==========================================
    // 7. OBTENER FORMATO DE EJEMPLO
    // ==========================================

    public String getFormatoEjemplo() {
        return formatoEjemplo;
    }

    // ==========================================
    // 8. NORMALIZAR NUMERO DE DOCUMENTO
    // ==========================================

    public String normalizarNumero(String numeroDocumento) {

        if (numeroDocumento == null) {
            throw new IllegalArgumentException(
                    "El numero de documento no puede ser nulo."
            );
        }

        String numero = numeroDocumento.trim();

        if (numero.isEmpty()) {
            throw new IllegalArgumentException(
                    "El numero de documento es obligatorio."
            );
        }

        if (numero.length() > LONGITUD_MAXIMA) {
            throw new IllegalArgumentException(
                    "El numero de documento supera los 30 caracteres."
            );
        }

        if (numero.codePoints().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException(
                    "El documento contiene caracteres de control."
            );
        }

        // Normalizar letras para comparar y almacenar
        return numero.toUpperCase(Locale.ROOT);
    }

    // ==========================================
    // 9. VALIDAR FORMATO DEL DOCUMENTO
    // ==========================================

    public boolean validarFormato(String numeroDocumento) {

        try {

            String numero = normalizarNumero(numeroDocumento);

            return pattern.matcher(numero).matches();

        } catch (IllegalArgumentException e) {

            return false;
        }
    }

    // ==========================================
    // 10. VALIDAR Y DEVOLVER NUMERO NORMALIZADO
    // ==========================================

    public String validarYNormalizar(String numeroDocumento) {

        String numero = normalizarNumero(numeroDocumento);

        if (!pattern.matcher(numero).matches()) {

            throw new IllegalArgumentException(
                    "El numero de documento no tiene un formato valido. "
                    + "Formato esperado: " + formatoEjemplo
            );
        }

        return numero;
    }

    // ==========================================
    // 11. VALIDAR TIPO DE DOCUMENTO DESDE TEXTO
    // ==========================================

    public static TipoDocumento desdeTexto(String texto) {

        if (texto == null || texto.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Debe seleccionar un tipo de documento."
            );
        }

        String normalizado =
                texto.trim().toUpperCase(Locale.ROOT);

        for (TipoDocumento tipo : values()) {

            if (tipo.name().equals(normalizado)
                    || tipo.descripcion.equalsIgnoreCase(texto.trim())) {

                return tipo;
            }
        }

        throw new IllegalArgumentException(
                "Tipo de documento no valido: " + texto
        );
    }

    // ==========================================
    // 12. VALIDAR TIPO Y NUMERO DE DOCUMENTO
    // ==========================================

    public static boolean esDocumentoValido(
            TipoDocumento tipo,
            String numeroDocumento
    ) {

        if (tipo == null) {
            return false;
        }

        return tipo.validarFormato(numeroDocumento);
    }

    // ==========================================
    // 13. OBTENER TODOS LOS TIPOS DISPONIBLES
    // ==========================================

    public static TipoDocumento[] obtenerTipos() {

        return values().clone();
    }

    // ==========================================
    // 14. REPRESENTACION PARA SWING
    // ==========================================

    @Override
    public String toString() {

        return descripcion + " (" + formatoEjemplo + ")";
    }
}
