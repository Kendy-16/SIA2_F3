package pe.edu.inventario.vista.venta;

import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.seguridad.AutorizacionVentas;

import javax.swing.*;
import java.awt.*;

public class ReportesAdminView extends JPanel {

    private JTabbedPane pestanas;
    private RolUsuario rolActual;

    public ReportesAdminView(RolUsuario rolActual) {
        this.rolActual = rolActual;
        setLayout(new BorderLayout());
        
        pestanas = new JTabbedPane();

        // 1. Pestaña de Estadísticas (Ventas totales, medios de pago)
        pestanas.addTab("Estadísticas y Totales", crearPanelEstadisticas());

        // 2. Pestaña de Costos y Ganancias (Altamente Restringido)
        if (AutorizacionVentas.puedeVerCostosYGanancias(rolActual)) {
            pestanas.addTab("Costos y Rentabilidad", crearPanelRentabilidad());
        }

        // 3. Pestaña de Auditoría (Anulaciones, cambios de precio, descuentos)
        if (AutorizacionVentas.puedeVerAuditoria(rolActual)) {
            pestanas.addTab("Auditoría de Transacciones", crearPanelAuditoria());
        }

        add(pestanas, BorderLayout.CENTER);
    }

    private JPanel crearPanelEstadisticas() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Aquí se renderiza el gráfico de barras y torta de ventas (Ej. JFreeChart)", SwingConstants.CENTER), BorderLayout.CENTER);
        // Botones para exportar a PDF / Excel
        return panel;
    }

    private JPanel crearPanelRentabilidad() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Reporte de Costo Promedio vs Precio de Venta (Cálculo de Margen Comercial)", SwingConstants.CENTER), BorderLayout.CENTER);
        // Utilizaría CostoPromedioService.java mencionado en tu árbol original
        return panel;
    }

    private JPanel crearPanelAuditoria() {
        JPanel panel = new JPanel(new BorderLayout());
        // Aquí iría un JTable mostrando quién autorizó qué (eventos de AuditoriaService)
        String[] col = {"Fecha", "Administrador", "Acción", "Detalle"};
        JTable tablaAudit = new JTable(new Object[][]{}, col);
        panel.add(new JScrollPane(tablaAudit), BorderLayout.CENTER);
        return panel;
    }
}
