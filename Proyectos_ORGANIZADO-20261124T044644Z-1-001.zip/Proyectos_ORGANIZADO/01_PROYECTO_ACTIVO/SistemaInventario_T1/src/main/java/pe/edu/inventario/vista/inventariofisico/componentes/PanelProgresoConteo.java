package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Barra de progreso del conteo: "x / y productos contados". */
public class PanelProgresoConteo extends JPanel {
    private final JProgressBar barra = new JProgressBar(0, 100);
    private final JLabel titulo = new JLabel("Avance del conteo");

    public PanelProgresoConteo() {
        super(new BorderLayout(0, 4));
        setOpaque(false);
        titulo.setForeground(MUTED);
        barra.setStringPainted(true);
        add(titulo, BorderLayout.NORTH);
        add(barra, BorderLayout.CENTER);
        actualizar(0, 0);
    }

    public void actualizar(int contados, int total) {
        barra.setMaximum(Math.max(1, total));
        barra.setValue(Math.min(contados, Math.max(1, total)));
        barra.setString(contados + " / " + total + " productos contados");
    }
}
