package pe.edu.inventario.dao.venta;

import pe.edu.inventario.modelo.venta.RolUsuario;
import java.util.List;
import java.util.Map;

public interface ReporteVentaDAO {
    
    // Requisito: Consultar todas las ventas (Historial global)
    List<Map<String, Object>> obtenerHistorialGlobal(String fechaInicio, String fechaFin);

    // Requisito: Consultar ventas anuladas y devoluciones
    List<Map<String, Object>> obtenerVentasConIncidencias(String fechaInicio, String fechaFin);

    // Requisito: Consultar totales y estadísticas
    Map<String, Object> obtenerEstadisticasVenta(String fechaInicio, String fechaFin);

    // Requisito: Consultar costos y ganancias (Requiere permiso específico)
    List<Map<String, Object>> obtenerReporteRentabilidad(String fechaInicio, String fechaFin, RolUsuario rol) throws SecurityException;
    
    // Requisito: Consultar auditoría de ventas
    List<Map<String, Object>> obtenerAuditoriaVentas();
}
