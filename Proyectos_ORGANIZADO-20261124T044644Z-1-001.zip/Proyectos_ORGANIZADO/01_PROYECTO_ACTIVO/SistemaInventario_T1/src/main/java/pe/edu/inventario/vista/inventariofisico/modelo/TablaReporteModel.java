package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Indicadores del reporte (resumen general) en forma de tabla, para vista previa y exportación. */
public class TablaReporteModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"Indicador", "Valor"};
    private final List<Object[]> filas = new ArrayList<>();

    public void setResumen(Resumen r) {
        filas.clear();
        filas.add(new Object[]{"Tomas realizadas", r.tomasRealizadas()});
        filas.add(new Object[]{"Tomas abiertas", r.tomasAbiertas()});
        filas.add(new Object[]{"Tomas conciliadas", r.tomasConciliadas()});
        filas.add(new Object[]{"Productos con diferencias", r.productosConDiferencias()});
        filas.add(new Object[]{"Ajustes pendientes", r.ajustesPendientes()});
        fireTableDataChanged();
    }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) { return c == 1 ? Integer.class : String.class; }
    @Override public Object getValueAt(int r, int c) { return filas.get(r)[c]; }
}
