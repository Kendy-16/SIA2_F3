package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Diferencias que ya tienen una solicitud de ajuste (pendiente, aprobada o rechazada). */
public class TablaAjustesModel extends AbstractTableModel {
    public static final String SIN_AJUSTE = "SIN AJUSTE";
    private static final String[] COLUMNAS = {"Código", "Producto", "Diferencia", "Valor", "Estado del ajuste"};
    private List<Diferencia> filas = new ArrayList<>();

    public void setDiferencias(List<Diferencia> todas) {
        filas = todas.stream().filter(d -> d.estadoRevision() != null && !SIN_AJUSTE.equalsIgnoreCase(d.estadoRevision())
                && d.tipo() != TipoDiferencia.PENDIENTE).toList();
        fireTableDataChanged();
    }
    public Diferencia getDiferencia(int fila) { return fila < 0 || fila >= filas.size() ? null : filas.get(fila); }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) { return c == 2 || c == 3 ? BigDecimal.class : String.class; }
    @Override public Object getValueAt(int r, int c) {
        Diferencia d = filas.get(r);
        return switch (c) { case 0 -> d.producto().codigo(); case 1 -> d.producto().nombre(); case 2 -> d.diferencia(); case 3 -> d.valorDiferencia(); default -> d.estadoRevision(); };
    }
}
