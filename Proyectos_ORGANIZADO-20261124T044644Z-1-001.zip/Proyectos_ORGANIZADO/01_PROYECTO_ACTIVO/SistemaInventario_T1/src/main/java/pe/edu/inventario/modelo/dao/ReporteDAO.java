package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Consultas de solo lectura para los reportes del inventario.
 */
public class ReporteDAO {

    /** Existencias por producto y almacén, con alerta de stock mínimo. */
    public List<Object[]> existencias() throws SQLException {
        return consultar("""
                SELECT p.codigo, p.nombre, a.nombre, i.cantidad,
                       p.unidad_medida, p.stock_minimo,
                       CASE WHEN i.cantidad <= p.stock_minimo
                            THEN 'REPONER' ELSE 'OK' END
                FROM inventario i
                JOIN productos p ON p.id_producto = i.id_producto
                JOIN almacenes a ON a.id_almacen = i.id_almacen
                ORDER BY p.nombre, a.nombre
                """);
    }

    /** Inventario valorizado al costo promedio: cantidad * costo promedio. */
    public List<Object[]> inventarioValorizado() throws SQLException {
        return consultar("""
                SELECT p.codigo, p.nombre, a.nombre, i.cantidad,
                       i.costo_promedio,
                       ROUND(i.cantidad * i.costo_promedio, 2)
                FROM inventario i
                JOIN productos p ON p.id_producto = i.id_producto
                JOIN almacenes a ON a.id_almacen = i.id_almacen
                ORDER BY p.nombre, a.nombre
                """);
    }

    /**
     * Utilidad bruta por artículo (salidas con precio de venta):
     * ventas netas - costo de ventas al costo promedio.
     */
    public List<Object[]> utilidadBruta() throws SQLException {
        return consultar("""
                SELECT p.codigo, p.nombre,
                       SUM(d.cantidad),
                       ROUND(SUM(d.cantidad * d.precio_venta), 2),
                       ROUND(SUM(d.cantidad * d.costo_unitario), 2),
                       ROUND(SUM(d.cantidad * (d.precio_venta - d.costo_unitario)), 2),
                       CASE WHEN SUM(d.cantidad * d.precio_venta) > 0
                            THEN ROUND(100.0 * SUM(d.cantidad * (d.precio_venta - d.costo_unitario))
                                 / SUM(d.cantidad * d.precio_venta), 2)
                            ELSE 0 END
                FROM detalle_movimientos d
                JOIN movimientos m ON m.id_movimiento = d.id_movimiento
                                  AND m.tipo = 'SALIDA'
                JOIN productos p ON p.id_producto = d.id_producto
                GROUP BY p.id_producto, p.codigo, p.nombre
                ORDER BY 6 DESC
                """);
    }

    /** Resumen del IGV: crédito fiscal (compras) y débito fiscal (ventas). */
    public List<Object[]> resumenIgv() throws SQLException {
        return consultar("""
                SELECT CASE m.tipo WHEN 'ENTRADA' THEN 'Compras (IGV crédito fiscal)'
                                   ELSE 'Ventas (IGV débito fiscal)' END,
                       COUNT(*),
                       ROUND(SUM(d.cantidad *
                            CASE m.tipo WHEN 'ENTRADA' THEN d.costo_unitario
                                        ELSE d.precio_venta END), 2),
                       ROUND(SUM(d.igv_monto), 2)
                FROM detalle_movimientos d
                JOIN movimientos m ON m.id_movimiento = d.id_movimiento
                WHERE m.tipo IN ('ENTRADA', 'SALIDA')
                GROUP BY m.tipo
                ORDER BY m.tipo
                """);
    }

    private List<Object[]> consultar(String sql) throws SQLException {

        List<Object[]> filas = new ArrayList<>();

        try (Connection c = ConexionDB.conectar();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();

            while (rs.next()) {
                Object[] fila = new Object[n];
                for (int i = 0; i < n; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                filas.add(fila);
            }
        }

        return filas;
    }
}
