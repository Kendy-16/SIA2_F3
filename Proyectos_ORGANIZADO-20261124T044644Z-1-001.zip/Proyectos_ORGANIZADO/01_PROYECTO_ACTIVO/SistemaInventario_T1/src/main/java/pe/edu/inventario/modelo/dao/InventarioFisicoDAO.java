
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.ConexionDB;


import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.modelo.DetalleInventarioFisico;

import java.math.BigDecimal;
import java.math.RoundingMode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * DAO del modulo de inventario fisico.
 *
 * Responsabilidades:
 *
 * - Crear tomas de inventario.
 * - Capturar el stock y costo promedio del sistema.
 * - Registrar cantidades fisicas.
 * - Calcular diferencias e impacto valorizado.
 * - Consultar los detalles de cada conteo.
 * - Procesar ajustes masivos.
 * - Actualizar inventario, movimientos y Kardex.
 * - Mantener la atomicidad de las operaciones.
 * - Proteger las operaciones concurrentes mediante
 *   transacciones de escritura de SQLite.
 *
 * El procesamiento masivo se realiza en una unica
 * transaccion JDBC.
 *
 * SQLite no admite SELECT FOR UPDATE. Por eso se
 * adquiere el bloqueo de escritura mediante una
 * actualizacion controlada de la fila del almacen.
 */
public class InventarioFisicoDAO {

    // =========================================================
    // 1. CONSTANTES
    // =========================================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final BigDecimal VALOR_MAXIMO =
            new BigDecimal("1000000000000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;

    private static final int MAX_DECIMALES_COSTO = 6;

    private static final int MAX_DECIMALES_VALOR = 6;

    private static final int MAX_OBSERVACION = 500;

    private static final int BUSY_TIMEOUT_CONTEO = 10000;

    private static final Set<String> MODOS_VALIDOS = Set.of(
            "GENERAL",
            "PARCIAL",
            "CICLICO"
    );

    private static final Set<String> UNIDADES_VALIDAS = Set.of(
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    );

    private static final Set<String> UNIDADES_ENTERAS = Set.of(
            "UNIDAD",
            "CAJA",
            "PAQUETE"
    );

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile(
                    "^[A-Z0-9][A-Z0-9._/-]{0,49}$"
            );

    // =========================================================
    // 2. CREAR CONTEO FISICO
    // =========================================================

    /**
     * Crea una nueva toma de inventario fisico.
     *
     * El sistema captura las existencias y costos actuales
     * de todos los productos activos del almacen.
     *
     * Antes de crearla:
     * - Bloquea la escritura en SQLite.
     * - Verifica que el almacen exista y este activo.
     * - Impide que exista otra toma abierta en el almacen.
     *
     * @param idAlmacen identificador del almacen
     * @param modo GENERAL, PARCIAL o CICLICO
     * @param observacion observacion general
     * @return identificador de la toma creada
     */
    public int crearConteo(
            int idAlmacen,
            String modo,
            String observacion
    ) throws SQLException {

        validarIdentificador(idAlmacen, "almacen");

        String modoValido = validarModo(modo);

        String observacionValida =
                normalizarObservacion(observacion);

        String sqlCabecera = """
                INSERT INTO tomas_inventario_fisico
                (
                    id_almacen,
                    modo,
                    observacion
                )
                VALUES (?, ?, ?)
                """;

        String sqlProductos = """
                SELECT
                    p.id_producto,
                    p.unidad_medida,
                    COALESCE(i.cantidad, 0) AS stock,
                    COALESCE(i.costo_promedio, 0) AS costo
                FROM productos p
                LEFT JOIN inventario i
                    ON i.id_producto = p.id_producto
                   AND i.id_almacen = ?
                WHERE p.activo = 1
                ORDER BY p.nombre COLLATE NOCASE
                """;

        String sqlDetalle = """
                INSERT INTO detalle_toma_inventario
                (
                    id_toma,
                    id_producto,
                    stock_sistema,
                    costo_promedio
                )
                VALUES (?, ?, ?, ?)
                """;

        try (Connection cn = ConexionDB.conectar()) {

            configurarBusyTimeoutConteo(cn);

            cn.setAutoCommit(false);

            try {

                // -------------------------------------------------
                // 1. BLOQUEAR ESCRITURA DEL ALMACEN
                // -------------------------------------------------

                bloquearEscrituraAlmacen(
                        cn,
                        idAlmacen
                );

                // -------------------------------------------------
                // 2. VALIDAR ALMACEN ACTIVO
                // -------------------------------------------------

                validarAlmacenActivoParaToma(
                        cn,
                        idAlmacen
                );

                // -------------------------------------------------
                // 3. IMPEDIR OTRA TOMA ABIERTA
                // -------------------------------------------------

                validarSinOtraTomaAbierta(
                        cn,
                        idAlmacen
                );

                // -------------------------------------------------
                // 4. CREAR CABECERA
                // -------------------------------------------------

                try (PreparedStatement ps =
                             cn.prepareStatement(sqlCabecera)) {

                    ps.setInt(1, idAlmacen);
                    ps.setString(2, modoValido);
                    ps.setString(3, observacionValida);

                    if (ps.executeUpdate() != 1) {

                        throw new SQLException(
                                "No se pudo crear la cabecera "
                                + "del conteo fisico."
                        );
                    }
                }

                int idToma = obtenerUltimoId(cn);

                if (idToma <= 0) {

                    throw new SQLException(
                            "No se pudo obtener el identificador "
                            + "del conteo."
                    );
                }

                // -------------------------------------------------
                // 5. CAPTURAR EXISTENCIAS Y COSTOS
                // -------------------------------------------------

                int productosRegistrados = 0;

                try (PreparedStatement psProductos =
                             cn.prepareStatement(sqlProductos);
                     PreparedStatement psDetalle =
                             cn.prepareStatement(sqlDetalle)) {

                    psProductos.setInt(1, idAlmacen);

                    try (ResultSet rs =
                                 psProductos.executeQuery()) {

                        while (rs.next()) {

                            int idProducto =
                                    rs.getInt("id_producto");

                            String unidad =
                                    rs.getString("unidad_medida");

                            BigDecimal stock = validarCantidad(
                                    decimal(rs.getString("stock"))
                            );

                            BigDecimal costo = validarCosto(
                                    decimal(rs.getString("costo"))
                            );

                            validarIdentificador(
                                    idProducto,
                                    "producto"
                            );

                            validarUnidad(
                                    unidad,
                                    idProducto
                            );

                            psDetalle.setInt(1, idToma);
                            psDetalle.setInt(2, idProducto);

                            // SQLite almacena estas columnas como REAL.
                            psDetalle.setDouble(
                                    3,
                                    stock.doubleValue()
                            );

                            psDetalle.setDouble(
                                    4,
                                    costo.doubleValue()
                            );

                            psDetalle.addBatch();

                            productosRegistrados++;
                        }
                    }

                    if (productosRegistrados == 0) {

                        throw new SQLException(
                                "No existen productos activos "
                                + "para realizar el conteo."
                        );
                    }

                    int[] resultados = psDetalle.executeBatch();

                    if (resultados.length != productosRegistrados) {

                        throw new SQLException(
                                "No se pudieron guardar todos "
                                + "los detalles del conteo."
                        );
                    }

                    for (int resultado : resultados) {

                        if (resultado == Statement.EXECUTE_FAILED) {

                            throw new SQLException(
                                    "Fallo el registro de un producto "
                                    + "en el conteo."
                            );
                        }
                    }
                }

                // -------------------------------------------------
                // 6. CONFIRMAR TRANSACCION
                // -------------------------------------------------

                cn.commit();

                return idToma;

            } catch (SQLException | RuntimeException ex) {

                rollback(cn, ex);

                throw ex;
            }
        }
    }

    // =========================================================
    // 3. REGISTRAR CANTIDAD FISICA
    // =========================================================

    /**
     * Registra la cantidad encontrada fisicamente.
     *
     * La cantidad puede ser cero porque representa
     * las unidades realmente encontradas.
     *
     * Se calcula:
     *
     * diferencia = cantidadFisica - stockSistema
     *
     * impactoValorizado = diferencia * costoPromedio
     *
     * La operacion se protege mediante una transaccion.
     *
     * @param idToma identificador de la toma
     * @param idProducto identificador del producto
     * @param cantidadFisica cantidad encontrada
     * @param observacion observacion del producto
     */
    public void registrarCantidadFisica(
            int idToma,
            int idProducto,
            BigDecimal cantidadFisica,
            String observacion
    ) throws SQLException {

        validarIdentificador(idToma, "conteo");

        validarIdentificador(idProducto, "producto");

        BigDecimal cantidadValidada =
                validarCantidad(cantidadFisica);

        String observacionValida =
                normalizarObservacion(observacion);

        try (Connection cn = ConexionDB.conectar()) {

            configurarBusyTimeoutConteo(cn);

            // Recuperar almacen antes de iniciar la transaccion.
            int idAlmacen =
                    obtenerAlmacenDeTomaPretransaccion(
                            cn,
                            idToma
                    );

            cn.setAutoCommit(false);

            try {

                // 1. Bloquear escritura.
                bloquearEscrituraAlmacen(
                        cn,
                        idAlmacen
                );

                // 2. Comprobar existencia del almacen.
                validarAlmacen(
                        cn,
                        idAlmacen
                );

                // 3. Comprobar que la toma siga abierta.
                validarConteoAbierto(
                        cn,
                        idToma
                );

                // 4. Recuperar los datos del producto en el conteo.
                DatosDetalle detalle =
                        obtenerDetalleParaRegistro(
                                cn,
                                idToma,
                                idProducto
                        );

                // 5. Validar unidad de medida.
                validarUnidadFisica(
                        cantidadValidada,
                        detalle.unidad(),
                        idProducto
                );

                // 6. Calcular diferencia e impacto.
                BigDecimal diferencia =
                        cantidadValidada.subtract(
                                detalle.stockSistema()
                        );

                diferencia = diferencia.setScale(
                        MAX_DECIMALES_CANTIDAD,
                        RoundingMode.UNNECESSARY
                );

                BigDecimal impacto =
                        diferencia.multiply(
                                detalle.costoPromedio()
                        ).setScale(
                                MAX_DECIMALES_VALOR,
                                RoundingMode.HALF_UP
                        );

                validarValorAbsoluto(impacto);

                // 7. Actualizar el detalle.
                String sql = """
                        UPDATE detalle_toma_inventario
                        SET
                            cantidad_fisica = ?,
                            diferencia = ?,
                            impacto_valorizado = ?,
                            observacion = ?
                        WHERE id_toma = ?
                          AND id_producto = ?
                          AND EXISTS (
                              SELECT 1
                              FROM tomas_inventario_fisico t
                              WHERE t.id_toma =
                                    detalle_toma_inventario.id_toma
                                AND t.estado = 'ABIERTO'
                          )
                        """;

                try (PreparedStatement ps =
                             cn.prepareStatement(sql)) {

                    ps.setDouble(
                            1,
                            cantidadValidada.doubleValue()
                    );

                    ps.setDouble(
                            2,
                            diferencia.doubleValue()
                    );

                    ps.setDouble(
                            3,
                            impacto.doubleValue()
                    );

                    ps.setString(4, observacionValida);

                    ps.setInt(5, idToma);
                    ps.setInt(6, idProducto);

                    if (ps.executeUpdate() != 1) {

                        throw new SQLException(
                                "No se actualizo el conteo. "
                                + "Compruebe que el producto "
                                + "pertenezca a la toma."
                        );
                    }
                }

                cn.commit();

            } catch (SQLException | RuntimeException ex) {

                rollback(cn, ex);

                throw ex;
            }
        }
    }

    // =========================================================
    // 4. LISTAR DETALLE DEL CONTEO
    // =========================================================

    /**
     * Recupera los productos incluidos en una toma.
     *
     * @param idToma identificador del conteo
     * @return lista de detalles del conteo
     */
    public List<DetalleInventarioFisico> listarDetalle(
            int idToma
    ) throws SQLException {

        validarIdentificador(idToma, "conteo");

        String sql = """
                SELECT
                    d.id_detalle,
                    d.id_toma,
                    d.id_producto,
                    p.codigo,
                    p.nombre,
                    p.unidad_medida,
                    d.stock_sistema,
                    d.cantidad_fisica,
                    d.costo_promedio,
                    d.observacion
                FROM detalle_toma_inventario d
                INNER JOIN productos p
                    ON p.id_producto = d.id_producto
                WHERE d.id_toma = ?
                ORDER BY p.nombre COLLATE NOCASE
                """;

        List<DetalleInventarioFisico> resultado =
                new ArrayList<>();

        try (Connection cn = ConexionDB.conectar();
             PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idToma);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    String cantidadTexto =
                            rs.getString("cantidad_fisica");

                    BigDecimal cantidad =
                            cantidadTexto == null
                                    ? null
                                    : decimal(cantidadTexto);

                    resultado.add(
                            new DetalleInventarioFisico(
                                    rs.getInt("id_detalle"),
                                    rs.getInt("id_toma"),
                                    rs.getInt("id_producto"),
                                    rs.getString("codigo"),
                                    rs.getString("nombre"),
                                    rs.getString("unidad_medida"),
                                    validarCantidad(
                                            decimal(
                                                    rs.getString(
                                                            "stock_sistema"
                                                    )
                                            )
                                    ),
                                    cantidad == null
                                            ? null
                                            : validarCantidad(cantidad),
                                    validarCosto(
                                            decimal(
                                                    rs.getString(
                                                            "costo_promedio"
                                                    )
                                            )
                                    ),
                                    rs.getString("observacion")
                            )
                    );
                }
            }
        }

        return resultado;
    }

    // =========================================================
    // 5. PROCESAR CONTEO MASIVO
    // =========================================================

    /**
     * Procesa todos los productos de una toma.
     *
     * La operacion completa se realiza dentro de una
     * unica transaccion JDBC.
     *
     * Actualiza:
     * - movimientos
     * - detalle_movimientos
     * - inventario
     * - kardex
     * - estado de la toma
     *
     * @param idToma identificador del conteo
     * @return cantidad de ajustes registrados
     */
    public int procesarConteo(
            int idToma
    ) throws SQLException {

        validarIdentificador(idToma, "conteo");

        try (Connection cn = ConexionDB.conectar()) {

            configurarBusyTimeoutConteo(cn);

            // -------------------------------------------------
            // 5.1 RECUPERAR ALMACEN ANTES DE LA TRANSACCION
            // -------------------------------------------------

            int idAlmacenBloqueo =
                    obtenerAlmacenDeTomaPretransaccion(
                            cn,
                            idToma
                    );

            cn.setAutoCommit(false);

            try {

                // -------------------------------------------------
                // 5.2 ADQUIRIR BLOQUEO DE ESCRITURA
                // -------------------------------------------------

                bloquearEscrituraAlmacen(
                        cn,
                        idAlmacenBloqueo
                );

                // Comprobar que el almacen siga existiendo.
                validarAlmacen(
                        cn,
                        idAlmacenBloqueo
                );

                // -------------------------------------------------
                // 5.3 OBTENER CABECERA Y ESTADO
                // -------------------------------------------------

                int idAlmacen;

                String sqlCabecera = """
                        SELECT id_almacen, estado
                        FROM tomas_inventario_fisico
                        WHERE id_toma = ?
                        """;

                try (PreparedStatement ps =
                             cn.prepareStatement(sqlCabecera)) {

                    ps.setInt(1, idToma);

                    try (ResultSet rs = ps.executeQuery()) {

                        if (!rs.next()) {

                            throw new SQLException(
                                    "El conteo fisico no existe."
                            );
                        }

                        idAlmacen =
                                rs.getInt("id_almacen");

                        String estado =
                                rs.getString("estado");

                        if (idAlmacen != idAlmacenBloqueo) {

                            throw new SQLException(
                                    "El almacen de la toma "
                                    + "cambio durante la operacion."
                            );
                        }

                        if (!"ABIERTO".equals(estado)) {

                            throw new SQLException(
                                    "Solo se pueden procesar "
                                    + "conteos que esten abiertos."
                            );
                        }
                    }
                }

                // -------------------------------------------------
                // 5.4 OBTENER PRODUCTOS DEL CONTEO
                // -------------------------------------------------

                List<FilaConteo> filas =
                        obtenerFilasConteo(
                                cn,
                                idToma,
                                idAlmacen
                        );

                if (filas.isEmpty()) {

                    throw new SQLException(
                            "El conteo no contiene productos."
                    );
                }

                // -------------------------------------------------
                // 5.5 VERIFICAR QUE TODOS ESTEN CONTADOS
                // -------------------------------------------------

                for (FilaConteo fila : filas) {

                    if (fila.cantidadFisica() == null) {

                        throw new SQLException(
                                "Falta registrar la cantidad fisica "
                                + "del producto ID "
                                + fila.idProducto() + "."
                        );
                    }

                    BigDecimal cantidad =
                            validarCantidad(fila.cantidadFisica());

                    validarUnidadFisica(
                            cantidad,
                            fila.unidad(),
                            fila.idProducto()
                    );
                }

                // -------------------------------------------------
                // 5.6 VERIFICAR CAMBIOS EN EL INVENTARIO
                // -------------------------------------------------

                for (FilaConteo fila : filas) {

                    if (fila.stockActual().compareTo(
                            fila.stockSistema()
                    ) != 0
                            || fila.costoActual().compareTo(
                                    fila.costoPromedio()
                            ) != 0) {

                        throw new SQLException(
                                "El inventario del producto ID "
                                + fila.idProducto()
                                + " cambio despues de iniciar "
                                + "el conteo. Debe realizar "
                                + "un nuevo conteo."
                        );
                    }
                }

                // -------------------------------------------------
                // 5.7 REGISTRAR AJUSTES
                // -------------------------------------------------

                int ajustesRegistrados = 0;

                for (FilaConteo fila : filas) {

                    BigDecimal diferencia =
                            fila.cantidadFisica().subtract(
                                    fila.stockSistema()
                            );

                    // Si no existen diferencias, no se genera
                    // movimiento ni registro de ajuste.
                    if (diferencia.signum() == 0) {
                        continue;
                    }

                    BigDecimal cantidadAjuste =
                            diferencia.abs();

                    validarCantidad(cantidadAjuste);

                    validarUnidadFisica(
                            cantidadAjuste,
                            fila.unidad(),
                            fila.idProducto()
                    );

                    BigDecimal costo =
                            validarCosto(
                                    fila.costoPromedio()
                            );

                    // No se puede valorizar un sobrante sin costo.
                    if (diferencia.signum() > 0
                            && (!fila.existeInventario()
                            || costo.signum() <= 0)) {

                        throw new SQLException(
                                "El producto ID "
                                + fila.idProducto()
                                + " no tiene un costo promedio "
                                + "valido. Registre primero "
                                + "una entrada valorizada."
                        );
                    }

                    String documento =
                            "IF-" + idToma + "-"
                            + fila.idProducto();

                    validarDocumento(documento);

                    String observacion =
                            "Ajuste por inventario fisico #"
                            + idToma;

                    // 1. Insertar cabecera.
                    int idMovimiento = insertarMovimiento(
                            cn,
                            documento,
                            observacion,
                            idAlmacen
                    );

                    // 2. Insertar detalle.
                    insertarDetalleMovimiento(
                            cn,
                            idMovimiento,
                            fila.idProducto(),
                            cantidadAjuste,
                            costo
                    );

                    // 3. Actualizar existencias.
                    actualizarExistencias(
                            cn,
                            fila,
                            idAlmacen
                    );

                    // 4. Determinar direccion del ajuste.
                    BigDecimal entrada =
                            diferencia.signum() > 0
                                    ? cantidadAjuste
                                    : BigDecimal.ZERO.setScale(
                                            MAX_DECIMALES_CANTIDAD
                                    );

                    BigDecimal salida =
                            diferencia.signum() < 0
                                    ? cantidadAjuste
                                    : BigDecimal.ZERO.setScale(
                                            MAX_DECIMALES_CANTIDAD
                                    );

                    // 5. Registrar Kardex.
                    insertarKardex(
                            cn,
                            fila.idProducto(),
                            idAlmacen,
                            documento,
                            entrada,
                            salida,
                            fila.cantidadFisica(),
                            costo
                    );

                    ajustesRegistrados++;
                }

                // -------------------------------------------------
                // 5.8 CERRAR CONTEO
                // -------------------------------------------------

                String sqlCerrar = """
                        UPDATE tomas_inventario_fisico
                        SET
                            estado = 'PROCESADO',
                            procesado_en =
                                datetime('now','localtime')
                        WHERE id_toma = ?
                          AND estado = 'ABIERTO'
                        """;

                try (PreparedStatement ps =
                             cn.prepareStatement(sqlCerrar)) {

                    ps.setInt(1, idToma);

                    if (ps.executeUpdate() != 1) {

                        throw new SQLException(
                                "No se pudo cerrar el conteo fisico."
                        );
                    }
                }

                // -------------------------------------------------
                // 5.9 CONFIRMAR TRANSACCION COMPLETA
                // -------------------------------------------------

                cn.commit();

                return ajustesRegistrados;

            } catch (SQLException | RuntimeException ex) {

                rollback(cn, ex);

                throw ex;
            }
        }
    }

    // =========================================================
    // 6. OBTENER FILAS DEL CONTEO
    // =========================================================

    private List<FilaConteo> obtenerFilasConteo(
            Connection cn,
            int idToma,
            int idAlmacen
    ) throws SQLException {

        String sqlDetalle = """
                SELECT
                    d.id_producto,
                    d.stock_sistema,
                    d.cantidad_fisica,
                    d.costo_promedio,
                    p.unidad_medida
                FROM detalle_toma_inventario d
                INNER JOIN productos p
                    ON p.id_producto = d.id_producto
                WHERE d.id_toma = ?
                ORDER BY d.id_producto
                """;

        String sqlInventario = """
                SELECT cantidad, costo_promedio
                FROM inventario
                WHERE id_producto = ?
                  AND id_almacen = ?
                """;

        List<FilaConteo> filas = new ArrayList<>();

        try (PreparedStatement psDetalle =
                     cn.prepareStatement(sqlDetalle);
             PreparedStatement psInventario =
                     cn.prepareStatement(sqlInventario)) {

            psDetalle.setInt(1, idToma);

            try (ResultSet rs = psDetalle.executeQuery()) {

                while (rs.next()) {

                    int idProducto =
                            rs.getInt("id_producto");

                    String unidad =
                            rs.getString("unidad_medida");

                    validarUnidad(
                            unidad,
                            idProducto
                    );

                    BigDecimal stockSistema =
                            validarCantidad(
                                    decimal(
                                            rs.getString(
                                                    "stock_sistema"
                                            )
                                    )
                            );

                    String cantidadTexto =
                            rs.getString("cantidad_fisica");

                    BigDecimal cantidadFisica =
                            cantidadTexto == null
                                    ? null
                                    : validarCantidad(
                                            decimal(cantidadTexto)
                                    );

                    BigDecimal costoPromedio =
                            validarCosto(
                                    decimal(
                                            rs.getString(
                                                    "costo_promedio"
                                            )
                                    )
                            );

                    psInventario.setInt(1, idProducto);
                    psInventario.setInt(2, idAlmacen);

                    BigDecimal stockActual =
                            BigDecimal.ZERO.setScale(
                                    MAX_DECIMALES_CANTIDAD
                            );

                    BigDecimal costoActual =
                            BigDecimal.ZERO.setScale(
                                    MAX_DECIMALES_COSTO
                            );

                    boolean existeInventario = false;

                    try (ResultSet ri =
                                 psInventario.executeQuery()) {

                        if (ri.next()) {

                            existeInventario = true;

                            stockActual =
                                    validarCantidad(
                                            decimal(
                                                    ri.getString(
                                                            "cantidad"
                                                    )
                                            )
                                    );

                            costoActual =
                                    validarCosto(
                                            decimal(
                                                    ri.getString(
                                                            "costo_promedio"
                                                    )
                                            )
                                    );
                        }
                    }

                    filas.add(
                            new FilaConteo(
                                    idProducto,
                                    unidad,
                                    stockSistema,
                                    cantidadFisica,
                                    costoPromedio,
                                    stockActual,
                                    costoActual,
                                    existeInventario
                            )
                    );
                }
            }
        }

        return filas;
    }

    // =========================================================
    // 7. OBTENER DETALLE PARA REGISTRAR CANTIDAD
    // =========================================================

    private DatosDetalle obtenerDetalleParaRegistro(
            Connection cn,
            int idToma,
            int idProducto
    ) throws SQLException {

        String sql = """
                SELECT
                    d.stock_sistema,
                    d.costo_promedio,
                    p.unidad_medida
                FROM detalle_toma_inventario d
                INNER JOIN productos p
                    ON p.id_producto = d.id_producto
                WHERE d.id_toma = ?
                  AND d.id_producto = ?
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idToma);
            ps.setInt(2, idProducto);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {

                    throw new SQLException(
                            "El producto no pertenece "
                            + "al conteo seleccionado."
                    );
                }

                return new DatosDetalle(
                        validarCantidad(
                                decimal(
                                        rs.getString("stock_sistema")
                                )
                        ),
                        validarCosto(
                                decimal(
                                        rs.getString("costo_promedio")
                                )
                        ),
                        rs.getString("unidad_medida")
                );
            }
        }
    }

    // =========================================================
    // 8. INSERTAR CABECERA DE MOVIMIENTO
    // =========================================================

    private int insertarMovimiento(
            Connection cn,
            String documento,
            String observacion,
            int idAlmacen
    ) throws SQLException {

        validarDocumento(documento);

        String sql = """
                INSERT INTO movimientos
                (
                    tipo,
                    fecha,
                    documento,
                    observacion,
                    id_almacen
                )
                VALUES (
                    'AJUSTE',
                    datetime('now','localtime'),
                    ?, ?, ?
                )
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setString(1, documento);
            ps.setString(2, observacion);
            ps.setInt(3, idAlmacen);

            if (ps.executeUpdate() != 1) {

                throw new SQLException(
                        "No se pudo registrar la cabecera "
                        + "del movimiento."
                );
            }
        }

        int idMovimiento = obtenerUltimoId(cn);

        if (idMovimiento <= 0) {

            throw new SQLException(
                    "No se pudo obtener el ID del movimiento."
            );
        }

        return idMovimiento;
    }

    // =========================================================
    // 9. INSERTAR DETALLE DEL MOVIMIENTO
    // =========================================================

    private void insertarDetalleMovimiento(
            Connection cn,
            int idMovimiento,
            int idProducto,
            BigDecimal cantidad,
            BigDecimal costo
    ) throws SQLException {

        BigDecimal cantidadValida =
                validarCantidad(cantidad);

        BigDecimal costoValido =
                validarCosto(costo);

        if (cantidadValida.signum() <= 0) {

            throw new SQLException(
                    "El detalle del ajuste debe ser mayor que cero."
            );
        }

        String sql = """
                INSERT INTO detalle_movimientos
                (
                    id_movimiento,
                    id_producto,
                    cantidad,
                    costo_unitario
                )
                VALUES (?, ?, ?, ?)
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idMovimiento);
            ps.setInt(2, idProducto);

            ps.setDouble(
                    3,
                    cantidadValida.doubleValue()
            );

            ps.setDouble(
                    4,
                    costoValido.doubleValue()
            );

            if (ps.executeUpdate() != 1) {

                throw new SQLException(
                        "No se pudo registrar el detalle "
                        + "del movimiento."
                );
            }
        }
    }

    // =========================================================
    // 10. ACTUALIZAR EXISTENCIAS
    // =========================================================

    private void actualizarExistencias(
            Connection cn,
            FilaConteo fila,
            int idAlmacen
    ) throws SQLException {

        BigDecimal cantidadFisica =
                validarCantidad(fila.cantidadFisica());

        if (fila.existeInventario()) {

            String sql = """
                    UPDATE inventario
                    SET cantidad = ?
                    WHERE id_producto = ?
                      AND id_almacen = ?
                    """;

            try (PreparedStatement ps =
                         cn.prepareStatement(sql)) {

                ps.setDouble(
                        1,
                        cantidadFisica.doubleValue()
                );

                ps.setInt(2, fila.idProducto());
                ps.setInt(3, idAlmacen);

                if (ps.executeUpdate() != 1) {

                    throw new SQLException(
                            "No se pudo actualizar el stock "
                            + "del producto ID "
                            + fila.idProducto() + "."
                    );
                }
            }

        } else {

            // No se debe crear inventario sin un costo valido.
            if (cantidadFisica.signum() > 0) {

                throw new SQLException(
                        "No existe un registro de inventario "
                        + "ni un costo promedio para el producto ID "
                        + fila.idProducto() + "."
                );
            }
        }
    }

    // =========================================================
    // 11. INSERTAR KARDEX
    // =========================================================

    private void insertarKardex(
            Connection cn,
            int idProducto,
            int idAlmacen,
            String documento,
            BigDecimal entrada,
            BigDecimal salida,
            BigDecimal saldo,
            BigDecimal costoPromedio
    ) throws SQLException {

        BigDecimal entradaValida =
                validarCantidad(entrada);

        BigDecimal salidaValida =
                validarCantidad(salida);

        BigDecimal saldoValido =
                validarCantidad(saldo);

        BigDecimal costoValido =
                validarCosto(costoPromedio);

        if (entradaValida.signum() > 0
                && salidaValida.signum() > 0) {

            throw new SQLException(
                    "Un ajuste no puede representar "
                    + "una entrada y una salida simultaneas."
            );
        }

        if (entradaValida.signum() == 0
                && salidaValida.signum() == 0) {

            throw new SQLException(
                    "El Kardex requiere una entrada o salida positiva."
            );
        }

        BigDecimal valorSaldo =
                saldoValido.multiply(costoValido)
                        .setScale(
                                MAX_DECIMALES_VALOR,
                                RoundingMode.HALF_UP
                        );

        validarValorAbsoluto(valorSaldo);

        validarDocumento(documento);

        String sql = """
                INSERT INTO kardex
                (
                    id_producto,
                    id_almacen,
                    fecha,
                    tipo,
                    documento,
                    entrada,
                    salida,
                    saldo,
                    costo_unitario,
                    costo_promedio,
                    valor_saldo
                )
                VALUES (
                    ?, ?,
                    datetime('now','localtime'),
                    'AJUSTE',
                    ?, ?, ?, ?, ?, ?, ?
                )
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idProducto);
            ps.setInt(2, idAlmacen);
            ps.setString(3, documento);

            ps.setDouble(
                    4,
                    entradaValida.doubleValue()
            );

            ps.setDouble(
                    5,
                    salidaValida.doubleValue()
            );

            ps.setDouble(
                    6,
                    saldoValido.doubleValue()
            );

            // El ajuste se valora al costo promedio vigente.
            ps.setDouble(
                    7,
                    costoValido.doubleValue()
            );

            ps.setDouble(
                    8,
                    costoValido.doubleValue()
            );

            ps.setDouble(
                    9,
                    valorSaldo.doubleValue()
            );

            if (ps.executeUpdate() != 1) {

                throw new SQLException(
                        "No se pudo registrar el Kardex "
                        + "del producto ID " + idProducto + "."
                );
            }
        }
    }

    // =========================================================
    // 12. VALIDAR EXISTENCIA DEL ALMACEN
    // =========================================================

    private void validarAlmacen(
            Connection cn,
            int idAlmacen
    ) throws SQLException {

        String sql = """
                SELECT 1
                FROM almacenes
                WHERE id_almacen = ?
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idAlmacen);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {

                    throw new SQLException(
                            "El almacen seleccionado no existe."
                    );
                }
            }
        }
    }

    // =========================================================
    // 13. VALIDAR CONTEO ABIERTO
    // =========================================================

    private void validarConteoAbierto(
            Connection cn,
            int idToma
    ) throws SQLException {

        String sql = """
                SELECT estado
                FROM tomas_inventario_fisico
                WHERE id_toma = ?
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idToma);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {

                    throw new SQLException(
                            "El conteo fisico no existe."
                    );
                }

                if (!"ABIERTO".equals(rs.getString("estado"))) {

                    throw new SQLException(
                            "El conteo ya no se encuentra abierto."
                    );
                }
            }
        }
    }

    // =========================================================
    // 14. VALIDAR UNIDAD DEL PRODUCTO
    // =========================================================

    private void validarUnidadProducto(
            Connection cn,
            int idProducto,
            BigDecimal cantidad
    ) throws SQLException {

        String sql = """
                SELECT unidad_medida
                FROM productos
                WHERE id_producto = ?
                """;

        try (PreparedStatement ps =
                     cn.prepareStatement(sql)) {

            ps.setInt(1, idProducto);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {

                    throw new SQLException(
                            "El producto no existe."
                    );
                }

                validarUnidadFisica(
                        cantidad,
                        rs.getString("unidad_medida"),
                        idProducto
                );
            }
        }
    }

    // =========================================================
    // 15. VALIDAR UNIDAD DE MEDIDA
    // =========================================================

    private void validarUnidad(
            String unidad,
            int idProducto
    ) throws SQLException {

        if (unidad == null || unidad.isBlank()) {

            throw new SQLException(
                    "El producto ID " + idProducto
                    + " no tiene unidad de medida."
            );
        }

        String normalizada =
                unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(normalizada)) {

            throw new SQLException(
                    "La unidad del producto ID "
                    + idProducto + " no es valida."
            );
        }
    }

    private void validarUnidadFisica(
            BigDecimal cantidad,
            String unidad,
            int idProducto
    ) throws SQLException {

        validarUnidad(unidad, idProducto);

        String normalizada =
                unidad.trim().toUpperCase(Locale.ROOT);

        if (UNIDADES_ENTERAS.contains(normalizada)
                && cantidad.stripTrailingZeros().scale() > 0) {

            throw new SQLException(
                    "El producto ID " + idProducto
                    + " utiliza la unidad " + normalizada
                    + " y requiere cantidades enteras."
            );
        }
    }

    // =========================================================
    // 16. VALIDAR IDENTIFICADORES
    // =========================================================

    private void validarIdentificador(
            int id,
            String entidad
    ) {

        if (id <= 0) {

            throw new IllegalArgumentException(
                    "El identificador del "
                    + entidad + " debe ser positivo."
            );
        }
    }

    // =========================================================
    // 17. VALIDAR MODO DE CONTEO
    // =========================================================

    private String validarModo(String modo) {

        if (modo == null || modo.isBlank()) {

            throw new IllegalArgumentException(
                    "Seleccione un modo de conteo."
            );
        }

        String normalizado =
                modo.trim().toUpperCase(Locale.ROOT);

        if (!MODOS_VALIDOS.contains(normalizado)) {

            throw new IllegalArgumentException(
                    "El modo de conteo no es valido."
            );
        }

        return normalizado;
    }

    // =========================================================
    // 18. VALIDAR CANTIDAD
    // =========================================================

    /**
     * Valida cantidades y devuelve su representacion
     * normalizada a tres decimales sin redondear.
     *
     * Se permite cero en el conteo fisico.
     */
    private BigDecimal validarCantidad(
            BigDecimal cantidad
    ) {

        if (cantidad == null) {

            throw new IllegalArgumentException(
                    "La cantidad fisica es obligatoria."
            );
        }

        if (cantidad.signum() < 0) {

            throw new IllegalArgumentException(
                    "La cantidad fisica no puede ser negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {

            throw new IllegalArgumentException(
                    "La cantidad supera el maximo permitido."
            );
        }

        if (cantidad.stripTrailingZeros().scale()
                > MAX_DECIMALES_CANTIDAD) {

            throw new IllegalArgumentException(
                    "La cantidad admite como maximo tres decimales."
            );
        }

        return cantidad.setScale(
                MAX_DECIMALES_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 19. VALIDAR COSTO
    // =========================================================

    /**
     * Valida costos y devuelve su representacion
     * normalizada a seis decimales.
     */
    private BigDecimal validarCosto(
            BigDecimal costo
    ) {

        if (costo == null) {

            throw new IllegalArgumentException(
                    "El costo promedio es obligatorio."
            );
        }

        if (costo.signum() < 0) {

            throw new IllegalArgumentException(
                    "El costo promedio no puede ser negativo."
            );
        }

        if (costo.compareTo(COSTO_MAXIMO) > 0) {

            throw new IllegalArgumentException(
                    "El costo promedio supera el maximo permitido."
            );
        }

        if (costo.stripTrailingZeros().scale()
                > MAX_DECIMALES_COSTO) {

            throw new IllegalArgumentException(
                    "El costo admite como maximo seis decimales."
            );
        }

        return costo.setScale(
                MAX_DECIMALES_COSTO,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 20. VALIDAR IMPACTO VALORIZADO
    // =========================================================

    private void validarValorAbsoluto(
            BigDecimal valor
    ) throws SQLException {

        if (valor == null) {

            throw new SQLException(
                    "El impacto valorizado es obligatorio."
            );
        }

        if (valor.abs().compareTo(VALOR_MAXIMO) > 0) {

            throw new SQLException(
                    "El impacto valorizado supera el maximo permitido."
            );
        }
    }

    // =========================================================
    // 21. VALIDAR DOCUMENTO
    // =========================================================

    private void validarDocumento(
            String documento
    ) throws SQLException {

        if (documento == null || documento.isBlank()) {

            throw new SQLException(
                    "El documento del ajuste es obligatorio."
            );
        }

        String normalizado =
                documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > 50
                || !DOCUMENTO_PATTERN.matcher(
                        normalizado
                ).matches()) {

            throw new SQLException(
                    "El documento del ajuste tiene "
                    + "un formato invalido."
            );
        }
    }

    // =========================================================
    // 22. NORMALIZAR OBSERVACION
    // =========================================================

    private String normalizarObservacion(
            String observacion
    ) {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        for (int i = 0; i < observacion.length(); i++) {

            if (Character.isISOControl(
                    observacion.charAt(i))) {

                throw new IllegalArgumentException(
                        "La observacion contiene caracteres "
                        + "no permitidos."
                );
            }
        }

        String valor =
                observacion.trim().replaceAll("\\s+", " ");

        if (valor.length() > MAX_OBSERVACION) {

            throw new IllegalArgumentException(
                    "La observacion no puede superar "
                    + MAX_OBSERVACION + " caracteres."
            );
        }

        return valor.isEmpty() ? null : valor;
    }

    // =========================================================
    // 23. CONVERTIR VALORES DECIMALES
    // =========================================================

    private BigDecimal decimal(
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {

            throw new SQLException(
                    "La base de datos contiene un valor "
                    + "decimal nulo o vacio."
            );
        }

        try {

            BigDecimal resultado =
                    new BigDecimal(valor.trim());

            if (resultado.signum() < 0) {

                throw new SQLException(
                        "La base de datos contiene un "
                        + "valor decimal negativo no permitido."
                );
            }

            return resultado;

        } catch (NumberFormatException ex) {

            throw new SQLException(
                    "Se encontro un valor decimal invalido "
                    + "en la base de datos.",
                    ex
            );
        }
    }

    // =========================================================
    // 24. OBTENER ULTIMO ID GENERADO
    // =========================================================

    private int obtenerUltimoId(
            Connection cn
    ) throws SQLException {

        try (Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT last_insert_rowid()"
             )) {

            if (!rs.next()) {

                throw new SQLException(
                        "No se pudo recuperar el ultimo ID generado."
                );
            }

            int id = rs.getInt(1);

            if (id <= 0) {

                throw new SQLException(
                        "El identificador generado no es valido."
                );
            }

            return id;
        }
    }

    // =========================================================
    // 25. ROLLBACK SEGURO
    // =========================================================

    private void rollback(
            Connection cn,
            Exception excepcionOriginal
    ) {

        try {

            cn.rollback();

        } catch (SQLException exRollback) {

            excepcionOriginal.addSuppressed(exRollback);
        }
    }

    // =========================================================
    // 26. CONFIGURAR ESPERA DE BLOQUEO SQLITE
    // =========================================================

    private void configurarBusyTimeoutConteo(
            Connection conexion
    ) throws SQLException {

        try (Statement sentencia =
                     conexion.createStatement()) {

            sentencia.execute(
                    "PRAGMA busy_timeout = "
                            + BUSY_TIMEOUT_CONTEO
            );
        }
    }

    // =========================================================
    // 27. ADQUIRIR BLOQUEO DE ESCRITURA
    // =========================================================

    /**
     * SQLite no admite SELECT FOR UPDATE.
     *
     * Esta actualizacion sin cambio de valor inicia
     * la transaccion de escritura y permite serializar
     * las operaciones concurrentes.
     *
     * Debe ser la primera operacion SQL de escritura
     * de la transaccion.
     */
    private void bloquearEscrituraAlmacen(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        if (idAlmacen <= 0) {

            throw new IllegalArgumentException(
                    "El identificador del almacen debe ser positivo."
            );
        }

        String sql =
                "UPDATE almacenes "
                + "SET nombre = nombre "
                + "WHERE id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            int filas = sentencia.executeUpdate();

            if (filas != 1) {

                throw new SQLException(
                        "No se pudo bloquear el almacen seleccionado."
                );
            }
        }
    }

    // =========================================================
    // 28. OBTENER ALMACEN ASOCIADO A UNA TOMA
    // =========================================================

    /**
     * Se ejecuta antes de comenzar la transaccion para
     * identificar el almacen que debe bloquearse.
     *
     * Despues del bloqueo se vuelve a comprobar el estado
     * de la toma dentro de la transaccion.
     */
    private int obtenerAlmacenDeTomaPretransaccion(
            Connection conexion,
            int idToma
    ) throws SQLException {

        String sql = """
                SELECT id_almacen
                FROM tomas_inventario_fisico
                WHERE id_toma = ?
                """;

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idToma);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {

                    throw new SQLException(
                            "La toma de inventario no existe."
                    );
                }

                return resultado.getInt("id_almacen");
            }
        }
    }

    // =========================================================
    // 29. VALIDAR ALMACEN ACTIVO
    // =========================================================

    private void validarAlmacenActivoParaToma(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql = """
                SELECT activo
                FROM almacenes
                WHERE id_almacen = ?
                """;

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {

                    throw new SQLException(
                            "El almacen seleccionado no existe."
                    );
                }

                if (resultado.getInt("activo") != 1) {

                    throw new SQLException(
                            "No se puede crear el conteo. "
                            + "El almacen se encuentra inactivo."
                    );
                }
            }
        }
    }

    // =========================================================
    // 30. IMPEDIR OTRA TOMA ABIERTA
    // =========================================================

    private void validarSinOtraTomaAbierta(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql = """
                SELECT id_toma
                FROM tomas_inventario_fisico
                WHERE id_almacen = ?
                  AND estado = 'ABIERTO'
                LIMIT 1
                """;

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (resultado.next()) {

                    throw new SQLException(
                            "Ya existe un inventario fisico abierto "
                            + "para este almacen. Debe finalizarlo "
                            + "antes de crear otro."
                    );
                }
            }
        }
    }

    // =========================================================
    // 31. REGISTRO INTERNO DE FILA DE CONTEO
    // =========================================================

    /**
     * Conserva los valores iniciales y actuales
     * de cada producto durante el procesamiento.
     */
    private record FilaConteo(
            int idProducto,
            String unidad,
            BigDecimal stockSistema,
            BigDecimal cantidadFisica,
            BigDecimal costoPromedio,
            BigDecimal stockActual,
            BigDecimal costoActual,
            boolean existeInventario
    ) {}

    // =========================================================
    // 32. DATOS DEL DETALLE PARA REGISTRO
    // =========================================================

    /**
     * Datos del producto y sus valores capturados
     * al iniciar el conteo.
     */
    private record DatosDetalle(
            BigDecimal stockSistema,
            BigDecimal costoPromedio,
            String unidad
    ) {}
        // =========================================================
    // CONSULTAR ESTADO DE UNA TOMA DE INVENTARIO
    // =========================================================

    /**
     * Consulta el estado actual de una toma de inventario fisico.
     *
     * @param idToma identificador de la toma
     * @return ABIERTO, PROCESADO o ANULADO
     * @throws SQLException si la toma no existe o falla la consulta
     */
    public String obtenerEstadoConteo(int idToma) throws SQLException {

        if (idToma <= 0) {
            throw new IllegalArgumentException(
                    "El identificador de la toma debe ser positivo."
            );
        }

        String sql = """
                SELECT estado
                FROM tomas_inventario_fisico
                WHERE id_toma = ?
                """;

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia = conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(1, idToma);

            try (ResultSet resultado = sentencia.executeQuery()) {

                if (!resultado.next()) {
                    throw new SQLException(
                            "No existe la toma de inventario con ID: " + idToma
                    );
                }

                String estado = resultado.getString("estado");

                if (estado == null || estado.trim().isEmpty()) {
                    throw new SQLException(
                            "La toma no tiene un estado registrado."
                    );
                }

                return estado.trim().toUpperCase(java.util.Locale.ROOT);
            }
        }
    }

    // =========================================================
    // COMPROBAR SI UN ALMACEN EXISTE Y ESTA ACTIVO
    // =========================================================

    /**
     * Comprueba si un almacen existe y se encuentra activo.
     *
     * Requiere que la migracion V002_control_stock.sql
     * haya agregado la columna activo a la tabla almacenes.
     *
     * @param idAlmacen identificador del almacen
     * @return true si existe y esta activo
     * @throws SQLException si ocurre un error de consulta
     */
    public boolean existeAlmacenActivo(int idAlmacen) throws SQLException {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del almacen debe ser positivo."
            );
        }

        String sql = """
                SELECT 1
                FROM almacenes
                WHERE id_almacen = ?
                  AND activo = 1
                LIMIT 1
                """;

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia = conexion.prepareStatement(sql)
        ) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado = sentencia.executeQuery()) {
                return resultado.next();
            }
        }
    }
}
