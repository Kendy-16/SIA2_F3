
package pe.edu.inventario.controlador;

import pe.edu.inventario.servicio.InventarioService;

import java.sql.SQLException;

public class InventarioController {

    private final InventarioService inventarioService;

    // Constructor
    public InventarioController() {
        this.inventarioService = new InventarioService();
    }

    // Constructor with dependency injection
    public InventarioController(
            InventarioService inventarioService
    ) {

        if (inventarioService == null) {
            throw new IllegalArgumentException(
                    "El servicio de inventario es obligatorio."
            );
        }

        this.inventarioService = inventarioService;
    }

    // ==========================================
    // REGISTER PHYSICAL INVENTORY COUNT
    // ==========================================

    public boolean realizarConteoFisico(
            int idAlmacen,
            int idProducto,
            double cantidadFisica,
            String motivo
    ) throws SQLException {

        return inventarioService.registrarAjusteInventario(
                idAlmacen,
                idProducto,
                cantidadFisica,
                motivo
        );
    }
}
