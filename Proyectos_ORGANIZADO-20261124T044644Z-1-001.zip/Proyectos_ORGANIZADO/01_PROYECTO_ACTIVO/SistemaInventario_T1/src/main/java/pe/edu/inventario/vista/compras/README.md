# Compras

Pendiente. Órdenes y registro de compras a proveedores.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
