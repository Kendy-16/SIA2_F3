package pe.edu.inventario.vista.movimientos.componentes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

/**
 * Centraliza los estilos visuales del módulo de movimientos.
 *
 * Permite mantener una apariencia uniforme en:
 * - Entradas.
 * - Salidas.
 * - Ajustes físicos.
 * - Historial de movimientos.
 */
public final class EstilosMovimiento {

    // =====================================================
    // 1. COLORES INSTITUCIONALES
    // =====================================================

    public static final Color AZUL_PRINCIPAL =
            new Color(31, 78, 121);

    public static final Color AZUL_OSCURO =
            new Color(24, 55, 86);

    public static final Color AZUL_CLARO =
            new Color(232, 240, 248);

    public static final Color FONDO =
            new Color(245, 247, 250);

    public static final Color BLANCO =
            Color.WHITE;

    public static final Color TEXTO =
            new Color(36, 59, 83);

    public static final Color TEXTO_SECUNDARIO =
            new Color(100, 116, 139);

    public static final Color BORDE =
            new Color(218, 225, 233);

    public static final Color EXITO =
            new Color(6, 118, 71);

    public static final Color ADVERTENCIA =
            new Color(181, 71, 8);

    public static final Color ERROR =
            new Color(180, 35, 24);

    public static final Color FONDO_DESHABILITADO =
            new Color(239, 242, 246);


    // =====================================================
    // 2. TIPOGRAFÍAS
    // =====================================================

    public static final String FUENTE =
            "Segoe UI";

    public static final Font TITULO =
            new Font(FUENTE, Font.BOLD, 23);

    public static final Font SUBTITULO =
            new Font(FUENTE, Font.BOLD, 16);

    public static final Font TEXTO_NORMAL =
            new Font(FUENTE, Font.PLAIN, 13);

    public static final Font TEXTO_NEGRITA =
            new Font(FUENTE, Font.BOLD, 13);

    public static final Font TEXTO_PEQUENO =
            new Font(FUENTE, Font.PLAIN, 12);

    public static final Font BOTON =
            new Font(FUENTE, Font.BOLD, 13);


    // =====================================================
    // 3. BORDES
    // =====================================================

    public static final Border BORDE_CAMPO =
            BorderFactory.createCompoundBorder(
                    new LineBorder(BORDE, 1, true),
                    new EmptyBorder(7, 10, 7, 10)
            );

    public static final Border BORDE_PANEL =
            BorderFactory.createCompoundBorder(
                    new LineBorder(BORDE, 1, true),
                    new EmptyBorder(16, 16, 16, 16)
            );

    public static final Border MARGEN_PANEL =
            new EmptyBorder(18, 20, 18, 20);


    // =====================================================
    // 4. CONSTRUCTOR PRIVADO
    // =====================================================

    private EstilosMovimiento() {
        // Esta clase únicamente proporciona estilos estáticos.
    }


    // =====================================================
    // 5. CONFIGURACIÓN DE ETIQUETAS
    // =====================================================

    public static JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(TEXTO_NEGRITA);
        etiqueta.setForeground(TEXTO);

        return etiqueta;
    }


    public static JLabel crearTitulo(String texto) {

        JLabel titulo = new JLabel(texto);

        titulo.setFont(TITULO);
        titulo.setForeground(AZUL_PRINCIPAL);

        return titulo;
    }


    public static JLabel crearSubtitulo(String texto) {

        JLabel subtitulo = new JLabel(texto);

        subtitulo.setFont(SUBTITULO);
        subtitulo.setForeground(TEXTO);

        return subtitulo;
    }


    public static JLabel crearTextoSecundario(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(TEXTO_PEQUENO);
        etiqueta.setForeground(TEXTO_SECUNDARIO);

        return etiqueta;
    }


    // =====================================================
    // 6. CONFIGURACIÓN DE CAMPOS DE TEXTO
    // =====================================================

    public static void configurarCampo(JTextField campo) {

        campo.setFont(TEXTO_NORMAL);
        campo.setForeground(TEXTO);
        campo.setBackground(BLANCO);

        campo.setBorder(BORDE_CAMPO);

        campo.setCaretColor(AZUL_PRINCIPAL);

        campo.setMargin(new Insets(7, 10, 7, 10));

        campo.setToolTipText("Ingrese un valor");
    }


    public static void configurarCampoSoloLectura(
            JTextField campo) {

        configurarCampo(campo);

        campo.setEditable(false);
        campo.setBackground(FONDO_DESHABILITADO);
        campo.setForeground(TEXTO_SECUNDARIO);
    }


    // =====================================================
    // 7. CONFIGURACIÓN DE LISTAS DESPLEGABLES
    // =====================================================

    public static void configurarCombo(
            JComboBox<?> combo) {

        combo.setFont(TEXTO_NORMAL);
        combo.setForeground(TEXTO);
        combo.setBackground(BLANCO);

        combo.setBorder(
                new LineBorder(BORDE, 1, true)
        );

        combo.setFocusable(true);
    }


    // =====================================================
    // 8. CONFIGURACIÓN DE ÁREAS DE TEXTO
    // =====================================================

    public static void configurarArea(
            JTextArea area) {

        area.setFont(TEXTO_NORMAL);
        area.setForeground(TEXTO);
        area.setBackground(BLANCO);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);

        area.setBorder(
                new EmptyBorder(8, 10, 8, 10)
        );

        area.setCaretColor(AZUL_PRINCIPAL);
    }


    // =====================================================
    // 9. CONFIGURACIÓN DE BOTONES
    // =====================================================

    public static void configurarBotonPrimario(
            JButton boton) {

        configurarBotonBase(boton);

        boton.setBackground(AZUL_PRINCIPAL);
        boton.setForeground(BLANCO);

        boton.setBorder(
                new EmptyBorder(10, 18, 10, 18)
        );
    }


    public static void configurarBotonSecundario(
            JButton boton) {

        configurarBotonBase(boton);

        boton.setBackground(BLANCO);
        boton.setForeground(AZUL_PRINCIPAL);

        boton.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(AZUL_PRINCIPAL, 1, true),
                        new EmptyBorder(9, 17, 9, 17)
                )
        );
    }


    public static void configurarBotonPeligro(
            JButton boton) {

        configurarBotonBase(boton);

        boton.setBackground(ERROR);
        boton.setForeground(BLANCO);

        boton.setBorder(
                new EmptyBorder(10, 18, 10, 18)
        );
    }


    private static void configurarBotonBase(
            JButton boton) {

        boton.setFont(BOTON);

        boton.setFocusPainted(false);
        boton.setOpaque(true);

        boton.setContentAreaFilled(true);

        boton.setBorderPainted(true);

        boton.setCursor(
                new java.awt.Cursor(
                        java.awt.Cursor.HAND_CURSOR
                )
        );
    }


    // =====================================================
    // 10. CONFIGURACIÓN DE PANELES
    // =====================================================

    public static void configurarPanel(
            javax.swing.JPanel panel) {

        panel.setBackground(BLANCO);
        panel.setBorder(BORDE_PANEL);
    }


    public static void configurarPanelFondo(
            javax.swing.JPanel panel) {

        panel.setBackground(FONDO);
    }


    // =====================================================
    // 11. CONFIGURACIÓN DE COMPONENTES DESHABILITADOS
    // =====================================================

    public static void configurarDeshabilitado(
            JTextField campo) {

        campo.setEditable(false);
        campo.setEnabled(false);

        campo.setBackground(FONDO_DESHABILITADO);
        campo.setForeground(TEXTO_SECUNDARIO);
    }

}