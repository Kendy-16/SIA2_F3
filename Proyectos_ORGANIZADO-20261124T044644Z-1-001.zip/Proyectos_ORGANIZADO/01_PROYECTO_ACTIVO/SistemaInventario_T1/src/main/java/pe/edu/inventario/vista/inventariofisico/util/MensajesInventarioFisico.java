package pe.edu.inventario.vista.inventariofisico.util;

import javax.swing.*;
import java.awt.Component;

/** Textos y cuadros de diálogo estándar del módulo. */
public final class MensajesInventarioFisico {
    public static final String TITULO = "Inventario físico";
    public static final String SELECCIONA_TOMA = "Selecciona una toma.";
    public static final String SELECCIONA_TOMA_TABLA = "Selecciona una toma de la tabla.";
    public static final String SELECCIONA_PRODUCTO = "Selecciona un producto.";
    public static final String SELECCIONA_DIFERENCIA = "Selecciona una diferencia.";
    public static final String SIN_PERMISO = "Tu perfil no tiene permiso para realizar esta acción.";

    private MensajesInventarioFisico() { }

    public static void advertencia(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Validación", JOptionPane.WARNING_MESSAGE);
    }

    public static void informacion(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, TITULO, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component padre, Throwable t) {
        String m = t.getMessage() == null ? t.toString() : t.getMessage();
        JOptionPane.showMessageDialog(padre, m, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirmar(Component padre, String mensaje, String titulo) {
        return JOptionPane.showConfirmDialog(padre, mensaje, titulo, JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}
