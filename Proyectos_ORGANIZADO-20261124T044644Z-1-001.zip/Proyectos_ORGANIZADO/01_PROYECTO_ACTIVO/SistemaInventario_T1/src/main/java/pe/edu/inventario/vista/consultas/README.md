# Consultas

Pendiente. Consultas rápidas de stock, precios y movimientos.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
