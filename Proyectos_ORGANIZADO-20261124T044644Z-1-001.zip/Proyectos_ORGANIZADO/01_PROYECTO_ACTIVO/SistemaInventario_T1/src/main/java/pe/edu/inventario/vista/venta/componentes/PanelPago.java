package pe.edu.inventario.vista.venta.componentes;

import pe.edu.inventario.servicio.venta.CajaService;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 * Requisito 9: medio de pago, monto recibido y vuelto.
 * Los medios de la lista deben coincidir con los habilitados en CajaService.
 */
public class PanelPago extends JPanel {
    private JComboBox<String> cbMetodoPago;
    private JTextField txtMontoRecibido;
    private JLabel lblVuelto;

    public PanelPago() {
        setLayout(new GridLayout(3, 2, 5, 5));
        setBorder(BorderFactory.createTitledBorder("Información de Pago"));

        cbMetodoPago = new JComboBox<>(new String[]{CajaService.EFECTIVO, "Tarjeta Crédito/Débito", "Transferencia / Yape / Plin"});
        txtMontoRecibido = new JTextField("0.00");
        lblVuelto = new JLabel("0.00");
        lblVuelto.setForeground(new Color(0, 100, 0));
        lblVuelto.setFont(new Font("Arial", Font.BOLD, 14));

        // Solo en efectivo se digita el monto; en los demás medios se cobra el total exacto.
        cbMetodoPago.addActionListener(e -> txtMontoRecibido.setEnabled(esEfectivo()));

        add(new JLabel("Método de Pago:"));
        add(cbMetodoPago);

        add(new JLabel("Monto Recibido: S/"));
        add(txtMontoRecibido);

        add(new JLabel("Vuelto: S/"));
        add(lblVuelto);
    }

    public String getMetodoPago() { return cbMetodoPago.getSelectedItem().toString(); }
    public String getMontoRecibido() { return txtMontoRecibido.getText(); }
    public void setVuelto(String vuelto) { lblVuelto.setText(vuelto); }
    public boolean esEfectivo() { return CajaService.EFECTIVO.equals(getMetodoPago()); }

    /** Avisa a la vista cuando cambia el método de pago o el monto digitado, para recalcular el vuelto. */
    public void addCambioListener(Runnable accion) {
        cbMetodoPago.addActionListener(e -> accion.run());
        txtMontoRecibido.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { accion.run(); }
            @Override public void removeUpdate(DocumentEvent e) { accion.run(); }
            @Override public void changedUpdate(DocumentEvent e) { accion.run(); }
        });
    }

    public void limpiar() {
        cbMetodoPago.setSelectedIndex(0);
        txtMontoRecibido.setText("0.00");
        lblVuelto.setText("0.00");
    }
}
