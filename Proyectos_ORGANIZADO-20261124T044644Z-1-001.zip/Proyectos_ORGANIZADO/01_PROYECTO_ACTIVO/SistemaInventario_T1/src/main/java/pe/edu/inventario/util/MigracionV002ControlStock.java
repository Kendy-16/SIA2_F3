
package pe.edu.inventario.util;

import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Ejecuta la migracion V002 para incorporar
 * estados activos a productos y almacenes.
 */
public final class MigracionV002ControlStock {

    private MigracionV002ControlStock() {
    }

    public static void main(String[] args) throws SQLException {

        try (Connection conexion = ConexionDB.conectar()) {

            boolean autoCommitAnterior = conexion.getAutoCommit();

            try {

                conexion.setAutoCommit(false);

                agregarColumnaActivo(conexion, "productos");
                agregarColumnaActivo(conexion, "almacenes");

                crearIndices(conexion);

                conexion.commit();

                System.out.println(
                        "Migracion V002 aplicada correctamente."
                );

            } catch (SQLException | RuntimeException ex) {

                try {
                    conexion.rollback();
                } catch (SQLException errorRollback) {
                    ex.addSuppressed(errorRollback);
                }

                throw ex;

            } finally {

                conexion.setAutoCommit(autoCommitAnterior);
            }
        }
    }

    /**
     * Agrega la columna activo solamente si no existe.
     */
    private static void agregarColumnaActivo(
            Connection conexion,
            String tabla
    ) throws SQLException {

        boolean existe = false;

        String consulta = "PRAGMA table_info(" + tabla + ")";

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(consulta)) {

            while (rs.next()) {

                String nombreColumna = rs.getString("name");

                if ("activo".equalsIgnoreCase(nombreColumna)) {
                    existe = true;
                    break;
                }
            }
        }

        if (!existe) {

            String sql = "ALTER TABLE " + tabla
                    + " ADD COLUMN activo INTEGER NOT NULL DEFAULT 1"
                    + " CHECK (activo IN (0, 1))";

            try (Statement st = conexion.createStatement()) {
                st.executeUpdate(sql);
            }

            System.out.println(
                    "Columna activo agregada a " + tabla + "."
            );

        } else {

            System.out.println(
                    "La columna activo ya existe en " + tabla + "."
            );
        }
    }

    /**
     * Crea los indices de consulta de catalogos activos.
     */
    private static void crearIndices(
            Connection conexion
    ) throws SQLException {

        try (Statement st = conexion.createStatement()) {

            st.executeUpdate(
                    "CREATE INDEX IF NOT EXISTS idx_productos_activo "
                    + "ON productos(activo)"
            );

            st.executeUpdate(
                    "CREATE INDEX IF NOT EXISTS idx_almacenes_activo "
                    + "ON almacenes(activo)"
            );
        }
    }
}
