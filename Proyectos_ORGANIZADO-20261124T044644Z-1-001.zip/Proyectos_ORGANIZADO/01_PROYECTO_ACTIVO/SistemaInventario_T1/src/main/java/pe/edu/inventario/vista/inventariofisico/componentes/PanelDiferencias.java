package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Tabla de conciliación con totales de faltantes, sobrantes y diferencia neta valorizada. */
public class PanelDiferencias extends JPanel {
    private final TablaConciliacionModel modelo = new TablaConciliacionModel();
    private final JTable tabla = new JTable(modelo);
    private final JLabel totales = new JLabel(" ");

    public PanelDiferencias() {
        super(new BorderLayout(8, 8));
        setOpaque(false);
        estiloTabla(tabla);
        tabla.setDefaultRenderer(Object.class, new FilaRenderer());
        tabla.setDefaultRenderer(java.math.BigDecimal.class, new CantidadRenderer());
        tabla.getColumnModel().getColumn(4).setCellRenderer(new DiferenciaRenderer());
        tabla.getColumnModel().getColumn(5).setCellRenderer(new MonedaRenderer());
        tabla.getColumnModel().getColumn(6).setCellRenderer(new MonedaRenderer());
        tabla.getColumnModel().getColumn(7).setCellRenderer(new DiferenciaRenderer());
        tabla.getColumnModel().getColumn(8).setCellRenderer(new EstadoAjusteRenderer());
        totales.setForeground(MUTED);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(totales, BorderLayout.SOUTH);
    }

    /** Renderer base de texto con fila alterna. */
    private static final class FilaRenderer extends javax.swing.table.DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
            Component comp = super.getTableCellRendererComponent(t, v, sel, f, r, c);
            setBorder(new EmptyBorder(2, 7, 2, 7));
            aplicarCebra(comp, t, r, sel);
            if (!sel) setForeground(TEXT);
            return comp;
        }
    }

    public void setDiferencias(List<Diferencia> lista) {
        modelo.setFilas(lista);
        java.math.BigDecimal faltante = java.math.BigDecimal.ZERO, sobrante = java.math.BigDecimal.ZERO;
        int conDiferencia = 0;
        for (Diferencia d : lista) {
            if (d.valorDiferencia() == null) continue;
            if (d.tipo() == TipoDiferencia.FALTANTE) { faltante = faltante.add(d.valorDiferencia()); conDiferencia++; }
            else if (d.tipo() == TipoDiferencia.SOBRANTE) { sobrante = sobrante.add(d.valorDiferencia()); conDiferencia++; }
        }
        totales.setText("Registros: " + lista.size() + "  ·  Con diferencia: " + conDiferencia
                + "  ·  Faltante: " + moneda(faltante) + "  ·  Sobrante: " + moneda(sobrante)
                + "  ·  Neto: " + moneda(faltante.add(sobrante)));
    }

    public Diferencia getSeleccionada() {
        int fila = tabla.getSelectedRow();
        return fila < 0 ? null : modelo.getDiferencia(tabla.convertRowIndexToModel(fila));
    }

    public TablaConciliacionModel getModelo() { return modelo; }
    public JTable getTabla() { return tabla; }
}
