package pe.edu.inventario.vista.venta;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.modelo.venta.Venta;
import pe.edu.inventario.servicio.venta.VentaException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Requisitos 11 y 12: consultar el historial de ventas y anularlas con autorización.
 */
public class HistorialVentasView extends JPanel {
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final VentaController controller;
    private final RolUsuario rol;
    private final String idUsuario;

    private JTextField txtFechaInicio;
    private JTextField txtFechaFin;
    private JComboBox<String> cbTipoVenta;
    private JButton btnBuscar;

    private JTable tablaHistorial;
    private DefaultTableModel modeloHistorial;

    private JButton btnVerDetalle;
    private JButton btnAnularVenta;

    public HistorialVentasView(VentaController controller, RolUsuario rol, String idUsuario) {
        this.controller = controller;
        this.rol = rol;
        this.idUsuario = idUsuario;

        setLayout(new BorderLayout());

        // 1. Panel Superior: Filtros de Búsqueda
        JPanel panelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelFiltros.setBorder(BorderFactory.createTitledBorder("Filtros de Búsqueda"));

        txtFechaInicio = new JTextField(10);
        txtFechaFin = new JTextField(10);
        cbTipoVenta = new JComboBox<>(new String[]{"TODAS", "NORMAL", "MAYORISTA"});
        btnBuscar = new JButton("Buscar Ventas");

        panelFiltros.add(new JLabel("Desde (DD/MM/YYYY):")); panelFiltros.add(txtFechaInicio);
        panelFiltros.add(new JLabel("Hasta:")); panelFiltros.add(txtFechaFin);
        panelFiltros.add(new JLabel("Tipo:")); panelFiltros.add(cbTipoVenta);
        panelFiltros.add(btnBuscar);

        // 2. Zona Central: Tabla de Resultados
        String[] columnas = {"ID Venta", "Fecha", "Cliente", "Tipo", "Total", "Estado"};
        modeloHistorial = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaHistorial = new JTable(modeloHistorial);
        tablaHistorial.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 3. Panel Inferior: Acciones (Requisito 12: Anulación)
        JPanel panelAcciones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnVerDetalle = new JButton("Ver Detalle / Reimprimir");
        btnAnularVenta = new JButton("Anular Venta (Requiere Admin)");
        btnAnularVenta.setForeground(Color.RED);

        panelAcciones.add(btnVerDetalle);
        panelAcciones.add(btnAnularVenta);

        add(panelFiltros, BorderLayout.NORTH);
        add(new JScrollPane(tablaHistorial), BorderLayout.CENTER);
        add(panelAcciones, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e -> refrescar());
        btnVerDetalle.addActionListener(e -> verDetalle());
        btnAnularVenta.addActionListener(e -> anularVenta());
    }

    /** Vuelve a consultar con los filtros actuales (se llama también al abrir la pestaña). */
    public void refrescar() {
        try {
            List<Venta> ventas = controller.listarHistorial(txtFechaInicio.getText(), txtFechaFin.getText(),
                    (String) cbTipoVenta.getSelectedItem());
            modeloHistorial.setRowCount(0);
            for (Venta v : ventas) {
                modeloHistorial.addRow(new Object[]{
                        v.getIdVenta(),
                        v.getFechaEmision().format(FORMATO_FECHA),
                        v.getIdCliente() + " - " + v.getNombreCliente(),
                        v.getTipoVenta(),
                        v.getTotal().toPlainString(),
                        v.getEstado()
                });
            }
        } catch (IllegalArgumentException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private String idSeleccionado() {
        int fila = tablaHistorial.getSelectedRow();
        if (fila < 0) {
            mostrarError("Seleccione una venta de la tabla.");
            return null;
        }
        return (String) modeloHistorial.getValueAt(fila, 0);
    }

    private void verDetalle() {
        String id = idSeleccionado();
        if (id == null) {
            return;
        }
        JTextArea area = new JTextArea(controller.ticketDe(controller.buscarVenta(id)));
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(480, 420));
        JOptionPane.showMessageDialog(this, scroll, "Detalle de la venta " + id, JOptionPane.PLAIN_MESSAGE);
    }

    private void anularVenta() {
        String id = idSeleccionado();
        if (id == null) {
            return;
        }
        String motivo = JOptionPane.showInputDialog(this, "Motivo de la anulación de " + id + ":",
                "Anular venta", JOptionPane.QUESTION_MESSAGE);
        if (motivo == null) {
            return; // canceló
        }
        try {
            controller.anularVenta(id, rol, idUsuario, motivo);
            JOptionPane.showMessageDialog(this, "Venta " + id + " anulada. Se devolvió el stock al Kardex y el monto a Caja.",
                    "Venta anulada", JOptionPane.INFORMATION_MESSAGE);
            refrescar();
        } catch (VentaException | SecurityException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Atención", JOptionPane.WARNING_MESSAGE);
    }
}
