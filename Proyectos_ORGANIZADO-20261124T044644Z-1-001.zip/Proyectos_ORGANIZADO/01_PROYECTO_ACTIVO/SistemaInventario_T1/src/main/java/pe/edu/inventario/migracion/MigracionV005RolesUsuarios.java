
package pe.edu.inventario.migracion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Migración V005:
 * Incorpora roles para diferenciar administradores y usuarios.
 */
public final class MigracionV005RolesUsuarios {

    private MigracionV005RolesUsuarios() {
    }

    public static void ejecutar(Connection conexion)
            throws SQLException {

        if (conexion == null || conexion.isClosed()) {
            throw new SQLException(
                    "La conexión SQLite no está disponible."
            );
        }

        exigirTablaUsuarios(conexion);

        if (!existeColumnaRol(conexion)) {

            try (Statement st = conexion.createStatement()) {

                st.execute("""
                        ALTER TABLE usuarios
                        ADD COLUMN rol TEXT NOT NULL DEFAULT 'USUARIO'
                        CHECK (
                            rol IN ('ADMINISTRADOR', 'USUARIO')
                        )
                        """);
            }
        }

        normalizarYValidarRoles(conexion);

        crearIndiceRol(conexion);
    }

    /**
     * Verifica que exista la tabla usuarios.
     */
    private static void exigirTablaUsuarios(Connection conexion)
            throws SQLException {

        String sql = """
                SELECT 1
                FROM sqlite_master
                WHERE type = 'table'
                  AND name = 'usuarios'
                """;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (!rs.next()) {
                throw new SQLException(
                        "No existe la tabla usuarios. "
                        + "Inicialice primero el esquema base."
                );
            }
        }
    }

    /**
     * Comprueba si la columna rol ya existe.
     */
    private static boolean existeColumnaRol(Connection conexion)
            throws SQLException {

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(
                     "PRAGMA table_info(usuarios)"
             )) {

            while (rs.next()) {

                if ("rol".equalsIgnoreCase(
                        rs.getString("name")
                )) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Normaliza los roles y rechaza valores desconocidos.
     */
    private static void normalizarYValidarRoles(
            Connection conexion
    ) throws SQLException {

        try (Statement st = conexion.createStatement()) {

            st.executeUpdate("""
                    UPDATE usuarios
                    SET rol = UPPER(TRIM(rol))
                    WHERE rol IS NOT NULL
                    """);

            try (ResultSet rs = st.executeQuery("""
                    SELECT id_usuario, rol
                    FROM usuarios
                    WHERE rol IS NULL
                       OR rol NOT IN ('ADMINISTRADOR', 'USUARIO')
                    LIMIT 1
                    """)) {

                if (rs.next()) {

                    throw new SQLException(
                            "Rol inválido en el usuario ID "
                            + rs.getInt("id_usuario")
                            + ": " + rs.getString("rol")
                    );
                }
            }
        }
    }

    /**
     * Crea un índice para las consultas por rol.
     */
    private static void crearIndiceRol(Connection conexion)
            throws SQLException {

        try (Statement st = conexion.createStatement()) {

            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_usuarios_rol
                    ON usuarios(rol)
                    """);
        }
    }
}
