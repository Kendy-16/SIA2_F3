package pe.edu.inventario.servicio.venta;

import pe.edu.inventario.modelo.venta.*;
import pe.edu.inventario.seguridad.AutorizacionVentas;
import pe.edu.inventario.dao.venta.VentaDAO;
import pe.edu.inventario.servicio.kardex.KardexService;
import pe.edu.inventario.servicio.caja.CajaService;
import pe.edu.inventario.servicio.auditoria.AuditoriaService;
import java.math.BigDecimal;

public class VentaAdminService {

    private VentaDAO ventaDAO;
    private KardexService kardexService;
    private CajaService cajaService;
    private AuditoriaService auditoriaService; // Para el requisito de "Consultar auditoría"

    public VentaAdminService(VentaDAO ventaDAO, KardexService kardexService,
                             CajaService cajaService, AuditoriaService auditoriaService) {
        this.ventaDAO = ventaDAO;
        this.kardexService = kardexService;
        this.cajaService = cajaService;
        this.auditoriaService = auditoriaService;
    }

    /**
     * Requisito: Autorizar cambios de precio (si la política lo contempla)
     */
    public void autorizarCambioPrecio(DetalleVenta detalle, BigDecimal nuevoPrecio, Venta ventaActual, RolUsuario rolActual, String idAdmin) {
        if (!AutorizacionVentas.puedeModificarPrecio(rolActual)) {
            throw new SecurityException("No tiene permisos para modificar precios libremente.");
        }
        
        BigDecimal precioAnterior = detalle.getPrecioUnitario();
        detalle.setPrecioUnitario(nuevoPrecio);
        
        // Registrar en auditoría la excepción
        auditoriaService.registrarEvento("CAMBIO_PRECIO", idAdmin, 
            "Producto: " + detalle.getCodigoProducto() + " | Anterior: " + precioAnterior + " | Nuevo: " + nuevoPrecio);
    }

    /**
     * Requisito: Autorizar descuentos especiales
     */
    public void autorizarDescuentoEspecial(DetalleVenta detalle, BigDecimal nuevoDescuento, RolUsuario rolActual, String idAdmin) {
        if (!AutorizacionVentas.puedeAutorizarDescuentoEspecial(rolActual)) {
            throw new SecurityException("Se requiere autorización de ADMINISTRADOR para descuentos especiales.");
        }
        detalle.setPorcentajeDescuento(nuevoDescuento);
        
        auditoriaService.registrarEvento("DESCUENTO_ESPECIAL", idAdmin, 
            "Producto: " + detalle.getCodigoProducto() + " | Dscto: " + nuevoDescuento + "%");
    }

    /**
     * Requisito: Autorizar anulaciones (y rollback de inventario)
     */
    public void anularVenta(String idVenta, String motivo, RolUsuario rolActual, String idAdmin) throws Exception {
        if (!AutorizacionVentas.puedeAutorizarAnulacion(rolActual)) {
            throw new SecurityException("Solo un ADMINISTRADOR puede anular ventas.");
        }

        Venta venta = ventaDAO.buscarPorId(idVenta);
        if (venta == null) {
            throw new IllegalStateException("No existe la venta " + idVenta);
        }
        if (venta.getEstado() == EstadoVenta.ANULADA) {
            throw new IllegalStateException("La venta ya se encuentra anulada.");
        }

        // 1. Actualizar estado en BD
        ventaDAO.actualizarEstado(idVenta, EstadoVenta.ANULADA.name(), motivo, idAdmin);

        // 2. Reversión en Caja (Registrar egreso por anulación)
        cajaService.registrarEgresoPorAnulacion(idVenta, venta.getTotal());

        // 3. Reversión de Inventario (Regla: No modificar arbitrariamente el stock)
        // El administrador no edita el stock, el sistema registra una entrada justificada.
        for (DetalleVenta det : venta.getDetalles()) {
            kardexService.registrarIngresoPorAnulacion(det.getCodigoProducto(), det.getCantidad(), "ANULACION VENTA " + idVenta);
        }

        auditoriaService.registrarEvento("ANULACION_VENTA", idAdmin, "Venta: " + idVenta + " | Motivo: " + motivo);
    }
}
