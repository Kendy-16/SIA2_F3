
package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.Proveedor;
import pe.edu.inventario.servicio.ProveedorService;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controls supplier operations.
 * Connects ProveedorView with ProveedorService.
 */
public class ProveedorController {

    private final ProveedorService proveedorService;

    // Constructor
    public ProveedorController() {
        this.proveedorService = new ProveedorService();
    }

    // Constructor for dependency injection
    public ProveedorController(ProveedorService proveedorService) {

        if (proveedorService == null) {
            throw new IllegalArgumentException(
                    "El servicio de proveedores no puede ser nulo."
            );
        }

        this.proveedorService = proveedorService;
    }

    // Register supplier
    public boolean registrarProveedor(Proveedor proveedor)
            throws SQLException {

        return proveedorService.registrar(proveedor);
    }

    // List all suppliers
    public ArrayList<Proveedor> listarProveedores()
            throws SQLException {

        return proveedorService.listar();
    }

    // Search supplier by ID
    public Proveedor buscarProveedor(int idProveedor)
            throws SQLException {

        return proveedorService.buscarPorId(idProveedor);
    }

    // Update supplier
    public boolean actualizarProveedor(Proveedor proveedor)
            throws SQLException {

        return proveedorService.actualizar(proveedor);
    }

    // Delete supplier
    public boolean eliminarProveedor(int idProveedor)
            throws SQLException {

        return proveedorService.eliminar(idProveedor);
    }
}
