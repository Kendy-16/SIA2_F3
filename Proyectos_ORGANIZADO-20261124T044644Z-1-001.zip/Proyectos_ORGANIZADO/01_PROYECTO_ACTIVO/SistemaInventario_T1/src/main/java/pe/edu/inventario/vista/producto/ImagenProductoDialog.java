package pe.edu.inventario.vista.producto;

import pe.edu.inventario.controlador.ImagenProductoController;
import pe.edu.inventario.modelo.ImagenProducto;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.net.URI;
import java.util.List;

/**
 * Ventana para buscar, visualizar y guardar imágenes de Pixabay.
 */
public class ImagenProductoDialog extends JDialog {

    private static final long serialVersionUID = 1L;

    private final long idProducto;

    private final ImagenProductoController controlador;

    private final JTextField txtBusqueda;
    private final JButton btnBuscar;
    private final JButton btnGuardar;
    private final JButton btnCerrar;

    private final DefaultListModel<ImagenProducto> modeloLista;
    private final JList<ImagenProducto> listaImagenes;

    private final JLabel lblVistaPrevia;
    private final JLabel lblEstado;

    public ImagenProductoDialog(Window propietario, long idProducto) {

        super(
                propietario,
                "Buscar imagen del producto",
                ModalityType.APPLICATION_MODAL
        );

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del producto no es válido."
            );
        }

        this.idProducto = idProducto;
        this.controlador = new ImagenProductoController();

        this.txtBusqueda = new JTextField(25);
        this.btnBuscar = new JButton("Buscar en Pixabay");
        this.btnGuardar = new JButton("Guardar imagen");
        this.btnCerrar = new JButton("Cerrar");

        this.modeloLista = new DefaultListModel<>();
        this.listaImagenes = new JList<>(modeloLista);

        this.lblVistaPrevia = new JLabel(
                "Selecciona una imagen",
                JLabel.CENTER
        );

        this.lblEstado = new JLabel("Escribe un término de búsqueda.");

        configurarVentana();
        construirInterfaz();
        configurarEventos();
    }

    private void configurarVentana() {

        setSize(850, 570);
        setMinimumSize(new Dimension(750, 500));
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void construirInterfaz() {

        JPanel panelPrincipal = new JPanel(new BorderLayout(12, 12));
        panelPrincipal.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));

        panelBusqueda.add(new JLabel("Producto:"));
        panelBusqueda.add(txtBusqueda);
        panelBusqueda.add(btnBuscar);

        panelPrincipal.add(panelBusqueda, BorderLayout.NORTH);

        configurarLista();

        JScrollPane scrollLista = new JScrollPane(listaImagenes);
        scrollLista.setPreferredSize(new Dimension(330, 350));

        lblVistaPrevia.setPreferredSize(new Dimension(440, 350));
        lblVistaPrevia.setBorder(
                BorderFactory.createTitledBorder("Vista previa")
        );

        JPanel panelContenido = new JPanel(new BorderLayout(10, 10));

        panelContenido.add(scrollLista, BorderLayout.WEST);
        panelContenido.add(lblVistaPrevia, BorderLayout.CENTER);

        panelPrincipal.add(panelContenido, BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout());

        JPanel panelBotones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );

        panelBotones.add(btnGuardar);
        panelBotones.add(btnCerrar);

        panelInferior.add(lblEstado, BorderLayout.CENTER);
        panelInferior.add(panelBotones, BorderLayout.EAST);

        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        setContentPane(panelPrincipal);

        btnGuardar.setEnabled(false);
    }

    private void configurarLista() {

        listaImagenes.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        listaImagenes.setFont(
                new Font("Segoe UI", Font.PLAIN, 13)
        );

        listaImagenes.setCellRenderer(
                new DefaultListCellRenderer() {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public java.awt.Component getListCellRendererComponent(
                            JList<?> lista,
                            Object valor,
                            int indice,
                            boolean seleccionado,
                            boolean enfocado) {

                        JLabel etiqueta = (JLabel) super
                                .getListCellRendererComponent(
                                        lista,
                                        valor,
                                        indice,
                                        seleccionado,
                                        enfocado
                                );

                        if (valor instanceof ImagenProducto imagen) {

                            String texto = imagen.getEtiquetas() == null
                                    ? "Imagen Pixabay"
                                    : imagen.getEtiquetas();

                            String autor = imagen.getAutor() == null
                                    ? "Autor desconocido"
                                    : imagen.getAutor();

                            etiqueta.setText(
                                    "<html><b>"
                                            + escaparHtml(texto)
                                            + "</b><br>"
                                            + escaparHtml(autor)
                                            + "<br>ID: "
                                            + imagen.getPixabayId()
                                            + "</html>"
                            );
                        }

                        etiqueta.setBorder(
                                BorderFactory.createEmptyBorder(
                                        8, 8, 8, 8
                                )
                        );

                        return etiqueta;
                    }
                }
        );
    }

    private String escaparHtml(String texto) {

        return texto
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    private void configurarEventos() {

        btnBuscar.addActionListener(e -> buscar());

        btnGuardar.addActionListener(e -> guardar());

        btnCerrar.addActionListener(e -> dispose());

        listaImagenes.addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {
                mostrarVistaPrevia(
                        listaImagenes.getSelectedValue()
                );
            }
        });

        txtBusqueda.addActionListener(e -> buscar());
    }

    private void buscar() {

        String termino = txtBusqueda.getText().trim();

        if (termino.isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Escribe el nombre del producto.",
                    "Búsqueda",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        btnBuscar.setEnabled(false);
        btnGuardar.setEnabled(false);

        modeloLista.clear();
        lblVistaPrevia.setIcon(null);
        lblVistaPrevia.setText("Buscando imágenes...");
        lblEstado.setText("Consultando Pixabay...");

        SwingWorker<List<ImagenProducto>, Void> trabajador =
                new SwingWorker<>() {

                    @Override
                    protected List<ImagenProducto> doInBackground()
                            throws Exception {

                        return controlador.buscarImagenes(termino);
                    }

                    @Override
                    protected void done() {

                        btnBuscar.setEnabled(true);

                        try {
                            List<ImagenProducto> resultados = get();

                            for (ImagenProducto imagen : resultados) {
                                modeloLista.addElement(imagen);
                            }

                            if (resultados.isEmpty()) {

                                lblVistaPrevia.setText(
                                        "No se encontraron imágenes."
                                );

                                lblEstado.setText(
                                        "No hay resultados para la búsqueda."
                                );

                            } else {

                                lblEstado.setText(
                                        resultados.size()
                                                + " imágenes encontradas."
                                );

                                listaImagenes.setSelectedIndex(0);
                            }

                        } catch (Exception ex) {

                            mostrarError(
                                    "No se pudieron buscar las imágenes.",
                                    ex
                            );

                            lblVistaPrevia.setText(
                                    "No se pudo cargar la búsqueda."
                            );

                        }
                    }
                };

        trabajador.execute();
    }

    private void mostrarVistaPrevia(ImagenProducto imagen) {

        btnGuardar.setEnabled(false);

        if (imagen == null) {
            lblVistaPrevia.setIcon(null);
            lblVistaPrevia.setText("Selecciona una imagen");
            return;
        }

        lblVistaPrevia.setIcon(null);
        lblVistaPrevia.setText("Cargando vista previa...");

        SwingWorker<ImageIcon, Void> trabajador =
                new SwingWorker<>() {

                    @Override
                    protected ImageIcon doInBackground()
                            throws Exception {

                        BufferedImage original = ImageIO.read(
                                URI.create(
                                        imagen.getVistaPreviaUrl()
                                ).toURL()
                        );

                        if (original == null) {
                            throw new java.io.IOException(
                                    "No se pudo leer la vista previa."
                            );
                        }

                        int anchoMaximo = 420;
                        int altoMaximo = 310;

                        double escala = Math.min(
                                (double) anchoMaximo
                                        / original.getWidth(),
                                (double) altoMaximo
                                        / original.getHeight()
                        );

                        int ancho = Math.max(
                                1,
                                (int) (original.getWidth() * escala)
                        );

                        int alto = Math.max(
                                1,
                                (int) (original.getHeight() * escala)
                        );

                        Image escalada = original.getScaledInstance(
                                ancho,
                                alto,
                                Image.SCALE_SMOOTH
                        );

                        return new ImageIcon(escalada);
                    }

                    @Override
                    protected void done() {

                        if (listaImagenes.getSelectedValue() != imagen) {
                            return;
                        }

                        try {
                            lblVistaPrevia.setText("");
                            lblVistaPrevia.setIcon(get());
                            btnGuardar.setEnabled(true);

                        } catch (Exception ex) {

                            lblVistaPrevia.setIcon(null);
                            lblVistaPrevia.setText(
                                    "No se pudo mostrar la imagen."
                            );

                            lblEstado.setText(
                                    "Error al cargar la vista previa."
                            );
                        }
                    }
                };

        trabajador.execute();
    }

    private void guardar() {

        ImagenProducto seleccionada =
                listaImagenes.getSelectedValue();

        if (seleccionada == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Selecciona una imagen primero.",
                    "Guardar imagen",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        btnGuardar.setEnabled(false);
        btnBuscar.setEnabled(false);

        lblEstado.setText("Descargando y guardando imagen...");

        SwingWorker<ImagenProducto, Void> trabajador =
                new SwingWorker<>() {

                    @Override
                    protected ImagenProducto doInBackground()
                            throws Exception {

                        return controlador.guardarImagen(
                                idProducto,
                                seleccionada
                        );
                    }

                    @Override
                    protected void done() {

                        btnBuscar.setEnabled(true);
                        btnGuardar.setEnabled(true);

                        try {
                            ImagenProducto guardada = get();

                            JOptionPane.showMessageDialog(
                                    ImagenProductoDialog.this,
                                    "Imagen guardada correctamente.\n\n"
                                            + "Ruta: "
                                            + guardada.getRutaLocal()
                                            + "\nAutor: "
                                            + guardada.getAutor()
                                            + "\nFuente: Pixabay",
                                    "Imagen guardada",
                                    JOptionPane.INFORMATION_MESSAGE
                            );

                            dispose();

                        } catch (Exception ex) {

                            mostrarError(
                                    "No se pudo guardar la imagen.",
                                    ex
                            );
                        }
                    }
                };

        trabajador.execute();
    }

    private void mostrarError(String mensaje, Exception ex) {

        Throwable causa = ex;

        while (causa.getCause() != null) {
            causa = causa.getCause();
        }

        String detalle = causa.getMessage() == null
                ? causa.getClass().getSimpleName()
                : causa.getMessage();

        JOptionPane.showMessageDialog(
                this,
                mensaje + "\n\n" + detalle,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );

        lblEstado.setText("Se produjo un error.");
    }
}