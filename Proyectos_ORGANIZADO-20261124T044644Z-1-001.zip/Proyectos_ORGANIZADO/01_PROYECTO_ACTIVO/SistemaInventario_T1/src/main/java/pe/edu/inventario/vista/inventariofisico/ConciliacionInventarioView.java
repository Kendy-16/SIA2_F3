package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Pestaña de conciliación: compara el conteo con el sistema y gestiona ajustes y cierre. */
public class ConciliacionInventarioView extends JPanel {
    private final InventarioFisicoController controller;
    private final PermisosVistaInventario permisos;
    private final Runnable alCambiar;
    private final JComboBox<Toma> tomas = new JComboBox<>();
    private final PanelDiferencias panel = new PanelDiferencias();
    private boolean cargandoTomas = false;

    public ConciliacionInventarioView(InventarioFisicoController controller, PermisosVistaInventario permisos, Runnable alCambiar) {
        super(new BorderLayout(12, 12));
        this.controller = controller; this.permisos = permisos; this.alCambiar = alCambiar;
        setOpaque(false);

        tomas.setPrototypeDisplayValue(new Toma(999, "IF-2026-0000", "Almacén muy largo", null, null, "Responsable", 0, 0, 0, EstadoToma.ABIERTA));
        tomas.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                super.getListCellRendererComponent(l, v, i, s, f);
                if (v instanceof Toma t) setText(t.codigo() + " · " + t.almacen() + " · " + t.estado());
                return this;
            }
        });
        JButton cargar = botonSecundario("Cargar diferencias"), ejecutar = botonPrimario("Ejecutar conciliación"),
                revision = botonSecundario("Revisión de diferencias"), detalle = botonSecundario("Detalle de diferencia"),
                ajuste = botonSecundario("Gestionar ajuste"), cerrar = botonSecundario("Cerrar toma");
        ejecutar.setEnabled(permisos.puedeConciliar());
        cerrar.setEnabled(permisos.puedeCerrarToma());
        JPanel arriba = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        arriba.setOpaque(false);
        arriba.add(new JLabel("Toma física:"));
        arriba.add(tomas);
        for (JButton b : new JButton[]{cargar, ejecutar, revision, detalle, ajuste, cerrar}) arriba.add(b);
        add(arriba, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
        JLabel nota = etiquetaSecundaria("La conciliación compara el conteo con el saldo del sistema. La vista no actualiza existencias ni costos.");
        add(nota, BorderLayout.SOUTH);

        tomas.addActionListener(e -> { if (!cargandoTomas) cargarDiferencias(); });
        cargar.addActionListener(e -> cargarDiferencias());
        ejecutar.addActionListener(e -> ejecutarConciliacion());
        revision.addActionListener(e -> {
            Toma t = tomaActual();
            if (t == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_TOMA); return; }
            new RevisionDiferenciasDialog(ventana(), controller, t.id(), permisos, this::despuesDeCambio).setVisible(true);
        });
        detalle.addActionListener(e -> {
            Toma t = tomaActual(); Diferencia d = panel.getSeleccionada();
            if (t == null || d == null) { MensajesInventarioFisico.advertencia(this, "Selecciona un producto."); return; }
            new DetalleDiferenciaDialog(ventana(), controller, t.id(), d, this::cargarDiferencias).setVisible(true);
        });
        ajuste.addActionListener(e -> gestionarAjuste());
        cerrar.addActionListener(e -> cerrarToma());
        recargarTomas();
    }

    private Window ventana() { return SwingUtilities.getWindowAncestor(this); }
    private Toma tomaActual() { return (Toma) tomas.getSelectedItem(); }
    private void despuesDeCambio() { cargarDiferencias(); alCambiar.run(); }

    /** Vuelve a cargar la lista de tomas conservando la que estaba elegida. */
    public void recargarTomas() {
        Toma previa = tomaActual();
        TareaAsincrona.ejecutar(this, () -> controller.listarTomas("", null), lista -> {
            cargandoTomas = true;
            tomas.removeAllItems();
            lista.forEach(tomas::addItem);
            if (previa != null) for (int i = 0; i < tomas.getItemCount(); i++) if (tomas.getItemAt(i).id() == previa.id()) tomas.setSelectedIndex(i);
            cargandoTomas = false;
            cargarDiferencias();
        });
    }

    /** Elige una toma concreta (por ejemplo, desde el panel principal) y carga sus diferencias. */
    public void seleccionarToma(long id) {
        cargandoTomas = true;
        for (int i = 0; i < tomas.getItemCount(); i++) if (tomas.getItemAt(i).id() == id) tomas.setSelectedIndex(i);
        cargandoTomas = false;
        cargarDiferencias();
    }

    private void cargarDiferencias() {
        Toma t = tomaActual();
        if (t == null) { panel.setDiferencias(List.of()); return; }
        TareaAsincrona.ejecutar(this, () -> controller.listarDiferencias(t.id()), panel::setDiferencias);
    }

    private void ejecutarConciliacion() {
        Toma t = tomaActual();
        if (t == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_TOMA); return; }
        if (!MensajesInventarioFisico.confirmar(this, "¿Ejecutar conciliación de " + t.codigo() + "?", "Confirmar conciliación")) return;
        TareaAsincrona.ejecutar(this, () -> controller.conciliar(t.id()), lista -> {
            panel.setDiferencias(lista);
            alCambiar.run();
            MensajesInventarioFisico.informacion(this, "Conciliación realizada. Revisa los productos con diferencias.");
        });
    }

    private void gestionarAjuste() {
        Toma t = tomaActual(); Diferencia d = panel.getSeleccionada();
        if (t == null || d == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_DIFERENCIA); return; }
        boolean pendiente = d.estadoRevision() != null && d.estadoRevision().toUpperCase().startsWith("PENDIENTE");
        if (pendiente) new AprobacionAjusteDialog(ventana(), controller, t.id(), d, permisos, this::despuesDeCambio).setVisible(true);
        else if (permisos.puedeSolicitarAjuste()) new SolicitudAjusteDialog(ventana(), controller, t.id(), d, this::despuesDeCambio).setVisible(true);
        else MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SIN_PERMISO);
    }

    private void cerrarToma() {
        Toma t = tomaActual();
        if (t == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_TOMA); return; }
        if (!MensajesInventarioFisico.confirmar(this, "Cerrar " + t.codigo() + "? Una toma cerrada queda en consulta.", "Cerrar toma")) return;
        TareaAsincrona.ejecutar(this, () -> { controller.cerrarToma(t.id()); return true; }, ok -> {
            alCambiar.run();
            MensajesInventarioFisico.informacion(this, "Toma cerrada correctamente.");
        });
    }
}
