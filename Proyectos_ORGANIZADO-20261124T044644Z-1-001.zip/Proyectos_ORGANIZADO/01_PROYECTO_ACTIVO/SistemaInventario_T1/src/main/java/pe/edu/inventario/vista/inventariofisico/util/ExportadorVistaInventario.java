package pe.edu.inventario.vista.inventariofisico.util;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Exporta lo que muestra una tabla a CSV (compatible con Excel). */
public final class ExportadorVistaInventario {
    private ExportadorVistaInventario() { }

    public static String aCsv(TableModel m) {
        StringBuilder sb = new StringBuilder();
        for (int c = 0; c < m.getColumnCount(); c++) { if (c > 0) sb.append(','); sb.append(escapar(m.getColumnName(c))); }
        sb.append('\n');
        for (int r = 0; r < m.getRowCount(); r++) {
            for (int c = 0; c < m.getColumnCount(); c++) {
                if (c > 0) sb.append(',');
                Object v = m.getValueAt(r, c);
                sb.append(escapar(v instanceof java.math.BigDecimal b ? FormatoInventarioFisico.cantidad(b)
                        : v instanceof java.time.LocalDateTime d ? FormatoInventarioFisico.fecha(d)
                        : v == null ? "" : v.toString()));
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    public static void exportarCsv(TableModel m, File destino) throws IOException {
        // BOM UTF-8 para que Excel respete las tildes
        Files.writeString(destino.toPath(), "﻿" + aCsv(m), StandardCharsets.UTF_8);
    }

    /** Pide al usuario dónde guardar y exporta. @return el archivo creado o null si canceló. */
    public static File exportarConDialogo(Component padre, TableModel m, String nombreSugerido) throws IOException {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File(nombreSugerido.endsWith(".csv") ? nombreSugerido : nombreSugerido + ".csv"));
        if (fc.showSaveDialog(padre) != JFileChooser.APPROVE_OPTION) return null;
        File f = fc.getSelectedFile();
        exportarCsv(m, f);
        return f;
    }

    private static String escapar(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }
}
