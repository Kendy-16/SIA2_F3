
package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.servicio.AlmacenService;

import java.sql.SQLException;
import java.util.ArrayList;

public class AlmacenController {

    private final AlmacenService almacenService;

    // Constructor
    public AlmacenController() {
        this.almacenService = new AlmacenService();
    }

    // Register warehouse
    public boolean registrarAlmacen(Almacen almacen)
            throws SQLException {

        return almacenService.registrar(almacen);
    }

    // List warehouses
    public ArrayList<Almacen> listarAlmacenes()
            throws SQLException {

        return almacenService.listar();
    }

    // Search warehouse by ID
    public Almacen buscarAlmacen(int idAlmacen)
            throws SQLException {

        return almacenService.buscarPorId(idAlmacen);
    }

    // Update warehouse
    public boolean actualizarAlmacen(Almacen almacen)
            throws SQLException {

        return almacenService.actualizar(almacen);
    }

    // Delete warehouse
    public boolean eliminarAlmacen(int idAlmacen)
            throws SQLException {

        return almacenService.eliminar(idAlmacen);
    }
}
