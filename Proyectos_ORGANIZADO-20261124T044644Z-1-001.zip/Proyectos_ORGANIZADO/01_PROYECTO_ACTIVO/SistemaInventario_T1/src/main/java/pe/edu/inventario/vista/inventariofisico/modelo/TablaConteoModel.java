package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Productos de una toma con su conteo. En conteo ciego el stock del sistema se muestra como "OCULTO". */
public class TablaConteoModel extends AbstractTableModel {
    public static final String OCULTO = "OCULTO";
    private static final String[] COLUMNAS = {"Código", "Producto", "Unidad", "Ubicación", "Stock sistema", "Conteo 1", "Conteo 2", "Estado", "Observación"};
    private List<Producto> filas = new ArrayList<>();
    private boolean ocultarStock = true;

    public void setFilas(List<Producto> nuevas, boolean ocultarStock) {
        this.filas = new ArrayList<>(nuevas);
        this.ocultarStock = ocultarStock;
        fireTableDataChanged();
    }
    public Producto getProducto(int fila) { return fila < 0 || fila >= filas.size() ? null : filas.get(fila); }
    public List<Producto> getFilas() { return Collections.unmodifiableList(filas); }
    public int contados() { return (int) filas.stream().filter(p -> p.cantidadFinal() != null).count(); }

    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) {
        return switch (c) { case 4 -> Object.class; case 5, 6 -> BigDecimal.class; case 7 -> EstadoConteo.class; default -> String.class; };
    }
    @Override public Object getValueAt(int r, int c) {
        Producto p = filas.get(r);
        return switch (c) {
            case 0 -> p.codigo(); case 1 -> p.nombre(); case 2 -> p.unidad(); case 3 -> p.ubicacion();
            case 4 -> ocultarStock ? OCULTO : p.stockSistema();
            case 5 -> p.cantidadContada(); case 6 -> p.segundoConteo(); case 7 -> p.estado();
            default -> p.observacion() == null ? "" : p.observacion();
        };
    }
}
