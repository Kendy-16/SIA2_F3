
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Kardex;
import pe.edu.inventario.modelo.dao.KardexDAO;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class KardexService {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final int ANIO_MINIMO = 1;
    private static final int ANIO_MAXIMO = 9999;

    private static final DateTimeFormatter FORMATO_FECHA =
            DateTimeFormatter.ofPattern(
                    "uuuu-MM-dd HH:mm:ss"
            ).withResolverStyle(ResolverStyle.STRICT);

    // ==========================================
    // 2. ATRIBUTOS
    // ==========================================

    private final KardexDAO kardexDAO;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public KardexService() {
        this.kardexDAO = new KardexDAO();
    }

    // Constructor with dependency injection
    public KardexService(KardexDAO kardexDAO) {

        if (kardexDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de kardex es obligatorio."
            );
        }

        this.kardexDAO = kardexDAO;
    }

    // ==========================================
    // 4. CONSULTAR POR PRODUCTO
    // ==========================================

    public ArrayList<Kardex> consultarPorProducto(
            int idProducto
    ) throws SQLException {

        validarIdProducto(idProducto);

        ArrayList<Kardex> registros =
                kardexDAO.listarPorProducto(idProducto);

        validarResultados(
                registros,
                idProducto,
                null,
                null,
                null
        );

        return new ArrayList<>(registros);
    }

    // ==========================================
    // 5. CONSULTAR POR PRODUCTO Y ALMACEN
    // ==========================================

    public ArrayList<Kardex> consultarPorProductoYAlmacen(
            int idProducto,
            int idAlmacen
    ) throws SQLException {

        validarIdProducto(idProducto);
        validarIdAlmacen(idAlmacen);

        ArrayList<Kardex> registros =
                kardexDAO.listarPorProductoYAlmacen(
                        idProducto,
                        idAlmacen
                );

        validarResultados(
                registros,
                idProducto,
                idAlmacen,
                null,
                null
        );

        return new ArrayList<>(registros);
    }

    // ==========================================
    // 6. CONSULTAR POR PERIODO
    // ==========================================

    public ArrayList<Kardex> consultarPorPeriodo(
            int idProducto,
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) throws SQLException {

        validarIdProducto(idProducto);

        if (idAlmacen != null) {
            validarIdAlmacen(idAlmacen);
        }

        validarPeriodo(fechaDesde, fechaHasta);

        ArrayList<Kardex> registros =
                kardexDAO.listarPorPeriodo(
                        idProducto,
                        idAlmacen,
                        fechaDesde,
                        fechaHasta
                );

        validarResultados(
                registros,
                idProducto,
                idAlmacen,
                fechaDesde,
                fechaHasta
        );

        return new ArrayList<>(registros);
    }

    // ==========================================
    // 7. VALIDAR ID DE PRODUCTO
    // ==========================================

    private void validarIdProducto(int idProducto) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }
    }

    // ==========================================
    // 8. VALIDAR ID DE ALMACEN
    // ==========================================

    private void validarIdAlmacen(int idAlmacen) {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // 9. VALIDAR PERIODO
    // ==========================================

    private void validarPeriodo(
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) {

        if (fechaDesde == null) {
            throw new IllegalArgumentException(
                    "La fecha inicial es obligatoria."
            );
        }

        if (fechaHasta == null) {
            throw new IllegalArgumentException(
                    "La fecha final es obligatoria."
            );
        }

        validarFechaSQLite(fechaDesde);
        validarFechaSQLite(fechaHasta);

        if (fechaDesde.isAfter(fechaHasta)) {
            throw new IllegalArgumentException(
                    "La fecha inicial no puede ser posterior a la fecha final."
            );
        }
    }

    // ==========================================
    // 10. VALIDAR RANGO DE FECHAS SQLITE
    // ==========================================

    private void validarFechaSQLite(LocalDate fecha) {

        int anio = fecha.getYear();

        if (anio < ANIO_MINIMO || anio > ANIO_MAXIMO) {
            throw new IllegalArgumentException(
                    "El ano de la fecha debe estar entre 1 y 9999."
            );
        }
    }

    // ==========================================
    // 11. VALIDAR RESULTADOS DEL DAO
    // ==========================================

    private void validarResultados(
            ArrayList<Kardex> registros,
            int idProducto,
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) throws SQLException {

        if (registros == null) {
            throw new SQLException(
                    "El DAO devolvio una lista nula de kardex."
            );
        }

        Set<Integer> idsEncontrados = new HashSet<>();

        String fechaAnterior = null;
        int idAnterior = -1;

        for (Kardex registro : registros) {

            if (registro == null) {
                throw new SQLException(
                        "La consulta contiene un registro nulo."
                );
            }

            validarIntegridadRegistro(
                    registro,
                    idProducto,
                    idAlmacen,
                    fechaDesde,
                    fechaHasta
            );

            // Check persistent ID
            if (registro.getIdKardex() <= 0) {
                throw new SQLException(
                        "El kardex contiene un ID no valido."
                );
            }

            // Check duplicated IDs
            if (!idsEncontrados.add(
                    registro.getIdKardex()
            )) {

                throw new SQLException(
                        "Se encontro un ID de kardex duplicado: "
                                + registro.getIdKardex()
                );
            }

            // Check chronological order
            String fechaActual = registro.getFecha();

            int idActual = registro.getIdKardex();

            if (fechaAnterior != null) {

                int comparacion =
                        fechaAnterior.compareTo(fechaActual);

                if (comparacion > 0
                        || (comparacion == 0
                        && idAnterior > idActual)) {

                    throw new SQLException(
                            "Los registros del kardex no estan ordenados cronologicamente."
                    );
                }
            }

            fechaAnterior = fechaActual;
            idAnterior = idActual;
        }
    }

    // ==========================================
    // 12. VALIDAR INTEGRIDAD DEL REGISTRO
    // ==========================================

    private void validarIntegridadRegistro(
            Kardex registro,
            int idProducto,
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) throws SQLException {

        // Product
        if (registro.getIdProducto() != idProducto) {
            throw new SQLException(
                    "Se encontro un registro de otro producto."
            );
        }

        // Warehouse
        if (idAlmacen != null
                && registro.getIdAlmacen() != idAlmacen) {

            throw new SQLException(
                    "Se encontro un registro de otro almacen."
            );
        }

        // Date
        LocalDateTime fechaRegistro;

        try {

            fechaRegistro = LocalDateTime.parse(
                    registro.getFecha(),
                    FORMATO_FECHA
            );

        } catch (DateTimeParseException ex) {

            throw new SQLException(
                    "El kardex contiene una fecha invalida.",
                    ex
            );
        }

        LocalDate fecha = fechaRegistro.toLocalDate();

        validarFechaSQLite(fecha);

        // Start date
        if (fechaDesde != null
                && fecha.isBefore(fechaDesde)) {

            throw new SQLException(
                    "Existe un registro anterior al periodo solicitado."
            );
        }

        // End date
        if (fechaHasta != null
                && fecha.isAfter(fechaHasta)) {

            throw new SQLException(
                    "Existe un registro posterior al periodo solicitado."
            );
        }
    }
}
