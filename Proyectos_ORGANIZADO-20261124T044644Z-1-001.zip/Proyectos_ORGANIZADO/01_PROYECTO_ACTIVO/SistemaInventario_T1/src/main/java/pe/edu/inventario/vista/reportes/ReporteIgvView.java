package pe.edu.inventario.vista.reportes;

import pe.edu.inventario.modelo.dao.ReporteDAO;

import java.awt.BorderLayout;
import javax.swing.JPanel;

/** Resumen de IGV: crédito fiscal (compras) vs. débito fiscal (ventas). */
public class ReporteIgvView extends JPanel {

    public ReporteIgvView() {
        super(new BorderLayout());

        ReporteDAO dao = new ReporteDAO();

        add(new PanelReporteTabla(
                "Resumen de IGV (18 %)",
                "IGV de compras (crédito) y de ventas (débito) registrado en los movimientos.",
                new String[]{"Concepto", "Líneas", "Base imponible", "IGV"},
                new String[]{null, "%.0f", "%,.2f", "%,.2f"},
                dao::resumenIgv,
                filas -> {
                    double credito = 0, debito = 0;
                    for (Object[] f : filas) {
                        double igv = ((Number) f[3]).doubleValue();
                        if (String.valueOf(f[0]).startsWith("Compras")) {
                            credito = igv;
                        } else {
                            debito = igv;
                        }
                    }
                    return String.format(java.util.Locale.US,
                            "IGV por pagar (débito - crédito): S/ %,.2f",
                            debito - credito);
                }
        ), BorderLayout.CENTER);
    }
}
