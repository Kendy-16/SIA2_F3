package pe.edu.inventario.dao.venta;

import pe.edu.inventario.modelo.venta.EstadoVenta;
import pe.edu.inventario.modelo.venta.Venta;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementación en memoria de VentaDAO. Sirve para ejecutar el módulo sin base de datos;
 * para producción se reemplaza por una implementación JDBC/SQLite con la misma interfaz.
 */
public class VentaDAOMemoria implements VentaDAO {

    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/uuuu");

    private final Map<String, Venta> ventas = new LinkedHashMap<>();

    @Override
    public synchronized void guardar(Venta venta) throws Exception {
        if (ventas.containsKey(venta.getIdVenta())) {
            throw new IllegalStateException("La venta " + venta.getIdVenta() + " ya existe.");
        }
        ventas.put(venta.getIdVenta(), venta);
    }

    @Override
    public synchronized Venta buscarPorId(String idVenta) {
        return ventas.get(idVenta);
    }

    /**
     * @param fechaInicio DD/MM/YYYY (vacío = sin límite inferior)
     * @param fechaFin    DD/MM/YYYY (vacío = sin límite superior)
     * @param tipoVenta   "TODAS", "NORMAL" o "MAYORISTA"
     */
    @Override
    public synchronized List<Venta> listarHistorialPorFiltro(String fechaInicio, String fechaFin, String tipoVenta) {
        LocalDate desde = parsear(fechaInicio);
        LocalDate hasta = parsear(fechaFin);
        if (desde != null && hasta != null && desde.isAfter(hasta)) {
            throw new IllegalArgumentException("La fecha inicial no puede ser mayor que la final.");
        }
        boolean todas = tipoVenta == null || tipoVenta.trim().isEmpty() || "TODAS".equalsIgnoreCase(tipoVenta);

        List<Venta> resultado = new ArrayList<>();
        for (Venta v : ventas.values()) {
            LocalDate fecha = v.getFechaEmision().toLocalDate();
            if (desde != null && fecha.isBefore(desde)) continue;
            if (hasta != null && fecha.isAfter(hasta)) continue;
            if (!todas && !v.getTipoVenta().name().equalsIgnoreCase(tipoVenta)) continue;
            resultado.add(v);
        }
        resultado.sort(Comparator.comparing(Venta::getFechaEmision).reversed());
        return resultado;
    }

    @Override
    public synchronized void actualizarEstado(String idVenta, String nuevoEstado,
                                              String motivoAnulacion, String usuarioAutoriza) throws Exception {
        Venta v = ventas.get(idVenta);
        if (v == null) {
            throw new IllegalStateException("No existe la venta " + idVenta);
        }
        v.setEstado(EstadoVenta.valueOf(nuevoEstado));
        v.setMotivoAnulacion(motivoAnulacion);
        v.setUsuarioAutoriza(usuarioAutoriza);
    }

    private LocalDate parsear(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(texto.trim(), FORMATO);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Fecha inválida '" + texto + "'. Use el formato DD/MM/YYYY.");
        }
    }
}
