package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.SeleccionProductosDialog;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Formulario para crear una nueva toma de inventario físico. */
public class NuevaTomaInventarioDialog extends JDialog {
    private final InventarioFisicoController controller;
    private final Consumer<Toma> alCrear;
    private final PanelSeleccionAlmacen seleccion = new PanelSeleccionAlmacen();
    private final JCheckBox cero = new JCheckBox("Incluir productos con stock cero", true);
    private final JCheckBox ciego = new JCheckBox("Conteo ciego (ocultar stock del sistema)", true);
    private final JCheckBox segundo = new JCheckBox("Permitir segundo conteo", true);
    private final JCheckBox parcial = new JCheckBox("Permitir conteo parcial", false);
    private final PanelObservaciones observaciones = new PanelObservaciones("Observaciones:", 3);
    private final Set<Long> productos = new LinkedHashSet<>();
    private final JLabel etiquetaSeleccion = new JLabel("No se han seleccionado productos");
    private final JButton elegir = botonSecundario("Seleccionar productos...");

    public NuevaTomaInventarioDialog(Window owner, InventarioFisicoController controller, Consumer<Toma> alCrear) {
        super(owner, "Nueva toma de inventario físico", ModalityType.APPLICATION_MODAL);
        this.controller = controller; this.alCrear = alCrear;
        setSize(650, 640); setLocationRelativeTo(owner); setLayout(new BorderLayout(12, 12));

        JPanel form = new JPanel(new BorderLayout(8, 8));
        form.setBorder(new EmptyBorder(18, 22, 10, 22));
        form.setBackground(Color.WHITE);
        form.add(seleccion, BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(0, 1, 6, 6));
        centro.setOpaque(false);
        JPanel filaSel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); filaSel.setOpaque(false);
        filaSel.add(elegir); filaSel.add(etiquetaSeleccion);
        centro.add(filaSel);
        for (JCheckBox c : new JCheckBox[]{cero, ciego, segundo, parcial}) { c.setOpaque(false); centro.add(c); }
        form.add(centro, BorderLayout.CENTER);
        form.add(observaciones, BorderLayout.SOUTH);
        add(form, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botones.setBorder(new EmptyBorder(0, 12, 12, 12));
        JButton cancelar = botonSecundario("Cancelar"), crear = botonPrimario("Crear toma");
        botones.add(cancelar); botones.add(crear);
        add(botones, BorderLayout.SOUTH);

        elegir.setEnabled(false);
        seleccion.alCambiarAlcance(() -> elegir.setEnabled(seleccion.esSeleccionados()));
        elegir.addActionListener(e -> {
            new SeleccionProductosDialog(this, controller, seleccion.getAlmacen() == null ? "" : seleccion.getAlmacen(), seleccion.getCategoria(), productos).setVisible(true);
            etiquetaSeleccion.setText(productos.isEmpty() ? "No se han seleccionado productos" : productos.size() + " producto(s) seleccionado(s)");
        });
        cancelar.addActionListener(e -> dispose());
        crear.addActionListener(e -> crearToma());
        cargarOpciones();
    }

    private void cargarOpciones() {
        TareaAsincrona.ejecutar(this, () -> List.of(controller.listarAlmacenes(), controller.listarCategorias()),
                r -> seleccion.cargar(r.get(0), r.get(1)));
    }

    private void crearToma() {
        if (!seleccion.almacenListo()) { MensajesInventarioFisico.advertencia(this, "Selecciona un almacén."); return; }
        if (seleccion.esSeleccionados() && productos.isEmpty()) { MensajesInventarioFisico.advertencia(this, "Selecciona al menos un producto."); return; }
        NuevaToma solicitud = new NuevaToma(seleccion.getAlmacen(), seleccion.getAlcance(), seleccion.getCategoria(), cero.isSelected(),
                ciego.isSelected(), segundo.isSelected(), parcial.isSelected(), observaciones.getTexto(), new ArrayList<>(productos));
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        TareaAsincrona.ejecutar(this, () -> controller.crearToma(solicitud),
                t -> { setCursor(Cursor.getDefaultCursor()); dispose(); alCrear.accept(t); },
                ex -> { setCursor(Cursor.getDefaultCursor()); MensajesInventarioFisico.error(this, ex); });
    }
}
