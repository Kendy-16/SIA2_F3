package pe.edu.inventario.migracion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Migración V006:
 *  1) Agrega el IGV al detalle de movimientos (compras y ventas).
 *  2) Garantiza que exista al menos un ADMINISTRADOR.
 *
 * Reglas de negocio:
 *  - costo_unitario  = valor unitario SIN IGV (base del costo promedio).
 *  - igv_tasa        = 0.18 cuando la operación está afecta; 0 si no.
 *  - igv_monto       = cantidad * base * igv_tasa (2 decimales).
 *                      Base: costo_unitario en ENTRADA, precio_venta en SALIDA.
 *  - precio_venta    = valor de venta unitario SIN IGV (solo SALIDA).
 */
public final class MigracionV006IgvYAdministrador {

    private MigracionV006IgvYAdministrador() {
    }

    public static void ejecutar(Connection conexion) throws SQLException {

        agregarColumna(conexion, "detalle_movimientos", "igv_tasa",
                "REAL NOT NULL DEFAULT 0 CHECK (igv_tasa >= 0 AND igv_tasa <= 1)");

        agregarColumna(conexion, "detalle_movimientos", "igv_monto",
                "REAL NOT NULL DEFAULT 0 CHECK (igv_monto >= 0)");

        agregarColumna(conexion, "detalle_movimientos", "precio_venta",
                "REAL NOT NULL DEFAULT 0 CHECK (precio_venta >= 0)");

        // Si no hay ningún administrador, el usuario más antiguo lo será.
        try (Statement st = conexion.createStatement()) {
            st.executeUpdate("""
                    UPDATE usuarios
                    SET rol = 'ADMINISTRADOR'
                    WHERE id_usuario = (SELECT MIN(id_usuario) FROM usuarios)
                      AND NOT EXISTS (
                          SELECT 1 FROM usuarios WHERE rol = 'ADMINISTRADOR'
                      )
                    """);
        }
    }

    private static void agregarColumna(
            Connection conexion, String tabla, String columna, String definicion
    ) throws SQLException {

        boolean existe = false;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA table_info(" + tabla + ")")) {
            while (rs.next()) {
                if (columna.equalsIgnoreCase(rs.getString("name"))) {
                    existe = true;
                    break;
                }
            }
        }

        if (!existe) {
            try (Statement st = conexion.createStatement()) {
                st.execute("ALTER TABLE " + tabla
                        + " ADD COLUMN " + columna + " " + definicion);
            }
        }
    }
}
