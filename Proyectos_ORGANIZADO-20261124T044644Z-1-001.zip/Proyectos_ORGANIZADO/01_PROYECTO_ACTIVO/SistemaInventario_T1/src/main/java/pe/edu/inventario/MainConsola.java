package pe.edu.inventario;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.dao.venta.VentaDAO;
import pe.edu.inventario.dao.venta.VentaDAOMemoria;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.modelo.venta.TipoVenta;
import pe.edu.inventario.modelo.venta.Venta;
import pe.edu.inventario.seguridad.ControlIdempotencia;
import pe.edu.inventario.servicio.cliente.ClienteService;
import pe.edu.inventario.servicio.producto.ProductoService;
import pe.edu.inventario.servicio.venta.CajaService;
import pe.edu.inventario.servicio.venta.DocumentoService;
import pe.edu.inventario.servicio.venta.KardexService;
import pe.edu.inventario.servicio.venta.VentaException;
import pe.edu.inventario.servicio.venta.VentaService;

import java.math.BigDecimal;

/**
 * Demo sin interfaz gráfica: recorre los escenarios principales del módulo de ventas
 * (venta normal, mayorista, descuentos por perfil, idempotencia, stock y anulación).
 */
public class MainConsola {

    public static void main(String[] args) throws Exception {
        ProductoService productos = new ProductoService();
        KardexService kardex = new KardexService();
        ClienteService clientes = new ClienteService();
        CajaService caja = new CajaService();
        DatosDemo.cargar(productos, kardex, clientes);

        VentaDAO dao = new VentaDAOMemoria();
        VentaService servicio = new VentaService(kardex, caja, new DocumentoService(), dao, productos);

        // ---------- 1. Venta NORMAL en efectivo ----------
        titulo("1. Venta NORMAL (cliente genérico, efectivo)");
        VentaController normal = new VentaController(servicio, productos, clientes);
        normal.iniciarNuevaVenta(TipoVenta.NORMAL, RolUsuario.USUARIO, "cajero01");
        normal.agregarProducto("P001", 2);
        normal.agregarProducto("P002", 3);
        mostrarTotales(normal.getVentaActual());
        String comp1 = normal.procesarPagoYConfirmar("Efectivo", new BigDecimal("500.00"));
        System.out.println("Comprobante: " + comp1 + "  | vuelto S/ " + normal.getVentaActual().getVuelto());

        // ---------- 2. Descuento manual: USUARIO no puede ----------
        titulo("2. Descuento manual con perfil USUARIO (debe fallar)");
        normal.iniciarNuevaVenta(TipoVenta.NORMAL, RolUsuario.USUARIO, "cajero01");
        normal.agregarProducto("P003", 4);
        try {
            normal.aplicarDescuentoManual(0, new BigDecimal("10"));
            System.out.println("ERROR: debió bloquearse");
        } catch (SecurityException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }

        // ---------- 3. Descuento manual: ADMINISTRADOR sí ----------
        titulo("3. Descuento manual 10% con perfil ADMINISTRADOR");
        normal.iniciarNuevaVenta(TipoVenta.NORMAL, RolUsuario.ADMINISTRADOR, "admin01");
        normal.agregarProducto("P003", 4);
        normal.aplicarDescuentoManual(0, new BigDecimal("10"));
        mostrarTotales(normal.getVentaActual());
        normal.procesarPagoYConfirmar("Transferencia / Yape / Plin", null);

        // ---------- 4. Mayorista ----------
        titulo("4. Venta MAYORISTA");
        VentaController mayorista = new VentaController(servicio, productos, clientes);
        mayorista.iniciarNuevaVenta(TipoVenta.MAYORISTA, RolUsuario.USUARIO, "cajero02");
        try {
            mayorista.setCliente("00000000");
            System.out.println("ERROR: debió exigir cliente real");
        } catch (IllegalArgumentException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }
        mayorista.setCliente("20601234567");
        try {
            mayorista.agregarProducto("P001", 3);
            System.out.println("ERROR: debió exigir cantidad mínima");
        } catch (IllegalArgumentException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }
        mayorista.agregarProducto("P001", 10);
        mostrarTotales(mayorista.getVentaActual());
        String comp2 = mayorista.procesarPagoYConfirmar("Tarjeta Crédito/Débito", null);
        System.out.println("Comprobante: " + comp2);
        Venta mayoristaConfirmada = mayorista.getVentaActual();

        // ---------- 5. Idempotencia ----------
        titulo("5. Doble clic: confirmar la MISMA venta otra vez");
        try {
            servicio.confirmarVenta(mayoristaConfirmada);
            System.out.println("ERROR: se duplicó la venta");
        } catch (VentaException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }

        titulo("5b. Doble envío simultáneo: la misma operación ya está EN PROCESO");
        normal.iniciarNuevaVenta(TipoVenta.NORMAL, RolUsuario.USUARIO, "cajero01");
        normal.agregarProducto("P004", 1);
        String token = normal.getVentaActual().getTokenTransaccion();
        ControlIdempotencia.iniciarTransaccion(token); // simula el primer clic aún en curso
        try {
            normal.procesarPagoYConfirmar("Efectivo", new BigDecimal("100"));
            System.out.println("ERROR: se duplicó el cobro");
        } catch (VentaException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }
        ControlIdempotencia.liberarTransaccion(token); // el primer intento terminó/falló
        normal.procesarPagoYConfirmar("Efectivo", new BigDecimal("100"));
        System.out.println("Reintento tras liberar el token: OK, comprobante " + normal.getVentaActual().getComprobante());

        // ---------- 6. Stock insuficiente + reintento ----------
        titulo("6. Stock insuficiente (Router WiFi, stock 8) y reversa");
        normal.iniciarNuevaVenta(TipoVenta.NORMAL, RolUsuario.USUARIO, "cajero01");
        normal.agregarProducto("P006", 9);
        try {
            normal.procesarPagoYConfirmar("Efectivo", new BigDecimal("5000"));
            System.out.println("ERROR: debió fallar por stock");
        } catch (VentaException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }
        System.out.println("Caja no se movió. Saldo: S/ " + caja.getSaldo().toPlainString());

        // ---------- 7. Anulación ----------
        titulo("7. Anulación de la venta mayorista");
        try {
            servicio.anularVenta(mayoristaConfirmada.getIdVenta(), RolUsuario.USUARIO, "cajero02", "error");
            System.out.println("ERROR: USUARIO no debe anular");
        } catch (SecurityException e) {
            System.out.println("Bloqueado OK -> " + e.getMessage());
        }
        servicio.anularVenta(mayoristaConfirmada.getIdVenta(), RolUsuario.ADMINISTRADOR, "admin01",
                "Cliente se arrepintió");
        System.out.println("Estado ahora: " + servicio.buscarVenta(mayoristaConfirmada.getIdVenta()).getEstado());

        // ---------- Historial, Kardex y Caja ----------
        titulo("Historial (TODAS)");
        for (Venta v : servicio.listarHistorial("", "", "TODAS")) {
            System.out.printf("%-11s %-9s %-10s S/ %9s  %s%n", v.getIdVenta(), v.getTipoVenta(),
                    v.getEstado(), v.getTotal().toPlainString(), v.getComprobante());
        }
        titulo("Kardex");
        kardex.getMovimientos().forEach(System.out::println);
        titulo("Caja");
        caja.getMovimientos().forEach(System.out::println);
        System.out.println("Saldo final: S/ " + caja.getSaldo().toPlainString());

        titulo("Ticket de la venta mayorista (anulada)");
        System.out.println(servicio.formatearTicket(servicio.buscarVenta(mayoristaConfirmada.getIdVenta())));
    }

    private static void mostrarTotales(Venta v) {
        System.out.println("Subtotal S/ " + v.getSubtotal() + " | Dscto S/ " + v.getDescuentoTotal()
                + " | IGV S/ " + v.getImpuestos() + " | TOTAL S/ " + v.getTotal());
    }

    private static void titulo(String texto) {
        System.out.println("\n=== " + texto + " ===");
    }
}
