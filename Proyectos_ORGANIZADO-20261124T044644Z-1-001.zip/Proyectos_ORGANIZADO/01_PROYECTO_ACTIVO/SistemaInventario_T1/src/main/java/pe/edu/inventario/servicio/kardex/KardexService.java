package pe.edu.inventario.servicio.kardex;

/** Kardex: el stock solo cambia mediante movimientos justificados. (Clase de apoyo) */
public class KardexService {
    public void registrarIngresoPorAnulacion(String codigoProducto, int cantidad, String glosa) {
        // TODO: persistir movimiento de ingreso en el Kardex
    }
    public void registrarIngresoPorDevolucion(String codigoProducto, int cantidad, String glosa) {
        // TODO: persistir movimiento de ingreso en el Kardex
    }
}
