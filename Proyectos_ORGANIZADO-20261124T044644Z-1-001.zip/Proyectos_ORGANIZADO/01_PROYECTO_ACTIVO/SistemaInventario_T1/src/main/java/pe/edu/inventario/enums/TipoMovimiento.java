
package pe.edu.inventario.enums;

import java.util.Locale;

/**
 * Defines the allowed inventory movement types.
 */
public enum TipoMovimiento {

    ENTRADA("Entrada"),
    SALIDA("Salida"),
    AJUSTE("Ajuste");

    // Attributes
    private final String descripcion;

    // Constructor
    private TipoMovimiento(String descripcion) {

        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "La descripcion es obligatoria."
            );
        }

        this.descripcion = descripcion.trim();
    }

    // Get description
    public String getDescripcion() {
        return descripcion;
    }

    // Get database code
    public String getCodigo() {
        return name();
    }

    // Convert text to enum
    public static TipoMovimiento desdeValor(String valor) {

        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Debe seleccionar un tipo de movimiento."
            );
        }

        String normalizado = valor.trim().toUpperCase(Locale.ROOT);

        for (TipoMovimiento tipo : values()) {

            if (tipo.name().equals(normalizado)
                    || tipo.descripcion.equalsIgnoreCase(normalizado)) {

                return tipo;
            }
        }

        throw new IllegalArgumentException(
                "Tipo no valido. Use ENTRADA, SALIDA o AJUSTE."
        );
    }

    // Check movement type
    public boolean esEntrada() {
        return this == ENTRADA;
    }

    public boolean esSalida() {
        return this == SALIDA;
    }

    public boolean esAjuste() {
        return this == AJUSTE;
    }

    // Display description in Swing
    @Override
    public String toString() {
        return descripcion;
    }
}
