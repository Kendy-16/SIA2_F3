package pe.edu.inventario.demo;

import pe.edu.inventario.vista.inventariofisico.InventarioFisicoView;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** Punto de entrada para ejecutar la interfaz con datos ficticios. */
public final class InventarioFisicoDemo {
    private InventarioFisicoDemo() { }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { }
            InventarioFisicoView frame = new InventarioFisicoView(new DemoInventarioFisicoController());
            frame.setVisible(true);
        });
    }
}
