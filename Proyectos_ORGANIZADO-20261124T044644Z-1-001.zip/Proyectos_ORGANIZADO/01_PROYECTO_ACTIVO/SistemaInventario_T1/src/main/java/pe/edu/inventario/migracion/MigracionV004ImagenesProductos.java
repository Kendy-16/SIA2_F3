package pe.edu.inventario.migracion;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Migración V004: imágenes de productos mediante Pixabay.
 *
 * Recibe una conexión existente para no crear conexiones
 * independientes ni modificar la configuración de ConexionDB.
 */
public final class MigracionV004ImagenesProductos {

    private MigracionV004ImagenesProductos() {
    }

    /**
     * Ejecuta la migración V004 dentro de una conexión existente.
     *
     * El llamador controla la transacción.
     */
    public static void ejecutar(Connection conexion)
            throws SQLException {

        if (conexion == null || conexion.isClosed()) {
            throw new SQLException(
                    "La conexión SQLite no está disponible."
            );
        }

        String crearTablaImagenes = """
                CREATE TABLE IF NOT EXISTS imagenes_productos (
                    id_imagen INTEGER PRIMARY KEY AUTOINCREMENT,
                    id_producto INTEGER NOT NULL UNIQUE,
                    pixabay_id INTEGER NOT NULL,
                    ruta_local TEXT NOT NULL,
                    fuente TEXT NOT NULL DEFAULT 'Pixabay',
                    pagina_fuente TEXT NOT NULL,
                    autor TEXT,
                    fecha_guardado TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (id_producto)
                        REFERENCES productos(id_producto)
                        ON DELETE CASCADE
                )
                """;

        String crearIndice = """
                CREATE INDEX IF NOT EXISTS
                idx_imagenes_productos_producto
                ON imagenes_productos(id_producto)
                """;

        String crearTablaCache = """
                CREATE TABLE IF NOT EXISTS cache_busqueda_imagenes (
                    termino TEXT PRIMARY KEY COLLATE NOCASE,
                    respuesta_json TEXT NOT NULL,
                    fecha_consulta INTEGER NOT NULL
                )
                """;

        try (Statement sentencia = conexion.createStatement()) {

            sentencia.executeUpdate(crearTablaImagenes);
            sentencia.executeUpdate(crearIndice);
            sentencia.executeUpdate(crearTablaCache);
        }
    }
}