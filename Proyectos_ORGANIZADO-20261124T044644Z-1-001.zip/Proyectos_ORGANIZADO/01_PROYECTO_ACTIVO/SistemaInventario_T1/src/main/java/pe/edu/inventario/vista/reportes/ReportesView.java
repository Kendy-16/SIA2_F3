package pe.edu.inventario.vista.reportes;

import pe.edu.inventario.vista.almacen.ExistenciasView;
import pe.edu.inventario.vista.inventario.InventarioValorizadoView;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/** Contenedor de reportes del inventario. */
public class ReportesView extends JPanel {

    public ReportesView() {
        super(new BorderLayout());

        JTabbedPane pestanas = new JTabbedPane();

        pestanas.addTab("Existencias", new ExistenciasView());
        pestanas.addTab("Inventario valorizado", new InventarioValorizadoView());
        pestanas.addTab("Utilidad bruta", new ReporteUtilidadView());
        pestanas.addTab("IGV", new ReporteIgvView());

        add(pestanas, BorderLayout.CENTER);
    }
}
