
package pe.edu.inventario.modelo;

/**
 * Represents a product category.
 */
public class Categoria {

    // Attributes
    private int idCategoria;
    private String nombre;
    private String descripcion;

    // Empty constructor
    public Categoria() {
    }

    // Complete constructor
    public Categoria(
            int idCategoria,
            String nombre,
            String descripcion
    ) {

        this.idCategoria = idCategoria;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Constructor without ID
    public Categoria(
            String nombre,
            String descripcion
    ) {

        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    // Get ID
    public int getIdCategoria() {
        return idCategoria;
    }

    // Set ID
    public void setIdCategoria(int idCategoria) {

        if (idCategoria < 0) {
            throw new IllegalArgumentException(
                    "El ID no puede ser negativo."
            );
        }

        this.idCategoria = idCategoria;
    }

    // Get name
    public String getNombre() {
        return nombre;
    }

    // Set name
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Get description
    public String getDescripcion() {
        return descripcion;
    }

    // Set description
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // Display category name
    @Override
    public String toString() {
        return nombre == null ? "" : nombre;
    }
}
