package pe.edu.inventario.vista.venta.componentes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

// 2. Panel para escanear/buscar Productos y agregarlos al detalle
public class PanelProductos extends JPanel {
    private JTextField txtCodigoBarras;
    private JSpinner spCantidad;
    private JButton btnAgregar;

    public PanelProductos() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setBorder(BorderFactory.createTitledBorder("Búsqueda de Productos"));

        txtCodigoBarras = new JTextField(15);
        spCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        btnAgregar = new JButton("Agregar al Detalle");

        add(new JLabel("Código (Lector):"));
        add(txtCodigoBarras);
        add(new JLabel("Cantidad:"));
        add(spCantidad);
        add(btnAgregar);
    }

    public JButton getBtnAgregar() { return btnAgregar; }

    public String getCodigo() { return txtCodigoBarras.getText().trim(); }
    public int getCantidad() { return ((Number) spCantidad.getValue()).intValue(); }

    /** Los lectores de código de barras envían Enter al terminar: por eso también se escucha el campo. */
    public void addAgregarListener(ActionListener listener) {
        btnAgregar.addActionListener(listener);
        txtCodigoBarras.addActionListener(listener);
    }

    public void limpiarEntrada() {
        txtCodigoBarras.setText("");
        spCantidad.setValue(1);
        txtCodigoBarras.requestFocusInWindow();
    }
}
