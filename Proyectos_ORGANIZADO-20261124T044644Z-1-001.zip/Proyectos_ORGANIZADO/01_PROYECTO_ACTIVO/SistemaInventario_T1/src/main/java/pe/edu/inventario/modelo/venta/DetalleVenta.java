package pe.edu.inventario.modelo.venta;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Línea de detalle de una venta. */
public class DetalleVenta {
    private static final BigDecimal CIEN = new BigDecimal("100");

    private String codigoProducto;
    private String nombreProducto;
    private int cantidad;
    private BigDecimal precioUnitario = BigDecimal.ZERO;
    private BigDecimal porcentajeDescuento = BigDecimal.ZERO;
    /** Subtotal ya calculado por VentaService; si es null se calcula al vuelo. */
    private BigDecimal subtotalLinea;

    public String getCodigoProducto() { return codigoProducto; }
    public void setCodigoProducto(String v) { this.codigoProducto = v; }
    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String v) { this.nombreProducto = v; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int v) { this.cantidad = v; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal v) { this.precioUnitario = v == null ? BigDecimal.ZERO : v; }
    public BigDecimal getPorcentajeDescuento() { return porcentajeDescuento; }
    public void setPorcentajeDescuento(BigDecimal v) { this.porcentajeDescuento = v == null ? BigDecimal.ZERO : v; }

    public void setSubtotalLinea(BigDecimal v) { this.subtotalLinea = v; }

    /** Subtotal = cantidad * precio * (1 - descuento/100). Usa el valor calculado por el servicio si existe. */
    public BigDecimal getSubtotalLinea() {
        if (subtotalLinea != null) {
            return subtotalLinea;
        }
        BigDecimal bruto = precioUnitario.multiply(BigDecimal.valueOf(cantidad));
        BigDecimal factor = BigDecimal.ONE.subtract(porcentajeDescuento.divide(CIEN, 6, RoundingMode.HALF_UP));
        return bruto.multiply(factor).setScale(2, RoundingMode.HALF_UP);
    }
}
