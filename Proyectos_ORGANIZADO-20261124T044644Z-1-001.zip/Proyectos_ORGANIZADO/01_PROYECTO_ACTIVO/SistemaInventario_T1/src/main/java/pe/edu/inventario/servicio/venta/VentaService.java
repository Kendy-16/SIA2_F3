package pe.edu.inventario.servicio.venta;

import pe.edu.inventario.dao.venta.VentaDAO;
import pe.edu.inventario.modelo.producto.Producto;
import pe.edu.inventario.modelo.venta.*;
import pe.edu.inventario.seguridad.AutorizacionVentas;
import pe.edu.inventario.seguridad.ControlIdempotencia;
import pe.edu.inventario.servicio.cliente.ClienteService;
import pe.edu.inventario.servicio.producto.ProductoService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class VentaService {

    private static final BigDecimal CIEN = new BigDecimal("100");
    private static final BigDecimal IGV = new BigDecimal("0.18"); // IGV 18%

    // Dependencias (se inyectan por constructor)
    private final KardexService kardexService;
    private final CajaService cajaService;
    private final DocumentoService documentoService;
    private final VentaDAO ventaDAO;
    private final ProductoService productoService;

    public VentaService(KardexService kardexService, CajaService cajaService,
                        DocumentoService documentoService, VentaDAO ventaDAO,
                        ProductoService productoService) {
        this.kardexService = kardexService;
        this.cajaService = cajaService;
        this.documentoService = documentoService;
        this.ventaDAO = ventaDAO;
        this.productoService = productoService;
    }

    /**
     * Procesa y calcula los totales antes de confirmar
     */
    public void preProcesarVenta(Venta venta) {
        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal descuento = BigDecimal.ZERO;

        for (DetalleVenta det : venta.getDetalles()) {
            // 3.3 Diferencias: el precio viene dado por el controlador según el tipo de venta.

            // Validación Mayorista (Requisito 3.2: Cantidad mínima)
            if (venta.getTipoVenta() == TipoVenta.MAYORISTA) {
                validarCondicionesMayoristas(det.getCodigoProducto(), det.getCantidad());
            }

            BigDecimal totalLinea = det.getPrecioUnitario().multiply(BigDecimal.valueOf(det.getCantidad()));

            // Aplicar descuentos
            BigDecimal descuentoLinea = totalLinea.multiply(det.getPorcentajeDescuento())
                    .divide(CIEN, 2, RoundingMode.HALF_UP);
            det.setSubtotalLinea(totalLinea.subtract(descuentoLinea).setScale(2, RoundingMode.HALF_UP));

            subtotal = subtotal.add(totalLinea);
            descuento = descuento.add(descuentoLinea);
        }

        venta.setSubtotal(subtotal.setScale(2, RoundingMode.HALF_UP));
        venta.setDescuentoTotal(descuento.setScale(2, RoundingMode.HALF_UP));

        // IGV 18% sobre el subtotal con descuento
        BigDecimal baseImponible = subtotal.subtract(descuento);
        BigDecimal impuestos = baseImponible.multiply(IGV).setScale(2, RoundingMode.HALF_UP);

        venta.setImpuestos(impuestos);
        venta.setTotal(baseImponible.setScale(2, RoundingMode.HALF_UP).add(impuestos));
    }

    /**
     * Confirma la operación de venta (Requisito 3.1 y 3.2).
     * Orden: validaciones -> idempotencia -> Caja -> Kardex -> BD -> comprobante.
     * Si algo falla a mitad de camino se revierten Caja y Kardex y se libera el token.
     *
     * @return número del comprobante emitido
     */
    public String confirmarVenta(Venta venta) throws VentaException {
        if (venta.getEstado() != EstadoVenta.EN_PROCESO) {
            throw new VentaException("La venta " + venta.getIdVenta() + " ya fue procesada (estado "
                    + venta.getEstado() + ").");
        }
        if (venta.getDetalles().isEmpty()) {
            throw new VentaException("Agregue al menos un producto antes de confirmar.");
        }
        if (venta.getTipoVenta() == TipoVenta.MAYORISTA
                && (venta.getIdCliente() == null || ClienteService.CLIENTE_GENERICO.equals(venta.getIdCliente()))) {
            throw new VentaException("Ventas mayoristas requieren un cliente registrado válido.");
        }

        try {
            preProcesarVenta(venta); // recalcula y revalida condiciones mayoristas
        } catch (IllegalArgumentException e) {
            throw new VentaException(e.getMessage(), e);
        }
        validarPago(venta);

        // Protección contra doble clic / reenvío de la misma venta
        if (!ControlIdempotencia.iniciarTransaccion(venta.getTokenTransaccion())) {
            throw new VentaException("La venta " + venta.getIdVenta()
                    + " ya fue procesada o está en proceso. Se evitó un cobro duplicado.");
        }

        Map<String, Integer> salidas = new LinkedHashMap<>(); // lo ya descontado, por si hay que revertir
        boolean cajaRegistrada = false;
        try {
            // 1. Validar disponibilidad (Requisito: Disminuye inventario).
            //    Se agrupa por producto por si el mismo código aparece en varias líneas.
            Map<String, Integer> requerido = new LinkedHashMap<>();
            Map<String, String> nombres = new LinkedHashMap<>();
            for (DetalleVenta det : venta.getDetalles()) {
                requerido.merge(det.getCodigoProducto(), det.getCantidad(), Integer::sum);
                nombres.put(det.getCodigoProducto(), det.getNombreProducto());
            }
            for (Map.Entry<String, Integer> e : requerido.entrySet()) {
                if (!kardexService.verificarStock(e.getKey(), e.getValue())) {
                    throw new VentaException("Stock insuficiente para: " + nombres.get(e.getKey())
                            + " (disponible " + kardexService.stockActual(e.getKey())
                            + ", solicitado " + e.getValue() + ")");
                }
            }

            // 2. Registrar en Caja (Requisito: Pago y medios habilitados)
            cajaService.registrarIngresoVenta(venta.getIdVenta(), venta.getTotal(), venta.getMetodoPago());
            cajaRegistrada = true;

            // 3. Registrar salidas en Kardex (Requisito 3.3: Registra salida)
            for (Map.Entry<String, Integer> e : requerido.entrySet()) {
                kardexService.registrarSalida(e.getKey(), e.getValue(), "VENTA " + venta.getTipoVenta()
                        + " " + venta.getIdVenta());
                salidas.put(e.getKey(), e.getValue());
            }

            // 4. Guardar Venta en BD
            venta.setFechaEmision(LocalDateTime.now());
            venta.setEstado(EstadoVenta.COMPLETADA);
            ventaDAO.guardar(venta);

            // 5. Generar Comprobante (Boleta/Factura)
            return documentoService.generarComprobante(venta);

        } catch (Exception e) {
            // Reversa: devolver stock y dinero, y dejar la venta lista para reintentar.
            for (Map.Entry<String, Integer> s : salidas.entrySet()) {
                kardexService.registrarEntrada(s.getKey(), s.getValue(), "REVERSA " + venta.getIdVenta());
            }
            if (cajaRegistrada) {
                cajaService.registrarReversaVenta(venta.getIdVenta(), venta.getTotal(), venta.getMetodoPago());
            }
            venta.setEstado(EstadoVenta.EN_PROCESO);
            ControlIdempotencia.liberarTransaccion(venta.getTokenTransaccion());

            if (e instanceof VentaException) {
                throw (VentaException) e;
            }
            throw new VentaException("Error al confirmar la venta: " + e.getMessage(), e);
        }
    }

    /**
     * Requisito 9: valida el medio de pago y calcula el vuelto.
     * En efectivo el monto recibido debe cubrir el total; en otros medios se cobra el total exacto.
     */
    private void validarPago(Venta venta) throws VentaException {
        if (!cajaService.medioHabilitado(venta.getMetodoPago())) {
            throw new VentaException("Seleccione un medio de pago habilitado.");
        }
        if (CajaService.EFECTIVO.equals(venta.getMetodoPago())) {
            BigDecimal recibido = venta.getMontoRecibido();
            if (recibido == null || recibido.compareTo(venta.getTotal()) < 0) {
                throw new VentaException("El monto recibido (S/ "
                        + (recibido == null ? "0.00" : recibido.toPlainString())
                        + ") no cubre el total (S/ " + venta.getTotal().toPlainString() + ").");
            }
            venta.setVuelto(recibido.subtract(venta.getTotal()).setScale(2, RoundingMode.HALF_UP));
        } else {
            venta.setMontoRecibido(venta.getTotal());
            venta.setVuelto(BigDecimal.ZERO.setScale(2));
        }
    }

    /** Vuelto para mostrar en pantalla mientras el cajero digita el monto recibido. */
    public BigDecimal calcularVuelto(BigDecimal total, BigDecimal recibido) {
        BigDecimal vuelto = recibido.subtract(total);
        return vuelto.signum() < 0 ? BigDecimal.ZERO.setScale(2) : vuelto.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Requisito 3.2: Cantidad mínima para acceder al precio mayorista.
     * La política sale del catálogo de productos.
     */
    public void validarCondicionesMayoristas(String codigoProducto, int cantidad) {
        Producto producto = productoService.buscarPorCodigo(codigoProducto);
        if (producto == null) {
            throw new IllegalArgumentException("Producto no encontrado: " + codigoProducto);
        }
        int cantidadMinima = producto.getCantidadMinimaMayorista();
        if (cantidad < cantidadMinima) {
            throw new IllegalArgumentException("Para venta MAYORISTA de " + producto.getNombre()
                    + " la cantidad mínima es " + cantidadMinima);
        }
    }

    /**
     * Requisito 4: Validar descuentos manuales según perfil
     */
    public void aplicarDescuentoManual(Venta venta, DetalleVenta detalle, BigDecimal porcentaje) {
        if (!AutorizacionVentas.puedeAplicarDescuentoManual(venta.getRolUsuario())) {
            throw new SecurityException("El perfil USUARIO no tiene permisos para aplicar descuentos manuales.");
        }
        if (porcentaje.signum() < 0 || porcentaje.compareTo(CIEN) > 0) {
            throw new IllegalArgumentException("El descuento debe estar entre 0 y 100%.");
        }
        detalle.setPorcentajeDescuento(porcentaje);
        preProcesarVenta(venta); // Recalcular
    }

    /**
     * Requisito 12: anular una venta completada. Solo el administrador puede hacerlo;
     * devuelve el stock al Kardex, el dinero a Caja y deja constancia del motivo y quién autorizó.
     */
    public void anularVenta(String idVenta, RolUsuario rol, String usuarioAutoriza, String motivo)
            throws VentaException {
        if (!AutorizacionVentas.puedeAnularVenta(rol)) {
            throw new SecurityException("Solo un ADMINISTRADOR puede anular ventas.");
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new VentaException("Debe indicar el motivo de la anulación.");
        }
        Venta venta = ventaDAO.buscarPorId(idVenta);
        if (venta == null) {
            throw new VentaException("No existe la venta " + idVenta);
        }
        if (venta.getEstado() != EstadoVenta.COMPLETADA) {
            throw new VentaException("Solo se pueden anular ventas COMPLETADAS (estado actual: "
                    + venta.getEstado() + ").");
        }

        try {
            ventaDAO.actualizarEstado(idVenta, EstadoVenta.ANULADA.name(), motivo.trim(), usuarioAutoriza);
        } catch (Exception e) {
            throw new VentaException("No se pudo anular la venta: " + e.getMessage(), e);
        }
        for (DetalleVenta det : venta.getDetalles()) {
            kardexService.registrarEntrada(det.getCodigoProducto(), det.getCantidad(), "ANULACION " + idVenta);
        }
        cajaService.registrarReversaVenta(idVenta, venta.getTotal(), venta.getMetodoPago());
    }

    /** Requisito 11: consulta del historial con filtros (fechas DD/MM/YYYY, tipo TODAS/NORMAL/MAYORISTA). */
    public List<Venta> listarHistorial(String fechaInicio, String fechaFin, String tipoVenta) {
        return new ArrayList<>(ventaDAO.listarHistorialPorFiltro(fechaInicio, fechaFin, tipoVenta));
    }

    public Venta buscarVenta(String idVenta) {
        return ventaDAO.buscarPorId(idVenta);
    }

    public String formatearTicket(Venta venta) {
        return documentoService.formatearTicket(venta);
    }
}
