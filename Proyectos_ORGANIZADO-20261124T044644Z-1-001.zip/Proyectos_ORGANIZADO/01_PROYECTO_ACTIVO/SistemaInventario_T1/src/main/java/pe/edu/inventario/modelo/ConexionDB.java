package pe.edu.inventario.modelo;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * Gestiona la conexión y la inicialización de la base de datos SQLite.
 */
public class ConexionDB {

    // ==========================================
    // 1. CONFIGURACIÓN
    // ==========================================

    private static final String URL =
            "jdbc:sqlite:database/inventario.db";

    private ConexionDB() {
        // Evita instanciar esta clase.
    }

    // ==========================================
    // 2. OBTENER CONEXIÓN
    // ==========================================

    public static Connection conectar() throws SQLException {

        Connection conexion = DriverManager.getConnection(URL);

        try (Statement sentencia = conexion.createStatement()) {

            // Activar claves foráneas en cada conexión
            sentencia.execute("PRAGMA foreign_keys = ON");

            // Esperar si la base de datos está ocupada
            sentencia.execute("PRAGMA busy_timeout = 5000");

            return conexion;

        } catch (SQLException e) {

            conexion.close();
            throw e;
        }
    }

    // ==========================================
    // 3. INICIALIZAR BASE DE DATOS
    // ==========================================
    
public static void inicializar() {

    // ==========================================
    // 1. CREAR CARPETA DE BASE DE DATOS
    // ==========================================

    try {

        Files.createDirectories(Path.of("database"));

    } catch (IOException e) {

        throw new IllegalStateException(
                "No se pudo crear la carpeta de la base de datos.",
                e
        );
    }

    // ==========================================
    // 2. CONECTAR E INICIAR TRANSACCION
    // ==========================================

    try (Connection conexion = conectar()) {

        conexion.setAutoCommit(false);

        try (Statement sentencia = conexion.createStatement()) {

            // ==========================================
            // 3.1. TABLA CATEGORIAS
            // ==========================================

            String sqlCategorias = """
                CREATE TABLE IF NOT EXISTS categorias (

                    id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,

                    nombre TEXT NOT NULL UNIQUE
                        CHECK (
                            length(trim(nombre)) BETWEEN 1 AND 120
                        ),

                    descripcion TEXT
                )
                """;

            sentencia.execute(sqlCategorias);

            // ==========================================
            // 3.2. TABLA PROVEEDORES
            // ==========================================

            String sqlProveedores = """
                CREATE TABLE IF NOT EXISTS proveedores (

                    id_proveedor INTEGER PRIMARY KEY AUTOINCREMENT,

                    razon_social TEXT NOT NULL
                        CHECK (
                            length(trim(razon_social)) BETWEEN 2 AND 150
                        ),

                    ruc TEXT UNIQUE,

                    telefono TEXT,

                    correo TEXT,

                    direccion TEXT
                )
                """;

            sentencia.execute(sqlProveedores);

            // ==========================================
            // 3.3. TABLA ALMACENES
            // ==========================================

            String sqlAlmacenes = """
                CREATE TABLE IF NOT EXISTS almacenes (

                    id_almacen INTEGER PRIMARY KEY AUTOINCREMENT,

                    nombre TEXT NOT NULL UNIQUE
                        CHECK (
                            length(trim(nombre)) BETWEEN 2 AND 120
                        ),

                    ubicacion TEXT
                )
                """;

            sentencia.execute(sqlAlmacenes);

            // ==========================================
            // 3.4. TABLA PRODUCTOS
            // ==========================================

            String sqlProductos = """
                CREATE TABLE IF NOT EXISTS productos (

                    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,

                    codigo TEXT NOT NULL
                        CHECK (
                            length(trim(codigo)) BETWEEN 1 AND 30
                            AND codigo = upper(trim(codigo))
                        ),

                    nombre TEXT NOT NULL
                        CHECK (
                            length(trim(nombre)) BETWEEN 2 AND 120
                        ),

                    descripcion TEXT
                        CHECK (
                            descripcion IS NULL
                            OR length(trim(descripcion)) <= 500
                        ),

                    id_categoria INTEGER,

                    id_proveedor INTEGER,

                    unidad_medida TEXT NOT NULL
                        CHECK (
                            unidad_medida IN (
                                'UNIDAD',
                                'KILOGRAMO',
                                'GRAMO',
                                'LITRO',
                                'METRO',
                                'CAJA',
                                'PAQUETE'
                            )
                        ),

                    stock_minimo REAL NOT NULL DEFAULT 0
                        CHECK (
                            typeof(stock_minimo) IN ('integer', 'real')
                            AND stock_minimo >= 0
                            AND stock_minimo <= 1000000000
                            AND abs(
                                stock_minimo * 1000.0
                                - round(stock_minimo * 1000.0)
                            ) < 0.0000001
                            AND (
                                unidad_medida NOT IN (
                                    'UNIDAD',
                                    'CAJA',
                                    'PAQUETE'
                                )
                                OR stock_minimo = CAST(
                                    stock_minimo AS INTEGER
                                )
                            )
                        ),

                    FOREIGN KEY (id_categoria)
                        REFERENCES categorias(id_categoria)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT,

                    FOREIGN KEY (id_proveedor)
                        REFERENCES proveedores(id_proveedor)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT
                )
                """;

            sentencia.execute(sqlProductos);

            // ==========================================
            // 3.5. TABLA INVENTARIO
            // ==========================================

            String sqlInventario = """
                CREATE TABLE IF NOT EXISTS inventario (

                    id_inventario INTEGER PRIMARY KEY AUTOINCREMENT,

                    id_producto INTEGER NOT NULL,

                    id_almacen INTEGER NOT NULL,

                    cantidad REAL NOT NULL DEFAULT 0
                        CHECK (cantidad >= 0),

                    costo_promedio REAL NOT NULL DEFAULT 0
                        CHECK (costo_promedio >= 0),

                    UNIQUE (id_producto, id_almacen),

                    FOREIGN KEY (id_producto)
                        REFERENCES productos(id_producto)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT,

                    FOREIGN KEY (id_almacen)
                        REFERENCES almacenes(id_almacen)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT
                )
                """;

            sentencia.execute(sqlInventario);

            // ==========================================
            // 3.6. TABLA MOVIMIENTOS
            // ==========================================

            String sqlMovimientos = """
                CREATE TABLE IF NOT EXISTS movimientos (

                    id_movimiento INTEGER PRIMARY KEY AUTOINCREMENT,

                    tipo TEXT NOT NULL
                        CHECK (
                            tipo IN (
                                'ENTRADA',
                                'SALIDA',
                                'AJUSTE'
                            )
                        ),

                    fecha TEXT NOT NULL,

                    documento TEXT,

                    observacion TEXT,

                    id_almacen INTEGER NOT NULL,

                    FOREIGN KEY (id_almacen)
                        REFERENCES almacenes(id_almacen)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT
                )
                """;

            sentencia.execute(sqlMovimientos);

            // ==========================================
            // 3.7. TABLA DETALLE MOVIMIENTOS
            // ==========================================

            String sqlDetalles = """
                CREATE TABLE IF NOT EXISTS detalle_movimientos (

                    id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,

                    id_movimiento INTEGER NOT NULL,

                    id_producto INTEGER NOT NULL,

                    cantidad REAL NOT NULL
                        CHECK (cantidad > 0),

                    costo_unitario REAL NOT NULL DEFAULT 0
                        CHECK (costo_unitario >= 0),

                    FOREIGN KEY (id_movimiento)
                        REFERENCES movimientos(id_movimiento)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT,

                    FOREIGN KEY (id_producto)
                        REFERENCES productos(id_producto)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT
                )
                """;

            sentencia.execute(sqlDetalles);

            // ==========================================
            // 3.8. TABLA KARDEX
            // ==========================================

            String sqlKardex = """
                CREATE TABLE IF NOT EXISTS kardex (

                    id_kardex INTEGER PRIMARY KEY AUTOINCREMENT,

                    id_producto INTEGER NOT NULL,

                    id_almacen INTEGER NOT NULL,

                    fecha TEXT NOT NULL,

                    tipo TEXT NOT NULL,

                    documento TEXT,

                    entrada REAL NOT NULL DEFAULT 0
                        CHECK (entrada >= 0),

                    salida REAL NOT NULL DEFAULT 0
                        CHECK (salida >= 0),

                    saldo REAL NOT NULL
                        CHECK (saldo >= 0),

                    costo_unitario REAL NOT NULL
                        CHECK (costo_unitario >= 0),

                    costo_promedio REAL NOT NULL
                        CHECK (costo_promedio >= 0),

                    valor_saldo REAL NOT NULL
                        CHECK (valor_saldo >= 0),

                    FOREIGN KEY (id_producto)
                        REFERENCES productos(id_producto)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT,

                    FOREIGN KEY (id_almacen)
                        REFERENCES almacenes(id_almacen)
                        ON UPDATE RESTRICT
                        ON DELETE RESTRICT
                )
                """;

            sentencia.execute(sqlKardex);

            // ==========================================
            // 3.9. TABLA USUARIOS
            // ==========================================

            String sqlUsuarios = """
                CREATE TABLE IF NOT EXISTS usuarios (

                    id_usuario INTEGER PRIMARY KEY AUTOINCREMENT,

                    usuario TEXT NOT NULL COLLATE NOCASE UNIQUE
                        CHECK (
                            length(trim(usuario)) BETWEEN 3 AND 50
                        ),

                    password_hash TEXT NOT NULL
                        CHECK (length(trim(password_hash)) > 0),

                    password_salt TEXT NOT NULL
                        CHECK (length(trim(password_salt)) > 0),

                    activo INTEGER NOT NULL DEFAULT 1
                        CHECK (activo IN (0, 1)),

                    intentos_fallidos INTEGER NOT NULL DEFAULT 0
                        CHECK (
                            intentos_fallidos BETWEEN 0 AND 5
                        ),

                    bloqueado_hasta INTEGER
                        CHECK (
                            bloqueado_hasta IS NULL
                            OR bloqueado_hasta >= 0
                        ),

                    creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

                    ultimo_acceso TEXT
                )
                """;

            sentencia.execute(sqlUsuarios);

            // ==========================================
            // 3.10. VERIFICAR CODIGOS DUPLICADOS
            // ==========================================

            verificarCodigosDuplicados(conexion);

            // ==========================================
            // 3.11. INDICE UNICO DE CODIGOS
            // ==========================================

            String sqlIndiceCodigo = """
                CREATE UNIQUE INDEX IF NOT EXISTS
                idx_productos_codigo_nocase
                ON productos(codigo COLLATE NOCASE)
                """;

            sentencia.execute(sqlIndiceCodigo);

            // ==========================================
            // 3.12. INDICE DE BUSQUEDA POR NOMBRE
            // ==========================================

            sentencia.execute("""
                CREATE INDEX IF NOT EXISTS
                idx_productos_nombre
                ON productos(nombre COLLATE NOCASE)
                """);

            // ==========================================
            // 3.13. INDICES DE RELACIONES
            // ==========================================

            sentencia.execute("""
                CREATE INDEX IF NOT EXISTS
                idx_inventario_producto
                ON inventario(id_producto)
                """);

            sentencia.execute("""
                CREATE INDEX IF NOT EXISTS
                idx_detalles_producto
                ON detalle_movimientos(id_producto)
                """);

            sentencia.execute("""
                CREATE INDEX IF NOT EXISTS
                idx_kardex_producto_fecha
                ON kardex(id_producto, fecha)
                """);

            sentencia.execute("""
                CREATE INDEX IF NOT EXISTS
                idx_movimientos_almacen_fecha
                ON movimientos(id_almacen, fecha)
                """);

            // ==========================================
            // 3.14. VERIFICAR INTEGRIDAD REFERENCIAL
            // ==========================================

            try (ResultSet rs = sentencia.executeQuery(
                    "PRAGMA foreign_key_check"
            )) {

                if (rs.next()) {

                    throw new SQLException(
                            "Se encontraron errores de integridad "
                            + "en las relaciones de la base de datos."
                    );
                }
            }

            // ==========================================
            // 3.15. CONFIRMAR TRANSACCION
            // ==========================================

            conexion.commit();

            System.out.println(
                    "Base de datos SQLite inicializada correctamente."
            );

            System.out.println(
                    "Tablas e indices creados o verificados."
            );

            System.out.println(
                    "Restricciones de integridad verificadas."
            );

            System.out.println(
                    "Tabla de usuarios disponible."
            );

        } catch (SQLException e) {

            conexion.rollback();

            throw e;
        }

    } catch (SQLException e) {

        System.err.println(
                "Error al inicializar la base de datos: "
                + e.getMessage()
        );

        throw new IllegalStateException(
                "No se pudo inicializar la base de datos SQLite.",
                e
        );
    }
}

    // ==========================================
    // 4. VERIFICAR CÓDIGOS DUPLICADOS
    // ==========================================

    private static void verificarCodigosDuplicados(
            Connection conexion
    ) throws SQLException {

        String sql = """
            SELECT codigo, COUNT(*) AS cantidad
            FROM productos
            GROUP BY codigo COLLATE NOCASE
            HAVING COUNT(*) > 1
            """;

        StringBuilder duplicados = new StringBuilder();

        try (Statement sentencia = conexion.createStatement();
             ResultSet rs = sentencia.executeQuery(sql)) {

            while (rs.next()) {

                duplicados.append("\nCódigo: ")
                        .append(rs.getString("codigo"))
                        .append(" | Cantidad: ")
                        .append(rs.getInt("cantidad"));
            }
        }

        if (duplicados.length() > 0) {

            throw new SQLException(
                    "Existen códigos de productos duplicados "
                    + "al ignorar mayúsculas y minúsculas."
                    + duplicados
                    + "\nCorrija los códigos antes de crear "
                    + "el índice único."
            );
        }
    }
}
