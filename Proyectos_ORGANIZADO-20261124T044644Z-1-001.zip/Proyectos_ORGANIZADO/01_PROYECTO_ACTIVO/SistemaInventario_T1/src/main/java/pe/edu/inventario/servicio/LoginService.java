
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Usuario;
import pe.edu.inventario.modelo.dao.UsuarioDAO;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;

import java.sql.SQLException;

import java.util.Arrays;
import java.util.Base64;
import java.util.Locale;

/**
 * Implements authentication and password security.
 */
public class LoginService {

    // ==========================================
    // 1. SECURITY CONFIGURATION
    // ==========================================

    private static final int MIN_USUARIO = 3;
    private static final int MAX_USUARIO = 50;

    private static final int MIN_PASSWORD = 12;
    private static final int MAX_PASSWORD = 128;

    private static final int MAX_INTENTOS = 5;

    private static final long TIEMPO_BLOQUEO =
            15L * 60L * 1000L;

    private static final int ITERACIONES = 600000;
    private static final int BITS_HASH = 256;
    private static final int BYTES_SALT = 16;

    // ==========================================
    // 2. ATTRIBUTES
    // ==========================================

    private final UsuarioDAO usuarioDAO;

    private final SecureRandom generadorAleatorio;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public LoginService() {

        usuarioDAO = new UsuarioDAO();

        generadorAleatorio = new SecureRandom();
    }

    // ==========================================
    // 4. VERIFY CREDENTIALS
    // ==========================================

    public boolean verificarCredenciales(
            String usuario,
            String password
    ) throws SQLException {

        String nombreUsuario = validarNombreUsuario(usuario);

        if (password == null || password.isEmpty()
                || password.length() > MAX_PASSWORD) {

            return false;
        }

        Usuario cuenta =
                usuarioDAO.buscarPorUsuario(nombreUsuario);

        // Generic response: do not reveal whether
        // the account exists.
        if (cuenta == null || !cuenta.isActivo()) {
            return false;
        }

        long ahora = System.currentTimeMillis();

        int intentosAnteriores = cuenta.getIntentosFallidos();

        Long bloqueo = cuenta.getBloqueadoHasta();

        // Check temporary lock
        if (bloqueo != null) {

            if (bloqueo > ahora) {
                return false;
            }

            // Reset attempts after lock expires
            usuarioDAO.actualizarIntentos(
                    cuenta.getIdUsuario(),
                    0,
                    null
            );

            intentosAnteriores = 0;
        }

        char[] caracteres = password.toCharArray();

        boolean valido;

        try {

            valido = verificarPassword(
                    caracteres,
                    cuenta.getPasswordSalt(),
                    cuenta.getPasswordHash()
            );

        } finally {

            Arrays.fill(caracteres, '\0');
        }

        if (valido) {

            usuarioDAO.registrarAccesoExitoso(
                    cuenta.getIdUsuario()
            );

            return true;
        }

        // Increase failed attempts
        int nuevosIntentos = Math.min(
                intentosAnteriores + 1,
                MAX_INTENTOS
        );

        Long nuevoBloqueo = null;

        if (nuevosIntentos >= MAX_INTENTOS) {

            nuevoBloqueo = ahora + TIEMPO_BLOQUEO;
        }

        usuarioDAO.actualizarIntentos(
                cuenta.getIdUsuario(),
                nuevosIntentos,
                nuevoBloqueo
        );

        return false;
    }

    // ==========================================
    // 4B. GET ROLE OF AN AUTHENTICATED USER
    // ==========================================

    public String obtenerRol(String usuario) throws SQLException {

        Usuario cuenta = usuarioDAO.buscarPorUsuario(
                validarNombreUsuario(usuario)
        );

        if (cuenta == null || cuenta.getRol() == null) {
            return "USUARIO";
        }

        return cuenta.getRol();
    }

    // ==========================================
    // 5. REGISTER FIRST ADMINISTRATOR
    // ==========================================

    /**
     * Creates the first administrator only when the
     * users table is empty.
     *
     * This method is intended for an initial setup form.
     */
    public void registrarPrimerAdministrador(
            String usuario,
            char[] password
    ) throws SQLException {

        String nombreUsuario = validarNombreUsuario(usuario);

        if (usuarioDAO.existeUsuarios()) {
            throw new IllegalStateException(
                    "Ya existe un usuario. "
                    + "No se permite registrar otro administrador inicial."
            );
        }

        if (password == null) {
            throw new IllegalArgumentException(
                    "La contrasena es obligatoria."
            );
        }

        char[] copia = password.clone();

        try {

            validarPasswordNueva(copia);

            // Generate a unique random salt
            byte[] salt = new byte[BYTES_SALT];

            generadorAleatorio.nextBytes(salt);

            String saltTexto = Base64.getEncoder()
                    .encodeToString(salt);

            String hash = generarHash(copia, salt);

            Arrays.fill(salt, (byte) 0);

            Usuario nuevoUsuario = new Usuario(
                    0,
                    nombreUsuario,
                    hash,
                    saltTexto,
                    true,
                    0,
                    null
            );

            nuevoUsuario.setRol("ADMINISTRADOR");

            if (!usuarioDAO.insertar(nuevoUsuario)) {

                throw new SQLException(
                        "No se pudo registrar el administrador."
                );
            }

        } finally {

            Arrays.fill(copia, '\0');
            Arrays.fill(password, '\0');
        }
    }

    // ==========================================
    // 6. CHECK INITIAL CONFIGURATION
    // ==========================================

    public boolean hayUsuariosRegistrados()
            throws SQLException {

        return usuarioDAO.existeUsuarios();
    }

    // ==========================================
    // 7. VALIDATE USERNAME
    // ==========================================

    private String validarNombreUsuario(String usuario) {

        if (usuario == null || usuario.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre de usuario es obligatorio."
            );
        }

        usuario = usuario.trim();

        int longitud = usuario.codePointCount(
                0,
                usuario.length()
        );

        if (longitud < MIN_USUARIO || longitud > MAX_USUARIO) {
            throw new IllegalArgumentException(
                    "El usuario debe tener entre 3 y 50 caracteres."
            );
        }

        if (!usuario.matches("[\\p{L}\\p{N}._@-]+")) {
            throw new IllegalArgumentException(
                    "El nombre de usuario tiene un formato no valido."
            );
        }

        return usuario;
    }

    // ==========================================
    // 8. VALIDATE NEW PASSWORD
    // ==========================================

    private void validarPasswordNueva(char[] password) {

        if (password.length < MIN_PASSWORD
                || password.length > MAX_PASSWORD) {

            throw new IllegalArgumentException(
                    "La contrasena debe tener entre 12 y 128 caracteres."
            );
        }

        for (char caracter : password) {

            if (Character.isISOControl(caracter)) {
                throw new IllegalArgumentException(
                        "La contrasena contiene caracteres no permitidos."
                );
            }
        }
    }

    // ==========================================
    // 9. GENERATE PASSWORD HASH
    // ==========================================

    private String generarHash(
            char[] password,
            byte[] salt
    ) {

        PBEKeySpec spec = new PBEKeySpec(
                password,
                salt,
                ITERACIONES,
                BITS_HASH
        );

        try {

            SecretKeyFactory fabrica =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            byte[] hash = fabrica.generateSecret(spec)
                    .getEncoded();

            try {
                return Base64.getEncoder().encodeToString(hash);
            } finally {
                Arrays.fill(hash, (byte) 0);
            }

        } catch (GeneralSecurityException e) {

            throw new IllegalStateException(
                    "No se pudo generar el hash de la contrasena.",
                    e
            );

        } finally {

            spec.clearPassword();
        }
    }

    // ==========================================
    // 10. VERIFY PASSWORD HASH
    // ==========================================

    private boolean verificarPassword(
            char[] password,
            String saltTexto,
            String hashGuardado
    ) {

        if (saltTexto == null || hashGuardado == null) {
            throw new IllegalStateException(
                    "Los datos de seguridad del usuario estan incompletos."
            );
        }

        byte[] salt;
        byte[] hashEsperado;

        try {

            salt = Base64.getDecoder().decode(saltTexto);

            hashEsperado = Base64.getDecoder()
                    .decode(hashGuardado);

        } catch (IllegalArgumentException e) {

            throw new IllegalStateException(
                    "Los datos de autenticacion almacenados no son validos.",
                    e
            );
        }

        byte[] hashCalculado = null;

        try {

            hashCalculado = Base64.getDecoder().decode(
                    generarHash(password, salt)
            );

            return MessageDigest.isEqual(
                    hashEsperado,
                    hashCalculado
            );

        } finally {

            Arrays.fill(salt, (byte) 0);
            Arrays.fill(hashEsperado, (byte) 0);

            if (hashCalculado != null) {
                Arrays.fill(hashCalculado, (byte) 0);
            }
        }
    }
}
