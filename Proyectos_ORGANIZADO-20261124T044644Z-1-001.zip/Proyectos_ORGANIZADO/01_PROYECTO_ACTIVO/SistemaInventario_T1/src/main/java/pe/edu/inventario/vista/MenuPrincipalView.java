package pe.edu.inventario.vista;

import pe.edu.inventario.vista.producto.ProductoView;
import pe.edu.inventario.vista.producto.ProveedorView;
import pe.edu.inventario.vista.almacen.AlmacenView;
import pe.edu.inventario.vista.movimientos.MovimientoView;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MenuPrincipalView extends JFrame {

    // ==========================================
    // 1. COLORES DEL DISEÑO OSCURO
    // ==========================================

    private static final Color FONDO = new Color(17, 19, 25);
    private static final Color SIDEBAR = new Color(22, 25, 35);
    private static final Color PANEL = new Color(30, 34, 46);
    private static final Color BORDE = new Color(54, 60, 75);
    private static final Color TEXTO = new Color(239, 242, 248);
    private static final Color TEXTO_SECUNDARIO = new Color(148, 158, 176);
    private static final Color MORADO = new Color(126, 132, 255);
    private static final Color VERDE = new Color(43, 194, 112);

    // Color uniforme para las tarjetas del panel principal (#5479C9).
    private static final Color AZUL_TARJETA = new Color(84, 121, 201);
    private static final Color AZUL_TARJETA_HOVER = new Color(98, 137, 219);
    private static final Color BORDE_TARJETA = new Color(121, 153, 221);
    private static final Color TEXTO_TARJETA = new Color(228, 235, 251);

    private static final Color ITEM_SELECCIONADO = new Color(43, 47, 69);
    private static final Color ITEM_HOVER = new Color(34, 38, 54);
    private static final Color INSIGNIA_FONDO = new Color(52, 58, 91);
    private static final Color INSIGNIA_BORDE = new Color(78, 84, 140);
    private static final Color SCROLL_THUMB = new Color(74, 81, 102);

    // Medidas de las tarjetas (evitan que el texto se corte).
    private static final int ALTO_TARJETA = 88;
    private static final int ANCHO_MINIMO_TARJETA = 270;
    private static final int ANCHO_SIDEBAR = 280;

    // ==========================================
    // 2. COMPONENTES PRINCIPALES
    // ==========================================

    private final CardLayout administradorTarjetas = new CardLayout();
    private final JPanel panelContenido = new JPanel(administradorTarjetas);
    private final Map<String, ItemMenu> botonesMenu = new HashMap<>();
    private final String rolActual;

    private JLabel lblTitulo;
    private JLabel lblSubtitulo;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public MenuPrincipalView() {
    this("USUARIO");
    }

public MenuPrincipalView(String rol) {
    this.rolActual = normalizarRol(rol);

    configurarVentana();
    inicializarComponentes();
}

private String normalizarRol(String rol) {

    if (rol == null || rol.trim().isEmpty()) {
        return "USUARIO";
    }

    String rolNormalizado = rol.trim().toUpperCase();

    switch (rolNormalizado) {
        case "ADMIN":
        case "ADMINISTRADOR":
            return "ADMINISTRADOR";

        case "USER":
        case "USUARIO":
            return "USUARIO";

        default:
            return "USUARIO";
    }
}

private boolean esAdministrador() {
    return "ADMINISTRADOR".equals(rolActual);
}



    // ==========================================
    // 4. CONFIGURAR VENTANA
    // ==========================================

    private void configurarVentana() {
        setTitle("Sistema de Inventario");
        setSize(1250, 720);
        setMinimumSize(new Dimension(1000, 620));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(FONDO);
    }

    // ==========================================
    // 5. INICIALIZAR COMPONENTES
    // ==========================================

    private void inicializarComponentes() {

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(FONDO);

        principal.add(crearBarraLateral(), BorderLayout.WEST);

        JPanel areaTrabajo = new JPanel(new BorderLayout());
        areaTrabajo.setBackground(FONDO);
        areaTrabajo.add(crearEncabezado(), BorderLayout.NORTH);

        panelContenido.setBackground(FONDO);
        agregarPantallas();
        areaTrabajo.add(panelContenido, BorderLayout.CENTER);

        principal.add(areaTrabajo, BorderLayout.CENTER);

        setContentPane(principal);

        mostrarPagina(
                "inicio",
                "Inicio",
                "Administración y control de inventario"
        );
    }

    // ==========================================
    // 6. BARRA LATERAL
    // ==========================================

    private JPanel crearBarraLateral() {

        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(ANCHO_SIDEBAR, 0));
        sidebar.setBackground(SIDEBAR);
        sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, BORDE));

        sidebar.add(crearIdentidadSistema(), BorderLayout.NORTH);

        PanelDesplazable opciones = new PanelDesplazable();
        opciones.setLayout(new BoxLayout(opciones, BoxLayout.Y_AXIS));
        opciones.setBackground(SIDEBAR);
        opciones.setBorder(new EmptyBorder(14, 12, 18, 12));

        agregarSeccion(opciones, "GENERAL");
        agregarBotonMenu(opciones, "inicio", "IN", "Inicio",
                "Administración y control de inventario");

        agregarEspacio(opciones, 14);

        agregarSeccion(opciones, "GESTIÓN");
        agregarBotonMenu(opciones, "productos", "PR", "Productos",
                "Gestión del catálogo de productos");
        agregarBotonMenu(opciones, "proveedores", "PV", "Proveedores",
                "Gestión de proveedores");
        agregarBotonMenu(opciones, "almacenes", "AL", "Almacenes",
                "Control de almacenes");

        agregarEspacio(opciones, 14);

        agregarSeccion(opciones, "INVENTARIO");
        agregarBotonMenu(opciones, "movimientos", "MV", "Movimientos",
                "Registro de entradas y salidas");
        agregarBotonMenu(opciones, "fisico", "IF", "Inventario físico",
                "Control y conciliación física");
        agregarBotonMenu(opciones, "costo", "CP", "Costo promedio",
                "Valorización al costo promedio");
        agregarBotonMenu(opciones, "kardex", "KD", "Kardex",
                "Historial de movimientos");

        agregarEspacio(opciones, 14);

        agregarSeccion(opciones, "INFORMACIÓN");
        agregarBotonMenu(opciones, "reportes", "RP", "Reportes",
                "Información del inventario");

        sidebar.add(crearDesplazamiento(opciones, SIDEBAR), BorderLayout.CENTER);

        JLabel pie = crearEtiqueta("Sistema empresarial", Font.PLAIN, 11, TEXTO_SECUNDARIO);
        pie.setBorder(new EmptyBorder(14, 24, 18, 10));
        sidebar.add(pie, BorderLayout.SOUTH);

        return sidebar;
    }

    // ==========================================
    // 7. IDENTIDAD DEL SISTEMA
    // ==========================================

    private JPanel crearIdentidadSistema() {

        JPanel identidad = new JPanel(new BorderLayout(14, 0));
        identidad.setBackground(SIDEBAR);
        identidad.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, BORDE),
                        new EmptyBorder(24, 22, 24, 18)
                )
        );

        // Logotipo: se escala conservando proporciones y queda centrado,
        // siempre dentro del recuadro (nunca se corta).
        Insignia logo = new Insignia("", INSIGNIA_FONDO, INSIGNIA_BORDE, 16, 62);

        Icon icono = cargarLogo(48);

        if (icono != null) {
            logo.setIcon(icono);
        } else {
            logo.setText("SI");
            logo.setForeground(MORADO);
            logo.setFont(new Font("Arial", Font.BOLD, 22));
        }

        // El logo se envuelve para que no se estire con el alto del panel.
        JPanel envoltura = new JPanel(new GridBagLayout());
        envoltura.setOpaque(false);
        envoltura.add(logo);

        JPanel textos = new JPanel();
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        textos.setOpaque(false);

        JLabel nombre = crearEtiqueta("INVENTARIO", Font.BOLD, 19, TEXTO);
        JLabel descripcion = crearEtiqueta("Sistema empresarial", Font.PLAIN, 12, TEXTO_SECUNDARIO);

        textos.add(Box.createVerticalGlue());
        textos.add(nombre);
        textos.add(Box.createVerticalStrut(5));
        textos.add(descripcion);
        textos.add(Box.createVerticalGlue());

        identidad.add(envoltura, BorderLayout.WEST);
        identidad.add(textos, BorderLayout.CENTER);

        return identidad;
    }

    /**
     * Carga /imagenes/cajero.png y la reduce a un cuadro de "maximo" píxeles
     * manteniendo la proporción, con reducción progresiva para que se vea nítida.
     */
    private Icon cargarLogo(int maximo) {

        URL recurso = getClass().getResource("/imagenes/cajero.png");

        if (recurso == null) {
            return null;
        }

        try {
            BufferedImage original = ImageIO.read(recurso);

            if (original == null
                    || original.getWidth() <= 0
                    || original.getHeight() <= 0) {
                return null;
            }

            double escala = Math.min(
                    (double) maximo / original.getWidth(),
                    (double) maximo / original.getHeight()
            );

            int ancho = Math.max(1, (int) Math.round(original.getWidth() * escala));
            int alto = Math.max(1, (int) Math.round(original.getHeight() * escala));

            BufferedImage actual = original;
            int w = original.getWidth();
            int h = original.getHeight();

            while (w / 2 >= ancho && h / 2 >= alto) {
                w /= 2;
                h /= 2;
                actual = redimensionar(actual, w, h);
            }

            return new ImageIcon(redimensionar(actual, ancho, alto));

        } catch (IOException e) {
            return null;
        }
    }

    private static BufferedImage redimensionar(BufferedImage origen, int ancho, int alto) {

        BufferedImage destino =
                new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2 = destino.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2.drawImage(origen, 0, 0, ancho, alto, null);
        g2.dispose();

        return destino;
    }

    // ==========================================
    // 8. SECCIONES DEL MENÚ
    // ==========================================

    private void agregarSeccion(JPanel panel, String nombre) {

        JLabel etiqueta = crearEtiqueta(nombre, Font.BOLD, 11, TEXTO_SECUNDARIO);
        etiqueta.setBorder(new EmptyBorder(6, 14, 8, 5));
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(etiqueta);
    }

    private void agregarEspacio(JPanel panel, int altura) {
        panel.add(Box.createVerticalStrut(altura));
    }

    // ==========================================
    // 9. BOTONES DEL MENÚ LATERAL
    // ==========================================

    private void agregarBotonMenu(
            JPanel panel,
            String clave,
            String codigo,
            String nombre,
            String subtitulo
    ) {

        ItemMenu item = new ItemMenu(codigo, nombre);

        item.activarInteraccion(() -> mostrarPagina(clave, nombre, subtitulo));

        botonesMenu.put(clave, item);

        panel.add(item);
        panel.add(Box.createVerticalStrut(3));
    }

    // ==========================================
    // 10. ENCABEZADO SUPERIOR
    // ==========================================

    private JPanel crearEncabezado() {

        JPanel encabezado = new JPanel(new BorderLayout(20, 0));
        encabezado.setBackground(PANEL);
        encabezado.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, BORDE),
                        new EmptyBorder(18, 30, 16, 24)
                )
        );

        JPanel textos = new JPanel();
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        textos.setOpaque(false);

        lblTitulo = crearEtiqueta("Inicio", Font.BOLD, 26, TEXTO);
        lblSubtitulo = crearEtiqueta(
                "Administración y control de inventario",
                Font.PLAIN, 14, TEXTO_SECUNDARIO
        );

        textos.add(lblTitulo);
        textos.add(Box.createVerticalStrut(4));
        textos.add(lblSubtitulo);

        // Zona de usuario: BoxLayout horizontal centra todo verticalmente.
        JPanel usuario = new JPanel();
        usuario.setLayout(new BoxLayout(usuario, BoxLayout.X_AXIS));
        usuario.setOpaque(false);

        JLabel estado = crearEtiqueta("●  Sistema activo", Font.PLAIN, 13, VERDE);
        String nombreRol = esAdministrador() ? "Administrador" : "Usuario";

        JLabel administrador = crearEtiqueta(
           nombreRol,
           Font.BOLD,
           13,
           TEXTO
        );


        String inicialesRol = esAdministrador() ? "AD" : "US";

        Insignia iniciales = new Insignia(
                inicialesRol,
                INSIGNIA_FONDO,
                INSIGNIA_BORDE,
                42,
                42
        );


        iniciales.setForeground(MORADO);
        iniciales.setFont(new Font("Arial", Font.BOLD, 14));

        usuario.add(estado);
        usuario.add(Box.createHorizontalStrut(20));
        usuario.add(administrador);
        usuario.add(Box.createHorizontalStrut(12));
        usuario.add(iniciales);

        encabezado.add(textos, BorderLayout.CENTER);
        encabezado.add(usuario, BorderLayout.EAST);

        return encabezado;
    }

    // ==========================================
    // 11. AGREGAR LAS PANTALLAS
    // ==========================================

    /** Si una pantalla falla al crearse, se muestra el panel provisional y el menú sigue abriendo. */
    private JComponent crearSeguro(
            java.util.function.Supplier<? extends JComponent> fabrica,
            String titulo
    ) {
        try {
            return fabrica.get();
        } catch (RuntimeException | Error ex) {
            ex.printStackTrace();
            return crearPanelModulo(titulo);
        }
    }

     private void agregarPantallas() {

    panelContenido.add(crearPanelInicio(), "inicio");

    // Pantallas funcionales existentes.
    panelContenido.add(new ProductoView(), "productos");
    panelContenido.add(new ProveedorView(), "proveedores");
    panelContenido.add(new AlmacenView(), "almacenes");

    // Módulo de movimientos integrado.
    panelContenido.add(
            new MovimientoView(rolActual),
            "movimientos"
    );

    // Módulos pendientes de integración.
    panelContenido.add(
            crearSeguro(() -> new pe.edu.inventario.vista.inventario.InventarioFisicoView(),
                    "CONTROL DE INVENTARIO FÍSICO"),
            "fisico"
    );

    panelContenido.add(
            crearSeguro(() -> new pe.edu.inventario.vista.inventario.InventarioValorizadoView(),
                    "VALORIZACIÓN AL COSTO PROMEDIO"),
            "costo"
    );

    panelContenido.add(
            crearSeguro(() -> new pe.edu.inventario.vista.inventario.KardexView(),
                    "KARDEX VALORIZADO"),
            "kardex"
    );

    panelContenido.add(
            crearSeguro(() -> new pe.edu.inventario.vista.reportes.ReportesView(),
                    "REPORTES DEL INVENTARIO"),
            "reportes"
    );
} 
     
     


    // ==========================================
    // 12. PANTALLA DE INICIO
    // ==========================================

    private JComponent crearPanelInicio() {

        // El contenido siempre toma el ancho visible: nada se corta por los lados.
        PanelDesplazable contenido = new PanelDesplazable();
        contenido.setLayout(new GridBagLayout());
        contenido.setBackground(FONDO);
        contenido.setBorder(new EmptyBorder(30, 32, 32, 32));

        // --------------------------------------
        // BIENVENIDA
        // --------------------------------------

        JPanel bienvenida = new JPanel();
        bienvenida.setLayout(new BoxLayout(bienvenida, BoxLayout.Y_AXIS));
        bienvenida.setOpaque(false);

        JLabel titulo = crearEtiqueta("Bienvenido al sistema", Font.BOLD, 28, TEXTO);
        JLabel descripcion = crearEtiqueta(
                "Resumen general de la gestión de inventario.",
                Font.PLAIN, 15, TEXTO_SECUNDARIO
        );

        bienvenida.add(titulo);
        bienvenida.add(Box.createVerticalStrut(8));
        bienvenida.add(descripcion);

        agregarFila(contenido, bienvenida, 0, 0);

        // --------------------------------------
        // ACCESOS RÁPIDOS
        // --------------------------------------

        agregarFila(contenido,
                crearEtiqueta("Accesos rápidos", Font.BOLD, 18, TEXTO), 1, 28);

        GrillaResponsiva principales = new GrillaResponsiva(2, ANCHO_MINIMO_TARJETA, 16, ALTO_TARJETA);

        principales.add(crearTarjeta("Productos", "Gestión del catálogo", "PR", "productos"));
        principales.add(crearTarjeta("Proveedores", "Gestión de proveedores", "PV", "proveedores"));
        principales.add(crearTarjeta("Almacenes", "Control de almacenes", "AL", "almacenes"));
        principales.add(crearTarjeta("Movimientos", "Entradas y salidas", "MV", "movimientos"));

        agregarFila(contenido, principales, 2, 12);

        // --------------------------------------
        // DESCRIPCIÓN DEL SISTEMA
        // --------------------------------------

        PanelRedondeado informacion = new PanelRedondeado(PANEL, BORDE, 18);
        informacion.setLayout(new BorderLayout(0, 10));
        informacion.setBorder(new EmptyBorder(22, 24, 22, 24));

        JLabel tituloSistema = crearEtiqueta(
                "Sistema de inventario físico y valorizado",
                Font.BOLD, 19, TEXTO
        );

        JLabel activo = crearEtiqueta("●  ACTIVO", Font.BOLD, 13, VERDE);

        JPanel parteSuperior = new JPanel(new BorderLayout(12, 0));
        parteSuperior.setOpaque(false);
        parteSuperior.add(tituloSistema, BorderLayout.CENTER);
        parteSuperior.add(activo, BorderLayout.EAST);

        // Área de texto que se ajusta sola al ancho disponible.
        JTextArea textoSistema = crearTextoAjustable(
                "Control de existencias, movimientos de almacén y valorización "
                        + "mediante el método de costo promedio ponderado.",
                15, TEXTO_SECUNDARIO
        );

        informacion.add(parteSuperior, BorderLayout.NORTH);
        informacion.add(textoSistema, BorderLayout.CENTER);

        agregarFila(contenido, informacion, 3, 26);

        // --------------------------------------
        // MÓDULOS DISPONIBLES
        // --------------------------------------

        agregarFila(contenido,
                crearEtiqueta("Módulos disponibles", Font.BOLD, 18, TEXTO), 4, 28);

        GrillaResponsiva modulos = new GrillaResponsiva(3, ANCHO_MINIMO_TARJETA, 16, ALTO_TARJETA);

        modulos.add(crearTarjeta("Productos", "Administración de productos", "PR", "productos"));
        modulos.add(crearTarjeta("Proveedores", "Administración de proveedores", "PV", "proveedores"));
        modulos.add(crearTarjeta("Almacenes", "Gestión de almacenes", "AL", "almacenes"));
        modulos.add(crearTarjeta("Inventario físico", "Conteo y conciliación", "IF", "fisico"));
        modulos.add(crearTarjeta("Kardex", "Historial de movimientos", "KD", "kardex"));
        modulos.add(crearTarjeta("Reportes", "Información del inventario", "RP", "reportes"));

        agregarFila(contenido, modulos, 5, 12);

        // Relleno inferior: empuja todo hacia arriba.
        GridBagConstraints relleno = new GridBagConstraints();
        relleno.gridx = 0;
        relleno.gridy = 6;
        relleno.weighty = 1;
        relleno.fill = GridBagConstraints.BOTH;
        JPanel espacio = new JPanel();
        espacio.setOpaque(false);
        contenido.add(espacio, relleno);

        return crearDesplazamiento(contenido, FONDO);
    }

    private static void agregarFila(JPanel panel, Component componente, int fila, int margenSuperior) {

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.insets = new Insets(margenSuperior, 0, 0, 0);

        panel.add(componente, gbc);
    }

    // ==========================================
    // 13. TARJETAS DE LOS MÓDULOS
    // ==========================================

    private TarjetaModulo crearTarjeta(
            String titulo,
            String descripcion,
            String codigo,
            String pagina
    ) {

        TarjetaModulo tarjeta = new TarjetaModulo(titulo, descripcion, codigo);

        tarjeta.activarInteraccion(() ->
                mostrarPagina(
                        pagina,
                        obtenerTitulo(pagina),
                        obtenerSubtitulo(pagina)
                )
        );

        return tarjeta;
    }

    // ==========================================
    // 14. PANELES PROVISIONALES
    // ==========================================

    private JPanel crearPanelModulo(String nombre) {

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(FONDO);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        PanelRedondeado tarjeta = new PanelRedondeado(PANEL, BORDE, 20);
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(new EmptyBorder(34, 50, 34, 50));

        JLabel titulo = crearEtiqueta(nombre, Font.BOLD, 23, TEXTO);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel mensaje = crearEtiqueta(
                "Módulo pendiente de integración.",
                Font.PLAIN, 15, TEXTO_SECUNDARIO
        );
        mensaje.setAlignmentX(Component.CENTER_ALIGNMENT);

        tarjeta.add(titulo);
        tarjeta.add(Box.createVerticalStrut(10));
        tarjeta.add(mensaje);

        panel.add(tarjeta);

        return panel;
    }

    // ==========================================
    // 15. NAVEGACIÓN ENTRE PANTALLAS
    // ==========================================

    private void mostrarPagina(String clave, String titulo, String subtitulo) {

        administradorTarjetas.show(panelContenido, clave);

        lblTitulo.setText(titulo);
        lblSubtitulo.setText(subtitulo);

        for (Map.Entry<String, ItemMenu> entrada : botonesMenu.entrySet()) {
            entrada.getValue().setSeleccionado(entrada.getKey().equals(clave));
        }
    }

    // ==========================================
    // 16. TÍTULOS DE LOS MÓDULOS
    // ==========================================

    private String obtenerTitulo(String pagina) {

        switch (pagina) {
            case "inicio":
                return "Inicio";
            case "productos":
                return "Productos";
            case "proveedores":
                return "Proveedores";
            case "almacenes":
                return "Almacenes";
            case "movimientos":
                return "Movimientos";
            case "fisico":
                return "Inventario físico";
            case "costo":
                return "Costo promedio";
            case "kardex":
                return "Kardex";
            case "reportes":
                return "Reportes";
            default:
                return "Sistema de Inventario";
        }
    }

    private String obtenerSubtitulo(String pagina) {

        switch (pagina) {
            case "inicio":
                return "Administración y control de inventario";
            case "productos":
                return "Gestión del catálogo de productos";
            case "proveedores":
                return "Gestión de proveedores";
            case "almacenes":
                return "Control de almacenes";
            case "movimientos":
                return "Registro de entradas y salidas";
            case "fisico":
                return "Control y conciliación física";
            case "costo":
                return "Valorización al costo promedio";
            case "kardex":
                return "Historial de movimientos";
            case "reportes":
                return "Información del inventario";
            default:
                return "";
        }
    }

    // ==========================================
    // 17. UTILIDADES DE COMPONENTES
    // ==========================================

    private static JLabel crearEtiqueta(String texto, int estilo, int tamano, Color color) {

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(color);
        etiqueta.setFont(new Font("Arial", estilo, tamano));
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);

        return etiqueta;
    }

    /** Texto de varias líneas que se ajusta al ancho disponible (sin cortarse). */
    private static JTextArea crearTextoAjustable(String texto, int tamano, Color color) {

        // Estos textos son solo de lectura: nunca deben mover el scroll.
        JTextArea area = new JTextArea() {
            @Override
            public void scrollRectToVisible(Rectangle zona) {
                // Se ignora a propósito.
            }
        };
        area.setText(texto);
        area.setEditable(false);
        area.setFocusable(false);
        area.setOpaque(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(null);
        area.setHighlighter(null);

        // Evita que el cursor de texto desplace el scroll hacia este componente.
        if (area.getCaret() instanceof DefaultCaret) {
            ((DefaultCaret) area.getCaret()).setUpdatePolicy(DefaultCaret.NEVER_UPDATE);
        }

        area.setFont(new Font("Arial", Font.PLAIN, tamano));
        area.setForeground(color);

        return area;
    }

    private static JScrollPane crearDesplazamiento(Component vista, Color fondo) {

        JScrollPane desplazamiento = new JScrollPane(
                vista,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );

        desplazamiento.setBorder(null);
        desplazamiento.setBackground(fondo);
        desplazamiento.getViewport().setBackground(fondo);

        JScrollBar barra = desplazamiento.getVerticalScrollBar();
        barra.setBackground(fondo);
        barra.setUI(new ScrollBarOscuro());
        barra.setPreferredSize(new Dimension(10, 0));

        return desplazamiento;
    }

    // ==========================================
    // 18. COMPONENTES PERSONALIZADOS
    // ==========================================

    /** Panel que siempre ocupa el ancho visible del JScrollPane. */
    private static class PanelDesplazable extends JPanel implements Scrollable {

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visible, int orientacion, int direccion) {
            return 24;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visible, int orientacion, int direccion) {
            return orientacion == SwingConstants.VERTICAL
                    ? Math.max(40, visible.height - 40)
                    : visible.width;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    /** Panel con fondo y borde redondeados. */
    private static class PanelRedondeado extends JPanel {

        private final Color fondo;
        private final Color borde;
        private final int arco;

        PanelRedondeado(Color fondo, Color borde, int arco) {
            this.fondo = fondo;
            this.borde = borde;
            this.arco = arco;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fondo);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);
            g2.setColor(borde);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Etiqueta cuadrada o circular (códigos, iniciales, logo). */
    private static class Insignia extends JLabel {

        private Color fondo;
        private final Color borde;
        private final int arco;

        Insignia(String texto, Color fondo, Color borde, int arco, int lado) {
            super(texto, SwingConstants.CENTER);
            this.fondo = fondo;
            this.borde = borde;
            this.arco = arco;

            Dimension tamano = new Dimension(lado, lado);
            setPreferredSize(tamano);
            setMinimumSize(tamano);
            setMaximumSize(tamano);
            setOpaque(false);
            setFont(new Font("Arial", Font.BOLD, 13));
        }

        void setFondo(Color fondo) {
            this.fondo = fondo;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fondo);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arco, arco);

            if (borde != null) {
                g2.setColor(borde);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arco, arco);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Base para paneles clicables con efecto hover. */
    private abstract static class AreaClicable extends JPanel {

        protected boolean hover;

        AreaClicable() {
            setOpaque(false);
        }

        /** Llamar al final del constructor, cuando ya existen todos los hijos. */
        final void activarInteraccion(Runnable accion) {

            MouseAdapter oyente = new MouseAdapter() {

                @Override
                public void mouseEntered(MouseEvent e) {
                    cambiarHover(true);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    Point p = SwingUtilities.convertPoint(
                            (Component) e.getSource(), e.getPoint(), AreaClicable.this
                    );
                    cambiarHover(contains(p));
                }

                @Override
                public void mouseClicked(MouseEvent e) {
                    accion.run();
                }
            };

            instalar(this, oyente);
        }

        private void instalar(Component componente, MouseAdapter oyente) {

            componente.addMouseListener(oyente);
            componente.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            if (componente instanceof Container) {
                for (Component hijo : ((Container) componente).getComponents()) {
                    instalar(hijo, oyente);
                }
            }
        }

        private void cambiarHover(boolean valor) {
            if (hover != valor) {
                hover = valor;
                repaint();
            }
        }
    }

    /** Opción del menú lateral. */
    private static class ItemMenu extends AreaClicable {

        private final Insignia insignia;
        private final JLabel lblNombre;
        private boolean seleccionado;

        ItemMenu(String codigo, String nombre) {

            setLayout(new BorderLayout(12, 0));
            setBorder(new EmptyBorder(7, 14, 7, 12));
            setAlignmentX(Component.LEFT_ALIGNMENT);
            setPreferredSize(new Dimension(200, 50));
            setMinimumSize(new Dimension(100, 50));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

            insignia = new Insignia(codigo, INSIGNIA_FONDO, null, 10, 34);
            insignia.setForeground(TEXTO_SECUNDARIO);
            insignia.setFont(new Font("Arial", Font.BOLD, 12));

            JPanel envoltura = new JPanel(new GridBagLayout());
            envoltura.setOpaque(false);
            envoltura.add(insignia);

            lblNombre = new JLabel(nombre);
            lblNombre.setFont(new Font("Arial", Font.PLAIN, 14));
            lblNombre.setForeground(TEXTO_SECUNDARIO);

            add(envoltura, BorderLayout.WEST);
            add(lblNombre, BorderLayout.CENTER);
        }

        void setSeleccionado(boolean valor) {
            seleccionado = valor;
            lblNombre.setForeground(valor ? TEXTO : TEXTO_SECUNDARIO);
            lblNombre.setFont(new Font("Arial", valor ? Font.BOLD : Font.PLAIN, 14));
            insignia.setForeground(valor ? MORADO : TEXTO_SECUNDARIO);
            insignia.setFondo(valor ? INSIGNIA_BORDE : INSIGNIA_FONDO);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (seleccionado) {
                g2.setColor(ITEM_SELECCIONADO);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.setColor(MORADO);
                g2.fillRoundRect(0, 11, 4, getHeight() - 22, 4, 4);
            } else if (hover) {
                g2.setColor(ITEM_HOVER);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Tarjeta azul uniforme: código a la izquierda, título y descripción a la derecha. */
    private static class TarjetaModulo extends AreaClicable {

        TarjetaModulo(String titulo, String descripcion, String codigo) {

            setLayout(new BorderLayout(14, 0));
            setBorder(new EmptyBorder(12, 16, 12, 16));

            Insignia insignia = new Insignia(
                    codigo,
                    new Color(255, 255, 255, 45),
                    new Color(255, 255, 255, 80),
                    14, 46
            );
            insignia.setForeground(Color.WHITE);
            insignia.setFont(new Font("Arial", Font.BOLD, 14));

            JPanel envoltura = new JPanel(new GridBagLayout());
            envoltura.setOpaque(false);
            envoltura.add(insignia);

            JLabel lblTituloTarjeta = new JLabel(titulo);
            lblTituloTarjeta.setForeground(Color.WHITE);
            lblTituloTarjeta.setFont(new Font("Arial", Font.BOLD, 15));

            JTextArea lblDescripcion = crearTextoAjustable(descripcion, 12, TEXTO_TARJETA);

            JPanel textos = new JPanel(new GridBagLayout());
            textos.setOpaque(false);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.weightx = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.WEST;

            gbc.gridy = 0;
            textos.add(lblTituloTarjeta, gbc);

            gbc.gridy = 1;
            gbc.insets = new Insets(3, 0, 0, 0);
            textos.add(lblDescripcion, gbc);

            add(envoltura, BorderLayout.WEST);
            add(textos, BorderLayout.CENTER);
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(hover ? AZUL_TARJETA_HOVER : AZUL_TARJETA);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);

            g2.setColor(BORDE_TARJETA);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Cuadrícula adaptable: calcula cuántas columnas caben según el ancho
     * (respetando un ancho mínimo por tarjeta) y ajusta el alto total,
     * así las tarjetas nunca se aplastan ni se les corta el contenido.
     */
    private static class GrillaResponsiva extends JPanel {

        private final int columnasMaximas;
        private final int anchoMinimo;
        private final int espacio;
        private final int altoTarjeta;
        private int ultimasColumnas;

        GrillaResponsiva(int columnasMaximas, int anchoMinimo, int espacio, int altoTarjeta) {
            super(null);
            this.columnasMaximas = columnasMaximas;
            this.anchoMinimo = anchoMinimo;
            this.espacio = espacio;
            this.altoTarjeta = altoTarjeta;
            this.ultimasColumnas = columnasMaximas;
            setOpaque(false);
        }

        private int columnasPara(int anchoDisponible) {
            if (anchoDisponible <= 0) {
                return columnasMaximas;
            }
            int columnas = (anchoDisponible + espacio) / (anchoMinimo + espacio);
            return Math.max(1, Math.min(columnasMaximas, columnas));
        }

        @Override
        public void doLayout() {

            int total = getComponentCount();

            if (total == 0) {
                return;
            }

            Insets margen = getInsets();
            int ancho = getWidth() - margen.left - margen.right;
            int columnas = columnasPara(ancho);
            int anchoTarjeta = (ancho - (columnas - 1) * espacio) / columnas;

            for (int i = 0; i < total; i++) {
                int x = margen.left + (i % columnas) * (anchoTarjeta + espacio);
                int y = margen.top + (i / columnas) * (altoTarjeta + espacio);
                getComponent(i).setBounds(x, y, anchoTarjeta, altoTarjeta);
            }

            if (columnas != ultimasColumnas) {
                ultimasColumnas = columnas;
                SwingUtilities.invokeLater(this::revalidate);
            }
        }

        @Override
        public Dimension getPreferredSize() {

            int total = getComponentCount();
            Insets margen = getInsets();
            int ancho = getWidth() - margen.left - margen.right;
            int columnas = columnasPara(ancho);
            int filas = Math.max(1, (total + columnas - 1) / columnas);

            int alto = filas * altoTarjeta + (filas - 1) * espacio + margen.top + margen.bottom;

            return new Dimension(anchoMinimo + margen.left + margen.right, alto);
        }

        @Override
        public Dimension getMinimumSize() {
            return getPreferredSize();
        }
    }

    /** Barra de desplazamiento delgada para el tema oscuro. */
    private static class ScrollBarOscuro extends BasicScrollBarUI {

        @Override
        protected void configureScrollBarColors() {
            thumbColor = SCROLL_THUMB;
            trackColor = scrollbar.getBackground();
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return botonVacio();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return botonVacio();
        }

        private JButton botonVacio() {
            JButton boton = new JButton();
            Dimension cero = new Dimension(0, 0);
            boton.setPreferredSize(cero);
            boton.setMinimumSize(cero);
            boton.setMaximumSize(cero);
            return boton;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(trackColor);
            g.fillRect(r.x, r.y, r.width, r.height);
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {

            if (r.isEmpty() || !scrollbar.isEnabled()) {
                return;
            }

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(thumbColor);
            g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8);
            g2.dispose();
        }
    }
}


