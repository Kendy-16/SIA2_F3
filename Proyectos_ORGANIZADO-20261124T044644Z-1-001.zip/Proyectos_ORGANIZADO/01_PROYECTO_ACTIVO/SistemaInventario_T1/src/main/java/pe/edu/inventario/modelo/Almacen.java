
package pe.edu.inventario.modelo;

public class Almacen {

    private int idAlmacen;
    private String nombre;
    private String ubicacion;

    public Almacen() {
    }

    public Almacen(
            int idAlmacen,
            String nombre,
            String ubicacion
    ) {
        this.idAlmacen = idAlmacen;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
    }

    public Almacen(String nombre, String ubicacion) {
        this(0, nombre, ubicacion);
    }

    public int getIdAlmacen() {
        return idAlmacen;
    }

    public void setIdAlmacen(int idAlmacen) {
        if (idAlmacen < 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen no puede ser negativo."
            );
        }
        this.idAlmacen = idAlmacen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return nombre == null ? "" : nombre;
    }
}
