
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Categoria;
import pe.edu.inventario.modelo.dao.CategoriaDAO;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Implements category business rules and validations.
 */
public class CategoriaService {

    private final CategoriaDAO categoriaDAO;

    private static final int MIN_NOMBRE = 3;
    private static final int MAX_NOMBRE = 120;
    private static final int MAX_DESCRIPCION = 500;

    private static final String PATRON_NOMBRE =
            "[\\p{L}\\p{M}\\p{N}][\\p{L}\\p{M}\\p{N} .,'()/&_-]*";

    public CategoriaService() {
        categoriaDAO = new CategoriaDAO();
    }

    // ==========================================
    // 1. REGISTER CATEGORY
    // ==========================================

    public boolean registrar(Categoria categoria)
            throws SQLException {

        validarCategoria(categoria);

        Categoria existente =
                categoriaDAO.buscarPorNombre(categoria.getNombre());

        if (existente != null) {
            throw new IllegalArgumentException(
                    "Ya existe una categoria con ese nombre."
            );
        }

        return categoriaDAO.insertar(categoria);
    }

    // ==========================================
    // 2. LIST CATEGORIES
    // ==========================================

    public ArrayList<Categoria> listar() throws SQLException {

        ArrayList<Categoria> categorias = categoriaDAO.listar();

        return categorias == null
                ? new ArrayList<>()
                : categorias;
    }

    // ==========================================
    // 3. SEARCH BY ID
    // ==========================================

    public Categoria buscarPorId(int idCategoria)
            throws SQLException {

        validarId(idCategoria);

        return categoriaDAO.buscarPorId(idCategoria);
    }

    // ==========================================
    // 4. UPDATE CATEGORY
    // ==========================================

    public boolean actualizar(Categoria categoria)
            throws SQLException {

        if (categoria == null) {
            throw new IllegalArgumentException(
                    "Los datos de la categoria son obligatorios."
            );
        }

        validarId(categoria.getIdCategoria());

        Categoria actual =
                categoriaDAO.buscarPorId(categoria.getIdCategoria());

        if (actual == null) {
            throw new IllegalArgumentException(
                    "La categoria que desea actualizar no existe."
            );
        }

        validarCategoria(categoria);

        Categoria existente =
                categoriaDAO.buscarPorNombre(categoria.getNombre());

        if (existente != null
                && existente.getIdCategoria()
                != categoria.getIdCategoria()) {

            throw new IllegalArgumentException(
                    "Otra categoria ya utiliza ese nombre."
            );
        }

        return categoriaDAO.actualizar(categoria);
    }

    // ==========================================
    // 5. DELETE CATEGORY
    // ==========================================

    public boolean eliminar(int idCategoria)
            throws SQLException {

        validarId(idCategoria);

        Categoria existente =
                categoriaDAO.buscarPorId(idCategoria);

        if (existente == null) {
            throw new IllegalArgumentException(
                    "La categoria que desea eliminar no existe."
            );
        }

        return categoriaDAO.eliminar(idCategoria);
    }

    // ==========================================
    // 6. GENERAL VALIDATION
    // ==========================================

    private void validarCategoria(Categoria categoria) {

        if (categoria == null) {
            throw new IllegalArgumentException(
                    "Los datos de la categoria son obligatorios."
            );
        }

        validarNombre(categoria);
        validarDescripcion(categoria);
    }

    // ==========================================
    // 7. VALIDATE CATEGORY NAME
    // ==========================================

    private void validarNombre(Categoria categoria) {

        String nombre = categoria.getNombre();

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre de la categoria es obligatorio."
            );
        }

        nombre = nombre.trim();

        int longitud = nombre.codePointCount(0, nombre.length());

        if (longitud < MIN_NOMBRE || longitud > MAX_NOMBRE) {
            throw new IllegalArgumentException(
                    "El nombre debe tener entre 3 y 120 caracteres."
            );
        }

        if (nombre.codePoints().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException(
                    "El nombre contiene caracteres de control."
            );
        }

        if (!nombre.matches(PATRON_NOMBRE)) {
            throw new IllegalArgumentException(
                    "El nombre contiene caracteres no permitidos."
            );
        }

        categoria.setNombre(nombre);
    }

    // ==========================================
    // 8. VALIDATE DESCRIPTION
    // ==========================================

    private void validarDescripcion(Categoria categoria) {

        String descripcion = categoria.getDescripcion();

        if (descripcion == null || descripcion.trim().isEmpty()) {
            categoria.setDescripcion(null);
            return;
        }

        descripcion = descripcion.trim();

        int longitud =
                descripcion.codePointCount(0, descripcion.length());

        if (longitud > MAX_DESCRIPCION) {
            throw new IllegalArgumentException(
                    "La descripcion no puede superar los 500 caracteres."
            );
        }

        if (descripcion.codePoints()
                .anyMatch(Character::isISOControl)) {

            throw new IllegalArgumentException(
                    "La descripcion contiene caracteres de control."
            );
        }

        categoria.setDescripcion(descripcion);
    }

    // ==========================================
    // 9. VALIDATE ID
    // ==========================================

    private void validarId(int idCategoria) {

        if (idCategoria <= 0) {
            throw new IllegalArgumentException(
                    "El ID de categoria debe ser positivo."
            );
        }
    }
}
