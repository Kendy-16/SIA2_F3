package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Bitácora completa de una toma, exportable. */
public class AuditoriaTomaDialog extends JDialog {
    private final PanelAuditoria panel = new PanelAuditoria();

    public AuditoriaTomaDialog(Window owner, InventarioFisicoController controller, long idToma) {
        super(owner, "Auditoría de la toma " + idToma, ModalityType.APPLICATION_MODAL);
        setSize(720, 460); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
        panel.setBorder(new EmptyBorder(12, 12, 0, 12));
        add(panel, BorderLayout.CENTER);
        JButton exportar = botonSecundario("Exportar CSV"), cerrar = botonSecundario("Cerrar");
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(exportar); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);
        cerrar.addActionListener(e -> dispose());
        exportar.addActionListener(e -> {
            try {
                java.io.File f = ExportadorVistaInventario.exportarConDialogo(this, panel.getModelo(), "auditoria-toma-" + idToma);
                if (f != null) MensajesInventarioFisico.informacion(this, "Archivo guardado en " + f.getAbsolutePath());
            } catch (java.io.IOException ex) { MensajesInventarioFisico.error(this, ex); }
        });
        TareaAsincrona.ejecutar(this, () -> controller.listarAuditoria(idToma), panel::setEventos);
    }
}
