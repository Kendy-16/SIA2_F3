
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class AlmacenDAO {

    private static final int TIEMPO_MAXIMO_CONSULTA = 30;

    // ==========================================
    // 1. INSERTAR ALMACEN
    // ==========================================

    public boolean insertar(Almacen almacen)
            throws SQLException {

        if (almacen == null) {
            throw new IllegalArgumentException(
                    "El almacen es obligatorio."
            );
        }

        String sql =
                "INSERT INTO almacenes (nombre, ubicacion) " +
                "VALUES (?, ?)";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            sentencia.setString(
                    1,
                    almacen.getNombre()
            );

            asignarOpcional(
                    sentencia,
                    2,
                    almacen.getUbicacion()
            );

            return sentencia.executeUpdate() == 1;

        } catch (SQLException ex) {

            throw traducirError(ex);
        }
    }

    // ==========================================
    // 2. LISTAR ALMACENES
    // ==========================================

    public ArrayList<Almacen> listar()
            throws SQLException {

        ArrayList<Almacen> almacenes =
                new ArrayList<>();

        String sql =
                "SELECT id_almacen, nombre, ubicacion " +
                "FROM almacenes " +
                "ORDER BY nombre COLLATE NOCASE ASC";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                while (resultado.next()) {

                    almacenes.add(
                            mapearAlmacen(resultado)
                    );
                }
            }
        }

        return almacenes;
    }

    // ==========================================
    // 3. BUSCAR POR ID
    // ==========================================

    public Almacen buscarPorId(int idAlmacen)
            throws SQLException {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }

        String sql =
                "SELECT id_almacen, nombre, ubicacion " +
                "FROM almacenes " +
                "WHERE id_almacen = ?";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (resultado.next()) {
                    return mapearAlmacen(resultado);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 4. COMPROBAR NOMBRE DUPLICADO
    // ==========================================

    public boolean existeNombre(
            String nombre,
            int idExcluir
    ) throws SQLException {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                    "El nombre del almacen es obligatorio."
            );
        }

        if (idExcluir < 0) {
            throw new IllegalArgumentException(
                    "El ID excluido no puede ser negativo."
            );
        }

        String sql =
                "SELECT 1 " +
                "FROM almacenes " +
                "WHERE nombre = ? COLLATE NOCASE " +
                "AND id_almacen <> ? " +
                "LIMIT 1";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            sentencia.setString(1, nombre.trim());
            sentencia.setInt(2, idExcluir);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                return resultado.next();
            }
        }
    }

    // ==========================================
    // 5. ACTUALIZAR ALMACEN
    // ==========================================

    public boolean actualizar(Almacen almacen)
            throws SQLException {

        if (almacen == null) {
            throw new IllegalArgumentException(
                    "El almacen es obligatorio."
            );
        }

        if (almacen.getIdAlmacen() <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }

        String sql =
                "UPDATE almacenes SET " +
                "nombre = ?, " +
                "ubicacion = ? " +
                "WHERE id_almacen = ?";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            sentencia.setString(
                    1,
                    almacen.getNombre()
            );

            asignarOpcional(
                    sentencia,
                    2,
                    almacen.getUbicacion()
            );

            sentencia.setInt(
                    3,
                    almacen.getIdAlmacen()
            );

            return sentencia.executeUpdate() == 1;

        } catch (SQLException ex) {

            throw traducirError(ex);
        }
    }

    // ==========================================
    // 6. ELIMINAR ALMACEN
    // ==========================================

    public boolean eliminar(int idAlmacen)
            throws SQLException {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }

        String sql =
                "DELETE FROM almacenes " +
                "WHERE id_almacen = ?";

        try (
                Connection conexion = ConexionDB.conectar();
                PreparedStatement sentencia =
                        conexion.prepareStatement(sql)
        ) {

            sentencia.setQueryTimeout(
                    TIEMPO_MAXIMO_CONSULTA
            );

            sentencia.setInt(1, idAlmacen);

            return sentencia.executeUpdate() == 1;

        } catch (SQLException ex) {

            throw traducirError(ex);
        }
    }

    // ==========================================
    // 7. MAPEAR RESULTADO A OBJETO
    // ==========================================

    private Almacen mapearAlmacen(
            ResultSet resultado
    ) throws SQLException {

        int id = resultado.getInt("id_almacen");

        String nombre =
                resultado.getString("nombre");

        String ubicacion =
                resultado.getString("ubicacion");

        if (resultado.wasNull()) {
            ubicacion = null;
        }

        if (id <= 0 || nombre == null || nombre.isBlank()) {
            throw new SQLException(
                    "Se encontro un registro de almacen inconsistente."
            );
        }

        return new Almacen(
                id,
                nombre,
                ubicacion
        );
    }

    // ==========================================
    // 8. ASIGNAR TEXTO OPCIONAL
    // ==========================================

    private void asignarOpcional(
            PreparedStatement sentencia,
            int posicion,
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {

            sentencia.setNull(
                    posicion,
                    Types.VARCHAR
            );

        } else {

            sentencia.setString(
                    posicion,
                    valor.trim()
            );
        }
    }

    // ==========================================
    // 9. TRADUCIR ERRORES SQLITE
    // ==========================================

    private SQLException traducirError(
            SQLException ex
    ) {

        String mensaje = ex.getMessage() == null
                ? ""
                : ex.getMessage().toLowerCase();

        if (mensaje.contains("unique constraint failed")) {

            return new SQLException(
                    "Ya existe un almacen con ese nombre.",
                    ex
            );
        }

        if (mensaje.contains("foreign key constraint failed")) {

            return new SQLException(
                    "No se puede eliminar el almacen porque tiene movimientos o existencias relacionadas.",
                    ex
            );
        }

        if (mensaje.contains("no such table")) {

            return new SQLException(
                    "No existe la tabla almacenes en SQLite.",
                    ex
            );
        }

        if (mensaje.contains("no such column")) {

            return new SQLException(
                    "Las columnas de almacenes no coinciden con la consulta SQL.",
                    ex
            );
        }

        return ex;
    }
}
