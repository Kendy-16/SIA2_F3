
package pe.edu.inventario.servicio;

import pe.edu.inventario.servicio.MovimientoService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Locale;
import java.util.UUID;

public class InventarioService {

    private final MovimientoService movimientoService;

    // ==========================================
    // CONSTANTS
    // ==========================================

    private static final double CANTIDAD_MAXIMA =
            1_000_000_000.0;

    private static final int MAX_DECIMALES = 3;

    private static final int MIN_MOTIVO = 5;

    private static final int MAX_MOTIVO = 500;

    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public InventarioService() {
        this.movimientoService = new MovimientoService();
    }

    // Constructor with dependency injection
    public InventarioService(
            MovimientoService movimientoService
    ) {

        if (movimientoService == null) {
            throw new IllegalArgumentException(
                    "El servicio de movimientos es obligatorio."
            );
        }

        this.movimientoService = movimientoService;
    }

    // ==========================================
    // REGISTER PHYSICAL INVENTORY ADJUSTMENT
    // ==========================================

    public boolean registrarAjusteInventario(
            int idAlmacen,
            int idProducto,
            double cantidadFisica,
            String motivo
    ) throws SQLException {

        // Validate warehouse ID
        validarIdAlmacen(idAlmacen);

        // Validate product ID
        validarIdProducto(idProducto);

        // Validate physical quantity
        validarCantidadFisica(cantidadFisica);

        // Validate adjustment reason
        String motivoNormalizado = validarMotivo(motivo);

        // Generate an internal document identifier
        String documento = generarDocumentoInterno();

        // Delegate the adjustment transaction
        return movimientoService.registrarAjuste(
                idProducto,
                idAlmacen,
                documento,
                cantidadFisica,
                motivoNormalizado
        );
    }

    // ==========================================
    // VALIDATE WAREHOUSE ID
    // ==========================================

    private void validarIdAlmacen(int idAlmacen) {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // VALIDATE PRODUCT ID
    // ==========================================

    private void validarIdProducto(int idProducto) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }
    }

    // ==========================================
    // VALIDATE PHYSICAL QUANTITY
    // ==========================================

    private void validarCantidadFisica(
            double cantidadFisica
    ) {

        if (!Double.isFinite(cantidadFisica)) {
            throw new IllegalArgumentException(
                    "La cantidad fisica debe ser un numero finito."
            );
        }

        if (cantidadFisica < 0) {
            throw new IllegalArgumentException(
                    "La cantidad fisica no puede ser negativa."
            );
        }

        if (cantidadFisica > CANTIDAD_MAXIMA) {
            throw new IllegalArgumentException(
                    "La cantidad fisica supera el limite permitido."
            );
        }

        BigDecimal cantidad =
                BigDecimal.valueOf(cantidadFisica)
                        .stripTrailingZeros();

        if (cantidad.scale() > MAX_DECIMALES) {
            throw new IllegalArgumentException(
                    "La cantidad fisica admite como maximo 3 decimales."
            );
        }
    }

    // ==========================================
    // VALIDATE ADJUSTMENT REASON
    // ==========================================

    private String validarMotivo(String motivo) {

        if (motivo == null || motivo.isBlank()) {
            throw new IllegalArgumentException(
                    "El motivo del ajuste es obligatorio."
            );
        }

        String motivoNormalizado =
                motivo.trim().replaceAll("\\s+", " ");

        if (motivoNormalizado.length() < MIN_MOTIVO) {
            throw new IllegalArgumentException(
                    "El motivo debe tener al menos 5 caracteres."
            );
        }

        if (motivoNormalizado.length() > MAX_MOTIVO) {
            throw new IllegalArgumentException(
                    "El motivo no puede superar 500 caracteres."
            );
        }

        if (contieneCaracteresDeControl(motivoNormalizado)) {
            throw new IllegalArgumentException(
                    "El motivo contiene caracteres no permitidos."
            );
        }

        return motivoNormalizado;
    }

    // ==========================================
    // CHECK CONTROL CHARACTERS
    // ==========================================

    private boolean contieneCaracteresDeControl(
            String texto
    ) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    // ==========================================
    // GENERATE INTERNAL DOCUMENT
    // ==========================================

    private String generarDocumentoInterno() {

        String identificador = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 12)
                .toUpperCase(Locale.ROOT);

        return "AJU" + identificador;
    }
}
