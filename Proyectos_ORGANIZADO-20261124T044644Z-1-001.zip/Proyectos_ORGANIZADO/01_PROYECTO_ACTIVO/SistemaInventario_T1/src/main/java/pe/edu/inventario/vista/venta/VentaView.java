package pe.edu.inventario.vista.venta;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.modelo.venta.TipoVenta;

import java.awt.Color;

/**
 * Requisito 3.1: VENTA NORMAL
 * Cliente genérico por defecto (público en general) y precio de lista.
 * Los paneles y eventos compartidos viven en VentaBaseView.
 */
public class VentaView extends VentaBaseView {

    public VentaView(VentaController controller, RolUsuario rol, String idUsuario) {
        super(controller, TipoVenta.NORMAL, rol, idUsuario, "Confirmar y Pagar (F12)");

        btnConfirmarPago.setBackground(new Color(34, 139, 34)); // Verde
        btnConfirmarPago.setForeground(Color.WHITE);
    }
}
