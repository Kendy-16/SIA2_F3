package pe.edu.inventario.controlador.venta;

import pe.edu.inventario.modelo.producto.Producto;
import pe.edu.inventario.modelo.venta.*;
import pe.edu.inventario.servicio.cliente.ClienteService;
import pe.edu.inventario.servicio.producto.ProductoService;
import pe.edu.inventario.servicio.venta.VentaException;
import pe.edu.inventario.servicio.venta.VentaService;

import java.math.BigDecimal;
import java.util.List;

/**
 * El controlador actúa como puente entre las vistas (VentaView, VentaMayoristaView,
 * HistorialVentasView) y el servicio. Cada pantalla de venta usa su propia instancia.
 */
public class VentaController {

    private final VentaService ventaService;
    private final ProductoService productoService;
    private final ClienteService clienteService;

    private Venta ventaActual;

    public VentaController(VentaService ventaService, ProductoService productoService,
                           ClienteService clienteService) {
        this.ventaService = ventaService;
        this.productoService = productoService;
        this.clienteService = clienteService;
    }

    public void iniciarNuevaVenta(TipoVenta tipo, RolUsuario rolActual, String idUsuario) {
        ventaActual = new Venta();
        ventaActual.setTipoVenta(tipo);
        ventaActual.setRolUsuario(rolActual);
        ventaActual.setIdUsuario(idUsuario);
        ventaActual.setEstado(EstadoVenta.EN_PROCESO);

        // Requisito 3.1: Cliente genérico por defecto en venta normal
        if (tipo == TipoVenta.NORMAL) {
            ventaActual.setIdCliente(ClienteService.CLIENTE_GENERICO); // DNI Genérico - Público en general
            ventaActual.setNombreCliente(clienteService.buscarNombre(ClienteService.CLIENTE_GENERICO));
        }
    }

    /** Busca un cliente por documento (DNI/RUC). @return su nombre o null si no existe. */
    public String buscarCliente(String documento) {
        return clienteService.buscarNombre(documento);
    }

    /** @return el nombre del cliente seleccionado. */
    public String setCliente(String idCliente) {
        String documento = idCliente == null ? "" : idCliente.trim();
        // Requisito 3.2: Venta Mayorista exige identificación real (RUC/DNI)
        if (ventaActual.getTipoVenta() == TipoVenta.MAYORISTA && documento.equals(ClienteService.CLIENTE_GENERICO)) {
            throw new IllegalArgumentException("Ventas mayoristas requieren un cliente registrado válido.");
        }
        String nombre = clienteService.buscarNombre(documento);
        if (nombre == null) {
            throw new IllegalArgumentException("Cliente no registrado: " + documento);
        }
        ventaActual.setIdCliente(documento);
        ventaActual.setNombreCliente(nombre);
        return nombre;
    }

    /** Busca por código de barras o nombre, obtiene el precio según la modalidad y recalcula totales. */
    public void agregarProducto(String codigoONombre, int cantidad) {
        if (codigoONombre == null || codigoONombre.trim().isEmpty()) {
            throw new IllegalArgumentException("Ingrese un código de barras o un nombre de producto.");
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a cero.");
        }
        Producto producto = productoService.buscarPorCodigoONombre(codigoONombre);
        if (producto == null) {
            throw new IllegalArgumentException("Producto no encontrado: " + codigoONombre);
        }

        // Si el producto ya está en el detalle se acumula la cantidad en la misma línea.
        DetalleVenta existente = ventaActual.buscarDetalle(producto.getCodigo());
        int cantidadFinal = cantidad + (existente == null ? 0 : existente.getCantidad());

        // Se valida ANTES de modificar el detalle, para no dejar la venta en estado inválido.
        if (ventaActual.getTipoVenta() == TipoVenta.MAYORISTA) {
            ventaService.validarCondicionesMayoristas(producto.getCodigo(), cantidadFinal);
        }

        if (existente != null) {
            existente.setCantidad(cantidadFinal);
        } else {
            DetalleVenta det = new DetalleVenta();
            det.setCodigoProducto(producto.getCodigo());
            det.setNombreProducto(producto.getNombre());
            det.setCantidad(cantidad);
            det.setPrecioUnitario(productoService.obtenerPrecio(producto, ventaActual.getTipoVenta()));
            det.setPorcentajeDescuento(BigDecimal.ZERO); // Por defecto 0
            ventaActual.agregarDetalle(det);
        }
        ventaService.preProcesarVenta(ventaActual);
    }

    public void quitarLinea(int indice) {
        if (indice < 0 || indice >= ventaActual.getDetalles().size()) {
            throw new IllegalArgumentException("Seleccione una línea del detalle.");
        }
        ventaActual.quitarDetalle(indice);
        ventaService.preProcesarVenta(ventaActual);
    }

    /** Requisito 4: solo el ADMINISTRADOR puede aplicar descuentos manuales (lanza SecurityException si no). */
    public void aplicarDescuentoManual(int indiceLinea, BigDecimal porcentaje) {
        if (indiceLinea < 0 || indiceLinea >= ventaActual.getDetalles().size()) {
            throw new IllegalArgumentException("Seleccione una línea del detalle.");
        }
        ventaService.aplicarDescuentoManual(ventaActual, ventaActual.getDetalles().get(indiceLinea), porcentaje);
    }

    /**
     * Cobra y confirma la venta actual.
     * @param montoRecibido solo se usa en Efectivo (en otros medios se cobra el total exacto)
     * @return número del comprobante emitido
     */
    public String procesarPagoYConfirmar(String metodoPago, BigDecimal montoRecibido) throws VentaException {
        ventaActual.setMetodoPago(metodoPago);
        ventaActual.setMontoRecibido(montoRecibido == null ? BigDecimal.ZERO : montoRecibido);
        return ventaService.confirmarVenta(ventaActual);
    }

    public BigDecimal calcularVuelto(BigDecimal recibido) {
        return ventaService.calcularVuelto(ventaActual.getTotal(), recibido);
    }

    // ---- Historial y anulación (Requisitos 11 y 12) ----

    public List<Venta> listarHistorial(String desde, String hasta, String tipo) {
        return ventaService.listarHistorial(desde, hasta, tipo);
    }

    public Venta buscarVenta(String idVenta) {
        return ventaService.buscarVenta(idVenta);
    }

    public String ticketDe(Venta venta) {
        return ventaService.formatearTicket(venta);
    }

    public void anularVenta(String idVenta, RolUsuario rol, String usuarioAutoriza, String motivo)
            throws VentaException {
        ventaService.anularVenta(idVenta, rol, usuarioAutoriza, motivo);
    }

    public Venta getVentaActual() {
        return ventaActual;
    }
}
