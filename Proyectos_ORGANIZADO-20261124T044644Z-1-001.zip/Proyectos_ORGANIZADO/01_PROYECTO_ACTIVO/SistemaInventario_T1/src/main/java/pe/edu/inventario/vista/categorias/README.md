# Categorías

Reservada. La gestión de categorías hoy vive en vista/producto/CategoriaView.java.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
