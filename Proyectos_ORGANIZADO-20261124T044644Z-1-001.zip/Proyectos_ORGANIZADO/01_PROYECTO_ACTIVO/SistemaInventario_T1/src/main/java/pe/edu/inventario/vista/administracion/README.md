# Administración de usuarios

Pendiente. Gestión de usuarios, roles y permisos (ver pe/edu/inventario/seguridad en el diseño objetivo).

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
