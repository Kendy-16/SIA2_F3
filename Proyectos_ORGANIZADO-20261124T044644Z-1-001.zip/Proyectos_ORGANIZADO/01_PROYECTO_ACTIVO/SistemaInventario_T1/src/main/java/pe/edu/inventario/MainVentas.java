package pe.edu.inventario;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.dao.venta.VentaDAO;
import pe.edu.inventario.dao.venta.VentaDAOMemoria;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.servicio.cliente.ClienteService;
import pe.edu.inventario.servicio.producto.ProductoService;
import pe.edu.inventario.servicio.venta.CajaService;
import pe.edu.inventario.servicio.venta.DocumentoService;
import pe.edu.inventario.servicio.venta.KardexService;
import pe.edu.inventario.servicio.venta.VentaService;
import pe.edu.inventario.vista.venta.HistorialVentasView;
import pe.edu.inventario.vista.venta.VentaMayoristaView;
import pe.edu.inventario.vista.venta.VentaView;

import javax.swing.*;
import java.awt.Dimension;

/**
 * Punto de entrada con interfaz gráfica (Swing). Arma las dependencias, pide el perfil
 * (Administrador / Usuario) y muestra las pestañas: Venta Normal, Venta Mayorista e Historial.
 */
public class MainVentas {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainVentas::iniciar);
    }

    private static void iniciar() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignorada) {
            // si falla, queda el aspecto por defecto de Swing
        }

        // --- Composición de dependencias ---
        ProductoService productos = new ProductoService();
        KardexService kardex = new KardexService();
        ClienteService clientes = new ClienteService();
        CajaService caja = new CajaService();
        DatosDemo.cargar(productos, kardex, clientes);

        VentaDAO dao = new VentaDAOMemoria();
        VentaService servicio = new VentaService(kardex, caja, new DocumentoService(), dao, productos);

        // --- Perfil del usuario (Requisito 4) ---
        RolUsuario rol = pedirRol();
        if (rol == null) {
            System.exit(0);
        }
        String idUsuario = rol == RolUsuario.ADMINISTRADOR ? "admin01" : "cajero01";

        // Cada pantalla de venta tiene su propio controlador (cada una lleva su venta en curso)
        VentaView ventaNormal = new VentaView(new VentaController(servicio, productos, clientes), rol, idUsuario);
        VentaMayoristaView ventaMayorista =
                new VentaMayoristaView(new VentaController(servicio, productos, clientes), rol, idUsuario);
        HistorialVentasView historial =
                new HistorialVentasView(new VentaController(servicio, productos, clientes), rol, idUsuario);

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Venta Normal", ventaNormal);
        pestanas.addTab("Venta Mayorista", ventaMayorista);
        pestanas.addTab("Historial / Anulaciones", historial);
        pestanas.addChangeListener(e -> {
            if (pestanas.getSelectedComponent() == historial) {
                historial.refrescar();
            }
        });

        JFrame ventana = new JFrame("Módulo de Ventas - " + idUsuario + " (" + rol + ")");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setContentPane(pestanas);
        ventana.setMinimumSize(new Dimension(980, 640));
        ventana.pack();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
    }

    private static RolUsuario pedirRol() {
        Object[] opciones = {"Administrador", "Usuario"};
        int eleccion = JOptionPane.showOptionDialog(null, "Ingrese con el perfil:", "Módulo de Ventas",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[1]);
        if (eleccion == 0) return RolUsuario.ADMINISTRADOR;
        if (eleccion == 1) return RolUsuario.USUARIO;
        return null;
    }
}
