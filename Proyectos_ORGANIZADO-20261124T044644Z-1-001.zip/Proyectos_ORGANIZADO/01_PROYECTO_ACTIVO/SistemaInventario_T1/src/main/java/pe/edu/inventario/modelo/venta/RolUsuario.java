package pe.edu.inventario.modelo.venta;

/** Roles del sistema de ventas. (Clase de apoyo) */
public enum RolUsuario { ADMINISTRADOR, USUARIO }
