
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.Categoria;
import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Handles database operations for categories.
 */
public class CategoriaDAO {

    // ==========================================
    // 1. INSERT CATEGORY
    // ==========================================

    public boolean insertar(Categoria categoria)
            throws SQLException {

        if (categoria == null) {
            throw new IllegalArgumentException(
                    "La categoria no puede ser nula."
            );
        }

        String sql = """
            INSERT INTO categorias (
                nombre,
                descripcion
            )
            VALUES (?, ?)
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, categoria.getNombre());
            pstmt.setString(2, categoria.getDescripcion());

            return pstmt.executeUpdate() == 1;

        } catch (SQLException e) {

            throw traducirError(e);
        }
    }

    // ==========================================
    // 2. LIST CATEGORIES
    // ==========================================

    public ArrayList<Categoria> listar() throws SQLException {

        ArrayList<Categoria> categorias = new ArrayList<>();

        String sql = """
            SELECT
                id_categoria,
                nombre,
                descripcion
            FROM categorias
            ORDER BY nombre COLLATE NOCASE, id_categoria
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                categorias.add(mapearCategoria(rs));
            }
        }

        return categorias;
    }

    // ==========================================
    // 3. SEARCH CATEGORY BY ID
    // ==========================================

    public Categoria buscarPorId(int idCategoria)
            throws SQLException {

        if (idCategoria <= 0) {
            throw new IllegalArgumentException(
                    "El ID de categoria debe ser positivo."
            );
        }

        String sql = """
            SELECT
                id_categoria,
                nombre,
                descripcion
            FROM categorias
            WHERE id_categoria = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, idCategoria);

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return mapearCategoria(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 4. SEARCH CATEGORY BY NAME
    // ==========================================

    public Categoria buscarPorNombre(String nombre)
            throws SQLException {

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre es obligatorio."
            );
        }

        String sql = """
            SELECT
                id_categoria,
                nombre,
                descripcion
            FROM categorias
            WHERE nombre = ? COLLATE NOCASE
            LIMIT 1
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, nombre.trim());

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return mapearCategoria(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 5. UPDATE CATEGORY
    // ==========================================

    public boolean actualizar(Categoria categoria)
            throws SQLException {

        if (categoria == null || categoria.getIdCategoria() <= 0) {
            throw new IllegalArgumentException(
                    "Seleccione una categoria valida."
            );
        }

        String sql = """
            UPDATE categorias
            SET nombre = ?,
                descripcion = ?
            WHERE id_categoria = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, categoria.getNombre());
            pstmt.setString(2, categoria.getDescripcion());
            pstmt.setInt(3, categoria.getIdCategoria());

            return pstmt.executeUpdate() == 1;

        } catch (SQLException e) {

            throw traducirError(e);
        }
    }

    // ==========================================
    // 6. DELETE CATEGORY
    // ==========================================

    public boolean eliminar(int idCategoria)
            throws SQLException {

        if (idCategoria <= 0) {
            throw new IllegalArgumentException(
                    "El ID de categoria debe ser positivo."
            );
        }

        String sql = """
            DELETE FROM categorias
            WHERE id_categoria = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, idCategoria);

            return pstmt.executeUpdate() == 1;

        } catch (SQLException e) {

            throw traducirError(e);
        }
    }

    // ==========================================
    // 7. MAP RESULT TO CATEGORY
    // ==========================================

    private Categoria mapearCategoria(ResultSet rs)
            throws SQLException {

        return new Categoria(
                rs.getInt("id_categoria"),
                rs.getString("nombre"),
                rs.getString("descripcion")
        );
    }

    // ==========================================
    // 8. TRANSLATE DATABASE ERRORS
    // ==========================================

    private SQLException traducirError(SQLException e) {

        String mensaje = e.getMessage();

        if (mensaje == null) {
            return e;
        }

        String error = mensaje.toLowerCase(Locale.ROOT);

        if (error.contains("unique constraint failed")) {

            return new SQLException(
                    "Ya existe una categoria con ese nombre.",
                    e
            );
        }

        if (error.contains("foreign key constraint failed")) {

            return new SQLException(
                    "No se puede eliminar esta categoria porque "
                    + "tiene productos asociados.",
                    e
            );
        }

        return e;
    }
}
