package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Interfaz Swing completa del módulo de inventario físico.
 * No contiene SQL ni modifica directamente existencias o costos.
 */
public class InventarioFisicoFrame extends JFrame {
    private static final Color NAVY = new Color(25, 45, 75);
    private static final Color BLUE = new Color(43, 105, 190);
    private static final Color BG = new Color(245, 247, 251);
    private static final Color TEXT = new Color(45, 55, 72);
    private static final Color MUTED = new Color(110, 122, 140);
    private static final Color GREEN = new Color(29, 145, 95);
    private static final Color RED = new Color(195, 65, 65);
    private static final Color AMBER = new Color(190, 125, 25);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final NumberFormat MONEY = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-PE"));

    private final InventarioFisicoController controller;
    private final JTabbedPane tabs = new JTabbedPane();
    private final DefaultTableModel dashboardModel = model("ID", "Código", "Almacén", "Inicio", "Responsable", "Productos", "Contados", "Diferencias", "Avance", "Estado");
    private final JTable dashboardTable = table(dashboardModel);
    private final JTextField searchDashboard = new JTextField(18);
    private final JComboBox<String> stateDashboard = new JComboBox<>(new String[]{"Todos", "ABIERTA", "EN_CONTEO", "EN_REVISION", "CONCILIADA", "APROBADA", "CERRADA", "CANCELADA"});
    private final JLabel[] metricValues = new JLabel[5];
    private final JPanel reconciliationPanel = new JPanel(new BorderLayout(12, 12));
    private final DefaultTableModel reconciliationModel = model("Código", "Producto", "Sistema", "Físico", "Diferencia", "Costo prom.", "Valor diferencia", "Tipo", "Revisión");
    private final JTable reconciliationTable = table(reconciliationModel);
    private final JComboBox<Toma> reconciliationTake = new JComboBox<>();
    private final DefaultTableModel historyModel = model("ID", "Código", "Almacén", "Inicio", "Responsable", "Productos", "Diferencias", "Estado");
    private final JTable historyTable = table(historyModel);
    private final JLabel statusBar = new JLabel("Listo");

    public InventarioFisicoFrame(InventarioFisicoController controller) {
        this.controller = Objects.requireNonNull(controller, "El controlador es obligatorio.");
        setTitle("Sistema de Inventario · Inventario físico");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1120, 720));
        setSize(1380, 850);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());
        add(buildHeader(), BorderLayout.NORTH);
        add(buildTabs(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
        configureTables();
        refreshAll();
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(15, 5));
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 24, 18, 24));
        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("INVENTARIO FÍSICO");
        title.setForeground(Color.WHITE);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
        JLabel subtitle = new JLabel("Conteo, conciliación y control de diferencias por almacén");
        subtitle.setForeground(new Color(205, 216, 232));
        subtitle.setFont(subtitle.getFont().deriveFont(13f));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(4));
        titleBox.add(subtitle);
        JPanel userBox = new JPanel(new GridLayout(2, 1, 0, 3));
        userBox.setOpaque(false);
        JLabel user = new JLabel("Usuario: sesión autenticada");
        user.setForeground(Color.WHITE);
        user.setHorizontalAlignment(SwingConstants.RIGHT);
        JLabel role = new JLabel("Los permisos se validan también en el servicio");
        role.setForeground(new Color(205, 216, 232));
        role.setFont(role.getFont().deriveFont(11f));
        role.setHorizontalAlignment(SwingConstants.RIGHT);
        userBox.add(user);
        userBox.add(role);
        header.add(titleBox, BorderLayout.WEST);
        header.add(userBox, BorderLayout.EAST);
        return header;
    }

    private JComponent buildTabs() {
        tabs.setBorder(new EmptyBorder(12, 18, 8, 18));
        tabs.setFont(tabs.getFont().deriveFont(Font.BOLD, 13f));
        tabs.addTab("Resumen", buildDashboardPanel());
        tabs.addTab("Conciliación", buildReconciliationPanel());
        tabs.addTab("Historial", buildHistoryPanel());
        tabs.addTab("Reportes", new ReportPanel());
        return tabs;
    }

    private JComponent buildDashboardPanel() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setOpaque(false);
        JPanel north = new JPanel(new BorderLayout(10, 12));
        north.setOpaque(false);
        JPanel cards = new JPanel(new GridLayout(1, 5, 10, 0));
        cards.setOpaque(false);
        String[] names = {"Tomas realizadas", "Tomas abiertas", "Tomas conciliadas", "Productos con diferencias", "Ajustes pendientes"};
        for (int i = 0; i < names.length; i++) {
            JPanel card = metricCard(names[i]);
            metricValues[i] = (JLabel) card.getClientProperty("valueLabel");
            cards.add(card);
        }
        north.add(cards, BorderLayout.NORTH);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        actions.setOpaque(false);
        JButton create = primaryButton("Nueva toma física");
        JButton count = secondaryButton("Registrar conteo");
        JButton reconcile = secondaryButton("Conciliar");
        JButton detail = secondaryButton("Ver detalles");
        JButton history = secondaryButton("Historial completo");
        JButton report = secondaryButton("Reporte");
        actions.add(create); actions.add(count); actions.add(reconcile); actions.add(detail); actions.add(history); actions.add(report);
        north.add(actions, BorderLayout.SOUTH);
        root.add(north, BorderLayout.NORTH);

        JPanel tableBox = panelCard("Tomas físicas", new BorderLayout(8, 8));
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filters.setOpaque(false);
        filters.add(new JLabel("Buscar:"));
        filters.add(searchDashboard);
        filters.add(new JLabel("Estado:"));
        filters.add(stateDashboard);
        JButton refresh = secondaryButton("Actualizar");
        filters.add(refresh);
        tableBox.add(filters, BorderLayout.NORTH);
        tableBox.add(new JScrollPane(dashboardTable), BorderLayout.CENTER);
        root.add(tableBox, BorderLayout.CENTER);

        create.addActionListener(e -> openNewTake());
        count.addActionListener(e -> openCountForSelected());
        reconcile.addActionListener(e -> openReconciliationForSelected());
        detail.addActionListener(e -> openDetailsForSelected());
        history.addActionListener(e -> tabs.setSelectedIndex(2));
        report.addActionListener(e -> tabs.setSelectedIndex(3));
        refresh.addActionListener(e -> refreshAll());
        searchDashboard.addActionListener(e -> refreshTakes());
        stateDashboard.addActionListener(e -> refreshTakes());
        dashboardTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { if (e.getClickCount() == 2) openDetailsForSelected(); }
        });
        return root;
    }

    private JComponent buildReconciliationPanel() {
        reconciliationPanel.setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        top.add(new JLabel("Toma física:"));
        reconciliationTake.setPrototypeDisplayValue(new Toma(999, "IF-2026-0000", "Almacén muy largo", null, null, "Responsable", 0, 0, 0, EstadoToma.ABIERTA));
        top.add(reconciliationTake);
        JButton load = secondaryButton("Cargar diferencias");
        JButton run = primaryButton("Ejecutar conciliación");
        JButton detail = secondaryButton("Detalle de diferencia");
        JButton adjustment = secondaryButton("Gestionar ajuste");
        JButton close = secondaryButton("Cerrar toma");
        top.add(load); top.add(run); top.add(detail); top.add(adjustment); top.add(close);
        reconciliationPanel.add(top, BorderLayout.NORTH);
        reconciliationPanel.add(new JScrollPane(reconciliationTable), BorderLayout.CENTER);
        JLabel note = new JLabel("La conciliación compara el conteo con el saldo del sistema. La vista no actualiza existencias ni costos.");
        note.setForeground(MUTED);
        reconciliationPanel.add(note, BorderLayout.SOUTH);
        load.addActionListener(e -> loadDifferences());
        run.addActionListener(e -> executeReconciliation());
        detail.addActionListener(e -> openDifferenceDetail());
        adjustment.addActionListener(e -> manageAdjustment());
        close.addActionListener(e -> closeTake());
        reconciliationTake.addActionListener(e -> loadDifferences());
        return reconciliationPanel;
    }

    private JComponent buildHistoryPanel() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setOpaque(false);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        JTextField filter = new JTextField(22);
        JButton refresh = secondaryButton("Buscar / actualizar");
        JButton details = primaryButton("Ver toma seleccionada");
        top.add(new JLabel("Código, almacén o responsable:")); top.add(filter); top.add(refresh); top.add(details);
        root.add(top, BorderLayout.NORTH);
        root.add(new JScrollPane(historyTable), BorderLayout.CENTER);
        refresh.addActionListener(e -> loadHistory(filter.getText()));
        filter.addActionListener(e -> loadHistory(filter.getText()));
        details.addActionListener(e -> openDetails(historySelectedId()));
        historyTable.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { if (e.getClickCount() == 2) openDetails(historySelectedId()); }
        });
        loadHistory("");
        return root;
    }

    private JComponent buildStatusBar() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(225, 230, 238)));
        statusBar.setBorder(new EmptyBorder(7, 18, 7, 18));
        statusBar.setForeground(MUTED);
        statusBar.setFont(statusBar.getFont().deriveFont(11f));
        p.add(statusBar, BorderLayout.CENTER);
        return p;
    }

    private JPanel metricCard(String title) {
        JPanel card = new JPanel(new BorderLayout(4, 7));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(13, 14, 13, 14)));
        JLabel name = new JLabel(title);
        name.setForeground(MUTED);
        name.setFont(name.getFont().deriveFont(11f));
        JLabel value = new JLabel("—");
        value.setForeground(NAVY);
        value.setFont(value.getFont().deriveFont(Font.BOLD, 25f));
        card.add(name, BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        card.putClientProperty("valueLabel", value);
        return card;
    }

    private JPanel panelCard(String title, LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(12, 12, 12, 12)));
        JLabel label = new JLabel(title);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 15f));
        label.setForeground(TEXT);
        panel.add(label, BorderLayout.BEFORE_FIRST_LINE);
        return panel;
    }

    private void configureTables() {
        for (JTable t : List.of(dashboardTable, reconciliationTable, historyTable)) {
            t.setRowHeight(29);
            t.setFillsViewportHeight(true);
            t.setShowVerticalLines(false);
            t.setGridColor(new Color(235, 238, 243));
            t.setSelectionBackground(new Color(222, 235, 252));
            t.setSelectionForeground(TEXT);
            t.getTableHeader().setReorderingAllowed(false);
            t.getTableHeader().setBackground(new Color(240, 244, 249));
            t.getTableHeader().setForeground(TEXT);
            t.getTableHeader().setFont(t.getTableHeader().getFont().deriveFont(Font.BOLD, 11f));
            t.setFont(t.getFont().deriveFont(12f));
        }
        dashboardTable.getColumnModel().getColumn(0).setMinWidth(0);
        dashboardTable.getColumnModel().getColumn(0).setMaxWidth(0);
        historyTable.getColumnModel().getColumn(0).setMinWidth(0);
        historyTable.getColumnModel().getColumn(0).setMaxWidth(0);
        reconciliationTable.setDefaultRenderer(Object.class, new ZebraRenderer());
        dashboardTable.setDefaultRenderer(Object.class, new ZebraRenderer());
        historyTable.setDefaultRenderer(Object.class, new ZebraRenderer());
    }

    private void refreshAll() {
        async("Actualizando panel", controller::obtenerResumen, resumen -> {
            metricValues[0].setText(String.valueOf(resumen.tomasRealizadas()));
            metricValues[1].setText(String.valueOf(resumen.tomasAbiertas()));
            metricValues[2].setText(String.valueOf(resumen.tomasConciliadas()));
            metricValues[3].setText(String.valueOf(resumen.productosConDiferencias()));
            metricValues[4].setText(String.valueOf(resumen.ajustesPendientes()));
        });
        refreshTakes();
        loadHistory("");
        loadTakeOptions();
    }

    private void refreshTakes() {
        EstadoToma state = stateDashboard.getSelectedIndex() <= 0 ? null : EstadoToma.valueOf((String) stateDashboard.getSelectedItem());
        async("Cargando tomas", () -> controller.listarTomas(searchDashboard.getText(), state), items -> {
            dashboardModel.setRowCount(0);
            for (Toma t : items) dashboardModel.addRow(new Object[]{t.id(), t.codigo(), t.almacen(), format(t.fechaInicio()), t.responsable(), t.totalProductos(), t.productosContados(), t.productosDiferencia(), t.avancePorcentaje() + "%", t.estado()});
            statusBar.setText("Tomas encontradas: " + items.size());
        });
    }

    private void loadTakeOptions() {
        async("Cargando tomas para conciliación", () -> controller.listarTomas("", null), items -> {
            reconciliationTake.removeAllItems();
            for (Toma t : items) reconciliationTake.addItem(t);
            reconciliationTake.setRenderer(new DefaultListCellRenderer() {
                @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
                    super.getListCellRendererComponent(list, value, index, selected, focus);
                    if (value instanceof Toma t) setText(t.codigo() + " · " + t.almacen() + " · " + t.estado());
                    return this;
                }
            });
        });
    }

    private void loadHistory(String filter) {
        async("Cargando historial", () -> controller.listarTomas(filter, null), items -> {
            historyModel.setRowCount(0);
            for (Toma t : items) historyModel.addRow(new Object[]{t.id(), t.codigo(), t.almacen(), format(t.fechaInicio()), t.responsable(), t.totalProductos(), t.productosDiferencia(), t.estado()});
        });
    }

    private void loadDifferences() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) return;
        async("Cargando diferencias", () -> controller.listarDiferencias(t.id()), this::showDifferences);
    }

    private void showDifferences(List<Diferencia> list) {
        reconciliationModel.setRowCount(0);
        for (Diferencia d : list) {
            reconciliationModel.addRow(new Object[]{d.producto().codigo(), d.producto().nombre(), fmt(d.stockSistema()), fmt(d.cantidadFisica()), fmt(d.diferencia()), money(d.costoPromedio()), money(d.valorDiferencia()), d.tipo(), d.estadoRevision()});
        }
        statusBar.setText("Registros de conciliación: " + list.size());
    }

    private void executeReconciliation() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) { warn("Selecciona una toma."); return; }
        int yes = JOptionPane.showConfirmDialog(this, "¿Ejecutar conciliación de " + t.codigo() + "?", "Confirmar conciliación", JOptionPane.YES_NO_OPTION);
        if (yes != JOptionPane.YES_OPTION) return;
        async("Conciliando inventario", () -> controller.conciliar(t.id()), list -> {
            showDifferences(list); refreshAll();
            JOptionPane.showMessageDialog(this, "Conciliación realizada. Revisa los productos con diferencias.", "Conciliación", JOptionPane.INFORMATION_MESSAGE);
        });
    }

    private void openNewTake() {
        new NuevaTomaDialog(this, controller, t -> { refreshAll(); openCount(t.id()); }).setVisible(true);
    }

    private void openCountForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        openCount(id);
    }

    private void openCount(long id) { new RegistroConteoDialog(this, controller, id, this::refreshAll).setVisible(true); }

    private void openReconciliationForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        tabs.setSelectedIndex(1);
        for (int i = 0; i < reconciliationTake.getItemCount(); i++) if (reconciliationTake.getItemAt(i).id() == id) reconciliationTake.setSelectedIndex(i);
        loadDifferences();
    }

    private void openDetailsForSelected() {
        long id = dashboardSelectedId();
        if (id == -1) { warn("Selecciona una toma de la tabla."); return; }
        openDetails(id);
    }

    private void openDetails(long id) { if (id != -1) new DetalleTomaDialog(this, controller, id).setVisible(true); }

    private void openDifferenceDetail() {
        int row = reconciliationTable.getSelectedRow();
        if (row < 0) { warn("Selecciona un producto."); return; }
        String code = String.valueOf(reconciliationModel.getValueAt(row, 0));
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) return;
        async("Buscando diferencia", () -> controller.listarDiferencias(t.id()).stream().filter(d -> d.producto().codigo().equals(code)).findFirst().orElse(null), d -> {
            if (d != null) new DetalleDiferenciasDialog(this, controller, t.id(), d, this::loadDifferences).setVisible(true);
        });
    }

    private void manageAdjustment() {
        int row = reconciliationTable.getSelectedRow();
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (row < 0 || t == null) { warn("Selecciona una diferencia."); return; }
        String code = String.valueOf(reconciliationModel.getValueAt(row, 0));
        async("Buscando producto", () -> controller.listarDiferencias(t.id()).stream().filter(d -> d.producto().codigo().equals(code)).findFirst().orElse(null), d -> {
            if (d != null) new AjusteInventarioDialog(this, controller, t.id(), d, () -> { loadDifferences(); refreshAll(); }).setVisible(true);
        });
    }

    private void closeTake() {
        Toma t = (Toma) reconciliationTake.getSelectedItem();
        if (t == null) { warn("Selecciona una toma."); return; }
        int yes = JOptionPane.showConfirmDialog(this, "Cerrar " + t.codigo() + "? Una toma cerrada queda en consulta.", "Cerrar toma", JOptionPane.YES_NO_OPTION);
        if (yes == JOptionPane.YES_OPTION) async("Cerrando toma", () -> { controller.cerrarToma(t.id()); return true; }, ok -> { refreshAll(); loadDifferences(); info("Toma cerrada correctamente."); });
    }

    private long dashboardSelectedId() { int r = dashboardTable.getSelectedRow(); return r < 0 ? -1 : ((Number) dashboardModel.getValueAt(dashboardTable.convertRowIndexToModel(r), 0)).longValue(); }
    private long historySelectedId() { int r = historyTable.getSelectedRow(); return r < 0 ? -1 : ((Number) historyModel.getValueAt(historyTable.convertRowIndexToModel(r), 0)).longValue(); }

    private <T> void async(String message, Callable<T> task, Consumer<T> success) {
        statusBar.setText(message + "...");
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return task.call(); }
            @Override protected void done() {
                try { T result = get(); success.accept(result); statusBar.setText(message + " · completado"); }
                catch (Exception ex) { Throwable cause = ex.getCause() == null ? ex : ex.getCause(); statusBar.setText("No se pudo completar la operación"); error(cause); }
            }
        }.execute();
    }

    private static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) { @Override public boolean isCellEditable(int row, int column) { return false; } };
    }
    private static JTable table(DefaultTableModel model) { return new JTable(model); }
    private static JButton primaryButton(String text) { JButton b = new JButton(text); b.setBackground(BLUE); b.setForeground(Color.WHITE); b.setFocusPainted(false); b.setBorder(new EmptyBorder(8, 13, 8, 13)); return b; }
    private static JButton secondaryButton(String text) { JButton b = new JButton(text); b.setBackground(new Color(238, 243, 249)); b.setForeground(TEXT); b.setFocusPainted(false); b.setBorder(new EmptyBorder(8, 12, 8, 12)); return b; }
    private static String format(java.time.LocalDateTime date) { return date == null ? "—" : DATE.format(date); }
    private static String fmt(BigDecimal value) { return value == null ? "—" : value.stripTrailingZeros().toPlainString(); }
    private static String money(BigDecimal value) { return value == null ? "—" : MONEY.format(value); }
    private static void warn(String s) { JOptionPane.showMessageDialog(null, s, "Validación", JOptionPane.WARNING_MESSAGE); }
    private static void info(String s) { JOptionPane.showMessageDialog(null, s, "Inventario físico", JOptionPane.INFORMATION_MESSAGE); }
    private static void error(Throwable t) { JOptionPane.showMessageDialog(null, t.getMessage() == null ? t.toString() : t.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }

    private static class ZebraRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
            Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
            if (!selected) c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 253));
            setBorder(new EmptyBorder(2, 7, 2, 7));
            if (value instanceof EstadoToma || value instanceof TipoDiferencia) {
                String s = value.toString();
                setForeground(s.contains("FALTANTE") || s.equals("CANCELADA") ? RED : s.contains("SOBRANTE") || s.equals("EN_REVISION") ? AMBER : s.contains("CONFORME") || s.equals("CERRADA") || s.equals("APROBADA") ? GREEN : TEXT);
                setFont(getFont().deriveFont(Font.BOLD));
            } else if (!selected) setForeground(TEXT);
            return c;
        }
    }

    // ------------------------------ NUEVA TOMA ------------------------------
    private static final class NuevaTomaDialog extends JDialog {
        private final InventarioFisicoController controller;
        private final Consumer<Toma> onCreated;
        private final JComboBox<String> warehouse = new JComboBox<>();
        private final JComboBox<String> scope = new JComboBox<>(new String[]{"Todos los productos", "Productos seleccionados"});
        private final JComboBox<String> category = new JComboBox<>();
        private final JCheckBox zero = new JCheckBox("Incluir productos con stock cero", true);
        private final JCheckBox blind = new JCheckBox("Conteo ciego (ocultar stock del sistema)", true);
        private final JCheckBox second = new JCheckBox("Permitir segundo conteo", true);
        private final JCheckBox partial = new JCheckBox("Permitir conteo parcial", false);
        private final JTextArea notes = new JTextArea(3, 30);
        private final Set<Long> selectedProducts = new LinkedHashSet<>();
        private final JLabel selectionLabel = new JLabel("No se han seleccionado productos");

        NuevaTomaDialog(Frame owner, InventarioFisicoController controller, Consumer<Toma> onCreated) {
            super(owner, "Nueva toma de inventario físico", true);
            this.controller = controller; this.onCreated = onCreated;
            setSize(650, 620); setLocationRelativeTo(owner); setLayout(new BorderLayout(12, 12));
            JPanel form = new JPanel(new GridBagLayout()); form.setBorder(new EmptyBorder(18, 22, 10, 22)); form.setBackground(Color.WHITE);
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(6, 5, 6, 5); g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
            addField(form, g, 0, "Almacén", warehouse);
            addField(form, g, 1, "Alcance", scope);
            addField(form, g, 2, "Categoría (referencia de filtro)", category);
            JPanel selectPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); selectPanel.setOpaque(false);
            JButton select = secondaryButton("Seleccionar productos..."); selectPanel.add(select); selectPanel.add(selectionLabel);
            addField(form, g, 3, "Selección", selectPanel);
            JPanel options = new JPanel(new GridLayout(0, 1, 3, 3)); options.setOpaque(false);
            options.add(zero); options.add(blind); options.add(second); options.add(partial);
            addField(form, g, 4, "Configuración", options);
            notes.setLineWrap(true); notes.setWrapStyleWord(true);
            JScrollPane noteScroll = new JScrollPane(notes);
            addField(form, g, 5, "Observaciones", noteScroll);
            add(form, BorderLayout.CENTER);
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT)); buttons.setBorder(new EmptyBorder(0, 12, 12, 12));
            JButton cancel = secondaryButton("Cancelar"), create = primaryButton("Crear toma"); buttons.add(cancel); buttons.add(create); add(buttons, BorderLayout.SOUTH);
            scope.addActionListener(e -> select.setEnabled(scope.getSelectedIndex() == 1));
            select.setEnabled(false);
            select.addActionListener(e -> new SeleccionProductosDialog(this, controller, warehouse.getSelectedItem() == null ? "" : warehouse.getSelectedItem().toString(), (String) category.getSelectedItem(), selectedProducts).setVisible(true));
            cancel.addActionListener(e -> dispose());
            create.addActionListener(e -> createTake());
            loadOptions();
        }

        private void loadOptions() {
            warehouse.addItem("Cargando...");
            new SwingWorker<List<List<String>>, Void>() {
                @Override protected List<List<String>> doInBackground() throws Exception { return List.of(controller.listarAlmacenes(), controller.listarCategorias()); }
                @Override protected void done() { try { List<List<String>> r = get(); warehouse.removeAllItems(); r.get(0).forEach(warehouse::addItem); category.removeAllItems(); r.get(1).forEach(category::addItem); } catch (Exception ex) { error(ex); } }
            }.execute();
        }

        private void createTake() {
            String almacen = (String) warehouse.getSelectedItem();
            String alcance = (String) scope.getSelectedItem();
            if (almacen == null || almacen.isBlank() || almacen.equals("Cargando...")) { warn("Selecciona un almacén."); return; }
            if (alcance.equals("Productos seleccionados") && selectedProducts.isEmpty()) { warn("Selecciona al menos un producto."); return; }
            NuevaToma command = new NuevaToma(almacen, alcance, (String) category.getSelectedItem(), zero.isSelected(), blind.isSelected(), second.isSelected(), partial.isSelected(), notes.getText(), new ArrayList<>(selectedProducts));
            setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            new SwingWorker<Toma, Void>() {
                @Override protected Toma doInBackground() throws Exception { return controller.crearToma(command); }
                @Override protected void done() { setCursor(Cursor.getDefaultCursor()); try { Toma t = get(); dispose(); onCreated.accept(t); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }

        private static void addField(JPanel p, GridBagConstraints g, int row, String label, Component component) {
            g.gridx = 0; g.gridy = row; g.weightx = 0; p.add(new JLabel(label + ":"), g);
            g.gridx = 1; g.weightx = 1; p.add(component, g);
        }
    }

    // --------------------------- SELECCIÓN PRODUCTOS -------------------------
    private static final class SeleccionProductosDialog extends JDialog {
        private final InventarioFisicoController controller;
        private final String warehouse;
        private final String category;
        private final Set<Long> selected;
        private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Seleccionar", "Código", "Producto", "Categoría", "Unidad", "Stock", "ID"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return c == 0; }
            @Override public Class<?> getColumnClass(int c) { return c == 0 ? Boolean.class : Object.class; }
        };
        private final JTable table = new JTable(model);
        private final JTextField search = new JTextField(18);

        SeleccionProductosDialog(Dialog owner, InventarioFisicoController controller, String warehouse, String category, Set<Long> selected) {
            super(owner, "Seleccionar productos para la toma", true);
            this.controller = controller; this.warehouse = warehouse; this.category = category; this.selected = selected;
            setSize(780, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
            JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Buscar:")); top.add(search); JButton find = secondaryButton("Buscar"); top.add(find); add(top, BorderLayout.NORTH);
            model.setRowCount(0); table.setRowHeight(27); table.getColumnModel().getColumn(0).setMaxWidth(85); table.getColumnModel().getColumn(6).setMinWidth(0); table.getColumnModel().getColumn(6).setMaxWidth(0); table.getColumnModel().getColumn(6).setWidth(0);
            add(new JScrollPane(table), BorderLayout.CENTER);
            JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton cancel = secondaryButton("Cancelar"), accept = primaryButton("Aplicar selección"); bottom.add(cancel); bottom.add(accept); add(bottom, BorderLayout.SOUTH);
            find.addActionListener(e -> load()); search.addActionListener(e -> load());
            cancel.addActionListener(e -> dispose()); accept.addActionListener(e -> { updateSelection(); dispose(); });
            load();
        }
        private void load() {
            new SwingWorker<List<Producto>, Void>() {
                @Override protected List<Producto> doInBackground() throws Exception { return controller.listarProductosDisponibles(search.getText(), category, warehouse); }
                @Override protected void done() { try { model.setRowCount(0); for (Producto p : get()) model.addRow(new Object[]{selected.contains(p.id()), p.codigo(), p.nombre(), p.categoria(), p.unidad(), p.stockSistema(), p.id()}); } catch (Exception ex) { error(ex); } }
            }.execute();
        }
        private void updateSelection() {
            // Solo se actualizan los productos visibles; las selecciones de búsquedas anteriores se conservan.
            for (int i = 0; i < model.getRowCount(); i++) {
                try {
                    long id = ((Number) model.getValueAt(i, 6)).longValue();
                    if (Boolean.TRUE.equals(model.getValueAt(i, 0))) selected.add(id);
                    else selected.remove(id);
                } catch (Exception ignored) { }
            }
        }
    }

    // ------------------------------ REGISTRO CONTEO --------------------------
    private static final class RegistroConteoDialog extends JDialog {
        private final InventarioFisicoController controller;
        private final long idToma;
        private final Runnable onChanged;
        private final DefaultTableModel model = model("ID", "Código", "Producto", "Unidad", "Ubicación", "Stock sistema", "Conteo 1", "Conteo 2", "Estado", "Observación");
        private final JTable table = table(model);
        private final JTextField quantity = new JTextField(10);
        private final JTextField observation = new JTextField(28);
        private final JCheckBox second = new JCheckBox("Registrar segundo conteo");
        private boolean secondAllowed = true;
        private boolean blindMode = true;
        private final JLabel countTitle = new JLabel();
        private final JProgressBar progress = new JProgressBar(0, 100);
        private final JLabel selectedProduct = new JLabel("Selecciona un producto de la tabla");

        RegistroConteoDialog(Frame owner, InventarioFisicoController controller, long idToma, Runnable onChanged) {
            super(owner, "Registro de conteo físico", true);
            this.controller = controller; this.idToma = idToma; this.onChanged = onChanged;
            setSize(1120, 650); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
            JPanel north = new JPanel(new BorderLayout()); north.setBorder(new EmptyBorder(12, 14, 0, 14));
            countTitle.setText("REGISTRO DE CONTEO · Toma ID " + idToma); countTitle.setFont(countTitle.getFont().deriveFont(Font.BOLD, 17f)); north.add(countTitle, BorderLayout.NORTH); north.add(progress, BorderLayout.SOUTH); add(north, BorderLayout.NORTH);
            table.setRowHeight(27); table.getColumnModel().getColumn(0).setMaxWidth(0); table.getColumnModel().getColumn(0).setMinWidth(0);
            add(new JScrollPane(table), BorderLayout.CENTER);
            JPanel editor = new JPanel(new GridBagLayout()); editor.setBorder(new EmptyBorder(8, 14, 8, 14));
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(4, 5, 4, 5); g.anchor = GridBagConstraints.WEST;
            g.gridx = 0; g.gridy = 0; editor.add(selectedProduct, g); g.gridx = 1; editor.add(new JLabel("Cantidad física:"), g); g.gridx = 2; editor.add(quantity, g); g.gridx = 3; editor.add(second, g);
            g.gridx = 0; g.gridy = 1; editor.add(new JLabel("Observación:"), g); g.gridx = 1; g.gridwidth = 3; editor.add(observation, g); g.gridwidth = 1;
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton save = primaryButton("Guardar conteo"), reload = secondaryButton("Actualizar"), reconcile = secondaryButton("Ir a conciliación"), close = secondaryButton("Cerrar"); buttons.add(save); buttons.add(reload); buttons.add(reconcile); buttons.add(close);
            JPanel south = new JPanel(new BorderLayout()); south.add(editor, BorderLayout.CENTER); south.add(buttons, BorderLayout.SOUTH); add(south, BorderLayout.SOUTH);
            table.getSelectionModel().addListSelectionListener(e -> showSelected());
            save.addActionListener(e -> saveCount()); reload.addActionListener(e -> load()); close.addActionListener(e -> dispose());
            reconcile.addActionListener(e -> { onChanged.run(); dispose(); JOptionPane.showMessageDialog(owner, "Selecciona la toma en la pestaña Conciliación para comparar los resultados."); });
            second.setEnabled(true); load();
        }
        private void load() {
            new SwingWorker<List<Producto>, Void>() {
                @Override protected List<Producto> doInBackground() throws Exception { secondAllowed = controller.permiteSegundoConteo(idToma); blindMode = controller.esConteoCiego(idToma); return controller.listarProductosToma(idToma, blindMode); }
                @Override protected void done() { try { List<Producto> ps = get(); second.setEnabled(secondAllowed); countTitle.setText((blindMode ? "REGISTRO DE CONTEO CIEGO" : "REGISTRO DE CONTEO") + " · Toma ID " + idToma); model.setRowCount(0); int counted = 0; for (Producto p : ps) { if (p.cantidadFinal() != null) counted++; model.addRow(new Object[]{p.id(), p.codigo(), p.nombre(), p.unidad(), p.ubicacion(), blindMode ? "OCULTO" : fmt(p.stockSistema()), fmt(p.cantidadContada()), fmt(p.segundoConteo()), p.estado(), p.observacion()}); } progress.setMaximum(Math.max(1, ps.size())); progress.setValue(counted); progress.setStringPainted(true); progress.setString(counted + " / " + ps.size() + " productos contados"); } catch (Exception ex) { error(ex); } }
            }.execute();
        }
        private void showSelected() { int r = table.getSelectedRow(); if (r < 0) return; selectedProduct.setText(model.getValueAt(r, 1) + " · " + model.getValueAt(r, 2)); quantity.setText(second.isSelected() ? String.valueOf(model.getValueAt(r, 7)).replace("—", "") : String.valueOf(model.getValueAt(r, 6)).replace("—", "")); observation.setText(String.valueOf(model.getValueAt(r, 9))); }
        private void saveCount() {
            int r = table.getSelectedRow(); if (r < 0) { warn("Selecciona un producto."); return; }
            BigDecimal qty;
            try { qty = new BigDecimal(quantity.getText().trim().replace(',', '.')); } catch (Exception ex) { warn("Ingresa una cantidad válida."); return; }
            if (qty.signum() < 0 || qty.scale() > 3) { warn("La cantidad debe ser cero o mayor y no superar 3 decimales."); return; }
            String unidad = String.valueOf(model.getValueAt(table.convertRowIndexToModel(r), 3)).toUpperCase(Locale.ROOT);
            if (Set.of("UNIDAD", "CAJA", "PAQUETE").contains(unidad) && qty.stripTrailingZeros().scale() > 0) { warn("La unidad " + unidad + " solo admite cantidades enteras."); return; }
            if (second.isSelected() && !secondAllowed) { warn("El segundo conteo no está habilitado para esta toma."); return; }
            long id = ((Number) model.getValueAt(table.convertRowIndexToModel(r), 0)).longValue();
            boolean isSecond = second.isSelected();
            new SwingWorker<Void, Void>() {
                @Override protected Void doInBackground() throws Exception { controller.registrarConteo(idToma, id, qty, observation.getText(), isSecond); return null; }
                @Override protected void done() { try { get(); load(); onChanged.run(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }
    }

    // ------------------------------ DETALLE DIFERENCIA -----------------------
    private static final class DetalleDiferenciasDialog extends JDialog {
        DetalleDiferenciasDialog(Frame owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable onSaved) {
            super(owner, "Detalle de diferencia", true); setSize(590, 500); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
            JPanel details = new JPanel(new GridLayout(0, 2, 8, 8)); details.setBorder(new EmptyBorder(18, 20, 8, 20));
            addPair(details, "Código", d.producto().codigo()); addPair(details, "Producto", d.producto().nombre()); addPair(details, "Almacén / ubicación", d.producto().ubicacion());
            addPair(details, "Stock del sistema", fmt(d.stockSistema())); addPair(details, "Cantidad física", fmt(d.cantidadFisica())); addPair(details, "Diferencia", fmt(d.diferencia()));
            addPair(details, "Costo promedio", money(d.costoPromedio())); addPair(details, "Valor de diferencia", money(d.valorDiferencia())); addPair(details, "Clasificación", d.tipo().toString());
            add(details, BorderLayout.NORTH);
            JTextArea note = new JTextArea(d.motivo() == null ? "" : d.motivo(), 5, 35); note.setLineWrap(true); note.setWrapStyleWord(true);
            JPanel notePanel = new JPanel(new BorderLayout(5, 5)); notePanel.setBorder(new EmptyBorder(0, 20, 8, 20)); notePanel.add(new JLabel("Observaciones / explicación:"), BorderLayout.NORTH); notePanel.add(new JScrollPane(note), BorderLayout.CENTER); add(notePanel, BorderLayout.CENTER);
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton save = primaryButton("Guardar observación"), close = secondaryButton("Cerrar"); actions.add(save); actions.add(close); add(actions, BorderLayout.SOUTH);
            save.addActionListener(e -> new SwingWorker<Void, Void>() { @Override protected Void doInBackground() throws Exception { controller.guardarObservacion(idToma, d.producto().id(), note.getText()); return null; } @Override protected void done() { try { get(); onSaved.run(); dispose(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } } }.execute());
            close.addActionListener(e -> dispose());
        }
    }

    // -------------------------------- AJUSTE ----------------------------------
    private static final class AjusteInventarioDialog extends JDialog {
        AjusteInventarioDialog(Frame owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable onChanged) {
            super(owner, "Solicitud y aprobación de ajuste", true); setSize(640, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
            JPanel info = new JPanel(new GridLayout(0, 2, 8, 7)); info.setBorder(new EmptyBorder(16, 18, 8, 18));
            addPair(info, "Producto", d.producto().codigo() + " · " + d.producto().nombre()); addPair(info, "Stock del sistema", fmt(d.stockSistema())); addPair(info, "Cantidad física", fmt(d.cantidadFisica())); addPair(info, "Diferencia", fmt(d.diferencia())); addPair(info, "Valor referencial", money(d.valorDiferencia())); addPair(info, "Estado del ajuste", d.estadoRevision());
            add(info, BorderLayout.NORTH);
            JPanel form = new JPanel(new GridBagLayout()); form.setBorder(new EmptyBorder(0, 18, 8, 18));
            JComboBox<String> reason = new JComboBox<>(new String[]{"Pérdida", "Deterioro", "Error de registro", "Error de recepción", "Error de despacho", "Producto mal ubicado", "Unidad de medida", "Sobrante no registrado", "Otro"});
            JTextArea note = new JTextArea(4, 34); note.setLineWrap(true); note.setWrapStyleWord(true);
            GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(5, 4, 5, 4); g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
            g.gridx = 0; g.gridy = 0; form.add(new JLabel("Motivo:"), g); g.gridx = 1; form.add(reason, g);
            g.gridx = 0; g.gridy = 1; form.add(new JLabel("Observaciones:"), g); g.gridx = 1; form.add(new JScrollPane(note), g); add(form, BorderLayout.CENTER);
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT)); JButton request = secondaryButton("Solicitar ajuste"), approve = primaryButton("Aprobar"), reject = secondaryButton("Rechazar"), close = secondaryButton("Cerrar"); actions.add(request); actions.add(approve); actions.add(reject); actions.add(close); add(actions, BorderLayout.SOUTH);
            request.addActionListener(e -> run(() -> controller.solicitarAjuste(idToma, d.producto().id(), (String) reason.getSelectedItem(), note.getText()), "Solicitud de ajuste registrada.", onChanged));
            approve.addActionListener(e -> { if (!"PENDIENTE".equalsIgnoreCase(d.estadoRevision())) { warn("Primero debe existir una solicitud pendiente."); return; } int yes = JOptionPane.showConfirmDialog(this, "¿Aprobar el ajuste? La actualización real de inventario debe ejecutarse en el servicio transaccional.", "Aprobar ajuste", JOptionPane.YES_NO_OPTION); if (yes == JOptionPane.YES_OPTION) run(() -> controller.aprobarAjuste(idToma, d.producto().id()), "Ajuste aprobado.", onChanged); });
            reject.addActionListener(e -> run(() -> controller.rechazarAjuste(idToma, d.producto().id(), note.getText()), "Ajuste rechazado.", onChanged));
            close.addActionListener(e -> dispose());
        }
        private void run(ThrowingRunnable action, String message, Runnable changed) {
            new SwingWorker<Void, Void>() { @Override protected Void doInBackground() throws Exception { action.run(); return null; } @Override protected void done() { try { get(); info(message); changed.run(); dispose(); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } } }.execute();
        }
    }

    // -------------------------------- HISTORIAL/DETALLE -----------------------
    private static final class DetalleTomaDialog extends JDialog {
        DetalleTomaDialog(Frame owner, InventarioFisicoController controller, long idToma) {
            super(owner, "Detalle de toma física · " + idToma, true); setSize(930, 650); setLocationRelativeTo(owner); setLayout(new BorderLayout());
            JTabbedPane panes = new JTabbedPane();
            JPanel productPanel = new JPanel(new BorderLayout()); DefaultTableModel pm = model("Código", "Producto", "Ubicación", "Unidad", "Stock sistema", "Conteo 1", "Conteo 2", "Estado", "Observación"); JTable pt = table(pm); productPanel.add(new JScrollPane(pt), BorderLayout.CENTER);
            JPanel diffPanel = new JPanel(new BorderLayout()); DefaultTableModel dm = model("Código", "Producto", "Sistema", "Físico", "Diferencia", "Valor", "Tipo", "Ajuste"); JTable dt = table(dm); diffPanel.add(new JScrollPane(dt), BorderLayout.CENTER);
            JTextArea audit = new JTextArea(); audit.setEditable(false); audit.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            JPanel general = new JPanel(new GridLayout(0, 2, 10, 10)); general.setBorder(new EmptyBorder(20, 20, 20, 20));
            JLabel code = new JLabel("Código: cargando..."); JLabel warehouse = new JLabel("Almacén: —"); JLabel responsible = new JLabel("Responsable: —"); JLabel start = new JLabel("Inicio: —"); JLabel status = new JLabel("Estado: —"); JLabel progress = new JLabel("Avance: —");
            general.add(code); general.add(warehouse); general.add(responsible); general.add(start); general.add(status); general.add(progress);
            panes.addTab("General", general); panes.addTab("Productos y conteos", productPanel); panes.addTab("Diferencias", diffPanel); panes.addTab("Auditoría", new JScrollPane(audit)); add(panes, BorderLayout.CENTER);
            JButton close = secondaryButton("Cerrar"); JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); bottom.add(close); add(bottom, BorderLayout.SOUTH); close.addActionListener(e -> dispose());
            new SwingWorker<Object[], Void>() {
                @Override protected Object[] doInBackground() throws Exception { Toma t = controller.listarTomas("", null).stream().filter(x -> x.id() == idToma).findFirst().orElse(null); return new Object[]{t, controller.listarProductosToma(idToma, false), controller.listarDiferencias(idToma), controller.listarAuditoria(idToma)}; }
                @SuppressWarnings("unchecked") @Override protected void done() { try { Object[] r = get(); Toma toma = (Toma) r[0]; if (toma != null) { code.setText("Código: " + toma.codigo()); warehouse.setText("Almacén: " + toma.almacen()); responsible.setText("Responsable: " + toma.responsable()); start.setText("Inicio: " + format(toma.fechaInicio())); status.setText("Estado: " + toma.estado()); progress.setText("Avance: " + toma.avancePorcentaje() + "%"); } for (Producto p : (List<Producto>) r[1]) pm.addRow(new Object[]{p.codigo(), p.nombre(), p.ubicacion(), p.unidad(), "OCULTO", fmt(p.cantidadContada()), fmt(p.segundoConteo()), p.estado(), p.observacion()}); for (Diferencia d : (List<Diferencia>) r[2]) dm.addRow(new Object[]{d.producto().codigo(), d.producto().nombre(), fmt(d.stockSistema()), fmt(d.cantidadFisica()), fmt(d.diferencia()), money(d.valorDiferencia()), d.tipo(), d.estadoRevision()}); audit.setText(String.join("\n", (List<String>) r[3])); } catch (Exception ex) { error(ex.getCause() == null ? ex : ex.getCause()); } }
            }.execute();
        }
    }

    // -------------------------------- REPORTES -------------------------------
    private final class ReportPanel extends JPanel {
        private final JLabel totalTakes = new JLabel("—"), totalOpen = new JLabel("—"), totalDiff = new JLabel("—"), totalPending = new JLabel("—");
        ReportPanel() {
            super(new BorderLayout(12, 12)); setOpaque(false);
            JPanel cards = new JPanel(new GridLayout(1, 4, 10, 10)); cards.setOpaque(false);
            cards.add(reportMetric("Tomas", totalTakes)); cards.add(reportMetric("Abiertas", totalOpen)); cards.add(reportMetric("Productos con diferencia", totalDiff)); cards.add(reportMetric("Ajustes pendientes", totalPending));
            add(cards, BorderLayout.NORTH);
            ChartPanel chart = new ChartPanel(); add(chart, BorderLayout.CENTER);
            JButton refresh = secondaryButton("Actualizar indicadores"); JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT)); bottom.setOpaque(false); bottom.add(refresh); add(bottom, BorderLayout.SOUTH);
            refresh.addActionListener(e -> loadReport(chart)); loadReport(chart);
        }
        private JPanel reportMetric(String title, JLabel value) { JPanel p = new JPanel(new BorderLayout(4, 8)); p.setBackground(Color.WHITE); p.setBorder(new EmptyBorder(15, 15, 15, 15)); JLabel l = new JLabel(title); l.setForeground(MUTED); value.setFont(value.getFont().deriveFont(Font.BOLD, 25f)); value.setForeground(NAVY); p.add(l, BorderLayout.NORTH); p.add(value, BorderLayout.CENTER); return p; }
        private void loadReport(ChartPanel chart) { async("Actualizando reporte", controller::obtenerResumen, r -> { totalTakes.setText(String.valueOf(r.tomasRealizadas())); totalOpen.setText(String.valueOf(r.tomasAbiertas())); totalDiff.setText(String.valueOf(r.productosConDiferencias())); totalPending.setText(String.valueOf(r.ajustesPendientes())); chart.setData(r); }); }
    }

    private static final class ChartPanel extends JPanel {
        private Resumen data = new Resumen(0, 0, 0, 0, 0);
        ChartPanel() { setBackground(Color.WHITE); setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)), new EmptyBorder(18, 18, 18, 18))); }
        void setData(Resumen data) { this.data = data; repaint(); }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g); Graphics2D g2 = (Graphics2D) g.create(); g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT); g2.setFont(getFont().deriveFont(Font.BOLD, 15f)); g2.drawString("Indicadores del inventario físico", 20, 28);
            String[] labels = {"Tomas abiertas", "Conciliadas", "Productos con diferencias", "Ajustes pendientes"};
            int[] values = {data.tomasAbiertas(), data.tomasConciliadas(), data.productosConDiferencias(), data.ajustesPendientes()};
            int max = Math.max(1, Arrays.stream(values).max().orElse(1)); int y = 70; int maxWidth = Math.max(100, getWidth() - 290);
            for (int i = 0; i < values.length; i++) {
                g2.setColor(MUTED); g2.setFont(getFont().deriveFont(12f)); g2.drawString(labels[i], 22, y + 17);
                int w = (int) (maxWidth * (values[i] / (double) max)); g2.setColor(new Color[]{BLUE, GREEN, AMBER, RED}[i]); g2.fillRoundRect(230, y, Math.max(3, w), 24, 8, 8);
                g2.setColor(TEXT); g2.drawString(String.valueOf(values[i]), 240 + w, y + 17); y += 62;
            }
            g2.dispose();
        }
    }

    private static void addPair(JPanel panel, String label, String value) { JLabel l = new JLabel(label + ":"); l.setForeground(MUTED); JLabel v = new JLabel(value == null ? "—" : value); v.setForeground(TEXT); panel.add(l); panel.add(v); }
    @FunctionalInterface private interface ThrowingRunnable { void run() throws Exception; }
}
