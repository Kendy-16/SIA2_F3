package pe.edu.inventario;

import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.migracion.AdministradorMigraciones;
import pe.edu.inventario.vista.LoginView;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        // Inicializar la base de datos.
        ConexionDB.inicializar();

        // Ejecutar las migraciones.
        AdministradorMigraciones.ejecutar();

        // Mostrar primero la pantalla de inicio de sesión.
        SwingUtilities.invokeLater(() -> {

            LoginView ventana = new LoginView();

            ventana.setVisible(true);

        });
    }
}