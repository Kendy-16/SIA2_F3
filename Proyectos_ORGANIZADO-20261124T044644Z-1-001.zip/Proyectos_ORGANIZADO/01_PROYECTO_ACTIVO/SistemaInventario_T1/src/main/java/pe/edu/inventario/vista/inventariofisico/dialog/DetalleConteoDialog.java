package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Ficha de solo lectura de un producto de la toma con sus conteos. */
public class DetalleConteoDialog extends JDialog {
    public DetalleConteoDialog(Window owner, Producto p, boolean conteoCiego) {
        super(owner, "Detalle de conteo · " + p.codigo(), ModalityType.APPLICATION_MODAL);
        setSize(520, 470); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
        JPanel datos = new JPanel(new GridLayout(0, 2, 8, 8));
        datos.setBorder(new EmptyBorder(18, 20, 8, 20));
        par(datos, "Código", p.codigo());
        par(datos, "Código de barras", p.codigoBarras());
        par(datos, "Producto", p.nombre());
        par(datos, "Categoría", p.categoria());
        par(datos, "Unidad", p.unidad());
        par(datos, "Ubicación", p.ubicacion());
        par(datos, "Stock del sistema", conteoCiego ? "OCULTO (conteo ciego)" : cantidad(p.stockSistema()));
        par(datos, "Conteo 1", cantidad(p.cantidadContada()));
        par(datos, "Conteo 2", cantidad(p.segundoConteo()));
        par(datos, "Cantidad final", cantidad(p.cantidadFinal()));
        par(datos, "Estado", String.valueOf(p.estado()));
        add(datos, BorderLayout.NORTH);
        PanelObservaciones obs = new PanelObservaciones("Observación:", 3);
        obs.setTexto(p.observacion());
        obs.setEditable(false);
        obs.setBorder(new EmptyBorder(0, 20, 8, 20));
        add(obs, BorderLayout.CENTER);
        JButton cerrar = botonSecundario("Cerrar");
        cerrar.addActionListener(e -> dispose());
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);
    }

    private static void par(JPanel panel, String etiqueta, String valor) {
        JLabel l = etiquetaSecundaria(etiqueta + ":");
        JLabel v = new JLabel(texto(valor)); v.setForeground(TEXT);
        panel.add(l); panel.add(v);
    }
}
