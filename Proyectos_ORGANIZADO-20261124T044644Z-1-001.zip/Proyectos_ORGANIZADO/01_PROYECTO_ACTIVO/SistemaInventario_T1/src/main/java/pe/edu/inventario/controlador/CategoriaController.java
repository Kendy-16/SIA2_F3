
package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.Categoria;
import pe.edu.inventario.servicio.CategoriaService;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controls category operations.
 *
 * Connects CategoriaView with CategoriaService.
 */
public class CategoriaController {

    // Service
    private final CategoriaService categoriaService;

    // Constructor
    public CategoriaController() {

        categoriaService = new CategoriaService();
    }

    // Register category
    public boolean registrarCategoria(Categoria categoria)
            throws SQLException {

        return categoriaService.registrar(categoria);
    }

    // List categories
    public ArrayList<Categoria> listarCategorias()
            throws SQLException {

        return categoriaService.listar();
    }

    // Search category by ID
    public Categoria buscarCategoria(int idCategoria)
            throws SQLException {

        return categoriaService.buscarPorId(idCategoria);
    }

    // Update category
    public boolean actualizarCategoria(Categoria categoria)
            throws SQLException {

        return categoriaService.actualizar(categoria);
    }

    // Delete category
    public boolean eliminarCategoria(int idCategoria)
            throws SQLException {

        return categoriaService.eliminar(idCategoria);
    }
}
