package pe.edu.inventario.servicio.auditoria;

import java.time.LocalDateTime;

public class AuditoriaService {
    
    // DAO inyectado para persistir en BD
    // private AuditoriaDAO auditoriaDAO; 

    public void registrarEvento(String tipoAccion, String idUsuarioAutorizador, String detalle) {
        // Objeto de registro
        String log = String.format("[%s] ACCION: %s | AUTORIZA: %s | DETALLE: %s", 
                LocalDateTime.now().toString(), tipoAccion, idUsuarioAutorizador, detalle);
        
        System.out.println("NUEVO REGISTRO DE AUDITORÍA: " + log);
        
        // auditoriaDAO.guardarRegistro(tipoAccion, idUsuarioAutorizador, detalle, LocalDateTime.now());
    }
}
