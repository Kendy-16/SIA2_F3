
package pe.edu.inventario.vista.almacen;

import pe.edu.inventario.controlador.AlmacenController;
import pe.edu.inventario.modelo.Almacen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class AlmacenView extends JPanel {

    private final AlmacenController controlador;

    private JTextField txtNombre;
    private JTextField txtUbicacion;
    private JTextField txtBuscar;

    private JTable tablaAlmacenes;
    private DefaultTableModel modeloTabla;

    private JLabel lblTotal;
    private JLabel lblEstado;

    private JButton btnNuevo;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;

    private int idSeleccionado = 0;

    private final Color COLOR_PRINCIPAL =
            new Color(31, 78, 121);

    private final Color COLOR_FONDO =
            new Color(245, 247, 250);

    public AlmacenView() {

        controlador = new AlmacenController();

        configurarPanel();
        inicializarComponentes();
        cargarAlmacenes();
        configurarEventos();
    }

    private void configurarPanel() {

        setLayout(new BorderLayout(12, 12));
        setBackground(COLOR_FONDO);
        setBorder(new EmptyBorder(18, 18, 18, 18));
    }

    private void inicializarComponentes() {

        add(crearEncabezado(), BorderLayout.NORTH);
        add(crearContenido(), BorderLayout.CENTER);
        add(crearPie(), BorderLayout.SOUTH);
    }

    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(COLOR_PRINCIPAL);
        panel.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel titulo = new JLabel("GESTION DE ALMACENES");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));

        JLabel subtitulo = new JLabel(
                "Administracion de almacenes y ubicaciones"
        );
        subtitulo.setForeground(Color.WHITE);
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 13));

        JPanel textos = new JPanel();
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(Box.createVerticalStrut(5));
        textos.add(subtitulo);

        panel.add(textos, BorderLayout.WEST);

        return panel;
    }

    private JPanel crearContenido() {

        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setOpaque(false);

        panel.add(crearFormulario(), BorderLayout.NORTH);
        panel.add(crearTabla(), BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearFormulario() {

        JPanel panel = new JPanel(new BorderLayout(10, 12));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 225, 230)
                ),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel titulo = new JLabel("DATOS DEL ALMACEN");
        titulo.setFont(new Font("Arial", Font.BOLD, 15));
        titulo.setForeground(COLOR_PRINCIPAL);

        JPanel campos = new JPanel(new GridLayout(2, 2, 12, 10));
        campos.setOpaque(false);

        txtNombre = new JTextField();
        txtUbicacion = new JTextField();

        configurarCampo(txtNombre);
        configurarCampo(txtUbicacion);

        campos.add(crearCampo("Nombre del almacen:", txtNombre));
        campos.add(crearCampo("Ubicacion:", txtUbicacion));

        JPanel botones = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 8, 5)
        );
        botones.setOpaque(false);

        btnNuevo = crearBoton("Nuevo", new Color(108, 117, 125));
        btnGuardar = crearBoton("Guardar", new Color(40, 167, 69));
        btnActualizar = crearBoton("Actualizar", COLOR_PRINCIPAL);
        btnEliminar = crearBoton("Eliminar", new Color(220, 53, 69));
        btnLimpiar = crearBoton("Limpiar", new Color(108, 117, 125));

        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        JPanel inferior = new JPanel(new BorderLayout());
        inferior.setOpaque(false);
        inferior.add(botones, BorderLayout.WEST);

        panel.add(titulo, BorderLayout.NORTH);
        panel.add(campos, BorderLayout.CENTER);
        panel.add(inferior, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearCampo(String etiqueta, JTextField campo) {

        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setOpaque(false);

        JLabel label = new JLabel(etiqueta);
        label.setFont(new Font("Arial", Font.BOLD, 12));

        panel.add(label, BorderLayout.NORTH);
        panel.add(campo, BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearTabla() {

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 225, 230)
                ),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel titulo = new JLabel("LISTADO DE ALMACENES");
        titulo.setFont(new Font("Arial", Font.BOLD, 15));
        titulo.setForeground(COLOR_PRINCIPAL);

        JPanel busqueda = new JPanel(new BorderLayout(8, 0));
        busqueda.setOpaque(false);

        txtBuscar = new JTextField();
        txtBuscar.setToolTipText("Buscar por nombre o ubicacion");

        JButton btnBuscar = crearBoton(
                "Buscar",
                COLOR_PRINCIPAL
        );

        JButton btnMostrarTodos = crearBoton(
                "Mostrar todos",
                new Color(108, 117, 125)
        );

        JPanel accionesBusqueda = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 5, 0)
        );
        accionesBusqueda.setOpaque(false);
        accionesBusqueda.add(btnBuscar);
        accionesBusqueda.add(btnMostrarTodos);

        busqueda.add(txtBuscar, BorderLayout.CENTER);
        busqueda.add(accionesBusqueda, BorderLayout.EAST);

        JPanel superior = new JPanel(new BorderLayout(10, 10));
        superior.setOpaque(false);
        superior.add(titulo, BorderLayout.NORTH);
        superior.add(busqueda, BorderLayout.CENTER);

        modeloTabla = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "NOMBRE DEL ALMACEN",
                        "UBICACION"
                },
                0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaAlmacenes = new JTable(modeloTabla);
        tablaAlmacenes.setRowHeight(27);
        tablaAlmacenes.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaAlmacenes.getTableHeader().setFont(
                new Font("Arial", Font.BOLD, 12)
        );
        tablaAlmacenes.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );
        tablaAlmacenes.setAutoCreateRowSorter(true);

        tablaAlmacenes.getColumnModel()
                .getColumn(0).setPreferredWidth(50);

        tablaAlmacenes.getColumnModel()
                .getColumn(1).setPreferredWidth(220);

        tablaAlmacenes.getColumnModel()
                .getColumn(2).setPreferredWidth(250);

        JScrollPane scroll = new JScrollPane(tablaAlmacenes);
        scroll.setPreferredSize(new Dimension(700, 260));

        lblTotal = new JLabel("Total de almacenes: 0");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 12));

        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inferior.setOpaque(false);
        inferior.add(lblTotal);

        panel.add(superior, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(inferior, BorderLayout.SOUTH);

        btnBuscar.addActionListener(e -> buscarAlmacenes());

        btnMostrarTodos.addActionListener(e -> {
            txtBuscar.setText("");
            cargarAlmacenes();
        });

        txtBuscar.addActionListener(e -> buscarAlmacenes());

        return panel;
    }

    private JPanel crearPie() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        lblEstado = new JLabel("Sistema de gestion de almacenes");
        lblEstado.setFont(new Font("Arial", Font.ITALIC, 11));

        panel.add(lblEstado, BorderLayout.WEST);

        return panel;
    }

    private void configurarCampo(JTextField campo) {

        campo.setFont(new Font("Arial", Font.PLAIN, 13));
        campo.setPreferredSize(new Dimension(200, 32));
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(190, 200, 210)
                ),
                new EmptyBorder(5, 8, 5, 8)
        ));
    }

    private JButton crearBoton(String texto, Color color) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Arial", Font.BOLD, 12));
        boton.setForeground(Color.WHITE);
        boton.setBackground(color);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setPreferredSize(new Dimension(105, 34));

        return boton;
    }

    private void configurarEventos() {

        btnNuevo.addActionListener(e -> limpiarFormulario());

        btnGuardar.addActionListener(e -> registrarAlmacen());

        btnActualizar.addActionListener(e -> actualizarAlmacen());

        btnEliminar.addActionListener(e -> eliminarAlmacen());

        btnLimpiar.addActionListener(e -> limpiarFormulario());

        tablaAlmacenes.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {
                        seleccionarAlmacen();
                    }
                });
    }

    private void registrarAlmacen() {

        try {

            Almacen almacen = new Almacen();

            almacen.setNombre(txtNombre.getText());
            almacen.setUbicacion(txtUbicacion.getText());

            boolean registrado =
                    controlador.registrarAlmacen(almacen);

            if (registrado) {

                mostrarMensaje(
                        "Almacen registrado correctamente.",
                        "Registro exitoso",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError("No se pudo registrar el almacen.");
            }

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());

        } catch (SQLException ex) {

            mostrarError("Error de base de datos: " + ex.getMessage());
        }
    }

    private void actualizarAlmacen() {

        if (idSeleccionado <= 0) {
            mostrarError("Seleccione un almacen de la tabla.");
            return;
        }

        try {

            Almacen almacen = new Almacen();

            almacen.setIdAlmacen(idSeleccionado);
            almacen.setNombre(txtNombre.getText());
            almacen.setUbicacion(txtUbicacion.getText());

            boolean actualizado =
                    controlador.actualizarAlmacen(almacen);

            if (actualizado) {

                mostrarMensaje(
                        "Almacen actualizado correctamente.",
                        "Actualizacion exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError("No se encontro el almacen seleccionado.");
            }

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());

        } catch (SQLException ex) {

            mostrarError("Error de base de datos: " + ex.getMessage());
        }
    }

    private void eliminarAlmacen() {

        if (idSeleccionado <= 0) {
            mostrarError("Seleccione un almacen de la tabla.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "Esta seguro de eliminar el almacen seleccionado?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean eliminado =
                    controlador.eliminarAlmacen(idSeleccionado);

            if (eliminado) {

                mostrarMensaje(
                        "Almacen eliminado correctamente.",
                        "Eliminacion exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError("No se pudo encontrar el almacen.");
            }

        } catch (SQLException ex) {

            mostrarError(
                    "No se puede eliminar el almacen. "
                    + "Puede tener movimientos o existencias asociadas.\n"
                    + ex.getMessage()
            );

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());
        }
    }

    private void cargarAlmacenes() {

        try {

            ArrayList<Almacen> almacenes =
                    controlador.listarAlmacenes();

            modeloTabla.setRowCount(0);

            for (Almacen almacen : almacenes) {

                modeloTabla.addRow(new Object[]{
                        almacen.getIdAlmacen(),
                        almacen.getNombre(),
                        almacen.getUbicacion() == null
                                ? ""
                                : almacen.getUbicacion()
                });
            }

            lblTotal.setText(
                    "Total de almacenes: " + almacenes.size()
            );

            lblEstado.setText("Listado actualizado correctamente.");

        } catch (SQLException ex) {

            mostrarError(
                    "No se pudieron cargar los almacenes: "
                    + ex.getMessage()
            );
        }
    }

    private void buscarAlmacenes() {

        String texto = txtBuscar.getText()
                .trim()
                .toLowerCase();

        if (texto.isEmpty()) {
            cargarAlmacenes();
            return;
        }

        try {

            ArrayList<Almacen> almacenes =
                    controlador.listarAlmacenes();

            modeloTabla.setRowCount(0);

            int encontrados = 0;

            for (Almacen almacen : almacenes) {

                String nombre = almacen.getNombre() == null
                        ? ""
                        : almacen.getNombre().toLowerCase();

                String ubicacion = almacen.getUbicacion() == null
                        ? ""
                        : almacen.getUbicacion().toLowerCase();

                if (nombre.contains(texto)
                        || ubicacion.contains(texto)) {

                    modeloTabla.addRow(new Object[]{
                            almacen.getIdAlmacen(),
                            almacen.getNombre(),
                            almacen.getUbicacion() == null
                                    ? ""
                                    : almacen.getUbicacion()
                    });

                    encontrados++;
                }
            }

            lblTotal.setText(
                    "Almacenes encontrados: " + encontrados
            );

            lblEstado.setText("Busqueda finalizada.");

        } catch (SQLException ex) {

            mostrarError("Error durante la busqueda: " + ex.getMessage());
        }
    }

    private void seleccionarAlmacen() {

        int filaVista = tablaAlmacenes.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo = tablaAlmacenes.convertRowIndexToModel(filaVista);

        idSeleccionado = Integer.parseInt(
                modeloTabla.getValueAt(filaModelo, 0).toString()
        );

        txtNombre.setText(
                modeloTabla.getValueAt(filaModelo, 1).toString()
        );

        txtUbicacion.setText(
                modeloTabla.getValueAt(filaModelo, 2).toString()
        );

        lblEstado.setText(
                "Almacen seleccionado: " + idSeleccionado
        );
    }

    private void limpiarFormulario() {

        idSeleccionado = 0;

        txtNombre.setText("");
        txtUbicacion.setText("");

        tablaAlmacenes.clearSelection();

        lblEstado.setText("Formulario listo para registrar.");

        txtNombre.requestFocus();
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    private void mostrarMensaje(
            String mensaje,
            String titulo,
            int tipo
    ) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                titulo,
                tipo
        );
    }
}
