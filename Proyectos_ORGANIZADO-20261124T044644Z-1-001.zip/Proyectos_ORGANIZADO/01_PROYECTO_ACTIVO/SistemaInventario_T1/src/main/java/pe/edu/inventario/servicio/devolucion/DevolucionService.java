package pe.edu.inventario.servicio.devolucion;

import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.seguridad.AutorizacionVentas;
import pe.edu.inventario.servicio.kardex.KardexService;
import pe.edu.inventario.servicio.caja.CajaService;
import java.math.BigDecimal;

public class DevolucionService {

    private KardexService kardexService;
    private CajaService cajaService;
    // DAO para registrar la devolución en BD...

    /**
     * Requisito: Autorizar devoluciones cuando corresponda.
     */
    public void procesarDevolucion(String idVenta, String codigoProducto, int cantidadDevuelta, BigDecimal montoADevolver, String motivo, RolUsuario rolActual, String idAdmin) throws Exception {
        
        if (!AutorizacionVentas.puedeAutorizarDevolucion(rolActual)) {
            throw new SecurityException("Solo el ADMINISTRADOR puede autorizar devoluciones.");
        }

        // 1. Validar que la venta exista y tenga ese producto (Omitido por brevedad)
        
        // 2. Devolver dinero de la caja
        cajaService.registrarEgresoPorDevolucion(idVenta, montoADevolver, motivo);

        // 3. Devolver producto al inventario (¡Sin editar Kardex a mano!)
        kardexService.registrarIngresoPorDevolucion(codigoProducto, cantidadDevuelta, "DEVOLUCION VENTA " + idVenta);

        // 4. Guardar registro de la devolución vinculada a la venta original
        // devolucionDAO.guardar(...);
    }
}
