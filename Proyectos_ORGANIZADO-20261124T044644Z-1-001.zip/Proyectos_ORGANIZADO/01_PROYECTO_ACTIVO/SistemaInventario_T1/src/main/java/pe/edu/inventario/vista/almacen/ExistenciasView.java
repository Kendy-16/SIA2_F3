package pe.edu.inventario.vista.almacen;

import pe.edu.inventario.modelo.dao.ReporteDAO;
import pe.edu.inventario.vista.reportes.PanelReporteTabla;

import java.awt.BorderLayout;
import javax.swing.JPanel;

/** Existencias por producto y almacén (alerta de stock mínimo). */
public class ExistenciasView extends JPanel {

    public ExistenciasView() {
        super(new BorderLayout());

        ReporteDAO dao = new ReporteDAO();

        add(new PanelReporteTabla(
                "Existencias",
                "Stock actual por producto y almacén.",
                new String[]{"Código", "Producto", "Almacén", "Cantidad",
                        "Unidad", "Stock mínimo", "Estado"},
                new String[]{null, null, null, "%.3f", null, "%.3f", null},
                dao::existencias,
                filas -> "Registros: " + filas.size()
                        + "   |   Con alerta de reposición: "
                        + filas.stream()
                        .filter(f -> "REPONER".equals(f[6])).count()
        ), BorderLayout.CENTER);
    }
}
