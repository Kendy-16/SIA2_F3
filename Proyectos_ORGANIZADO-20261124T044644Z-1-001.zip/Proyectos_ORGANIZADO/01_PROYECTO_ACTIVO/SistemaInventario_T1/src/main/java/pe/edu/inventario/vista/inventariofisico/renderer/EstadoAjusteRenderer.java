package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Colorea el estado de revisión de un ajuste (texto: PENDIENTE, APROBADO, RECHAZADO, SIN AJUSTE). */
public class EstadoAjusteRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
        Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
        setBorder(new EmptyBorder(2, 7, 2, 7));
        FormatoInventarioFisico.aplicarCebra(c, table, row, selected);
        setHorizontalAlignment(SwingConstants.LEFT);
        String s = value == null ? "" : value.toString().toUpperCase();
        if (!selected) {
            setForeground(s.startsWith("PENDIENTE") ? FormatoInventarioFisico.AMBER
                    : s.startsWith("APROBADO") ? FormatoInventarioFisico.GREEN
                    : s.startsWith("RECHAZADO") ? FormatoInventarioFisico.RED
                    : FormatoInventarioFisico.MUTED);
        }
        setFont(getFont().deriveFont(Font.BOLD));
        return c;
    }
}
