package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Registro del conteo físico de una toma: tabla de productos, formulario de cantidad y avance. */
public class RegistroConteoView extends JDialog {
    private record Cargado(Toma toma, boolean ciego, boolean segundoPermitido, List<Producto> productos) { }

    private final InventarioFisicoController controller;
    private final long idToma;
    private final PermisosVistaInventario permisos;
    private final Runnable alCambiar;
    private final Runnable irAConciliacion;

    private final TablaConteoModel modelo = new TablaConteoModel();
    private final JTable tabla = new JTable(modelo);
    private final PanelRegistroCantidad registro = new PanelRegistroCantidad();
    private final PanelProgresoConteo progreso = new PanelProgresoConteo();
    private final JLabel titulo = new JLabel();
    private boolean segundoPermitido = true;
    private boolean ciego = true;

    public RegistroConteoView(Window owner, InventarioFisicoController controller, long idToma, PermisosVistaInventario permisos,
                              Runnable alCambiar, Runnable irAConciliacion) {
        super(owner, "Registro de conteo físico", ModalityType.APPLICATION_MODAL);
        this.controller = controller; this.idToma = idToma; this.permisos = permisos;
        this.alCambiar = alCambiar; this.irAConciliacion = irAConciliacion;
        setSize(1120, 680); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));

        JPanel norte = new JPanel(new BorderLayout(0, 6));
        norte.setBorder(new EmptyBorder(12, 14, 0, 14));
        titulo.setText("REGISTRO DE CONTEO · Toma ID " + idToma);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 17f));
        norte.add(titulo, BorderLayout.NORTH);
        norte.add(progreso, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);

        estiloTabla(tabla);
        tabla.setDefaultRenderer(Object.class, rendererTexto());
        tabla.setDefaultRenderer(BigDecimal.class, new CantidadRenderer());
        tabla.getColumnModel().getColumn(4).setCellRenderer(new CantidadRenderer());
        tabla.getColumnModel().getColumn(7).setCellRenderer(new EstadoConteoRenderer());
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JButton guardar = botonPrimario("Guardar conteo"), segundo = botonSecundario("Segundo conteo..."), detalle = botonSecundario("Ver detalle"),
                actualizar = botonSecundario("Actualizar"), conciliar = botonSecundario("Ir a conciliación"), cerrar = botonSecundario("Cerrar");
        guardar.setEnabled(permisos.puedeRegistrarConteo());
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        for (JButton b : new JButton[]{guardar, segundo, detalle, actualizar, conciliar, cerrar}) botones.add(b);
        JPanel sur = new JPanel(new BorderLayout());
        sur.add(registro, BorderLayout.CENTER);
        sur.add(botones, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);

        tabla.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) mostrarSeleccionado(); });
        registro.alCambiarModoConteo(this::mostrarSeleccionado);
        guardar.addActionListener(e -> guardarConteo());
        segundo.addActionListener(e -> abrirSegundoConteo());
        detalle.addActionListener(e -> {
            Producto p = seleccionado();
            if (p == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_PRODUCTO); return; }
            new DetalleConteoDialog(this, p, ciego).setVisible(true);
        });
        actualizar.addActionListener(e -> cargar());
        conciliar.addActionListener(e -> {
            alCambiar.run();
            dispose();
            if (irAConciliacion != null) irAConciliacion.run();
            else MensajesInventarioFisico.informacion(getOwner(), "Selecciona la toma en la pestaña Conciliación para comparar los resultados.");
        });
        cerrar.addActionListener(e -> dispose());
        cargar();
    }

    private Producto seleccionado() {
        int fila = tabla.getSelectedRow();
        return fila < 0 ? null : modelo.getProducto(tabla.convertRowIndexToModel(fila));
    }

    private void mostrarSeleccionado() { registro.mostrarProducto(seleccionado()); }

    private void cargar() {
        Producto previo = seleccionado();
        Long idPrevio = previo == null ? null : previo.id();
        TareaAsincrona.ejecutar(this, () -> {
            Toma toma = controller.listarTomas("", null).stream().filter(t -> t.id() == idToma).findFirst().orElse(null);
            boolean sp = controller.permiteSegundoConteo(idToma);
            boolean cg = controller.esConteoCiego(idToma);
            return new Cargado(toma, cg, sp, controller.listarProductosToma(idToma, cg));
        }, c -> {
            segundoPermitido = c.segundoPermitido();
            ciego = c.ciego();
            registro.setSegundoHabilitado(segundoPermitido);
            titulo.setText((ciego ? "REGISTRO DE CONTEO CIEGO" : "REGISTRO DE CONTEO") + " · "
                    + (c.toma() == null ? "Toma ID " + idToma : c.toma().codigo() + " · " + c.toma().almacen()));
            modelo.setFilas(c.productos(), ciego);
            progreso.actualizar(modelo.contados(), c.productos().size());
            if (idPrevio != null) {
                for (int i = 0; i < modelo.getRowCount(); i++) {
                    if (modelo.getProducto(i).id() == idPrevio) { int v = tabla.convertRowIndexToView(i); tabla.setRowSelectionInterval(v, v); break; }
                }
            }
        });
    }

    private void guardarConteo() {
        Producto p = seleccionado();
        if (p == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_PRODUCTO); return; }
        boolean esSegundo = registro.esSegundoConteo();
        ValidadorFormularioConteo.Resultado r = ValidadorFormularioConteo.validar(registro.getCantidadTexto(), p.unidad(), esSegundo, segundoPermitido);
        if (!r.esValido()) { MensajesInventarioFisico.advertencia(this, r.error()); return; }
        String obs = registro.getObservacion();
        TareaAsincrona.ejecutar(this, () -> { controller.registrarConteo(idToma, p.id(), r.cantidad(), obs, esSegundo); return true; },
                ok -> { cargar(); alCambiar.run(); registro.enfocarCantidad(); });
    }

    private void abrirSegundoConteo() {
        Producto p = seleccionado();
        if (p == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_PRODUCTO); return; }
        if (!segundoPermitido) { MensajesInventarioFisico.advertencia(this, "El segundo conteo no está habilitado para esta toma."); return; }
        if (p.cantidadContada() == null) { MensajesInventarioFisico.advertencia(this, "Primero registra el primer conteo de este producto."); return; }
        new SegundoConteoDialog(this, controller, idToma, modelo.getFilas(), p, () -> { cargar(); alCambiar.run(); }).setVisible(true);
    }
}
