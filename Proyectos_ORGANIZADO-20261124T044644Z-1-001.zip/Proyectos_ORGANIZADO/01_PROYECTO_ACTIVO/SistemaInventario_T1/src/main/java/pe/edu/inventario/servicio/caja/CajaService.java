package pe.edu.inventario.servicio.caja;

import java.math.BigDecimal;

/** Movimientos de caja. (Clase de apoyo) */
public class CajaService {
    public void registrarEgresoPorAnulacion(String idVenta, BigDecimal monto) {
        // TODO: persistir egreso en caja
    }
    public void registrarEgresoPorDevolucion(String idVenta, BigDecimal monto, String motivo) {
        // TODO: persistir egreso en caja
    }
}
