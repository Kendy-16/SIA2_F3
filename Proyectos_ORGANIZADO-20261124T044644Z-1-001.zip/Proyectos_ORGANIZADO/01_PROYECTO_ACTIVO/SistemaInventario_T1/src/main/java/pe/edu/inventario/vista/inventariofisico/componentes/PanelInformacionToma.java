package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Datos generales de una toma: código, almacén, responsable, fechas, estado y avance. */
public class PanelInformacionToma extends JPanel {
    private final JLabel codigo = valor(), almacen = valor(), responsable = valor(), inicio = valor(), cierre = valor(), estado = valor();
    private final JProgressBar avance = new JProgressBar(0, 100);

    public PanelInformacionToma() {
        super(new GridBagLayout());
        setOpaque(false);
        setBorder(new EmptyBorder(16, 18, 16, 18));
        fila(0, "Código", codigo);
        fila(1, "Almacén", almacen);
        fila(2, "Responsable", responsable);
        fila(3, "Inicio", inicio);
        fila(4, "Cierre", cierre);
        fila(5, "Estado", estado);
        avance.setStringPainted(true);
        fila(6, "Avance", avance);
    }

    private static JLabel valor() { JLabel l = new JLabel(SIN_DATO); l.setForeground(TEXT); return l; }

    private void fila(int y, String etiqueta, JComponent componente) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = y; g.insets = new Insets(5, 4, 5, 12); g.anchor = GridBagConstraints.WEST;
        g.gridx = 0;
        add(etiquetaSecundaria(etiqueta + ":"), g);
        g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
        add(componente, g);
    }

    public void mostrar(Toma t) {
        if (t == null) {
            codigo.setText(SIN_DATO); almacen.setText(SIN_DATO); responsable.setText(SIN_DATO);
            inicio.setText(SIN_DATO); cierre.setText(SIN_DATO); estado.setText(SIN_DATO);
            avance.setValue(0); avance.setString("0%");
            return;
        }
        codigo.setText(t.codigo());
        almacen.setText(t.almacen());
        responsable.setText(texto(t.responsable()));
        inicio.setText(fecha(t.fechaInicio()));
        cierre.setText(fecha(t.fechaCierre()));
        estado.setText(String.valueOf(t.estado()));
        avance.setValue(t.avancePorcentaje());
        avance.setString(porcentaje(t.avancePorcentaje()) + " · " + t.productosContados() + " de " + t.totalProductos());
    }
}
