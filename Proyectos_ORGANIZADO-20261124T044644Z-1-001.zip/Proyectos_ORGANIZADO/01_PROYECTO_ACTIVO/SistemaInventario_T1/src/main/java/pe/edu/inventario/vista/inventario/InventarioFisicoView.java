
package pe.edu.inventario.vista.inventario;

import pe.edu.inventario.controlador.InventarioFisicoController;
import pe.edu.inventario.modelo.DetalleInventarioFisico;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.ListSelectionModel;

import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import java.math.BigDecimal;
import java.math.RoundingMode;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Interfaz grafica profesional del modulo de inventario fisico.
 *
 * Funcionalidades:
 * - Crear conteos fisicos.
 * - Seleccionar almacen y modalidad.
 * - Consultar estado real de las tomas.
 * - Mostrar productos y existencias.
 * - Registrar cantidades fisicas.
 * - Calcular diferencias e impacto valorizado.
 * - Detectar discrepancias inusuales.
 * - Exigir justificacion en diferencias criticas.
 * - Bloquear tomas procesadas o anuladas.
 * - Proteger cambios sin guardar al seleccionar filas.
 * - Prevenir doble ejecucion de operaciones.
 * - Ejecutar operaciones JDBC fuera del EDT.
 */
public class InventarioFisicoView extends JPanel {

    // =========================================================
    // 1. COLORES CORPORATIVOS
    // =========================================================

    private static final Color AZUL_PRINCIPAL =
            new Color(31, 78, 121);

    private static final Color FONDO =
            new Color(245, 247, 250);

    private static final Color BLANCO =
            Color.WHITE;

    private static final Color TEXTO =
            new Color(36, 59, 83);

    private static final Color TEXTO_SECUNDARIO =
            new Color(100, 116, 139);

    private static final Color VERDE =
            new Color(6, 118, 71);

    private static final Color ROJO =
            new Color(180, 35, 24);

    private static final Color NARANJA =
            new Color(181, 71, 8);

    private static final Color BORDE =
            new Color(226, 232, 240);

    // =========================================================
    // 2. CONSTANTES DE NEGOCIO
    // =========================================================

    private static final BigDecimal PORCENTAJE_CRITICO =
            new BigDecimal("20");

    private static final BigDecimal FACTOR_DISCREPANCIA =
            new BigDecimal("10");

    private static final BigDecimal LIMITE_DISCREPANCIA_CERO =
            new BigDecimal("100");

    /**
     * Umbral de impacto valorizado que exige justificacion.
     *
     * Se expresa en la moneda utilizada por el sistema.
     * Ajustar este importe segun la politica de la empresa.
     */
    private static final BigDecimal IMPACTO_CRITICO =
            new BigDecimal("10000.00");

    private static final int MIN_OBSERVACION_CRITICA = 5;

    private static final int MAX_DECIMALES_CANTIDAD = 3;

    private static final int ESCALA_MONETARIA = 6;

    // =========================================================
    // 3. CONTROLADOR
    // =========================================================

    private final InventarioFisicoController controller;

    // =========================================================
    // 4. COMPONENTES
    // =========================================================

    private JTextField txtIdAlmacen;
    private JTextField txtIdToma;
    private JTextField txtObservacionConteo;

    private JComboBox<String> cmbModo;

    private JTextField txtCantidadFisica;
    private JTextField txtObservacionProducto;

    private JTable tablaDetalle;
    private ModeloTablaInventario modeloTabla;

    private JButton btnCrearConteo;
    private JButton btnCargar;
    private JButton btnRegistrarCantidad;
    private JButton btnProcesar;
    private JButton btnLimpiar;

    // =========================================================
    // 5. INDICADORES
    // =========================================================

    private JLabel lblTotalProductos;
    private JLabel lblContados;
    private JLabel lblPendientes;
    private JLabel lblFaltantes;
    private JLabel lblSobrantes;

    private JLabel lblImpacto;
    private JLabel lblEstado;

    // =========================================================
    // 6. ESTADO DE LA INTERFAZ
    // =========================================================

    private String estadoToma;

    private boolean tomaSoloLectura = true;

    private boolean ocupado = false;

    private boolean actualizandoSeleccion = false;

    private Integer idProductoSeleccionado;

    private String cantidadInicial = "";

    private String observacionInicial = "";

    private int totalProductos;

    private int totalPendientes;

    // =========================================================
    // 7. CONSTRUCTORES
    // =========================================================

    public InventarioFisicoView() {
        this(new InventarioFisicoController());
    }

    public InventarioFisicoView(
            InventarioFisicoController controller
    ) {

        if (controller == null) {
            throw new IllegalArgumentException(
                    "El controlador de inventario fisico es obligatorio."
            );
        }

        this.controller = controller;

        configurarVista();
        inicializarComponentes();
        registrarEventos();

        actualizarControles();
    }

    // =========================================================
    // 8. CONFIGURACION PRINCIPAL
    // =========================================================

    private void configurarVista() {

        setLayout(new BorderLayout(0, 16));

        setBackground(FONDO);

        setBorder(
                new EmptyBorder(22, 24, 22, 24)
        );

    }

    private void inicializarComponentes() {

        JPanel superior = new JPanel(
                new BorderLayout(0, 17)
        );

        superior.setOpaque(false);

        superior.add(
                crearEncabezado(),
                BorderLayout.NORTH
        );

        superior.add(
                crearPanelConfiguracion(),
                BorderLayout.CENTER
        );

        add(superior, BorderLayout.NORTH);

        add(
                crearPanelCentral(),
                BorderLayout.CENTER
        );

        add(
                crearPanelRegistro(),
                BorderLayout.SOUTH
        );
    }

    // =========================================================
    // 9. ENCABEZADO
    // =========================================================

    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(
                new BorderLayout()
        );

        panel.setOpaque(false);

        JPanel informacion = new JPanel(
                new GridLayout(2, 1, 0, 5)
        );

        informacion.setOpaque(false);

        JLabel titulo = new JLabel(
                "Inventario físico"
        );

        titulo.setFont(
                new Font("Segoe UI", Font.BOLD, 25)
        );

        titulo.setForeground(AZUL_PRINCIPAL);

        JLabel subtitulo = new JLabel(
                "Control, conteo y conciliación de existencias por almacén"
        );

        subtitulo.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        subtitulo.setForeground(TEXTO_SECUNDARIO);

        informacion.add(titulo);
        informacion.add(subtitulo);

        lblEstado = new JLabel(
                "SIN CONTEO SELECCIONADO"
        );

        lblEstado.setOpaque(true);

        lblEstado.setBackground(
                new Color(239, 246, 255)
        );

        lblEstado.setForeground(AZUL_PRINCIPAL);

        lblEstado.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        lblEstado.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(191, 219, 254)
                        ),
                        new EmptyBorder(8, 12, 8, 12)
                )
        );

        panel.add(
                informacion,
                BorderLayout.CENTER
        );

        panel.add(
                lblEstado,
                BorderLayout.EAST
        );

        return panel;
    }

    // =========================================================
    // 10. CONFIGURACION DEL CONTEO
    // =========================================================

    private JPanel crearPanelConfiguracion() {

        JPanel panel = crearPanelBlanco();

        panel.setLayout(
                new BorderLayout(10, 12)
        );

        panel.setBorder(
                new EmptyBorder(15, 17, 15, 17)
        );

        panel.add(
                crearEtiquetaTitulo(
                        "CONFIGURACIÓN DEL CONTEO"
                ),
                BorderLayout.NORTH
        );

        JPanel campos = new JPanel(
                new GridLayout(2, 4, 12, 10)
        );

        campos.setOpaque(false);

        txtIdAlmacen = crearCampoTexto();

        txtIdToma = crearCampoTexto();

        // Permite consultar una toma existente escribiendo su ID.
        txtIdToma.setEditable(true);

        txtObservacionConteo = crearCampoTexto();

        cmbModo = new JComboBox<>(
                new String[]{
                        "GENERAL",
                        "PARCIAL",
                        "CICLICO"
                }
        );

        estilizarCombo(cmbModo);

        btnCrearConteo = crearBotonPrimario(
                "Crear conteo"
        );

        btnCargar = crearBotonSecundario(
                "Cargar detalle"
        );

        btnProcesar = crearBotonExito(
                "Procesar conteo"
        );

        campos.add(
                crearCampo("ID del almacén", txtIdAlmacen)
        );

        campos.add(
                crearCampo("Modalidad", cmbModo)
        );

        campos.add(
                crearCampo(
                        "Observación general",
                        txtObservacionConteo
                )
        );

        campos.add(
                crearCampoAccion(
                        "Nueva toma",
                        btnCrearConteo
                )
        );

        campos.add(
                crearCampo("ID del conteo", txtIdToma)
        );

        campos.add(
                crearCampoAccion(
                        "Consultar",
                        btnCargar
                )
        );

        campos.add(
                crearCampoAccion(
                        "Finalización",
                        btnProcesar
                )
        );

        JLabel nota = new JLabel(
                "Ingrese un identificador válido de almacén y consulte las tomas existentes."
        );

        nota.setFont(
                new Font("Segoe UI", Font.ITALIC, 10)
        );

        nota.setForeground(TEXTO_SECUNDARIO);

        JPanel contenido = new JPanel(
                new BorderLayout(0, 8)
        );

        contenido.setOpaque(false);

        contenido.add(
                campos,
                BorderLayout.CENTER
        );

        contenido.add(
                nota,
                BorderLayout.SOUTH
        );

        panel.add(
                contenido,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =========================================================
    // 11. PANEL CENTRAL
    // =========================================================

    private JPanel crearPanelCentral() {

        JPanel panel = new JPanel(
                new BorderLayout(0, 13)
        );

        panel.setOpaque(false);

        panel.add(
                crearPanelIndicadores(),
                BorderLayout.NORTH
        );

        panel.add(
                crearPanelTabla(),
                BorderLayout.CENTER
        );

        return panel;
    }

    // =========================================================
    // 12. INDICADORES
    // =========================================================

    private JPanel crearPanelIndicadores() {

        JPanel panel = new JPanel(
                new GridLayout(1, 5, 12, 0)
        );

        panel.setOpaque(false);

        lblTotalProductos = crearValorIndicador();

        lblContados = crearValorIndicador();

        lblPendientes = crearValorIndicador();

        lblFaltantes = crearValorIndicador();

        lblSobrantes = crearValorIndicador();

        panel.add(
                crearTarjeta(
                        "PRODUCTOS",
                        lblTotalProductos,
                        AZUL_PRINCIPAL
                )
        );

        panel.add(
                crearTarjeta(
                        "CONTADOS",
                        lblContados,
                        VERDE
                )
        );

        panel.add(
                crearTarjeta(
                        "PENDIENTES",
                        lblPendientes,
                        NARANJA
                )
        );

        panel.add(
                crearTarjeta(
                        "FALTANTES",
                        lblFaltantes,
                        ROJO
                )
        );

        panel.add(
                crearTarjeta(
                        "SOBRANTES",
                        lblSobrantes,
                        VERDE
                )
        );

        return panel;
    }

    private JPanel crearTarjeta(
            String titulo,
            JLabel valor,
            Color color
    ) {

        JPanel panel = crearPanelBlanco();

        panel.setLayout(
                new BorderLayout(0, 8)
        );

        panel.setBorder(
                new EmptyBorder(13, 15, 13, 15)
        );

        JLabel etiqueta = new JLabel(titulo);

        etiqueta.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        etiqueta.setForeground(
                TEXTO_SECUNDARIO
        );

        valor.setForeground(color);

        panel.add(etiqueta, BorderLayout.NORTH);

        panel.add(valor, BorderLayout.CENTER);

        return panel;
    }

    private JLabel crearValorIndicador() {

        JLabel valor = new JLabel("0");

        valor.setFont(
                new Font("Segoe UI", Font.BOLD, 25)
        );

        return valor;
    }

    // =========================================================
    // 13. PANEL DE TABLA
    // =========================================================

    private JPanel crearPanelTabla() {

        JPanel panel = crearPanelBlanco();

        panel.setLayout(
                new BorderLayout(0, 12)
        );

        panel.setBorder(
                new EmptyBorder(15, 17, 15, 17)
        );

        panel.add(
                crearEtiquetaTitulo(
                        "DETALLE DE PRODUCTOS"
                ),
                BorderLayout.NORTH
        );

        modeloTabla = new ModeloTablaInventario();

        tablaDetalle = new JTable(modeloTabla);

        configurarTabla();

        JScrollPane scroll = new JScrollPane(tablaDetalle);

        scroll.setBorder(
                BorderFactory.createLineBorder(BORDE)
        );

        scroll.getViewport().setBackground(BLANCO);

        panel.add(
                scroll,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =========================================================
    // 14. CONFIGURAR TABLA
    // =========================================================

    private void configurarTabla() {

        tablaDetalle.setRowHeight(35);

        tablaDetalle.setFont(
                new Font("Segoe UI", Font.PLAIN, 11)
        );

        tablaDetalle.setForeground(TEXTO);

        tablaDetalle.setBackground(BLANCO);

        tablaDetalle.setGridColor(
                new Color(241, 245, 249)
        );

        tablaDetalle.setShowVerticalLines(false);

        tablaDetalle.setShowHorizontalLines(true);

        tablaDetalle.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaDetalle.setFillsViewportHeight(true);

        tablaDetalle.setAutoCreateRowSorter(true);

        tablaDetalle.getTableHeader().setReorderingAllowed(false);

        tablaDetalle.getTableHeader().setPreferredSize(
                new Dimension(0, 39)
        );

        tablaDetalle.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        tablaDetalle.getTableHeader().setBackground(
                AZUL_PRINCIPAL
        );

        tablaDetalle.getTableHeader().setForeground(BLANCO);

        tablaDetalle.setSelectionBackground(
                new Color(219, 234, 254)
        );

        tablaDetalle.setSelectionForeground(TEXTO);

        DefaultTableCellRenderer derecha =
                new DefaultTableCellRenderer();

        derecha.setHorizontalAlignment(
                SwingConstants.RIGHT
        );

        tablaDetalle.getColumnModel()
                .getColumn(3)
                .setCellRenderer(derecha);

        tablaDetalle.getColumnModel()
                .getColumn(4)
                .setCellRenderer(derecha);

        tablaDetalle.getColumnModel()
                .getColumn(5)
                .setCellRenderer(
                        new RendererDiferencia()
                );

        tablaDetalle.getColumnModel()
                .getColumn(6)
                .setCellRenderer(derecha);

        tablaDetalle.getColumnModel()
                .getColumn(7)
                .setCellRenderer(derecha);

        tablaDetalle.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(90);

        tablaDetalle.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(190);

        tablaDetalle.getColumnModel()
                .getColumn(8)
                .setPreferredWidth(180);
    }

    // =========================================================
    // 15. PANEL DE REGISTRO
    // =========================================================

    private JPanel crearPanelRegistro() {

        JPanel panel = crearPanelBlanco();

        panel.setLayout(
                new BorderLayout(12, 10)
        );

        panel.setBorder(
                new EmptyBorder(15, 17, 15, 17)
        );

        panel.add(
                crearEtiquetaTitulo(
                        "REGISTRO DE CONTEO FÍSICO"
                ),
                BorderLayout.NORTH
        );

        txtCantidadFisica = crearCampoTexto();

        // Solo permite numeros y hasta tres decimales.
        ((AbstractDocument) txtCantidadFisica.getDocument())
                .setDocumentFilter(
                        new FiltroCantidad()
                );

        txtObservacionProducto = crearCampoTexto();

        btnLimpiar = crearBotonSecundario("Limpiar");

        btnRegistrarCantidad =
                crearBotonPrimario("Registrar cantidad");

        JPanel formulario = new JPanel(
                new GridLayout(1, 2, 12, 0)
        );

        formulario.setOpaque(false);

        formulario.add(
                crearCampo(
                        "Cantidad física encontrada",
                        txtCantidadFisica
                )
        );

        formulario.add(
                crearCampo(
                        "Observación del producto",
                        txtObservacionProducto
                )
        );

        JPanel acciones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 8, 12)
        );

        acciones.setOpaque(false);

        acciones.add(btnLimpiar);

        acciones.add(btnRegistrarCantidad);

        JPanel centro = new JPanel(
                new BorderLayout(10, 0)
        );

        centro.setOpaque(false);

        centro.add(formulario, BorderLayout.CENTER);

        centro.add(acciones, BorderLayout.EAST);

        panel.add(centro, BorderLayout.CENTER);

        JPanel resumen = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 5, 0)
        );

        resumen.setOpaque(false);

        JLabel textoImpacto = new JLabel(
                "Impacto valorizado neto:"
        );

        textoImpacto.setForeground(TEXTO_SECUNDARIO);

        textoImpacto.setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        lblImpacto = new JLabel("0.000000");

        lblImpacto.setFont(
                new Font("Segoe UI", Font.BOLD, 13)
        );

        lblImpacto.setForeground(AZUL_PRINCIPAL);

        resumen.add(textoImpacto);

        resumen.add(lblImpacto);

        panel.add(resumen, BorderLayout.SOUTH);

        return panel;
    }

    // =========================================================
    // 16. REGISTRAR EVENTOS
    // =========================================================

    private void registrarEventos() {

        btnCrearConteo.addActionListener(
                e -> crearConteo()
        );

        btnCargar.addActionListener(
                e -> cargarDetalle()
        );

        btnRegistrarCantidad.addActionListener(
                e -> registrarCantidad()
        );

        btnProcesar.addActionListener(
                e -> procesarConteo()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFormularioDetalle()
        );

        tablaDetalle.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()
                            && !actualizandoSeleccion) {

                        gestionarCambioSeleccion();
                    }
                });
    }

    // =========================================================
    // 17. CREAR CONTEO
    // =========================================================

    private void crearConteo() {

        try {

            // Validar primero el texto antes de llamar al controlador.
            int idAlmacen = convertirEnteroPositivo(
                    txtIdAlmacen.getText(),
                    "almacen"
            );

            String modo =
                    (String) cmbModo.getSelectedItem();

            if (modo == null || modo.isBlank()) {

                throw new IllegalArgumentException(
                        "Seleccione una modalidad de conteo."
                );
            }

            String observacion =
                    txtObservacionConteo.getText();

            int confirmacion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Desea crear una nueva toma de inventario\n"
                    + "para el almacén ID " + idAlmacen + "?",
                    "Confirmar creación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (confirmacion != JOptionPane.YES_OPTION) {
                return;
            }

            ejecutarEnSegundoPlano(

                    () -> {

                        // Verificar existencia y estado activo.
                        boolean activo =
                                controller.existeAlmacenActivo(
                                        idAlmacen
                                );

                        if (!activo) {

                            throw new IllegalArgumentException(
                                    "El almacén no existe "
                                    + "o se encuentra inactivo."
                            );
                        }

                        // Crear toma solamente despues de validar.
                        int idToma = controller.crearConteo(
                                idAlmacen,
                                modo,
                                observacion
                        );

                        CargaConteo carga =
                                cargarDatosConteo(idToma);

                        return new CreacionConteo(
                                idToma,
                                carga
                        );
                    },

                    resultado -> {

                        txtIdToma.setText(
                                String.valueOf(resultado.idToma())
                        );

                        limpiarFormularioDetalle();

                        mostrarConteo(resultado.carga());

                        JOptionPane.showMessageDialog(
                                this,
                                "El conteo se creó correctamente.\n"
                                + "Identificador: "
                                + resultado.idToma(),
                                "Inventario físico",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
            );

        } catch (IllegalArgumentException ex) {

            mostrarMensaje(
                    ex.getMessage(),
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    // =========================================================
    // 18. CARGAR DETALLE DEL CONTEO
    // =========================================================

    private void cargarDetalle() {

        try {

            int idToma = convertirEnteroPositivo(
                    txtIdToma.getText(),
                    "conteo"
            );

            ejecutarEnSegundoPlano(

                    () -> cargarDatosConteo(idToma),

                    carga -> {

                        limpiarFormularioDetalle();

                        mostrarConteo(carga);
                    }
            );

        } catch (IllegalArgumentException ex) {

            mostrarMensaje(
                    ex.getMessage(),
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    /**
     * Recupera estado y detalles mediante el controlador.
     *
     * Este metodo se ejecuta desde SwingWorker.
     */
    private CargaConteo cargarDatosConteo(
            int idToma
    ) throws SQLException {

        String estado =
                controller.obtenerEstadoConteo(idToma);

        List<DetalleInventarioFisico> detalles =
                controller.listarDetalle(idToma);

        if (estado == null || detalles == null) {

            throw new SQLException(
                    "El servicio devolvió información incompleta."
            );
        }

        return new CargaConteo(
                estado,
                new ArrayList<>(detalles)
        );
    }

    // =========================================================
    // 19. MOSTRAR INFORMACION DEL CONTEO
    // =========================================================

    private void mostrarConteo(
            CargaConteo carga
    ) {

        if (carga == null || carga.detalles() == null) {

            mostrarMensaje(
                    "No se recibieron datos válidos del conteo.",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        estadoToma = carga.estado();

        tomaSoloLectura =
                !"ABIERTO".equals(estadoToma);

        modeloTabla.setDatos(carga.detalles());

        actualizarIndicadores(carga.detalles());

        if ("ABIERTO".equals(estadoToma)) {

            establecerEstado(
                    "CONTEO ABIERTO",
                    VERDE
            );

        } else if ("PROCESADO".equals(estadoToma)) {

            establecerEstado(
                    "SOLO LECTURA - PROCESADO",
                    AZUL_PRINCIPAL
            );

        } else if ("ANULADO".equals(estadoToma)) {

            establecerEstado(
                    "SOLO LECTURA - ANULADO",
                    ROJO
            );

        } else {

            establecerEstado(
                    "ESTADO NO RECONOCIDO",
                    NARANJA
            );

            tomaSoloLectura = true;
        }

        idProductoSeleccionado = null;

        cantidadInicial = "";

        observacionInicial = "";

        limpiarCamposRegistro();

        actualizarControles();
    }

    // =========================================================
    // 20. GESTIONAR CAMBIO DE FILA
    // =========================================================

    /**
     * Detecta modificaciones sin guardar antes de seleccionar
     * otro producto.
     *
     * Si existen cambios, el usuario puede:
     * - Confirmar que desea descartarlos.
     * - Cancelar y permanecer en el producto anterior.
     *
     * Nunca se registra el contenido del formulario sobre
     * un producto diferente al que fue seleccionado.
     */
    private void gestionarCambioSeleccion() {

        int filaVista = tablaDetalle.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo =
                tablaDetalle.convertRowIndexToModel(filaVista);

        if (!indiceModeloValido(filaModelo)) {
            return;
        }

        DetalleInventarioFisico nuevoDetalle =
                modeloTabla.getDetalleAt(filaModelo);

        if (nuevoDetalle == null) {
            return;
        }

        int nuevoId = nuevoDetalle.getIdProducto();

        if (idProductoSeleccionado != null
                && !idProductoSeleccionado.equals(nuevoId)
                && existenCambiosSinGuardar()) {

            int opcion = JOptionPane.showConfirmDialog(
                    this,
                    "El producto seleccionado tiene cambios sin guardar.\n\n"
                    + "¿Desea descartar esos cambios y seleccionar otro producto?",
                    "Cambios sin guardar",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (opcion != JOptionPane.YES_OPTION) {

                restaurarSeleccionAnterior();

                return;
            }
        }

        cargarProductoSeleccionado(filaModelo);
    }

    /**
     * Comprueba si los campos fueron modificados
     * desde la ultima carga del producto seleccionado.
     */
    private boolean existenCambiosSinGuardar() {

        String cantidadActual =
                txtCantidadFisica.getText().trim();

        String observacionActual =
                txtObservacionProducto.getText().trim();

        return !cantidadActual.equals(
                    cantidadInicial
                )
                || !observacionActual.equals(
                    observacionInicial
                );
    }

    /**
     * Restaura la fila que se encontraba seleccionada.
     */
    private void restaurarSeleccionAnterior() {

        if (idProductoSeleccionado == null) {

            actualizarSeleccion(null);

            return;
        }

        int filaModelo = modeloTabla.buscarFilaPorProducto(
                idProductoSeleccionado
        );

        if (filaModelo < 0) {

            actualizarSeleccion(null);

            return;
        }

        int filaVista =
                tablaDetalle.convertRowIndexToView(filaModelo);

        if (filaVista < 0) {
            return;
        }

        actualizandoSeleccion = true;

        try {

            tablaDetalle.setRowSelectionInterval(
                    filaVista,
                    filaVista
            );

        } finally {

            actualizandoSeleccion = false;
        }
    }

    /**
     * Carga los datos de la fila que realmente fue seleccionada.
     */
    private void cargarProductoSeleccionado(
            int filaModelo
    ) {

        if (!indiceModeloValido(filaModelo)) {
            return;
        }

        DetalleInventarioFisico detalle =
                modeloTabla.getDetalleAt(filaModelo);

        if (detalle == null) {
            return;
        }

        idProductoSeleccionado =
                detalle.getIdProducto();

        txtCantidadFisica.setText(
                detalle.getCantidadFisica() == null
                        ? ""
                        : detalle.getCantidadFisica().toPlainString()
        );

        txtObservacionProducto.setText(
                detalle.getObservacion() == null
                        ? ""
                        : detalle.getObservacion()
        );

        cantidadInicial =
                txtCantidadFisica.getText().trim();

        observacionInicial =
                txtObservacionProducto.getText().trim();

        actualizarControles();
    }

    private void actualizarSeleccion(
            Integer idProducto
    ) {

        if (idProducto == null) {

            idProductoSeleccionado = null;

            limpiarCamposRegistro();

            return;
        }

        int filaModelo =
                modeloTabla.buscarFilaPorProducto(idProducto);

        if (filaModelo >= 0) {

            cargarProductoSeleccionado(filaModelo);
        }
    }

    private boolean indiceModeloValido(
            int filaModelo
    ) {

        return filaModelo >= 0
                && filaModelo < modeloTabla.getRowCount();
    }

    // =========================================================
    // 21. REGISTRAR CANTIDAD FISICA
    // =========================================================

    private void registrarCantidad() {

        // Validacion defensiva de seleccion.
        int filaVista = tablaDetalle.getSelectedRow();

        if (filaVista == -1) {

            mostrarMensaje(
                    "Seleccione un producto de la tabla.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int filaModelo =
                tablaDetalle.convertRowIndexToModel(filaVista);

        if (!indiceModeloValido(filaModelo)) {

            mostrarMensaje(
                    "La fila seleccionada no es válida. "
                    + "Actualice el detalle e inténtelo nuevamente.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (tomaSoloLectura) {

            mostrarMensaje(
                    "La toma está cerrada. "
                    + "No se permite modificar cantidades.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (idProductoSeleccionado == null) {

            mostrarMensaje(
                    "No se pudo identificar el producto seleccionado.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        DetalleInventarioFisico detalle =
                modeloTabla.getDetalleAt(filaModelo);

        if (detalle == null
                || detalle.getIdProducto()
                        != idProductoSeleccionado) {

            mostrarMensaje(
                    "El producto seleccionado cambió. "
                    + "Vuelva a seleccionarlo.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            int idToma = convertirEnteroPositivo(
                    txtIdToma.getText(),
                    "conteo"
            );

            BigDecimal cantidad =
                    convertirDecimal(
                            txtCantidadFisica.getText(),
                            "cantidad física"
                    );

            validarCantidadInterfaz(cantidad);

            String observacion =
                    txtObservacionProducto.getText().trim();

            // -------------------------------------------------
            // COMPROBAR DISCREPANCIA DESPROPORCIONADA
            // -------------------------------------------------

            if (esDiscrepanciaDesproporcionada(
                    detalle,
                    cantidad
            )) {

                int confirmacion = JOptionPane.showConfirmDialog(
                        this,
                        "La cantidad física está muy alejada "
                        + "del stock registrado.\n\n"
                        + "Stock del sistema: "
                        + detalle.getStockSistema()
                        + "\nCantidad física: "
                        + cantidad
                        + "\n\n¿Está seguro de registrar esta cantidad?",
                        "Confirmar discrepancia importante",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (confirmacion != JOptionPane.YES_OPTION) {
                    return;
                }
            }

            // -------------------------------------------------
            // EXIGIR OBSERVACION EN DIFERENCIAS CRITICAS
            // -------------------------------------------------

            if (esDiferenciaCritica(
                    detalle,
                    cantidad
            )) {

                if (observacion.length()
                        < MIN_OBSERVACION_CRITICA) {

                    mostrarMensaje(
                            "La diferencia supera el umbral crítico.\n\n"
                            + "Debe ingresar una justificación de al menos "
                            + MIN_OBSERVACION_CRITICA
                            + " caracteres.",
                            JOptionPane.WARNING_MESSAGE
                    );

                    txtObservacionProducto.requestFocusInWindow();

                    return;
                }
            }

            ejecutarEnSegundoPlano(

                    () -> {

                        controller.registrarCantidadFisica(
                                idToma,
                                detalle.getIdProducto(),
                                cantidad,
                                observacion
                        );

                        return cargarDatosConteo(idToma);
                    },

                    carga -> {

                        mostrarConteo(carga);

                        establecerEstado(
                                "CANTIDAD REGISTRADA",
                                VERDE
                        );

                        JOptionPane.showMessageDialog(
                                this,
                                "La cantidad física se registró correctamente.",
                                "Registro completado",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
            );

        } catch (IllegalArgumentException ex) {

            mostrarMensaje(
                    ex.getMessage(),
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    // =========================================================
    // 22. DISCREPANCIAS DESPROPORCIONADAS
    // =========================================================

    /**
     * Detecta cantidades fisicas muy superiores al stock
     * del sistema.
     *
     * Ejemplo:
     * Stock: 5
     * Fisico: 5000
     *
     * La relacion supera diez veces el stock original.
     */
    private boolean esDiscrepanciaDesproporcionada(
            DetalleInventarioFisico detalle,
            BigDecimal cantidadFisica
    ) {

        BigDecimal stock =
                detalle.getStockSistema();

        if (stock == null) {
            return false;
        }

        if (stock.signum() == 0) {

            return cantidadFisica.compareTo(
                    LIMITE_DISCREPANCIA_CERO
            ) >= 0;
        }

        BigDecimal limite =
                stock.multiply(FACTOR_DISCREPANCIA);

        return cantidadFisica.compareTo(limite) > 0;
    }

    // =========================================================
    // 23. DIFERENCIAS CRITICAS
    // =========================================================

    /**
     * Una diferencia se considera critica si:
     *
     * - Representa al menos el 20% del stock del sistema.
     * - El stock del sistema es cero y existe sobrante.
     * - El impacto valorizado alcanza el umbral establecido.
     *
     * En esos casos se exige una observacion.
     */
    private boolean esDiferenciaCritica(
            DetalleInventarioFisico detalle,
            BigDecimal cantidadFisica
    ) {

        BigDecimal stock =
                detalle.getStockSistema();

        BigDecimal diferencia =
                cantidadFisica.subtract(stock).abs();

        if (diferencia.signum() == 0) {
            return false;
        }

        // Si el sistema registra cero, cualquier diferencia
        // debe justificarse.
        if (stock.signum() == 0) {
            return true;
        }

        BigDecimal porcentaje = diferencia
                .multiply(new BigDecimal("100"))
                .divide(
                        stock,
                        6,
                        RoundingMode.HALF_UP
                );

        if (porcentaje.compareTo(
                PORCENTAJE_CRITICO
        ) >= 0) {
            return true;
        }

        BigDecimal costo =
                detalle.getCostoPromedio();

        if (costo == null) {
            return false;
        }

        BigDecimal impacto = diferencia
                .multiply(costo)
                .abs();

        return impacto.compareTo(
                IMPACTO_CRITICO
        ) >= 0;
    }

    // =========================================================
    // 24. VALIDAR CANTIDAD DE INTERFAZ
    // =========================================================

    private void validarCantidadInterfaz(
            BigDecimal cantidad
    ) {

        if (cantidad == null) {

            throw new IllegalArgumentException(
                    "La cantidad física es obligatoria."
            );
        }

        if (cantidad.signum() < 0) {

            throw new IllegalArgumentException(
                    "La cantidad no puede ser negativa."
            );
        }

        if (cantidad.compareTo(
                new BigDecimal("1000000000")
        ) > 0) {

            throw new IllegalArgumentException(
                    "La cantidad supera el límite permitido."
            );
        }

        if (cantidad.stripTrailingZeros().scale()
                > MAX_DECIMALES_CANTIDAD) {

            throw new IllegalArgumentException(
                    "La cantidad admite como máximo tres decimales."
            );
        }
    }

    // =========================================================
    // 25. PROCESAR CONTEO
    // =========================================================

    private void procesarConteo() {

        if (tomaSoloLectura
                || !"ABIERTO".equals(estadoToma)) {

            mostrarMensaje(
                    "La toma no está abierta. "
                    + "No se puede procesar nuevamente.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        // Comprobacion estricta de productos pendientes.
        if (totalPendientes > 0) {

            mostrarMensaje(
                    "No se puede procesar el inventario físico.\n\n"
                    + "Existen " + totalPendientes
                    + " productos pendientes de conteo.\n\n"
                    + "Debe completar todos los conteos "
                    + "antes de continuar.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        if (totalProductos == 0) {

            mostrarMensaje(
                    "No existen productos registrados en este conteo.",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            int idToma = convertirEnteroPositivo(
                    txtIdToma.getText(),
                    "conteo"
            );

            int confirmacion = JOptionPane.showConfirmDialog(
                    this,
                    "Está a punto de procesar el inventario físico.\n\n"
                    + "Productos: " + totalProductos
                    + "\nPendientes: " + totalPendientes
                    + "\n\nSe actualizarán existencias, movimientos "
                    + "y Kardex en una única transacción.\n\n"
                    + "¿Desea continuar?",
                    "Confirmar procesamiento",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirmacion != JOptionPane.YES_OPTION) {
                return;
            }

            ejecutarEnSegundoPlano(

                    () -> {

                        // Reconsultar el estado antes de procesar.
                        String estadoActual =
                                controller.obtenerEstadoConteo(idToma);

                        if (!"ABIERTO".equals(estadoActual)) {

                            throw new IllegalArgumentException(
                                    "La toma ya no se encuentra abierta."
                            );
                        }

                        // Revalidar los pendientes desde la base de datos.
                        List<DetalleInventarioFisico> actuales =
                                controller.listarDetalle(idToma);

                        if (actuales == null || actuales.isEmpty()) {

                            throw new IllegalArgumentException(
                                    "La toma no contiene productos."
                            );
                        }

                        long pendientes = actuales.stream()
                                .filter(d -> d == null || !d.estaContado())
                                .count();

                        if (pendientes > 0) {

                            throw new IllegalArgumentException(
                                    "Existen " + pendientes
                                    + " productos sin contar."
                            );
                        }

                        int ajustes =
                                controller.procesarConteo(idToma);

                        CargaConteo carga =
                                cargarDatosConteo(idToma);

                        return new ResultadoProcesamiento(
                                ajustes,
                                carga
                        );
                    },

                    resultado -> {

                        mostrarConteo(resultado.carga());

                        JOptionPane.showMessageDialog(
                                this,
                                "El inventario físico fue procesado correctamente.\n\n"
                                + "Ajustes registrados: "
                                + resultado.ajustes()
                                + "\nEstado: PROCESADO",
                                "Procesamiento completado",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
            );

        } catch (IllegalArgumentException ex) {

            mostrarMensaje(
                    ex.getMessage(),
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    // =========================================================
    // 26. ACTUALIZAR INDICADORES
    // =========================================================

    private void actualizarIndicadores(
            List<DetalleInventarioFisico> detalles
    ) {

        int total = 0;

        int contados = 0;

        int pendientes = 0;

        int faltantes = 0;

        int sobrantes = 0;

        BigDecimal impactoTotal = BigDecimal.ZERO;

        for (DetalleInventarioFisico detalle : detalles) {

            if (detalle == null) {
                continue;
            }

            total++;

            if (!detalle.estaContado()) {

                pendientes++;

                continue;
            }

            contados++;

            if (detalle.tieneFaltante()) {
                faltantes++;
            }

            if (detalle.tieneSobrante()) {
                sobrantes++;
            }

            if (detalle.getImpactoValorizado() != null) {

                impactoTotal = impactoTotal.add(
                        detalle.getImpactoValorizado()
                );
            }
        }

        totalProductos = total;

        totalPendientes = pendientes;

        lblTotalProductos.setText(
                String.valueOf(total)
        );

        lblContados.setText(
                String.valueOf(contados)
        );

        lblPendientes.setText(
                String.valueOf(pendientes)
        );

        lblFaltantes.setText(
                String.valueOf(faltantes)
        );

        lblSobrantes.setText(
                String.valueOf(sobrantes)
        );

        lblImpacto.setText(
                formatearDecimal(
                        impactoTotal,
                        ESCALA_MONETARIA
                )
        );

        if (impactoTotal.signum() < 0) {

            lblImpacto.setForeground(ROJO);

        } else if (impactoTotal.signum() > 0) {

            lblImpacto.setForeground(VERDE);

        } else {

            lblImpacto.setForeground(AZUL_PRINCIPAL);
        }

        actualizarControles();
    }

    // =========================================================
    // 27. BLOQUEO GLOBAL DE CONTROLES
    // =========================================================

    /**
     * Todos los botones principales se bloquean mientras
     * una operacion JDBC se ejecuta fuera del EDT.
     */
    private void setOcupado(boolean ocupado) {

        this.ocupado = ocupado;

        setCursor(
                Cursor.getPredefinedCursor(
                        ocupado
                                ? Cursor.WAIT_CURSOR
                                : Cursor.DEFAULT_CURSOR
                )
        );

        actualizarControles();
    }

    /**
     * Determina que controles pueden utilizarse segun:
     *
     * - Estado de la toma.
     * - Existencia de fila seleccionada.
     * - Cantidad de pendientes.
     * - Operacion actualmente en curso.
     */
    private void actualizarControles() {

        if (btnCrearConteo == null) {
            return;
        }

        boolean abierta =
                "ABIERTO".equals(estadoToma)
                && !tomaSoloLectura;

        boolean filaSeleccionada =
                idProductoSeleccionado != null;

        btnCrearConteo.setEnabled(!ocupado);

        btnCargar.setEnabled(!ocupado);

        btnRegistrarCantidad.setEnabled(
                !ocupado
                && abierta
                && filaSeleccionada
        );

        btnProcesar.setEnabled(
        !ocupado
        && abierta
        && totalProductos > 0
        );   

        btnLimpiar.setEnabled(!ocupado);

        txtIdAlmacen.setEnabled(!ocupado);

        txtIdToma.setEnabled(!ocupado);

        cmbModo.setEnabled(!ocupado);

        txtObservacionConteo.setEnabled(!ocupado);

        tablaDetalle.setEnabled(!ocupado);

        txtCantidadFisica.setEditable(
                !ocupado
                && abierta
                && filaSeleccionada
        );

        txtObservacionProducto.setEditable(
                !ocupado
                && abierta
                && filaSeleccionada
        );
    }

    // =========================================================
    // 28. LIMPIAR FORMULARIO
    // =========================================================

    private void limpiarCamposRegistro() {

        txtCantidadFisica.setText("");

        txtObservacionProducto.setText("");

        cantidadInicial = "";

        observacionInicial = "";
    }

    private void limpiarFormularioDetalle() {

        actualizandoSeleccion = true;

        try {

            tablaDetalle.clearSelection();

            idProductoSeleccionado = null;

            limpiarCamposRegistro();

        } finally {

            actualizandoSeleccion = false;
        }

        actualizarControles();
    }

    // =========================================================
    // 29. EJECUTAR EN SEGUNDO PLANO
    // =========================================================

    /**
     * Ejecuta las operaciones de base de datos mediante
     * SwingWorker para evitar bloquear el EDT.
     *
     * El bloqueo de controles se mantiene hasta que termina
     * la consulta y se procesa el resultado.
     */
    private <T> void ejecutarEnSegundoPlano(
            Callable<T> tarea,
            Consumer<T> alCompletar
    ) {

        if (ocupado) {
            return;
        }

        setOcupado(true);

        SwingWorker<T, Void> worker =
                new SwingWorker<>() {

                    @Override
                    protected T doInBackground()
                            throws Exception {

                        return tarea.call();
                    }

                    @Override
                    protected void done() {

                        try {

                            T resultado = get();

                            alCompletar.accept(resultado);

                        } catch (InterruptedException ex) {

                            Thread.currentThread().interrupt();

                            mostrarError(
                                    "Operación interrumpida.",
                                    ex
                            );

                        } catch (ExecutionException ex) {

                            mostrarError(
                                    "No se pudo completar la operación.",
                                    ex.getCause()
                            );

                        } catch (RuntimeException ex) {

                            mostrarError(
                                    "Ocurrió un error al actualizar la interfaz.",
                                    ex
                            );

                        } finally {

                            setOcupado(false);
                        }
                    }
                };

        worker.execute();
    }

    // =========================================================
    // 30. VALIDACIONES DE ENTRADA
    // =========================================================

    private int convertirEnteroPositivo(
            String valor,
            String campo
    ) {

        if (valor == null || valor.isBlank()) {

            throw new IllegalArgumentException(
                    "Ingrese el identificador del " + campo + "."
            );
        }

        try {

            int resultado = Integer.parseInt(
                    valor.trim()
            );

            if (resultado <= 0) {

                throw new IllegalArgumentException(
                        "El identificador del "
                        + campo + " debe ser positivo."
                );
            }

            return resultado;

        } catch (NumberFormatException ex) {

            throw new IllegalArgumentException(
                    "El identificador del "
                    + campo + " debe ser un entero valido."
            );
        }
    }

    private BigDecimal convertirDecimal(
            String valor,
            String campo
    ) {

        if (valor == null || valor.isBlank()) {

            throw new IllegalArgumentException(
                    "Ingrese la " + campo + "."
            );
        }

        try {

            return new BigDecimal(
                    valor.trim().replace(',', '.')
            );

        } catch (NumberFormatException ex) {

            throw new IllegalArgumentException(
                    "La " + campo + " debe ser un numero valido."
            );
        }
    }

    private String formatearDecimal(
            BigDecimal valor,
            int escala
    ) {

        if (valor == null) {
            return "—";
        }

        return valor.setScale(
                escala,
                RoundingMode.HALF_UP
        ).toPlainString();
    }

    // =========================================================
    // 31. MENSAJES Y ESTADOS
    // =========================================================

    private void establecerEstado(
            String texto,
            Color color
    ) {

        lblEstado.setText(texto);

        lblEstado.setForeground(color);
    }

    private void mostrarMensaje(
            String mensaje,
            int tipo
    ) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Inventario físico",
                tipo
        );
    }

    private void mostrarError(
            String titulo,
            Throwable error
    ) {

        String mensaje = obtenerMensajeError(error);

        establecerEstado(
                "OPERACION NO COMPLETADA",
                ROJO
        );

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                titulo,
                JOptionPane.ERROR_MESSAGE
        );
    }

    private String obtenerMensajeError(
            Throwable error
    ) {

        Throwable actual = error;

        while (actual != null && actual.getCause() != null) {
            actual = actual.getCause();
        }

        if (actual == null
                || actual.getMessage() == null
                || actual.getMessage().isBlank()) {

            return "Ocurrio un error inesperado.";
        }

        String mensaje = actual.getMessage();

        String normalizado =
                mensaje.toLowerCase();

        if (normalizado.contains("database is locked")
                || normalizado.contains("sqlite_busy")
                || normalizado.contains("busy")) {

            return "La base de datos esta ocupada por otra operacion. "
                    + "Intente nuevamente.";
        }

        if (normalizado.contains("unique constraint")) {

            return "Ya existe un registro duplicado. "
                    + "Compruebe los conteos abiertos.";
        }

        if (normalizado.contains("foreign key constraint")) {

            return "No se puede completar la operacion debido "
                    + "a una referencia relacionada.";
        }

        if (normalizado.contains("no se puede registrar el movimiento")
                || normalizado.contains("inventario fisico")) {

            return mensaje;
        }

        return mensaje;
    }

    // =========================================================
    // 32. COMPONENTES DE FORMULARIO
    // =========================================================

    private JPanel crearCampo(
            String titulo,
            Component componente
    ) {

        JPanel panel = new JPanel(
                new BorderLayout(0, 6)
        );

        panel.setOpaque(false);

        JLabel etiqueta = new JLabel(titulo);

        etiqueta.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        etiqueta.setForeground(TEXTO_SECUNDARIO);

        panel.add(etiqueta, BorderLayout.NORTH);

        panel.add(componente, BorderLayout.CENTER);

        return panel;
    }

    private JPanel crearCampoAccion(
            String titulo,
            JButton boton
    ) {

        JPanel panel = new JPanel(
                new BorderLayout(0, 6)
        );

        panel.setOpaque(false);

        JLabel etiqueta = new JLabel(titulo);

        etiqueta.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        etiqueta.setForeground(TEXTO_SECUNDARIO);

        boton.setPreferredSize(
                new Dimension(125, 34)
        );

        panel.add(etiqueta, BorderLayout.NORTH);

        panel.add(boton, BorderLayout.CENTER);

        return panel;
    }

    private JTextField crearCampoTexto() {

        JTextField campo = new JTextField();

        campo.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        campo.setForeground(TEXTO);

        campo.setCaretColor(AZUL_PRINCIPAL);

        campo.setPreferredSize(
                new Dimension(130, 36)
        );

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDE),
                        new EmptyBorder(7, 9, 7, 9)
                )
        );

        return campo;
    }

    private void estilizarCombo(
            JComboBox<String> combo
    ) {

        combo.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        combo.setForeground(TEXTO);

        combo.setBackground(BLANCO);

        combo.setPreferredSize(
                new Dimension(130, 36)
        );
    }

    // =========================================================
    // 33. BOTONES
    // =========================================================

    private JButton crearBotonPrimario(
            String texto
    ) {

        return crearBoton(
                texto,
                AZUL_PRINCIPAL,
                BLANCO
        );
    }

    private JButton crearBotonSecundario(
            String texto
    ) {

        JButton boton = crearBoton(
                texto,
                BLANCO,
                AZUL_PRINCIPAL
        );

        boton.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDE),
                        new EmptyBorder(7, 13, 7, 13)
                )
        );

        return boton;
    }

    private JButton crearBotonExito(
            String texto
    ) {

        return crearBoton(
                texto,
                VERDE,
                BLANCO
        );
    }

    private JButton crearBoton(
            String texto,
            Color fondo,
            Color primerPlano
    ) {

        JButton boton = new JButton(texto);

        boton.setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        boton.setForeground(primerPlano);

        boton.setBackground(fondo);

        boton.setFocusPainted(false);

        boton.setOpaque(true);

        boton.setBorderPainted(false);

        boton.setBorder(
                new EmptyBorder(9, 15, 9, 15)
        );

        boton.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        return boton;
    }

    // =========================================================
    // 34. PANELES Y ETIQUETAS
    // =========================================================

    private JPanel crearPanelBlanco() {

        JPanel panel = new JPanel();

        panel.setBackground(BLANCO);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDE),
                        new EmptyBorder(1, 1, 1, 1)
                )
        );

        return panel;
    }

    private JLabel crearEtiquetaTitulo(
            String texto
    ) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        etiqueta.setForeground(AZUL_PRINCIPAL);

        return etiqueta;
    }

    // =========================================================
    // 35. MODELO DE TABLA
    // =========================================================

    private static class ModeloTablaInventario
            extends DefaultTableModel {

        private static final String[] COLUMNAS = {
                "Código",
                "Producto",
                "Unidad",
                "Stock sistema",
                "Cantidad física",
                "Diferencia",
                "Costo promedio",
                "Impacto valorizado",
                "Observación"
        };

        private List<DetalleInventarioFisico> detalles =
                new ArrayList<>();

        private ModeloTablaInventario() {
            super(COLUMNAS, 0);
        }

        public void setDatos(
                List<DetalleInventarioFisico> datos
        ) {

            detalles = datos == null
                    ? new ArrayList<>()
                    : new ArrayList<>(datos);

            fireTableDataChanged();
        }

        public DetalleInventarioFisico getDetalleAt(
                int fila
        ) {

            if (fila < 0 || fila >= detalles.size()) {
                return null;
            }

            return detalles.get(fila);
        }

        public int buscarFilaPorProducto(
                int idProducto
        ) {

            for (int i = 0; i < detalles.size(); i++) {

                DetalleInventarioFisico d = detalles.get(i);

                if (d != null
                        && d.getIdProducto() == idProducto) {

                    return i;
                }
            }

            return -1;
        }

        @Override
        public int getRowCount() {
            return detalles == null ? 0 : detalles.size();
        }

        @Override
        public int getColumnCount() {
            return COLUMNAS.length;
        }

        @Override
        public String getColumnName(int columna) {
            return COLUMNAS[columna];
        }

        @Override
        public Object getValueAt(
                int fila,
                int columna
        ) {

            DetalleInventarioFisico d =
                    detalles.get(fila);

            if (d == null) {
                return "";
            }

            switch (columna) {

                case 0:
                    return d.getCodigoProducto();

                case 1:
                    return d.getNombreProducto();

                case 2:
                    return d.getUnidadMedida();

                case 3:
                    return formato(d.getStockSistema(), 3);

                case 4:
                    return d.getCantidadFisica() == null
                            ? "Pendiente"
                            : formato(d.getCantidadFisica(), 3);

                case 5:
                    return d.getDiferencia() == null
                            ? "Pendiente"
                            : formato(d.getDiferencia(), 3);

                case 6:
                    return formato(d.getCostoPromedio(), 6);

                case 7:
                    return d.getImpactoValorizado() == null
                            ? "Pendiente"
                            : formato(
                                    d.getImpactoValorizado(),
                                    6
                            );

                case 8:
                    return d.getObservacion() == null
                            ? ""
                            : d.getObservacion();

                default:
                    return "";
            }
        }

        private static String formato(
                BigDecimal valor,
                int escala
        ) {

            if (valor == null) {
                return "—";
            }

            return valor.setScale(
                    escala,
                    RoundingMode.HALF_UP
            ).toPlainString();
        }

        @Override
        public boolean isCellEditable(
                int fila,
                int columna
        ) {
            return false;
        }
    }

    // =========================================================
    // 36. RENDERIZADOR DE DIFERENCIAS
    // =========================================================

    private class RendererDiferencia
            extends DefaultTableCellRenderer {

        public RendererDiferencia() {

            setHorizontalAlignment(
                    SwingConstants.RIGHT
            );
        }

        @Override
        public Component getTableCellRendererComponent(
                JTable tabla,
                Object valor,
                boolean seleccionado,
                boolean tieneFoco,
                int fila,
                int columna
        ) {

            Component componente =
                    super.getTableCellRendererComponent(
                            tabla,
                            valor,
                            seleccionado,
                            tieneFoco,
                            fila,
                            columna
                    );

            if (seleccionado) {

                componente.setBackground(
                        tabla.getSelectionBackground()
                );

                componente.setForeground(
                        tabla.getSelectionForeground()
                );

                return componente;
            }

            int filaModelo =
                    tabla.convertRowIndexToModel(fila);

            DetalleInventarioFisico detalle =
                    modeloTabla.getDetalleAt(filaModelo);

            setFont(
                    new Font("Segoe UI", Font.BOLD, 11)
            );

            if (detalle == null || !detalle.estaContado()) {

                setForeground(TEXTO_SECUNDARIO);

            } else if (detalle.tieneFaltante()) {

                setForeground(ROJO);

            } else if (detalle.tieneSobrante()) {

                setForeground(NARANJA);

            } else {

                setForeground(VERDE);
            }

            setBackground(
                    fila % 2 == 0
                            ? BLANCO
                            : new Color(248, 250, 252)
            );

            return componente;
        }
    }

    // =========================================================
    // 37. FILTRO DE CANTIDAD FISICA
    // =========================================================

    /**
     * Impide:
     * - Letras.
     * - Signos negativos.
     * - Simbolos no numericos.
     * - Mas de un separador decimal.
     * - Mas de tres decimales.
     *
     * Admite punto o coma decimal.
     * Tambien admite pegar texto validado.
     */
    private static class FiltroCantidad
            extends DocumentFilter {

        private static final Pattern PATRON =
                Pattern.compile("\\d*(?:[.,]\\d{0,3})?");

        @Override
        public void insertString(
                FilterBypass fb,
                int offset,
                String texto,
                AttributeSet attrs
        ) throws BadLocationException {

            if (texto == null) {
                return;
            }

            String actual = fb.getDocument().getText(
                    0,
                    fb.getDocument().getLength()
            );

            String nuevo =
                    actual.substring(0, offset)
                    + texto
                    + actual.substring(offset);

            if (PATRON.matcher(nuevo).matches()) {
                fb.insertString(
                        offset,
                        texto,
                        attrs
                );
            }
        }

        @Override
        public void replace(
                FilterBypass fb,
                int offset,
                int length,
                String texto,
                AttributeSet attrs
        ) throws BadLocationException {

            String actual = fb.getDocument().getText(
                    0,
                    fb.getDocument().getLength()
            );

            String reemplazo =
                    texto == null ? "" : texto;

            String nuevo =
                    actual.substring(0, offset)
                    + reemplazo
                    + actual.substring(offset + length);

            if (PATRON.matcher(nuevo).matches()) {

                fb.replace(
                        offset,
                        length,
                        reemplazo,
                        attrs
                );
            }
        }

        @Override
        public void remove(
                FilterBypass fb,
                int offset,
                int length
        ) throws BadLocationException {

            fb.remove(offset, length);
        }
    }

    // =========================================================
    // 38. RESULTADOS DE OPERACIONES ASINCRONAS
    // =========================================================

    private record CargaConteo(
            String estado,
            List<DetalleInventarioFisico> detalles
    ) {}

    private record CreacionConteo(
            int idToma,
            CargaConteo carga
    ) {}

    private record ResultadoProcesamiento(
            int ajustes,
            CargaConteo carga
    ) {}
}
