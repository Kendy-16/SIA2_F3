package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Selector de productos para una toma parcial. La selección solo se aplica al pulsar "Aplicar selección". */
public class SeleccionProductosDialog extends JDialog {
    private final InventarioFisicoController controller;
    private final String almacen;
    private final String categoria;
    private final Set<Long> destino;
    private final Set<Long> trabajo;
    private final TablaProductosSeleccionModel modelo;
    private final JTable tabla;
    private final JLabel contador = new JLabel();

    public SeleccionProductosDialog(Window owner, InventarioFisicoController controller, String almacen, String categoria, Set<Long> seleccionados) {
        super(owner, "Seleccionar productos para la toma", ModalityType.APPLICATION_MODAL);
        this.controller = controller; this.almacen = almacen; this.categoria = categoria; this.destino = seleccionados;
        this.trabajo = new LinkedHashSet<>(seleccionados);
        this.modelo = new TablaProductosSeleccionModel(trabajo);
        this.tabla = new JTable(modelo);
        setSize(780, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));

        add(new PanelBusquedaProductos(this::cargar), BorderLayout.NORTH);
        estiloTabla(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(90);
        tabla.getColumnModel().getColumn(5).setCellRenderer(new CantidadRenderer());
        modelo.addTableModelListener(e -> actualizarContador());
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JButton todos = botonSecundario("Marcar visibles"), ninguno = botonSecundario("Quitar visibles");
        JButton cancelar = botonSecundario("Cancelar"), aplicar = botonPrimario("Aplicar selección");
        JPanel abajo = new JPanel(new BorderLayout());
        JPanel izq = new JPanel(new FlowLayout(FlowLayout.LEFT)); izq.add(todos); izq.add(ninguno); izq.add(contador);
        JPanel der = new JPanel(new FlowLayout(FlowLayout.RIGHT)); der.add(cancelar); der.add(aplicar);
        abajo.add(izq, BorderLayout.WEST); abajo.add(der, BorderLayout.EAST);
        add(abajo, BorderLayout.SOUTH);

        todos.addActionListener(e -> modelo.marcarVisibles(true));
        ninguno.addActionListener(e -> modelo.marcarVisibles(false));
        cancelar.addActionListener(e -> dispose());
        aplicar.addActionListener(e -> { destino.clear(); destino.addAll(trabajo); dispose(); });
        actualizarContador();
        cargar("");
    }

    private void actualizarContador() { contador.setText("Seleccionados: " + trabajo.size()); }

    private void cargar(String texto) {
        TareaAsincrona.ejecutar(this, () -> controller.listarProductosDisponibles(texto, categoria, almacen), modelo::setFilas);
    }
}
