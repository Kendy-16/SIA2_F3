package pe.edu.inventario.controlador.venta;

import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.servicio.venta.VentaAdminService;
import pe.edu.inventario.vista.venta.componentes.DialogoAutorizacion;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class VentaAdminController {

    private VentaAdminService adminService;
    private JFrame ventanaPrincipal; // Referencia a la ventana base para centrar modales

    public VentaAdminController(VentaAdminService adminService, JFrame ventanaPrincipal) {
        this.adminService = adminService;
        this.ventanaPrincipal = ventanaPrincipal;
    }

    public void solicitarAnulacion(String idVenta, RolUsuario rolCajero) {
        String idAdmin = null;
        RolUsuario rolEfectivo = rolCajero;

        // Si el que opera es un USUARIO, pedir clave de administrador
        if (rolCajero != RolUsuario.ADMINISTRADOR) {
            DialogoAutorizacion auth = new DialogoAutorizacion(ventanaPrincipal, "Anular Venta " + idVenta);
            auth.setVisible(true);
            
            if (auth.isAutorizado()) {
                rolEfectivo = RolUsuario.ADMINISTRADOR; // Se eleva el privilegio temporalmente
                idAdmin = auth.getIdAdminAutorizador();
            } else {
                return; // Se canceló la anulación
            }
        }

        // Pedir motivo (Obligatorio para auditoría)
        String motivo = JOptionPane.showInputDialog(ventanaPrincipal, "Ingrese el motivo de la anulación:");
        if (motivo != null && !motivo.trim().isEmpty()) {
            try {
                adminService.anularVenta(idVenta, motivo, rolEfectivo, idAdmin);
                JOptionPane.showMessageDialog(ventanaPrincipal, "Venta anulada correctamente. Kardex actualizado.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(ventanaPrincipal, e.getMessage(), "Error al anular", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
