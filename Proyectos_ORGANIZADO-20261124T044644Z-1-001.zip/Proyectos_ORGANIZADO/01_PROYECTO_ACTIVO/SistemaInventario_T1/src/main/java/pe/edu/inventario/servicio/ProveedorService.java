
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Proveedor;
import pe.edu.inventario.modelo.dao.ProveedorDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Business rules and validations for suppliers.
 */
public class ProveedorService {

    private final ProveedorDAO proveedorDAO;

    // Maximum lengths
    private static final int MAX_RUC = 11;
    private static final int MAX_RAZON_SOCIAL = 150;
    private static final int MAX_TELEFONO = 20;
    private static final int MAX_CORREO = 120;
    private static final int MAX_DIRECCION = 250;

    // Validation patterns
    private static final Pattern RUC_PATTERN =
            Pattern.compile("^(10|20)[0-9]{9}$");

    private static final Pattern RAZON_SOCIAL_PATTERN =
            Pattern.compile(
                    "^[\\p{L}\\p{M}\\p{N}][\\p{L}\\p{M}\\p{N} .,&'()/-]*$"
            );

    private static final Pattern TELEFONO_PATTERN =
            Pattern.compile("^\\+?[0-9]{7,15}$");

    private static final Pattern CORREO_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)+$"
            );

    // Constructor
    public ProveedorService() {
        this.proveedorDAO = new ProveedorDAO();
    }

    // Constructor for dependency injection and testing
    public ProveedorService(ProveedorDAO proveedorDAO) {

        if (proveedorDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de proveedores no puede ser nulo."
            );
        }

        this.proveedorDAO = proveedorDAO;
    }

    // ==========================================
    // 1. REGISTER SUPPLIER
    // ==========================================

    public boolean registrar(Proveedor proveedor) throws SQLException {

        validarProveedor(proveedor);

        if (proveedorDAO.existeRuc(proveedor.getRuc(), 0)) {
            throw new IllegalArgumentException(
                    "Ya existe un proveedor registrado con ese RUC."
            );
        }

        return proveedorDAO.insertar(proveedor);
    }

    // ==========================================
    // 2. LIST SUPPLIERS
    // ==========================================

    public ArrayList<Proveedor> listar() throws SQLException {

        ArrayList<Proveedor> proveedores = proveedorDAO.listar();

        if (proveedores == null) {
            return new ArrayList<>();
        }

        return proveedores;
    }

    // ==========================================
    // 3. SEARCH BY ID
    // ==========================================

    public Proveedor buscarPorId(int idProveedor)
            throws SQLException {

        if (idProveedor <= 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser positivo."
            );
        }

        Proveedor proveedor = proveedorDAO.buscarPorId(idProveedor);

        if (proveedor == null) {
            throw new IllegalArgumentException(
                    "No se encontro el proveedor solicitado."
            );
        }

        return proveedor;
    }

    // ==========================================
    // 4. UPDATE SUPPLIER
    // ==========================================

    public boolean actualizar(Proveedor proveedor)
            throws SQLException {

        if (proveedor == null || proveedor.getIdProveedor() <= 0) {
            throw new IllegalArgumentException(
                    "Seleccione un proveedor valido para actualizar."
            );
        }

        validarProveedor(proveedor);

        Proveedor existente =
                proveedorDAO.buscarPorId(proveedor.getIdProveedor());

        if (existente == null) {
            throw new IllegalArgumentException(
                    "El proveedor que intenta actualizar no existe."
            );
        }

        if (proveedorDAO.existeRuc(
                proveedor.getRuc(),
                proveedor.getIdProveedor()
        )) {
            throw new IllegalArgumentException(
                    "El RUC ya esta registrado por otro proveedor."
            );
        }

        return proveedorDAO.actualizar(proveedor);
    }

    // ==========================================
    // 5. DELETE SUPPLIER
    // ==========================================

    public boolean eliminar(int idProveedor) throws SQLException {

        if (idProveedor <= 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser positivo."
            );
        }

        Proveedor existente = proveedorDAO.buscarPorId(idProveedor);

        if (existente == null) {
            throw new IllegalArgumentException(
                    "El proveedor que intenta eliminar no existe."
            );
        }

        try {

            return proveedorDAO.eliminar(idProveedor);

        } catch (SQLException ex) {

            String detalle = ex.getMessage();

            if (detalle != null &&
                    detalle.toUpperCase().contains("FOREIGN KEY")) {

                throw new SQLException(
                        "No se puede eliminar el proveedor porque esta asociado a uno o mas productos.",
                        ex
                );
            }

            throw ex;
        }
    }

    // ==========================================
    // 6. VALIDATE SUPPLIER DATA
    // ==========================================

    public void validarProveedor(Proveedor proveedor) {

        if (proveedor == null) {
            throw new IllegalArgumentException(
                    "Los datos del proveedor son obligatorios."
            );
        }

        // RUC
        String ruc = normalizar(proveedor.getRuc());

        if (ruc.isEmpty()) {
            throw new IllegalArgumentException(
                    "El RUC es obligatorio."
            );
        }

        if (ruc.length() != MAX_RUC ||
                !RUC_PATTERN.matcher(ruc).matches()) {

            throw new IllegalArgumentException(
                    "El RUC debe tener 11 digitos y comenzar con 10 o 20."
            );
        }

        if (!validarDigitoVerificadorRuc(ruc)) {
            throw new IllegalArgumentException(
                    "El digito verificador del RUC no es valido."
            );
        }

        proveedor.setRuc(ruc);

        // Business name
        String razonSocial = normalizar(proveedor.getRazonSocial());

        if (razonSocial.isEmpty()) {
            throw new IllegalArgumentException(
                    "La razon social es obligatoria."
            );
        }

        if (razonSocial.length() < 2 ||
                razonSocial.length() > MAX_RAZON_SOCIAL ||
                !RAZON_SOCIAL_PATTERN.matcher(razonSocial).matches()) {

            throw new IllegalArgumentException(
                    "La razon social debe tener entre 2 y 150 caracteres validos."
            );
        }

        proveedor.setRazonSocial(razonSocial);

        // Phone
        String telefono = normalizar(proveedor.getTelefono());

        if (!telefono.isEmpty()) {

            telefono = telefono.replaceAll("[\\s()-]", "");

            if (telefono.length() > MAX_TELEFONO ||
                    !TELEFONO_PATTERN.matcher(telefono).matches()) {

                throw new IllegalArgumentException(
                        "El telefono debe contener entre 7 y 15 digitos. Puede incluir el prefijo +."
                );
            }
        }

        proveedor.setTelefono(valorONull(telefono));

        // Email
        String correo = normalizar(proveedor.getCorreo());

        if (!correo.isEmpty()) {

            if (correo.length() > MAX_CORREO ||
                    !CORREO_PATTERN.matcher(correo).matches()) {

                throw new IllegalArgumentException(
                        "El correo electronico no tiene un formato valido."
                );
            }
        }

        proveedor.setCorreo(valorONull(correo));

        // Address
        String direccion = normalizar(proveedor.getDireccion());

        if (direccion.length() > MAX_DIRECCION) {
            throw new IllegalArgumentException(
                    "La direccion no puede superar los 250 caracteres."
            );
        }

        if (contieneCaracteresDeControl(direccion)) {
            throw new IllegalArgumentException(
                    "La direccion contiene caracteres no permitidos."
            );
        }

        proveedor.setDireccion(valorONull(direccion));

        // ID
        if (proveedor.getIdProveedor() < 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor no puede ser negativo."
            );
        }
    }

    // ==========================================
    // 7. VALIDATE PERUVIAN RUC CHECK DIGIT
    // ==========================================

    private boolean validarDigitoVerificadorRuc(String ruc) {

        int[] pesos = {5, 4, 3, 2, 7, 6, 5, 4, 3, 2};

        int suma = 0;

        for (int i = 0; i < 10; i++) {

            int digito = Character.getNumericValue(ruc.charAt(i));

            suma += digito * pesos[i];
        }

        int resultado = 11 - (suma % 11);

        if (resultado == 11) {
            resultado = 0;
        } else if (resultado == 10) {
            resultado = 1;
        }

        int digitoVerificador =
                Character.getNumericValue(ruc.charAt(10));

        return resultado == digitoVerificador;
    }

    // ==========================================
    // 8. NORMALIZE TEXT
    // ==========================================

    private String normalizar(String valor) {

        return valor == null ? "" : valor.trim();
    }

    // ==========================================
    // 9. CONVERT EMPTY VALUES TO NULL
    // ==========================================

    private String valorONull(String valor) {

        return valor == null || valor.isBlank()
                ? null
                : valor.trim();
    }

    // ==========================================
    // 10. CHECK CONTROL CHARACTERS
    // ==========================================

    private boolean contieneCaracteresDeControl(String texto) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }
}
