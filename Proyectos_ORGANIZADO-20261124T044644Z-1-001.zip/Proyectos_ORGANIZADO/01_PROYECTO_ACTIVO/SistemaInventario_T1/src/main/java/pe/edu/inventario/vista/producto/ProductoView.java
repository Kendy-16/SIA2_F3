

package pe.edu.inventario.vista.producto;

import pe.edu.inventario.controlador.ProductoController;
import pe.edu.inventario.modelo.Producto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class ProductoView extends JPanel {

    // ==========================================
    // 1. COMPONENTES
    // ==========================================

    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtCategoria;
    private JTextField txtProveedor;
    private JTextField txtStockMinimo;
    private JTextField txtBuscar;

    private JTextArea txtDescripcion;

    private JComboBox<String> cmbUnidadMedida;

    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;

    private TableRowSorter<DefaultTableModel> ordenadorTabla;

    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnBuscarImagen;

    private int idSeleccionado = -1;

    private final ProductoController controlador;

    // ==========================================
    // 2. CONSTANTES
    // ==========================================

    private static final String[] UNIDADES_VALIDAS = {
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    };

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public ProductoView() {

        this(new ProductoController());
    }

    public ProductoView(ProductoController controlador) {

        if (controlador == null) {
            throw new IllegalArgumentException(
                    "El controlador de productos es obligatorio."
            );
        }

        this.controlador = controlador;

        inicializarComponentes();
        configurarEventos();
        cargarProductos();
    }

    // ==========================================
    // 4. INICIALIZAR INTERFAZ
    // ==========================================

    private void inicializarComponentes() {

        setLayout(new BorderLayout(10, 10));

        setBorder(
                new EmptyBorder(12, 12, 12, 12)
        );

        // Title
        JLabel lblTitulo = new JLabel(
                "GESTION DE PRODUCTOS"
        );

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 20)
        );

        JPanel panelTitulo = new JPanel(
                new FlowLayout(FlowLayout.LEFT)
        );

        panelTitulo.add(lblTitulo);

        add(panelTitulo, BorderLayout.NORTH);

        // Main section
        JPanel panelCentro = new JPanel(
                new BorderLayout(10, 10)
        );

        panelCentro.add(
                crearFormulario(),
                BorderLayout.NORTH
        );

        panelCentro.add(
                crearTabla(),
                BorderLayout.CENTER
        );

        panelCentro.add(
                crearPanelBotones(),
                BorderLayout.SOUTH
        );

        add(panelCentro, BorderLayout.CENTER);
    }

    // ==========================================
    // 5. CREAR FORMULARIO
    // ==========================================

    private JPanel crearFormulario() {

        JPanel panel = new JPanel(
                new GridBagLayout()
        );

        panel.setBorder(
                BorderFactory.createTitledBorder(
                        "Datos del producto"
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets = new Insets(5, 8, 5, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtCodigo = new JTextField(15);
        txtNombre = new JTextField(25);

        txtCategoria = new JTextField(10);
        txtProveedor = new JTextField(10);

        txtStockMinimo = new JTextField(12);

        txtDescripcion = new JTextArea(3, 25);

        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);

        cmbUnidadMedida = new JComboBox<>(
                UNIDADES_VALIDAS
        );

        // First row
        agregarCampo(
                panel, gbc, 0, 0,
                "Codigo *:", txtCodigo
        );

        agregarCampo(
                panel, gbc, 2, 0,
                "Nombre *:", txtNombre
        );

        // Second row
        agregarCampo(
                panel, gbc, 0, 1,
                "ID Categoria:", txtCategoria
        );

        agregarCampo(
                panel, gbc, 2, 1,
                "ID Proveedor:", txtProveedor
        );

        // Third row
        agregarCampo(
                panel, gbc, 0, 2,
                "Unidad *:", cmbUnidadMedida
        );

        agregarCampo(
                panel, gbc, 2, 2,
                "Stock minimo *:", txtStockMinimo
        );

        // Description
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;
        gbc.gridwidth = 1;

        panel.add(
                new JLabel("Descripcion:"),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.gridwidth = 3;

        JScrollPane scrollDescripcion =
                new JScrollPane(txtDescripcion);

        panel.add(
                scrollDescripcion,
                gbc
        );

        // Instructions
        JLabel lblNota = new JLabel(
                "* Campos obligatorios. Los ID de categoria y proveedor son opcionales."
        );

        lblNota.setForeground(Color.GRAY);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 4;

        panel.add(lblNota, gbc);

        return panel;
    }

    // ==========================================
    // 6. AGREGAR CAMPO
    // ==========================================

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int columna,
            int fila,
            String etiqueta,
            JComponent campo
    ) {

        gbc.gridx = columna;
        gbc.gridy = fila;

        gbc.weightx = 0;
        gbc.gridwidth = 1;

        panel.add(
                new JLabel(etiqueta),
                gbc
        );

        gbc.gridx = columna + 1;
        gbc.weightx = 1;

        panel.add(campo, gbc);
    }

    // ==========================================
    // 7. CREAR TABLA
    // ==========================================

    private JPanel crearTabla() {

        JPanel panel = new JPanel(
                new BorderLayout(5, 5)
        );

        panel.setBorder(
                BorderFactory.createTitledBorder(
                        "Listado de productos"
                )
        );

        // Search
        JPanel panelBusqueda = new JPanel(
                new BorderLayout(5, 5)
        );

        txtBuscar = new JTextField();

        JButton btnBuscar = new JButton("Buscar");

        JButton btnMostrarTodos =
                new JButton("Mostrar todos");

        panelBusqueda.add(
                new JLabel("Buscar:"),
                BorderLayout.WEST
        );

        panelBusqueda.add(
                txtBuscar,
                BorderLayout.CENTER
        );

        JPanel panelAcciones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );

        panelAcciones.add(btnBuscar);
        panelAcciones.add(btnMostrarTodos);

        panelBusqueda.add(
                panelAcciones,
                BorderLayout.EAST
        );

        // Table model
        modeloTabla = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "Codigo",
                        "Nombre",
                        "Descripcion",
                        "ID Categoria",
                        "ID Proveedor",
                        "Unidad",
                        "Stock minimo"
                },
                0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna
            ) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columna) {

                if (columna == 0
                        || columna == 4
                        || columna == 5) {
                    return Integer.class;
                }

                if (columna == 7) {
                    return Double.class;
                }

                return String.class;
            }
        };

        // JTable
        tablaProductos = new JTable(modeloTabla);

        tablaProductos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaProductos.setRowHeight(25);
        tablaProductos.setFillsViewportHeight(true);

        tablaProductos.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        ordenadorTabla =
                new TableRowSorter<>(modeloTabla);

        tablaProductos.setRowSorter(
                ordenadorTabla
        );

        // Column widths
        int[] anchos = {
                50, 110, 180, 250,
                90, 90, 110, 110
        };

        for (int i = 0; i < anchos.length; i++) {

            tablaProductos.getColumnModel()
                    .getColumn(i)
                    .setPreferredWidth(anchos[i]);
        }

        JScrollPane scroll = new JScrollPane(
                tablaProductos
        );

        panel.add(
                panelBusqueda,
                BorderLayout.NORTH
        );

        panel.add(
                scroll,
                BorderLayout.CENTER
        );

        btnBuscar.addActionListener(
                e -> buscarEnTabla()
        );

        txtBuscar.addActionListener(
                e -> buscarEnTabla()
        );

        btnMostrarTodos.addActionListener(e -> {

            txtBuscar.setText("");

            ordenadorTabla.setRowFilter(null);

            tablaProductos.clearSelection();
        });

        return panel;
    }

    // ==========================================
    // 8. BOTONES
    // ==========================================

    private JPanel crearPanelBotones() {

        JPanel panel = new JPanel(
                new FlowLayout(
                        FlowLayout.CENTER,
                        12,
                        8
                )
        );

        btnGuardar = new JButton("Guardar");

        btnActualizar = new JButton("Actualizar");

        btnEliminar = new JButton("Eliminar");

        btnLimpiar = new JButton("Limpiar");
        btnBuscarImagen = new JButton("Buscar imagen");
        btnBuscarImagen.setEnabled(false);

        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        panel.add(btnGuardar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnLimpiar);
        panel.add(btnBuscarImagen);

        return panel;
    }

    // ==========================================
    // 9. CONFIGURAR EVENTOS
    // ==========================================

    private void configurarEventos() {

        btnGuardar.addActionListener(
                e -> guardarProducto()
        );

        btnActualizar.addActionListener(
                e -> actualizarProducto()
        );

        btnEliminar.addActionListener(
                e -> eliminarProducto()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFormulario()
        );

        btnBuscarImagen.addActionListener(
                e -> abrirBuscadorImagenes()
        );

        tablaProductos.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {
                        seleccionarProducto();
                    }
                });
    }

    // ==========================================
    // 10. OBTENER DATOS DEL FORMULARIO
    // ==========================================

    private Producto obtenerDatosFormulario() {

        String codigo = txtCodigo.getText().trim();

        String nombre = txtNombre.getText().trim();

        String descripcion =
                txtDescripcion.getText().trim();

        String categoriaTexto =
                txtCategoria.getText().trim();

        String proveedorTexto =
                txtProveedor.getText().trim();

        String stockTexto =
                txtStockMinimo.getText().trim();

        String unidadMedida =
                (String) cmbUnidadMedida.getSelectedItem();

        // Required fields
        if (codigo.isEmpty()) {
            mostrarAdvertencia(
                    "El codigo del producto es obligatorio.",
                    txtCodigo
            );
            return null;
        }

        if (nombre.isEmpty()) {
            mostrarAdvertencia(
                    "El nombre del producto es obligatorio.",
                    txtNombre
            );
            return null;
        }

        if (stockTexto.isEmpty()) {
            mostrarAdvertencia(
                    "El stock minimo es obligatorio.",
                    txtStockMinimo
            );
            return null;
        }

        // Optional category ID
        Integer idCategoria =
                convertirIdOpcional(
                        categoriaTexto,
                        "Categoria:",
                        txtCategoria
                );

        if (!categoriaTexto.isEmpty()
                && idCategoria == null) {
            return null;
        }

        // Optional supplier ID
        Integer idProveedor =
                convertirIdOpcional(
                        proveedorTexto,
                        "Proveedor:",
                        txtProveedor
                );

        if (!proveedorTexto.isEmpty()
                && idProveedor == null) {
            return null;
        }

        // Minimum stock
        double stockMinimo;

        try {

            stockMinimo = Double.parseDouble(
                    stockTexto
            );

        } catch (NumberFormatException ex) {

            mostrarAdvertencia(
                    "El stock minimo debe ser numerico.",
                    txtStockMinimo
            );

            return null;
        }

        if (!Double.isFinite(stockMinimo)
                || stockMinimo < 0) {

            mostrarAdvertencia(
                    "El stock minimo debe ser finito y no negativo.",
                    txtStockMinimo
            );

            return null;
        }

        if (unidadMedida == null) {

            mostrarAdvertencia(
                    "Seleccione una unidad de medida.",
                    txtStockMinimo
            );

            return null;
        }

        // Build product object
        Producto producto = new Producto();

        if (idSeleccionado > 0) {
            producto.setIdProducto(idSeleccionado);
        }

        producto.setCodigo(codigo);
        producto.setNombre(nombre);

        producto.setDescripcion(
                descripcion.isEmpty() ? null : descripcion
        );

        producto.setIdCategoria(idCategoria);
        producto.setIdProveedor(idProveedor);

        producto.setUnidadMedida(unidadMedida);
        producto.setStockMinimo(stockMinimo);

        return producto;
    }

    // ==========================================
    // 11. CONVERTIR ID OPCIONAL
    // ==========================================

    private Integer convertirIdOpcional(
            String texto,
            String campo,
            JTextField componente
    ) {

        if (texto.isEmpty()) {
            return null;
        }

        try {

            int id = Integer.parseInt(texto);

            if (id <= 0) {

                mostrarAdvertencia(
                        campo + " debe ser un entero positivo.",
                        componente
                );

                return null;
            }

            return id;

        } catch (NumberFormatException ex) {

            mostrarAdvertencia(
                    campo + " debe contener un numero entero valido.",
                    componente
            );

            return null;
        }
    }

    // ==========================================
    // 12. REGISTRAR PRODUCTO
    // ==========================================

    private void guardarProducto() {

        try {

            Producto producto =
                    obtenerDatosFormulario();

            if (producto == null) {
                return;
            }

            boolean registrado =
                    controlador.registrarProducto(producto);

            if (registrado) {

                mostrarInformacion(
                        "Producto registrado correctamente."
                );

                limpiarFormulario();

                cargarProductos();

            } else {

                mostrarError(
                        "No se pudo registrar el producto."
                );
            }

        } catch (Exception ex) {

            mostrarError(ex.getMessage());
        }
    }

    // ==========================================
    // 13. ACTUALIZAR PRODUCTO
    // ==========================================

    private void actualizarProducto() {

        if (idSeleccionado <= 0) {

            mostrarError(
                    "Seleccione un producto para actualizar."
            );

            return;
        }

        try {

            Producto producto =
                    obtenerDatosFormulario();

            if (producto == null) {
                return;
            }

            boolean actualizado =
                    controlador.actualizarProducto(producto);

            if (actualizado) {

                mostrarInformacion(
                        "Producto actualizado correctamente."
                );

                limpiarFormulario();

                cargarProductos();

            } else {

                mostrarError(
                        "No se pudo actualizar el producto."
                );
            }

        } catch (Exception ex) {

            mostrarError(ex.getMessage());
        }
    }

    // ==========================================
    // 14. ELIMINAR PRODUCTO
    // ==========================================

    private void eliminarProducto() {

        if (idSeleccionado <= 0) {

            mostrarError(
                    "Seleccione un producto."
            );

            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "Esta seguro de eliminar el producto seleccionado?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean eliminado =
                    controlador.eliminarProducto(
                            idSeleccionado
                    );

            if (eliminado) {

                mostrarInformacion(
                        "Producto eliminado correctamente."
                );

                limpiarFormulario();

                cargarProductos();

            } else {

                mostrarError(
                        "No se pudo eliminar el producto."
                );
            }

        } catch (Exception ex) {

            mostrarError(ex.getMessage());
        }
    }

    // ==========================================
    // 15. CARGAR PRODUCTOS
    // ==========================================

    private void cargarProductos() {

        try {

            ArrayList<Producto> productos =
                    controlador.listarProductos();

            if (productos == null) {
                throw new IllegalStateException(
                        "El controlador devolvio una lista nula."
                );
            }

            modeloTabla.setRowCount(0);

            for (Producto producto : productos) {

                if (producto == null) {
                    continue;
                }

                modeloTabla.addRow(
                        new Object[]{

                                producto.getIdProducto(),
                                producto.getCodigo(),
                                producto.getNombre(),
                                textoSeguro(producto.getDescripcion()),
                                producto.getIdCategoria(),
                                producto.getIdProveedor(),
                                producto.getUnidadMedida(),
                                producto.getStockMinimo()
                        }
                );
            }

        } catch (Exception ex) {

            mostrarError(
                    "No se pudieron cargar los productos: "
                            + ex.getMessage()
            );
        }
    }

    // ==========================================
    // 16. SELECCIONAR PRODUCTO
    // ==========================================

    private void seleccionarProducto() {

        int filaVista =
                tablaProductos.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo =
                tablaProductos.convertRowIndexToModel(
                        filaVista
                );

        Object valorId =
                modeloTabla.getValueAt(filaModelo, 0);

        if (!(valorId instanceof Number)) {

            mostrarError(
                    "El ID del producto seleccionado no es valido."
            );

            return;
        }

        idSeleccionado =
                ((Number) valorId).intValue();

        txtCodigo.setText(
                obtenerTexto(filaModelo, 1)
        );

        txtNombre.setText(
                obtenerTexto(filaModelo, 2)
        );

        txtDescripcion.setText(
                obtenerTexto(filaModelo, 3)
        );

        txtCategoria.setText(
                obtenerTexto(filaModelo, 4)
        );

        txtProveedor.setText(
                obtenerTexto(filaModelo, 5)
        );

        String unidad = obtenerTexto(filaModelo, 6);

        cmbUnidadMedida.setSelectedItem(unidad);

        txtStockMinimo.setText(
                obtenerTexto(filaModelo, 7)
        );

        btnGuardar.setEnabled(false);
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);
        btnBuscarImagen.setEnabled(true);
    }

    private void abrirBuscadorImagenes() {

        if (idSeleccionado <= 0) {
            mostrarError("Seleccione un producto antes de buscar una imagen.");
            return;
        }

        ImagenProductoDialog dialogo = new ImagenProductoDialog(
                SwingUtilities.getWindowAncestor(this),
                idSeleccionado
        );
        dialogo.setVisible(true);
    }

    // ==========================================
    // 17. BUSCAR EN TABLA
    // ==========================================

    private void buscarEnTabla() {

        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {

            ordenadorTabla.setRowFilter(null);

            return;
        }

        ordenadorTabla.setRowFilter(
                RowFilter.regexFilter(
                        "(?i)" + Pattern.quote(texto)
                )
        );
    }

    // ==========================================
    // 18. LIMPIAR FORMULARIO
    // ==========================================

    private void limpiarFormulario() {

        txtCodigo.setText("");
        txtNombre.setText("");
        txtCategoria.setText("");
        txtProveedor.setText("");
        txtStockMinimo.setText("");
        txtDescripcion.setText("");

        cmbUnidadMedida.setSelectedIndex(0);

        idSeleccionado = -1;

        tablaProductos.clearSelection();

        btnGuardar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnBuscarImagen.setEnabled(false);

        txtCodigo.requestFocusInWindow();
    }

    // ==========================================
    // 19. OBTENER TEXTO SEGURO
    // ==========================================

    private String textoSeguro(String valor) {

        return valor == null ? "" : valor;
    }

    private String obtenerTexto(
            int fila,
            int columna
    ) {

        Object valor =
                modeloTabla.getValueAt(fila, columna);

        return valor == null ? "" : valor.toString();
    }

    // ==========================================
    // 20. MOSTRAR ADVERTENCIAS
    // ==========================================

    private void mostrarAdvertencia(
            String mensaje,
            JTextField campo
    ) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validacion de datos",
                JOptionPane.WARNING_MESSAGE
        );

        campo.requestFocusInWindow();
    }

    // ==========================================
    // 21. MOSTRAR INFORMACION
    // ==========================================

    private void mostrarInformacion(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Operacion exitosa",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ==========================================
    // 22. MOSTRAR ERRORES
    // ==========================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje == null || mensaje.isBlank()
                        ? "Ocurrio un error inesperado."
                        : mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
