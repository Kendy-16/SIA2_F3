
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Producto;
import pe.edu.inventario.modelo.dao.ProductoDAO;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/**
 * Servicio encargado de aplicar las reglas de negocio
 * y validaciones correspondientes a los productos.
 */
public class ProductoService {

    // ==========================================
    // 1. ATRIBUTOS Y CONSTANTES
    // ==========================================

    private final ProductoDAO productoDAO;

    // Unidades de medida permitidas
    private static final Set<String> UNIDADES_VALIDAS = Set.of(
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    );

    // Unidades que no permiten cantidades fraccionarias
    private static final Set<String> UNIDADES_ENTERAS = Set.of(
            "UNIDAD",
            "CAJA",
            "PAQUETE"
    );

    private static final int MAX_CODIGO = 30;
    private static final int MAX_NOMBRE = 120;
    private static final int MAX_DESCRIPCION = 500;

    private static final double STOCK_MAXIMO = 1_000_000_000.0;

    // Formato permitido para el código
    private static final String PATRON_CODIGO =
            "[A-Z0-9][A-Z0-9._/-]{0,29}";

    // Letras, acentos, números, espacios y signos habituales
    // para nombres comerciales.
    private static final String PATRON_NOMBRE =
            "[\\p{L}\\p{M}\\p{N}][\\p{L}\\p{M}\\p{N} .,'’()/&+#_-]*";

    // ==========================================
    // 2. CONSTRUCTOR
    // ==========================================

    public ProductoService() {
        productoDAO = new ProductoDAO();
    }

    // ==========================================
    // 3. REGISTRAR PRODUCTO
    // ==========================================

    public boolean registrar(Producto producto) throws SQLException {

        // Validar todos los campos
        validarProducto(producto);

        // Comprobar código duplicado
        Producto existente =
                productoDAO.buscarPorCodigo(producto.getCodigo());

        if (existente != null) {
            throw new IllegalArgumentException(
                    "Ya existe un producto registrado con ese código."
            );
        }

        // Registrar producto
        return productoDAO.insertar(producto);
    }

    // ==========================================
    // 4. LISTAR PRODUCTOS
    // ==========================================

    public ArrayList<Producto> listar() throws SQLException {

        ArrayList<Producto> productos = productoDAO.listar();

        // Evitar problemas cuando la consulta no devuelve resultados
        if (productos == null) {
            return new ArrayList<>();
        }

        return productos;
    }

    // ==========================================
    // 5. BUSCAR PRODUCTO POR CÓDIGO
    // ==========================================

    public Producto buscarPorCodigo(String codigo)
            throws SQLException {

        String codigoNormalizado = normalizarCodigo(codigo);

        return productoDAO.buscarPorCodigo(codigoNormalizado);
    }

    // ==========================================
    // 6. ACTUALIZAR PRODUCTO
    // ==========================================

    public boolean actualizar(Producto producto)
            throws SQLException {

        if (producto == null) {
            throw new IllegalArgumentException(
                    "Los datos del producto son obligatorios."
            );
        }

        // Validar ID
        if (producto.getIdProducto() <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        // Comprobar que el producto realmente exista
        Producto productoActual =
                buscarPorIdInterno(producto.getIdProducto());

        if (productoActual == null) {
            throw new IllegalArgumentException(
                    "No existe el producto que intenta actualizar."
            );
        }

        // Validar los datos nuevos
        validarProducto(producto);

        // Comprobar que el código no pertenezca a otro producto
        Producto existente =
                productoDAO.buscarPorCodigo(producto.getCodigo());

        if (existente != null
                && existente.getIdProducto() != producto.getIdProducto()) {

            throw new IllegalArgumentException(
                    "El código ingresado pertenece a otro producto."
            );
        }

        // Actualizar producto
        return productoDAO.actualizar(producto);
    }

    // ==========================================
    // 7. ELIMINAR PRODUCTO
    // ==========================================

    public boolean eliminar(int idProducto)
            throws SQLException {

        // Validar ID
        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        // Comprobar que el producto exista
        Producto existente = buscarPorIdInterno(idProducto);

        if (existente == null) {
            throw new IllegalArgumentException(
                    "No existe el producto que intenta eliminar."
            );
        }

        /*
         * SQLite debe impedir la eliminación física cuando
         * existen registros relacionados, mediante claves
         * foráneas correctamente configuradas.
         */

        return productoDAO.eliminar(idProducto);
    }

    // ==========================================
    // 8. BUSCAR PRODUCTO POR ID
    // ==========================================

    /*
     * Utiliza el método listar() disponible actualmente
     * en ProductoDAO para comprobar la existencia del ID.
     *
     * Posteriormente podemos optimizarlo incorporando
     * buscarPorId() directamente en ProductoDAO.
     */

    private Producto buscarPorIdInterno(int idProducto)
            throws SQLException {

        ArrayList<Producto> productos = listar();

        for (Producto producto : productos) {

            if (producto != null
                    && producto.getIdProducto() == idProducto) {

                return producto;
            }
        }

        return null;
    }

    // ==========================================
    // 9. VALIDACIÓN GENERAL
    // ==========================================

    private void validarProducto(Producto producto) {

        if (producto == null) {
            throw new IllegalArgumentException(
                    "Los datos del producto son obligatorios."
            );
        }

        validarCodigo(producto);
        validarNombre(producto);
        validarDescripcion(producto);
        validarCategoria(producto);
        validarProveedor(producto);
        validarUnidadMedida(producto);
        validarStockMinimo(producto);
    }

    // ==========================================
    // 10. VALIDAR CÓDIGO
    // ==========================================

    private void validarCodigo(Producto producto) {

        String codigo = producto.getCodigo();

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El código del producto es obligatorio."
            );
        }

        // Eliminar espacios externos y normalizar
        codigo = codigo.trim().toUpperCase(Locale.ROOT);

        if (codigo.length() < 1 || codigo.length() > MAX_CODIGO) {
            throw new IllegalArgumentException(
                    "El código debe tener entre 1 y 30 caracteres."
            );
        }

        if (!codigo.matches(PATRON_CODIGO)) {
            throw new IllegalArgumentException(
                    "El código contiene caracteres no permitidos. "
                    + "Utilice letras, números, puntos, guiones o barras."
            );
        }

        producto.setCodigo(codigo);
    }

    // ==========================================
    // 11. VALIDAR NOMBRE
    // ==========================================

    private void validarNombre(Producto producto) {

        String nombre = producto.getNombre();

        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre del producto es obligatorio."
            );
        }

        nombre = nombre.trim();

        int longitud = nombre.codePointCount(0, nombre.length());

        if (longitud < 2 || longitud > MAX_NOMBRE) {
            throw new IllegalArgumentException(
                    "El nombre debe tener entre 2 y 120 caracteres."
            );
        }

        if (contieneCaracterControl(nombre)) {
            throw new IllegalArgumentException(
                    "El nombre contiene caracteres de control no permitidos."
            );
        }

        if (!nombre.matches(PATRON_NOMBRE)) {
            throw new IllegalArgumentException(
                    "El nombre contiene caracteres no permitidos."
            );
        }

        producto.setNombre(nombre);
    }

    // ==========================================
    // 12. VALIDAR DESCRIPCIÓN
    // ==========================================

    private void validarDescripcion(Producto producto) {

        String descripcion = producto.getDescripcion();

        // La descripción es opcional
        if (descripcion == null || descripcion.trim().isEmpty()) {
            producto.setDescripcion(null);
            return;
        }

        descripcion = descripcion.trim();

        int longitud =
                descripcion.codePointCount(0, descripcion.length());

        if (longitud > MAX_DESCRIPCION) {
            throw new IllegalArgumentException(
                    "La descripción no puede superar los 500 caracteres."
            );
        }

        if (contieneCaracterControl(descripcion)) {
            throw new IllegalArgumentException(
                    "La descripción contiene caracteres de control no permitidos."
            );
        }

        producto.setDescripcion(descripcion);
    }

    // ==========================================
    // 13. VALIDAR CATEGORÍA
    // ==========================================

    private void validarCategoria(Producto producto) {

        Integer idCategoria = producto.getIdCategoria();

        // La categoría puede ser nula
        if (idCategoria == null) {
            return;
        }

        if (idCategoria <= 0) {
            throw new IllegalArgumentException(
                    "El ID de categoría debe ser mayor que cero."
            );
        }

        /*
         * La existencia de la categoría debe comprobarse
         * mediante la clave foránea de SQLite.
         */
    }

    // ==========================================
    // 14. VALIDAR PROVEEDOR
    // ==========================================

    private void validarProveedor(Producto producto) {

        Integer idProveedor = producto.getIdProveedor();

        // El proveedor puede ser nulo
        if (idProveedor == null) {
            return;
        }

        if (idProveedor <= 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser mayor que cero."
            );
        }

        /*
         * La existencia del proveedor debe comprobarse
         * mediante la clave foránea de SQLite.
         */
    }

    // ==========================================
    // 15. VALIDAR UNIDAD DE MEDIDA
    // ==========================================

    private void validarUnidadMedida(Producto producto) {

        String unidad = producto.getUnidadMedida();

        if (unidad == null || unidad.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Debe seleccionar una unidad de medida."
            );
        }

        unidad = unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidad)) {
            throw new IllegalArgumentException(
                    "La unidad de medida seleccionada no es válida."
            );
        }

        producto.setUnidadMedida(unidad);
    }

    // ==========================================
    // 16. VALIDAR STOCK MÍNIMO
    // ==========================================

    private void validarStockMinimo(Producto producto) {

        double stock = producto.getStockMinimo();

        // Comprobar que sea un número finito
        if (!Double.isFinite(stock)) {
            throw new IllegalArgumentException(
                    "El stock mínimo debe ser un número finito."
            );
        }

        // No permitir números negativos
        if (stock < 0) {
            throw new IllegalArgumentException(
                    "El stock mínimo no puede ser negativo."
            );
        }

        // Comprobar el valor máximo
        if (stock > STOCK_MAXIMO) {
            throw new IllegalArgumentException(
                    "El stock mínimo no puede superar 1 000 000 000."
            );
        }

        // Validar máximo de tres decimales
        BigDecimal valor = BigDecimal.valueOf(stock)
                .stripTrailingZeros();

        if (valor.scale() > 3) {
            throw new IllegalArgumentException(
                    "El stock mínimo admite como máximo tres decimales."
            );
        }

        // Comprobar cantidades enteras según la unidad
        String unidad = producto.getUnidadMedida();

        if (UNIDADES_ENTERAS.contains(unidad)
                && stock != Math.floor(stock)) {

            throw new IllegalArgumentException(
                    "La unidad seleccionada requiere un stock mínimo entero."
            );
        }

        // Normalizar cero negativo
        if (stock == 0.0) {
            producto.setStockMinimo(0.0);
        }
    }

    // ==========================================
    // 17. NORMALIZAR CÓDIGO PARA BÚSQUEDA
    // ==========================================

    private String normalizarCodigo(String codigo) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Ingrese el código del producto que desea buscar."
            );
        }

        codigo = codigo.trim().toUpperCase(Locale.ROOT);

        if (codigo.length() > MAX_CODIGO
                || !codigo.matches(PATRON_CODIGO)) {

            throw new IllegalArgumentException(
                    "El formato del código ingresado no es válido."
            );
        }

        return codigo;
    }

    // ==========================================
    // 18. DETECTAR CARACTERES DE CONTROL
    // ==========================================

    private boolean contieneCaracterControl(String texto) {

        return texto.codePoints()
                .anyMatch(Character::isISOControl);
    }
}
