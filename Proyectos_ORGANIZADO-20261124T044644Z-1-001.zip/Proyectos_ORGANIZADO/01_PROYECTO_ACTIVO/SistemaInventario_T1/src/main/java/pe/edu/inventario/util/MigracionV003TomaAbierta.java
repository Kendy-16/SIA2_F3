
package pe.edu.inventario.util;

import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Ejecuta la migracion V003.
 *
 * Garantiza que solamente exista una toma de inventario
 * fisico abierta por almacen.
 */
public final class MigracionV003TomaAbierta {

    private MigracionV003TomaAbierta() {
    }

    public static void main(String[] args) throws SQLException {

        try (Connection conexion = ConexionDB.conectar()) {

            configurarBusyTimeout(conexion);

            conexion.setAutoCommit(false);

            try {

                // 1. Verificar que V001 haya sido aplicada.
                validarTablaInventarioFisico(conexion);

                // 2. Verificar que V002 haya sido aplicada.
                validarColumnaActivo(conexion, "productos");
                validarColumnaActivo(conexion, "almacenes");

                // 3. Comprobar que no existan duplicados.
                validarTomasAbiertasDuplicadas(conexion);

                // 4. Crear restriccion unica.
                crearIndiceUnico(conexion);

                // 5. Crear indice para el historial.
                crearIndiceHistorial(conexion);

                // 6. Confirmar migracion.
                conexion.commit();

                System.out.println(
                        "Migracion V003 aplicada correctamente."
                );

                System.out.println(
                        "Restriccion activa: una toma abierta por almacen."
                );

            } catch (SQLException | RuntimeException ex) {

                try {
                    conexion.rollback();

                } catch (SQLException errorRollback) {
                    ex.addSuppressed(errorRollback);
                }

                throw ex;

            } finally {

                conexion.setAutoCommit(true);
            }
        }
    }

    // =========================================================
    // 1. CONFIGURAR TIEMPO DE ESPERA
    // =========================================================

    private static void configurarBusyTimeout(
            Connection conexion
    ) throws SQLException {

        try (Statement st = conexion.createStatement()) {

            st.execute("PRAGMA busy_timeout = 10000");
        }
    }

    // =========================================================
    // 2. VERIFICAR TABLA DE INVENTARIO FISICO
    // =========================================================

    private static void validarTablaInventarioFisico(
            Connection conexion
    ) throws SQLException {

        String sql = """
                SELECT COUNT(*)
                FROM sqlite_master
                WHERE type = 'table'
                  AND name = 'tomas_inventario_fisico'
                """;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (!rs.next() || rs.getInt(1) != 1) {

                throw new SQLException(
                        "No existe la tabla tomas_inventario_fisico. "
                        + "Primero debe aplicar la migracion V001."
                );
            }
        }
    }

    // =========================================================
    // 3. VERIFICAR COLUMNAS DE V002
    // =========================================================

    private static void validarColumnaActivo(
            Connection conexion,
            String tabla
    ) throws SQLException {

        boolean existe = false;

        String sql = "PRAGMA table_info(" + tabla + ")";

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                if ("activo".equalsIgnoreCase(
                        rs.getString("name")
                )) {
                    existe = true;
                    break;
                }
            }
        }

        if (!existe) {

            throw new SQLException(
                    "La tabla " + tabla
                    + " no tiene la columna activo. "
                    + "Primero debe aplicar la migracion V002."
            );
        }
    }

    // =========================================================
    // 4. VALIDAR TOMAS ABIERTAS DUPLICADAS
    // =========================================================

    private static void validarTomasAbiertasDuplicadas(
            Connection conexion
    ) throws SQLException {

        String sql = """
                SELECT
                    id_almacen,
                    COUNT(*) AS total
                FROM tomas_inventario_fisico
                WHERE estado = 'ABIERTO'
                GROUP BY id_almacen
                HAVING COUNT(*) > 1
                """;

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {

                int idAlmacen =
                        rs.getInt("id_almacen");

                int total =
                        rs.getInt("total");

                throw new SQLException(
                        "No se puede aplicar V003. "
                        + "El almacen ID " + idAlmacen
                        + " tiene " + total
                        + " conteos abiertos. "
                        + "Debe resolver los conteos duplicados "
                        + "sin eliminar su historial."
                );
            }
        }
    }

    // =========================================================
    // 5. CREAR INDICE UNICO
    // =========================================================

    private static void crearIndiceUnico(
            Connection conexion
    ) throws SQLException {

        String sql = """
                CREATE UNIQUE INDEX IF NOT EXISTS
                    idx_toma_abierta_unica_por_almacen
                ON tomas_inventario_fisico(id_almacen)
                WHERE estado = 'ABIERTO'
                """;

        try (Statement st = conexion.createStatement()) {
            st.executeUpdate(sql);
        }
    }

    // =========================================================
    // 6. CREAR INDICE DEL HISTORIAL
    // =========================================================

    private static void crearIndiceHistorial(
            Connection conexion
    ) throws SQLException {

        String sql = """
                CREATE INDEX IF NOT EXISTS
                    idx_tomas_estado_fecha
                ON tomas_inventario_fisico(estado, fecha)
                """;

        try (Statement st = conexion.createStatement()) {
            st.executeUpdate(sql);
        }
    }
}
