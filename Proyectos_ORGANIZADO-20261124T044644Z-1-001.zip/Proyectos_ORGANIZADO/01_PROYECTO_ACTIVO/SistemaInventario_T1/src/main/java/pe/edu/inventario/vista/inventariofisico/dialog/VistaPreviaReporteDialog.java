package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Vista previa de un reporte (tabla) con exportación a CSV. */
public class VistaPreviaReporteDialog extends JDialog {
    public VistaPreviaReporteDialog(Window owner, String titulo, javax.swing.table.TableModel modelo, PermisosVistaInventario permisos) {
        super(owner, "Vista previa · " + titulo, ModalityType.APPLICATION_MODAL);
        setSize(640, 420); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
        JLabel encabezado = new JLabel(titulo + " — generado el " + fecha(java.time.LocalDateTime.now()));
        encabezado.setBorder(new EmptyBorder(12, 14, 0, 14));
        encabezado.setFont(encabezado.getFont().deriveFont(Font.BOLD, 14f));
        add(encabezado, BorderLayout.NORTH);
        JTable tabla = new JTable(modelo);
        estiloTabla(tabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        JButton exportar = botonPrimario("Exportar CSV"), cerrar = botonSecundario("Cerrar");
        exportar.setEnabled(permisos.puedeExportar());
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(exportar); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);
        cerrar.addActionListener(e -> dispose());
        exportar.addActionListener(e -> {
            try {
                java.io.File f = ExportadorVistaInventario.exportarConDialogo(this, modelo, "reporte-inventario-fisico");
                if (f != null) MensajesInventarioFisico.informacion(this, "Archivo guardado en " + f.getAbsolutePath());
            } catch (java.io.IOException ex) { MensajesInventarioFisico.error(this, ex); }
        });
    }
}
