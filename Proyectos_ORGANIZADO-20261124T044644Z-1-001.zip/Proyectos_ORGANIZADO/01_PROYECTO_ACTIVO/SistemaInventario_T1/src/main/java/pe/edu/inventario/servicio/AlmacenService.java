
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.modelo.dao.AlmacenDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class AlmacenService {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final int MIN_NOMBRE = 3;
    private static final int MAX_NOMBRE = 120;
    private static final int MAX_UBICACION = 250;

    private static final Pattern NOMBRE_PATTERN =
            Pattern.compile(
                    "^[\\p{L}\\p{M}\\p{N}]" +
                    "[\\p{L}\\p{M}\\p{N} .,&'()/-]*$"
            );

    // ==========================================
    // 2. ATRIBUTOS
    // ==========================================

    private final AlmacenDAO almacenDAO;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public AlmacenService() {
        this.almacenDAO = new AlmacenDAO();
    }

    // Constructor with dependency injection
    public AlmacenService(AlmacenDAO almacenDAO) {

        if (almacenDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de almacenes es obligatorio."
            );
        }

        this.almacenDAO = almacenDAO;
    }

    // ==========================================
    // 4. REGISTRAR ALMACEN
    // ==========================================

    public boolean registrar(Almacen almacen)
            throws SQLException {

        validarYNormalizar(almacen);

        // Check duplicate name
        if (almacenDAO.existeNombre(
                almacen.getNombre(),
                0
        )) {

            throw new IllegalArgumentException(
                    "Ya existe un almacen con ese nombre."
            );
        }

        return almacenDAO.insertar(almacen);
    }

    // ==========================================
    // 5. LISTAR ALMACENES
    // ==========================================

    public ArrayList<Almacen> listar()
            throws SQLException {

        ArrayList<Almacen> almacenes =
                almacenDAO.listar();

        if (almacenes == null) {
            throw new SQLException(
                    "El DAO devolvio una lista de almacenes nula."
            );
        }

        // Check returned records
        for (Almacen almacen : almacenes) {

            validarIntegridadRegistro(almacen);
        }

        return new ArrayList<>(almacenes);
    }

    // ==========================================
    // 6. BUSCAR POR ID
    // ==========================================

    public Almacen buscarPorId(int idAlmacen)
            throws SQLException {

        validarId(idAlmacen);

        Almacen almacen =
                almacenDAO.buscarPorId(idAlmacen);

        if (almacen != null) {
            validarIntegridadRegistro(almacen);
        }

        return almacen;
    }

    // ==========================================
    // 7. ACTUALIZAR ALMACEN
    // ==========================================

    public boolean actualizar(Almacen almacen)
            throws SQLException {

        if (almacen == null) {
            throw new IllegalArgumentException(
                    "Los datos del almacen son obligatorios."
            );
        }

        // Check ID
        validarId(almacen.getIdAlmacen());

        // Validate fields
        validarYNormalizar(almacen);

        // Check existence
        Almacen existente =
                almacenDAO.buscarPorId(
                        almacen.getIdAlmacen()
                );

        if (existente == null) {
            return false;
        }

        // Check duplicate name excluding current record
        if (almacenDAO.existeNombre(
                almacen.getNombre(),
                almacen.getIdAlmacen()
        )) {

            throw new IllegalArgumentException(
                    "El nombre ya pertenece a otro almacen."
            );
        }

        return almacenDAO.actualizar(almacen);
    }

    // ==========================================
    // 8. ELIMINAR ALMACEN
    // ==========================================

    public boolean eliminar(int idAlmacen)
            throws SQLException {

        validarId(idAlmacen);

        // Check existence
        Almacen existente =
                almacenDAO.buscarPorId(idAlmacen);

        if (existente == null) {
            return false;
        }

        // DAO handles foreign key restrictions
        return almacenDAO.eliminar(idAlmacen);
    }

    // ==========================================
    // 9. VALIDAR Y NORMALIZAR DATOS
    // ==========================================

    private void validarYNormalizar(
            Almacen almacen
    ) {

        if (almacen == null) {
            throw new IllegalArgumentException(
                    "Los datos del almacen son obligatorios."
            );
        }

        // Validate and normalize name
        String nombre = limpiarTexto(
                almacen.getNombre()
        ).replaceAll("\\s+", " ");

        if (nombre.isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre del almacen es obligatorio."
            );
        }

        if (nombre.length() < MIN_NOMBRE
                || nombre.length() > MAX_NOMBRE) {

            throw new IllegalArgumentException(
                    "El nombre debe tener entre 3 y 120 caracteres."
            );
        }

        if (!NOMBRE_PATTERN.matcher(nombre).matches()) {
            throw new IllegalArgumentException(
                    "El nombre contiene caracteres no permitidos."
            );
        }

        almacen.setNombre(nombre);

        // Validate location
        String ubicacion = limpiarTexto(
                almacen.getUbicacion()
        );

        if (contieneCaracteresDeControl(ubicacion)) {
            throw new IllegalArgumentException(
                    "La ubicacion contiene caracteres no permitidos."
            );
        }

        ubicacion = ubicacion.replaceAll("\\s+", " ");

        if (ubicacion.length() > MAX_UBICACION) {
            throw new IllegalArgumentException(
                    "La ubicacion no puede superar 250 caracteres."
            );
        }

        almacen.setUbicacion(
                ubicacion.isEmpty() ? null : ubicacion
        );
    }

    // ==========================================
    // 10. VALIDAR INTEGRIDAD DEL REGISTRO
    // ==========================================

    private void validarIntegridadRegistro(
            Almacen almacen
    ) throws SQLException {

        if (almacen == null) {
            throw new SQLException(
                    "Se encontro un almacen nulo en la consulta."
            );
        }

        if (almacen.getIdAlmacen() <= 0) {
            throw new SQLException(
                    "Se encontro un almacen con ID invalido."
            );
        }

        String nombre = almacen.getNombre();

        if (nombre == null || nombre.isBlank()) {
            throw new SQLException(
                    "Se encontro un almacen sin nombre."
            );
        }

        if (nombre.length() < MIN_NOMBRE
                || nombre.length() > MAX_NOMBRE
                || !NOMBRE_PATTERN.matcher(nombre).matches()) {

            throw new SQLException(
                    "Se encontro un nombre de almacen inconsistente."
            );
        }

        String ubicacion = almacen.getUbicacion();

        if (ubicacion != null) {

            if (ubicacion.length() > MAX_UBICACION
                    || contieneCaracteresDeControl(ubicacion)) {

                throw new SQLException(
                        "Se encontro una ubicacion de almacen inconsistente."
                );
            }
        }
    }

    // ==========================================
    // 11. VALIDAR ID
    // ==========================================

    private void validarId(int idAlmacen) {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // 12. LIMPIAR TEXTO
    // ==========================================

    private String limpiarTexto(String texto) {

        return texto == null ? "" : texto.trim();
    }

    // ==========================================
    // 13. VALIDAR CARACTERES DE CONTROL
    // ==========================================

    private boolean contieneCaracteresDeControl(
            String texto
    ) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(
                    texto.charAt(i)
            )) {

                return true;
            }
        }

        return false;
    }
}
