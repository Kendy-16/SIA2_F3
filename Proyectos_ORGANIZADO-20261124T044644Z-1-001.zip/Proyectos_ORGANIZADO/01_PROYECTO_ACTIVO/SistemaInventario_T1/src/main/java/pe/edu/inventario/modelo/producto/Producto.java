package pe.edu.inventario.modelo.producto;

import java.math.BigDecimal;

/**
 * Producto del catálogo con su política comercial (precio normal, precio mayorista
 * y cantidad mínima para acceder al precio mayorista).
 */
public class Producto {
    private final String codigo;
    private final String nombre;
    private final BigDecimal precioNormal;
    private final BigDecimal precioMayorista;
    private final int cantidadMinimaMayorista;

    public Producto(String codigo, String nombre, BigDecimal precioNormal,
                    BigDecimal precioMayorista, int cantidadMinimaMayorista) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precioNormal = precioNormal;
        this.precioMayorista = precioMayorista;
        this.cantidadMinimaMayorista = cantidadMinimaMayorista;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public BigDecimal getPrecioNormal() { return precioNormal; }
    public BigDecimal getPrecioMayorista() { return precioMayorista; }
    public int getCantidadMinimaMayorista() { return cantidadMinimaMayorista; }
}
