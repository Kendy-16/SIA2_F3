package pe.edu.inventario.servicio.venta;

/**
 * Error de negocio del módulo de ventas (stock insuficiente, pago inválido,
 * venta duplicada, etc.). Su mensaje está pensado para mostrarse al usuario.
 */
public class VentaException extends Exception {

    public VentaException(String mensaje) {
        super(mensaje);
    }

    public VentaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
