package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Colorea el estado de una toma física (EstadoToma). */
public class EstadoTomaRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
        Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
        setBorder(new EmptyBorder(2, 7, 2, 7));
        FormatoInventarioFisico.aplicarCebra(c, table, row, selected);
        setHorizontalAlignment(SwingConstants.LEFT);
        setText(value == null ? FormatoInventarioFisico.SIN_DATO : value.toString());
        if (!selected) setForeground(colorDe(value));
        setFont(getFont().deriveFont(Font.BOLD));
        return c;
    }

    static Color colorDe(Object value) {
        if (!(value instanceof EstadoToma e)) return FormatoInventarioFisico.TEXT;
        return switch (e) {
            case CANCELADA -> FormatoInventarioFisico.RED;
            case EN_REVISION -> FormatoInventarioFisico.AMBER;
            case CONCILIADA, APROBADA, CERRADA -> FormatoInventarioFisico.GREEN;
            case EN_CONTEO -> FormatoInventarioFisico.BLUE;
            default -> FormatoInventarioFisico.TEXT;
        };
    }
}
