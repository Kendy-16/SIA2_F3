package pe.edu.inventario.vista.inventariofisico.util;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Colores, formatos de texto y estilos Swing compartidos por todas las pantallas de inventario físico. */
public final class FormatoInventarioFisico {
    public static final Color NAVY = new Color(25, 45, 75);
    public static final Color BLUE = new Color(43, 105, 190);
    public static final Color BG = new Color(245, 247, 251);
    public static final Color TEXT = new Color(45, 55, 72);
    public static final Color MUTED = new Color(110, 122, 140);
    public static final Color GREEN = new Color(29, 145, 95);
    public static final Color RED = new Color(195, 65, 65);
    public static final Color AMBER = new Color(190, 125, 25);
    public static final Color BORDE = new Color(226, 232, 240);
    public static final Color FILA_ALTERNA = new Color(248, 250, 253);
    public static final String SIN_DATO = "—";

    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final Locale PERU = Locale.forLanguageTag("es-PE");

    private FormatoInventarioFisico() { }

    public static String cantidad(BigDecimal v) {
        if (v == null) return SIN_DATO;
        return v.signum() == 0 ? "0" : v.stripTrailingZeros().toPlainString();
    }

    public static String moneda(BigDecimal v) {
        return v == null ? SIN_DATO : NumberFormat.getCurrencyInstance(PERU).format(v);
    }

    public static String fecha(LocalDateTime d) { return d == null ? SIN_DATO : FECHA_HORA.format(d); }

    public static String porcentaje(int valor) { return valor + "%"; }

    public static String texto(String s) { return s == null || s.isBlank() ? SIN_DATO : s; }

    /** Aplica el estilo común de tablas (altura, cabecera, selección). */
    public static void estiloTabla(JTable t) {
        t.setRowHeight(29);
        t.setFillsViewportHeight(true);
        t.setShowVerticalLines(false);
        t.setGridColor(new Color(235, 238, 243));
        t.setSelectionBackground(new Color(222, 235, 252));
        t.setSelectionForeground(TEXT);
        t.setAutoCreateRowSorter(true);
        t.getTableHeader().setReorderingAllowed(false);
        t.getTableHeader().setBackground(new Color(240, 244, 249));
        t.getTableHeader().setForeground(TEXT);
        t.getTableHeader().setFont(t.getTableHeader().getFont().deriveFont(Font.BOLD, 11f));
        t.setFont(t.getFont().deriveFont(12f));
    }

    /** Fondo alterno por fila; no pisa el color de la fila seleccionada. */
    public static void aplicarCebra(Component c, JTable table, int row, boolean selected) {
        if (!selected) c.setBackground(row % 2 == 0 ? Color.WHITE : FILA_ALTERNA);
    }

    /** Renderer de texto plano con fila alterna, para columnas sin formato especial. */
    public static TableCellRenderer rendererTexto() {
        return new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, f, r, c);
                setBorder(new EmptyBorder(2, 7, 2, 7));
                setHorizontalAlignment(v instanceof Number ? SwingConstants.CENTER : SwingConstants.LEFT);
                aplicarCebra(comp, t, r, sel);
                if (!sel) setForeground(TEXT);
                return comp;
            }
        };
    }

    public static JButton botonPrimario(String texto) {
        JButton b = new JButton(texto);
        b.setBackground(BLUE);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 13, 8, 13));
        return b;
    }

    public static JButton botonSecundario(String texto) {
        JButton b = new JButton(texto);
        b.setBackground(new Color(238, 243, 249));
        b.setForeground(TEXT);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 12, 8, 12));
        return b;
    }

    public static Border bordeTarjeta() {
        return BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDE), new EmptyBorder(12, 12, 12, 12));
    }

    public static JPanel tarjeta(LayoutManager layout) {
        JPanel p = new JPanel(layout);
        p.setBackground(Color.WHITE);
        p.setBorder(bordeTarjeta());
        return p;
    }

    public static JLabel etiquetaSecundaria(String texto) {
        JLabel l = new JLabel(texto);
        l.setForeground(MUTED);
        return l;
    }
}
