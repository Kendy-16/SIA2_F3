
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.Proveedor;
import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Data Access Object for suppliers.
 * Handles database operations using SQLite.
 */
public class ProveedorDAO {

    // ==========================================
    // 1. INSERTAR PROVEEDOR
    // ==========================================

    public boolean insertar(Proveedor proveedor) throws SQLException {

        String sql = """
                INSERT INTO proveedores (
                    ruc,
                    razon_social,
                    telefono,
                    correo,
                    direccion
                )
                VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, proveedor.getRuc());
            ps.setString(2, proveedor.getRazonSocial());
            ps.setString(3, valorONull(proveedor.getTelefono()));
            ps.setString(4, valorONull(proveedor.getCorreo()));
            ps.setString(5, valorONull(proveedor.getDireccion()));

            return ps.executeUpdate() > 0;
        }
    }

    // ==========================================
    // 2. LISTAR PROVEEDORES
    // ==========================================

    public ArrayList<Proveedor> listar() throws SQLException {

        ArrayList<Proveedor> proveedores = new ArrayList<>();

        String sql = """
                SELECT
                    id_proveedor,
                    ruc,
                    razon_social,
                    telefono,
                    correo,
                    direccion
                FROM proveedores
                ORDER BY razon_social COLLATE NOCASE
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                proveedores.add(mapearProveedor(rs));
            }
        }

        return proveedores;
    }

    // ==========================================
    // 3. BUSCAR PROVEEDOR POR ID
    // ==========================================

    public Proveedor buscarPorId(int idProveedor) throws SQLException {

        if (idProveedor <= 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser positivo."
            );
        }

        String sql = """
                SELECT
                    id_proveedor,
                    ruc,
                    razon_social,
                    telefono,
                    correo,
                    direccion
                FROM proveedores
                WHERE id_proveedor = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, idProveedor);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapearProveedor(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 4. BUSCAR PROVEEDOR POR RUC
    // ==========================================

    public Proveedor buscarPorRuc(String ruc) throws SQLException {

        if (ruc == null || ruc.isBlank()) {
            throw new IllegalArgumentException(
                    "El RUC es obligatorio para realizar la busqueda."
            );
        }

        String sql = """
                SELECT
                    id_proveedor,
                    ruc,
                    razon_social,
                    telefono,
                    correo,
                    direccion
                FROM proveedores
                WHERE ruc = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, ruc.trim());

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapearProveedor(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 5. ACTUALIZAR PROVEEDOR
    // ==========================================

    public boolean actualizar(Proveedor proveedor) throws SQLException {

        if (proveedor == null || proveedor.getIdProveedor() <= 0) {
            throw new IllegalArgumentException(
                    "El proveedor o su ID no son validos."
            );
        }

        String sql = """
                UPDATE proveedores
                SET
                    ruc = ?,
                    razon_social = ?,
                    telefono = ?,
                    correo = ?,
                    direccion = ?
                WHERE id_proveedor = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, proveedor.getRuc());
            ps.setString(2, proveedor.getRazonSocial());
            ps.setString(3, valorONull(proveedor.getTelefono()));
            ps.setString(4, valorONull(proveedor.getCorreo()));
            ps.setString(5, valorONull(proveedor.getDireccion()));
            ps.setInt(6, proveedor.getIdProveedor());

            return ps.executeUpdate() > 0;
        }
    }

    // ==========================================
    // 6. ELIMINAR PROVEEDOR
    // ==========================================

    public boolean eliminar(int idProveedor) throws SQLException {

        if (idProveedor <= 0) {
            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser positivo."
            );
        }

        String sql = """
                DELETE FROM proveedores
                WHERE id_proveedor = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, idProveedor);

            return ps.executeUpdate() > 0;
        }
    }

    // ==========================================
    // 7. VERIFICAR RUC DUPLICADO
    // ==========================================

    public boolean existeRuc(String ruc, int idExcluir)
            throws SQLException {

        if (ruc == null || ruc.isBlank()) {
            return false;
        }

        String sql = """
                SELECT COUNT(*)
                FROM proveedores
                WHERE ruc = ?
                  AND id_proveedor <> ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, ruc.trim());
            ps.setInt(2, idExcluir);

            try (ResultSet rs = ps.executeQuery()) {

                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    // ==========================================
    // 8. CONVERTIR RESULTADO SQL A OBJETO
    // ==========================================

    private Proveedor mapearProveedor(ResultSet rs)
            throws SQLException {

        Proveedor proveedor = new Proveedor();

        proveedor.setIdProveedor(rs.getInt("id_proveedor"));
        proveedor.setRuc(rs.getString("ruc"));
        proveedor.setRazonSocial(rs.getString("razon_social"));
        proveedor.setTelefono(rs.getString("telefono"));
        proveedor.setCorreo(rs.getString("correo"));
        proveedor.setDireccion(rs.getString("direccion"));

        return proveedor;
    }

    // ==========================================
    // 9. NORMALIZAR CAMPOS OPCIONALES
    // ==========================================

    private String valorONull(String valor) {

        if (valor == null || valor.isBlank()) {
            return null;
        }

        return valor.trim();
    }
}
