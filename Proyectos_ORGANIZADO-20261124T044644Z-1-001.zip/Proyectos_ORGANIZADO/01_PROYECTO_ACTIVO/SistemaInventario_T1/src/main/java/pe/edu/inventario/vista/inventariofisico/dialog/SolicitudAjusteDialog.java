package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Solicita un ajuste para una diferencia: motivo obligatorio y observaciones. */
public class SolicitudAjusteDialog extends JDialog {
    private static final String[] MOTIVOS = {"Pérdida", "Deterioro", "Error de registro", "Error de recepción", "Error de despacho",
            "Producto mal ubicado", "Unidad de medida", "Sobrante no registrado", "Otro"};

    public SolicitudAjusteDialog(Window owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable alCambiar) {
        super(owner, "Solicitud de ajuste", ModalityType.APPLICATION_MODAL);
        setSize(600, 470); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
        JPanel datos = new JPanel(new GridLayout(0, 2, 8, 7));
        datos.setBorder(new EmptyBorder(16, 18, 8, 18));
        datos.add(etiquetaSecundaria("Producto:")); datos.add(new JLabel(d.producto().codigo() + " · " + d.producto().nombre()));
        datos.add(etiquetaSecundaria("Stock del sistema:")); datos.add(new JLabel(cantidad(d.stockSistema())));
        datos.add(etiquetaSecundaria("Cantidad física:")); datos.add(new JLabel(cantidad(d.cantidadFisica())));
        datos.add(etiquetaSecundaria("Diferencia:")); datos.add(new JLabel(cantidad(d.diferencia())));
        datos.add(etiquetaSecundaria("Valor referencial:")); datos.add(new JLabel(moneda(d.valorDiferencia())));
        datos.add(new JLabel("Motivo:"));
        JComboBox<String> motivo = new JComboBox<>(MOTIVOS);
        datos.add(motivo);
        add(datos, BorderLayout.NORTH);
        PanelObservaciones obs = new PanelObservaciones("Observaciones:", 4);
        obs.setBorder(new EmptyBorder(0, 18, 8, 18));
        add(obs, BorderLayout.CENTER);

        JButton cancelar = botonSecundario("Cancelar"), solicitar = botonPrimario("Solicitar ajuste");
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(cancelar); abajo.add(solicitar);
        add(abajo, BorderLayout.SOUTH);
        cancelar.addActionListener(e -> dispose());
        solicitar.addActionListener(e -> {
            if (d.tipo() != TipoDiferencia.FALTANTE && d.tipo() != TipoDiferencia.SOBRANTE) {
                MensajesInventarioFisico.advertencia(this, "Solo se puede solicitar ajuste para faltantes o sobrantes.");
                return;
            }
            String m = (String) motivo.getSelectedItem(), o = obs.getTexto();
            TareaAsincrona.ejecutar(this, () -> { controller.solicitarAjuste(idToma, d.producto().id(), m, o); return true; },
                    ok -> { MensajesInventarioFisico.informacion(this, "Solicitud de ajuste registrada."); alCambiar.run(); dispose(); });
        });
    }
}
