package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Búsqueda por texto y filtro por estado de la lista de tomas. */
public class PanelFiltrosInventario extends JPanel {
    private final JTextField busqueda = new JTextField(18);
    private final JComboBox<String> estado = new JComboBox<>(new String[]{"Todos", "ABIERTA", "EN_CONTEO", "EN_REVISION", "CONCILIADA", "APROBADA", "CERRADA", "CANCELADA"});
    private final JButton actualizar = botonSecundario("Actualizar");

    public PanelFiltrosInventario() {
        super(new FlowLayout(FlowLayout.LEFT, 8, 0));
        setOpaque(false);
        add(new JLabel("Buscar:"));
        add(busqueda);
        add(new JLabel("Estado:"));
        add(estado);
        add(actualizar);
    }

    public String getTexto() { return busqueda.getText(); }
    /** @return el estado elegido o null si es "Todos". */
    public EstadoToma getEstado() { return estado.getSelectedIndex() <= 0 ? null : EstadoToma.valueOf((String) estado.getSelectedItem()); }
    public void alCambiar(Runnable r) {
        busqueda.addActionListener(e -> r.run());
        estado.addActionListener(e -> r.run());
        actualizar.addActionListener(e -> r.run());
    }
}
