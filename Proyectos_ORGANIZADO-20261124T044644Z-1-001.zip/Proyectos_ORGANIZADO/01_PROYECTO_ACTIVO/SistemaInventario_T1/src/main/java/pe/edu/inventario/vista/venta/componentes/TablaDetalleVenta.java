package pe.edu.inventario.vista.venta.componentes;

import pe.edu.inventario.modelo.venta.DetalleVenta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

// 3. Tabla donde se listan los productos antes de pagar
public class TablaDetalleVenta extends JPanel {
    private JTable tablaDetalle;
    private DefaultTableModel modelo;

    public TablaDetalleVenta() {
        setLayout(new BorderLayout());
        String[] columnas = {"Código", "Descripción", "Cant.", "Precio Unit.", "Dscto %", "Subtotal"};
        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false; // el detalle se modifica solo desde el controlador
            }
        };
        tablaDetalle = new JTable(modelo);
        tablaDetalle.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(new JScrollPane(tablaDetalle), BorderLayout.CENTER);
    }

    public void limpiarTabla() { modelo.setRowCount(0); }
    public void agregarFila(Object[] datos) { modelo.addRow(datos); }

    /** Redibuja toda la tabla a partir del detalle de la venta. */
    public void mostrarDetalles(List<DetalleVenta> detalles) {
        limpiarTabla();
        for (DetalleVenta d : detalles) {
            agregarFila(new Object[]{
                    d.getCodigoProducto(),
                    d.getNombreProducto(),
                    d.getCantidad(),
                    d.getPrecioUnitario().toPlainString(),
                    d.getPorcentajeDescuento().stripTrailingZeros().toPlainString(),
                    d.getSubtotalLinea().toPlainString()
            });
        }
    }

    /** @return el índice de la fila seleccionada, o -1 si no hay ninguna. */
    public int getFilaSeleccionada() { return tablaDetalle.getSelectedRow(); }
}
