package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Muestra importes en soles (S/); los negativos en rojo. */
public class MonedaRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
        Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
        setBorder(new EmptyBorder(2, 7, 2, 7));
        FormatoInventarioFisico.aplicarCebra(c, table, row, selected);
        setHorizontalAlignment(SwingConstants.LEFT);
        setHorizontalAlignment(SwingConstants.RIGHT);
        if (value instanceof BigDecimal b) {
            setText(FormatoInventarioFisico.moneda(b));
            if (!selected) setForeground(b.signum() < 0 ? FormatoInventarioFisico.RED : FormatoInventarioFisico.TEXT);
        } else {
            setText(FormatoInventarioFisico.SIN_DATO);
            if (!selected) setForeground(FormatoInventarioFisico.TEXT);
        }
        return c;
    }
}
