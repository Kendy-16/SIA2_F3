package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Barra superior azul con el título del módulo y los datos del usuario. */
public class PanelEncabezadoModulo extends JPanel {
    private final JLabel usuario = new JLabel();
    private final JLabel nota = new JLabel();

    public PanelEncabezadoModulo(String titulo, String subtitulo, String textoUsuario, String textoNota) {
        super(new BorderLayout(15, 5));
        setBackground(NAVY);
        setBorder(new EmptyBorder(18, 24, 18, 24));
        JPanel izquierda = new JPanel();
        izquierda.setOpaque(false);
        izquierda.setLayout(new BoxLayout(izquierda, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(titulo);
        t.setForeground(Color.WHITE);
        t.setFont(t.getFont().deriveFont(Font.BOLD, 22f));
        JLabel s = new JLabel(subtitulo);
        s.setForeground(new Color(205, 216, 232));
        s.setFont(s.getFont().deriveFont(13f));
        izquierda.add(t);
        izquierda.add(Box.createVerticalStrut(4));
        izquierda.add(s);
        JPanel derecha = new JPanel(new GridLayout(2, 1, 0, 3));
        derecha.setOpaque(false);
        usuario.setForeground(Color.WHITE);
        usuario.setHorizontalAlignment(SwingConstants.RIGHT);
        nota.setForeground(new Color(205, 216, 232));
        nota.setFont(nota.getFont().deriveFont(11f));
        nota.setHorizontalAlignment(SwingConstants.RIGHT);
        derecha.add(usuario);
        derecha.add(nota);
        add(izquierda, BorderLayout.WEST);
        add(derecha, BorderLayout.EAST);
        setUsuario(textoUsuario, textoNota);
    }

    public final void setUsuario(String textoUsuario, String textoNota) {
        usuario.setText(textoUsuario);
        nota.setText(textoNota);
    }
}
