package pe.edu.inventario.vista.inventariofisico.util;

import javax.swing.*;
import java.awt.Component;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/** Ejecuta una consulta o escritura fuera del hilo de Swing y devuelve el resultado en él. */
public final class TareaAsincrona {
    private TareaAsincrona() { }

    public static <T> void ejecutar(Component padre, Callable<T> tarea, Consumer<T> alTerminar) {
        ejecutar(padre, tarea, alTerminar, t -> MensajesInventarioFisico.error(padre, t));
    }

    public static <T> void ejecutar(Component padre, Callable<T> tarea, Consumer<T> alTerminar, Consumer<Throwable> alFallar) {
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return tarea.call(); }
            @Override protected void done() {
                try {
                    alTerminar.accept(get());
                } catch (java.util.concurrent.ExecutionException ex) {
                    alFallar.accept(ex.getCause() == null ? ex : ex.getCause());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    alFallar.accept(ex);
                }
            }
        }.execute();
    }
}
