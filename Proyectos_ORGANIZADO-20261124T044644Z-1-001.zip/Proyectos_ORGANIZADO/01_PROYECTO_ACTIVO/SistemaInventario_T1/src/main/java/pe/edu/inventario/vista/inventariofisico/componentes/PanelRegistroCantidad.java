package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Formulario para registrar la cantidad física de un producto (primer o segundo conteo). */
public class PanelRegistroCantidad extends JPanel {
    private final JLabel producto = new JLabel("Selecciona un producto de la tabla");
    private final JTextField cantidad = new JTextField(10);
    private final JTextField observacion = new JTextField(28);
    private final JCheckBox segundo = new JCheckBox("Registrar segundo conteo");

    public PanelRegistroCantidad() {
        super(new GridBagLayout());
        setBorder(new EmptyBorder(8, 14, 8, 14));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 5, 4, 5); g.anchor = GridBagConstraints.WEST;
        g.gridx = 0; g.gridy = 0; add(producto, g);
        g.gridx = 1; add(new JLabel("Cantidad física:"), g);
        g.gridx = 2; add(cantidad, g);
        g.gridx = 3; add(segundo, g);
        g.gridx = 0; g.gridy = 1; add(new JLabel("Observación:"), g);
        g.gridx = 1; g.gridwidth = 3; g.fill = GridBagConstraints.HORIZONTAL; add(observacion, g);
    }

    /** Carga los datos del producto elegido; si ya tenía conteo lo propone como valor inicial. */
    public void mostrarProducto(Producto p) {
        if (p == null) { limpiar(); return; }
        producto.setText(p.codigo() + " · " + p.nombre() + " (" + p.unidad() + ")");
        BigDecimalSeleccion.proponer(cantidad, segundo.isSelected() ? p.segundoConteo() : p.cantidadContada());
        observacion.setText(p.observacion() == null ? "" : p.observacion());
    }

    public void limpiar() {
        producto.setText("Selecciona un producto de la tabla");
        cantidad.setText("");
        observacion.setText("");
    }

    public String getCantidadTexto() { return cantidad.getText(); }
    public String getObservacion() { return observacion.getText(); }
    public boolean esSegundoConteo() { return segundo.isSelected(); }
    public void setSegundoHabilitado(boolean habilitado) { segundo.setEnabled(habilitado); if (!habilitado) segundo.setSelected(false); }
    public void setSegundoConteo(boolean valor) { segundo.setSelected(valor); }
    public void alCambiarModoConteo(Runnable r) { segundo.addActionListener(e -> r.run()); }
    public void enfocarCantidad() { cantidad.requestFocusInWindow(); cantidad.selectAll(); }

    /** Pequeña ayuda para mostrar una cantidad opcional en un campo de texto. */
    private static final class BigDecimalSeleccion {
        static void proponer(JTextField campo, java.math.BigDecimal valor) { campo.setText(valor == null ? "" : cantidad(valor)); }
    }
}
