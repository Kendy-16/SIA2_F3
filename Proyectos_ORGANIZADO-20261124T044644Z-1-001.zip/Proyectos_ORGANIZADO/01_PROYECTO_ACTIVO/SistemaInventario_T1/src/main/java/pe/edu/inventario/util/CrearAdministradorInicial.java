
package pe.edu.inventario.util;

import pe.edu.inventario.controlador.LoginController;
import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.migracion.AdministradorMigraciones;

import javax.swing.*;
import java.util.Arrays;

public final class CrearAdministradorInicial {

    private CrearAdministradorInicial() {
    }

    public static void main(String[] args) {

        try {

            // Inicializar la base de datos.
            ConexionDB.inicializar();

            AdministradorMigraciones.ejecutar();

            LoginController controlador =
                    new LoginController();

            // No permitir crear otro administrador.
            if (controlador.hayUsuariosRegistrados()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Ya existe un usuario registrado. "
                        + "No se creará otro administrador.",
                        "Configuración",
                        JOptionPane.INFORMATION_MESSAGE
                );

                return;
            }

            JTextField txtUsuario =
                    new JTextField("admin", 20);

            JPasswordField txtPassword =
                    new JPasswordField(20);

            JPasswordField txtConfirmacion =
                    new JPasswordField(20);

            Object[] campos = {
                "Usuario:", txtUsuario,
                "Contraseña:", txtPassword,
                "Confirmar contraseña:", txtConfirmacion
            };

            int respuesta = JOptionPane.showConfirmDialog(
                    null,
                    campos,
                    "Crear primer administrador",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (respuesta != JOptionPane.OK_OPTION) {
                return;
            }

            char[] password = txtPassword.getPassword();

            char[] confirmacion =
                    txtConfirmacion.getPassword();

            try {

                if (!Arrays.equals(password, confirmacion)) {

                    JOptionPane.showMessageDialog(
                            null,
                            "Las contraseñas no coinciden.",
                            "Error",
                            JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }

                controlador.registrarPrimerAdministrador(
                        txtUsuario.getText().trim(),
                        password
                );

                JOptionPane.showMessageDialog(
                        null,
                        "Administrador creado correctamente.\n"
                        + "Usuario: admin\n"
                        + "Ya puede iniciar sesión.",
                        "Registro exitoso",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } finally {

                Arrays.fill(password, '\0');
                Arrays.fill(confirmacion, '\0');

                txtPassword.setText("");
                txtConfirmacion.setText("");
            }

        } catch (RuntimeException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "No se pudo crear el administrador:\n"
                    + e.getMessage(),
                    "Error de configuración",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }
}
