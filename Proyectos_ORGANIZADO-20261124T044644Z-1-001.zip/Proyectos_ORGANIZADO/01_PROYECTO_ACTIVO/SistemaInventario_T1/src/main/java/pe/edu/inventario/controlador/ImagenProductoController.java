package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.ImagenProducto;
import pe.edu.inventario.servicio.ImagenProductoService;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Controlador del módulo de imágenes de productos.
 *
 * Comunica la vista con el servicio.
 */
public class ImagenProductoController {

    private final ImagenProductoService servicio;

    public ImagenProductoController() {
        this.servicio = new ImagenProductoService();
    }

    public List<ImagenProducto> buscarImagenes(String termino)
            throws IOException, InterruptedException {

        return servicio.buscarImagenes(termino);
    }

    public ImagenProducto guardarImagen(
            long idProducto,
            ImagenProducto imagen)
            throws IOException, InterruptedException, SQLException {

        return servicio.guardarImagen(idProducto, imagen);
    }

    public ImagenProducto obtenerImagen(long idProducto)
            throws SQLException {

        return servicio.obtenerImagen(idProducto);
    }
}