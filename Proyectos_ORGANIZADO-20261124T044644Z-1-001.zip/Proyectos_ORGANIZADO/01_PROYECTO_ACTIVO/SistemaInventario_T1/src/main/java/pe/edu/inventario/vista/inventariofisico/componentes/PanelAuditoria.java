package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Bitácora de eventos de una toma. */
public class PanelAuditoria extends JPanel {
    private final TablaAuditoriaModel modelo = new TablaAuditoriaModel();
    private final JTable tabla = new JTable(modelo);

    public PanelAuditoria() {
        super(new BorderLayout());
        setOpaque(false);
        estiloTabla(tabla);
        tabla.setAutoCreateRowSorter(false);
        tabla.getColumnModel().getColumn(0).setMaxWidth(60);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    public void setEventos(List<String> eventos) { modelo.setEventos(eventos); }
    public TablaAuditoriaModel getModelo() { return modelo; }
}
