package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Campo de búsqueda con botón; avisa con el texto cuando el usuario pulsa Enter o "Buscar". */
public class PanelBusquedaProductos extends JPanel {
    private final JTextField campo = new JTextField(18);

    public PanelBusquedaProductos(Consumer<String> alBuscar) {
        super(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton buscar = botonSecundario("Buscar");
        add(new JLabel("Buscar:"));
        add(campo);
        add(buscar);
        buscar.addActionListener(e -> alBuscar.accept(campo.getText()));
        campo.addActionListener(e -> alBuscar.accept(campo.getText()));
    }

    public String getTexto() { return campo.getText(); }
}
