package pe.edu.inventario.servicio.venta;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Kardex en memoria: controla el stock por producto y registra cada entrada/salida.
 * En el sistema real esta clase se conectaría con el módulo de Inventario.
 */
public class KardexService {

    public static class Movimiento {
        private final LocalDateTime fecha = LocalDateTime.now();
        private final String codigoProducto;
        private final String tipo; // ENTRADA | SALIDA
        private final int cantidad;
        private final String motivo;
        private final int saldo;

        Movimiento(String codigoProducto, String tipo, int cantidad, String motivo, int saldo) {
            this.codigoProducto = codigoProducto;
            this.tipo = tipo;
            this.cantidad = cantidad;
            this.motivo = motivo;
            this.saldo = saldo;
        }

        public LocalDateTime getFecha() { return fecha; }
        public String getCodigoProducto() { return codigoProducto; }
        public String getTipo() { return tipo; }
        public int getCantidad() { return cantidad; }
        public String getMotivo() { return motivo; }
        public int getSaldo() { return saldo; }

        @Override
        public String toString() {
            return String.format("%-8s %-7s cant=%-4d saldo=%-4d %s",
                    codigoProducto, tipo, cantidad, saldo, motivo);
        }
    }

    private final Map<String, Integer> stock = new HashMap<>();
    private final List<Movimiento> movimientos = new ArrayList<>();

    public synchronized void cargarStockInicial(String codigoProducto, int cantidad) {
        stock.put(codigoProducto, cantidad);
        movimientos.add(new Movimiento(codigoProducto, "ENTRADA", cantidad, "STOCK INICIAL", cantidad));
    }

    public synchronized int stockActual(String codigoProducto) {
        return stock.getOrDefault(codigoProducto, 0);
    }

    public synchronized boolean verificarStock(String codigoProducto, int cantidad) {
        return stockActual(codigoProducto) >= cantidad;
    }

    public synchronized void registrarSalida(String codigoProducto, int cantidad, String motivo) {
        int actual = stockActual(codigoProducto);
        if (actual < cantidad) {
            throw new IllegalStateException("Stock insuficiente para " + codigoProducto
                    + " (disponible " + actual + ", solicitado " + cantidad + ")");
        }
        int nuevo = actual - cantidad;
        stock.put(codigoProducto, nuevo);
        movimientos.add(new Movimiento(codigoProducto, "SALIDA", cantidad, motivo, nuevo));
    }

    public synchronized void registrarEntrada(String codigoProducto, int cantidad, String motivo) {
        int nuevo = stockActual(codigoProducto) + cantidad;
        stock.put(codigoProducto, nuevo);
        movimientos.add(new Movimiento(codigoProducto, "ENTRADA", cantidad, motivo, nuevo));
    }

    public synchronized List<Movimiento> getMovimientos() {
        return Collections.unmodifiableList(new ArrayList<>(movimientos));
    }
}
