package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Aprueba o rechaza una solicitud de ajuste. Solo el perfil autorizado puede decidir. */
public class AprobacionAjusteDialog extends JDialog {
    public AprobacionAjusteDialog(Window owner, InventarioFisicoController controller, long idToma, Diferencia d,
                                  PermisosVistaInventario permisos, Runnable alCambiar) {
        super(owner, "Aprobación de ajuste", ModalityType.APPLICATION_MODAL);
        setSize(600, 470); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));
        boolean pendiente = d.estadoRevision() != null && d.estadoRevision().toUpperCase().startsWith("PENDIENTE");
        JPanel datos = new JPanel(new GridLayout(0, 2, 8, 7));
        datos.setBorder(new EmptyBorder(16, 18, 8, 18));
        datos.add(etiquetaSecundaria("Producto:")); datos.add(new JLabel(d.producto().codigo() + " · " + d.producto().nombre()));
        datos.add(etiquetaSecundaria("Diferencia:")); datos.add(new JLabel(cantidad(d.diferencia()) + " (" + d.tipo() + ")"));
        datos.add(etiquetaSecundaria("Valor referencial:")); datos.add(new JLabel(moneda(d.valorDiferencia())));
        datos.add(etiquetaSecundaria("Estado del ajuste:")); datos.add(new JLabel(texto(d.estadoRevision())));
        datos.add(etiquetaSecundaria("Perfil:")); datos.add(new JLabel(permisos.descripcion()));
        add(datos, BorderLayout.NORTH);
        PanelObservaciones motivo = new PanelObservaciones("Motivo (obligatorio para rechazar):", 4);
        motivo.setBorder(new EmptyBorder(0, 18, 8, 18));
        add(motivo, BorderLayout.CENTER);

        JButton aprobar = botonPrimario("Aprobar"), rechazar = botonSecundario("Rechazar"), cerrar = botonSecundario("Cerrar");
        aprobar.setEnabled(pendiente && permisos.puedeAprobarAjuste());
        rechazar.setEnabled(pendiente && permisos.puedeRechazarAjuste());
        if (!pendiente) aprobar.setToolTipText("Primero debe existir una solicitud pendiente.");
        if (!permisos.puedeAprobarAjuste()) aprobar.setToolTipText(MensajesInventarioFisico.SIN_PERMISO);
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(aprobar); abajo.add(rechazar); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);

        cerrar.addActionListener(e -> dispose());
        aprobar.addActionListener(e -> {
            if (!MensajesInventarioFisico.confirmar(this,
                    "¿Aprobar el ajuste? La actualización real de inventario debe ejecutarse en el servicio transaccional.", "Aprobar ajuste")) return;
            TareaAsincrona.ejecutar(this, () -> { controller.aprobarAjuste(idToma, d.producto().id()); return true; },
                    ok -> { MensajesInventarioFisico.informacion(this, "Ajuste aprobado."); alCambiar.run(); dispose(); });
        });
        rechazar.addActionListener(e -> {
            String m = motivo.getTexto();
            if (m == null || m.isBlank()) { MensajesInventarioFisico.advertencia(this, "Escribe el motivo del rechazo."); return; }
            TareaAsincrona.ejecutar(this, () -> { controller.rechazarAjuste(idToma, d.producto().id(), m); return true; },
                    ok -> { MensajesInventarioFisico.informacion(this, "Ajuste rechazado."); alCambiar.run(); dispose(); });
        });
    }
}
