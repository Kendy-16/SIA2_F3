
package pe.edu.inventario.vista.movimientos;

import pe.edu.inventario.controlador.MovimientoController;
import pe.edu.inventario.vista.movimientos.componentes.EstilosMovimiento;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

/**
 * Vista principal del módulo de movimientos.
 *
 * ADMINISTRADOR:
 * - Registrar entradas.
 * - Registrar salidas.
 * - Registrar ajustes físicos.
 *
 * USUARIO:
 * - No puede registrar ni modificar movimientos.
 * - Puede consultar el historial desde Kardex,
 *   siempre que el menú y sus permisos lo permitan.
 *
 * Las validaciones de esta vista son complementarias.
 * El servicio y el DAO mantienen las validaciones definitivas.
 */
public class MovimientoView extends JPanel {

    // =========================================================
    // 1. CONSTANTES
    // =========================================================

    private static final String ROL_ADMINISTRADOR = "ADMINISTRADOR";
    private static final String ROL_USUARIO = "USUARIO";

    private static final BigDecimal CERO = BigDecimal.ZERO;

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;
    private static final int MAX_DECIMALES_COSTO = 6;

    private static final int MAX_DOCUMENTO = 50;
    private static final int MAX_OBSERVACION = 500;

    private static final Pattern PATRON_DOCUMENTO =
            Pattern.compile("^[A-Z0-9][A-Z0-9._/-]{0,49}$");

    private static final Pattern PATRON_CANTIDAD =
            Pattern.compile("^\\d+(?:[.,]\\d{1,3})?$");

    private static final Pattern PATRON_COSTO =
            Pattern.compile("^\\d+(?:[.,]\\d{1,6})?$");

    // =========================================================
    // 2. ATRIBUTOS
    // =========================================================

    private final MovimientoController movimientoController;

    private final String rolActual;

    private final boolean esAdministrador;

    // =========================================================
    // 3. CONSTRUCTORES
    // =========================================================

    /**
     * Constructor seguro por defecto.
     * Si no se proporciona un rol, no se concede acceso administrativo.
     */
    public MovimientoView() {
        this(ROL_USUARIO);
    }

    /**
     * Constructor que recibe el rol de la sesión autenticada.
     *
     * Roles admitidos:
     * ADMINISTRADOR, ADMIN, USUARIO y USER.
     */


    public MovimientoView(String rol) {
        this(rol, new MovimientoController(rol));
    }


    /**
     * Constructor con inyección del controlador.
     */
    public MovimientoView(
            String rol,
            MovimientoController movimientoController
    ) {

        if (movimientoController == null) {
            throw new IllegalArgumentException(
                    "El controlador de movimientos es obligatorio."
            );
        }

        this.rolActual = normalizarRol(rol);

        this.esAdministrador =
                ROL_ADMINISTRADOR.equals(this.rolActual);

        this.movimientoController = movimientoController;

        inicializarVista();
    }

    // =========================================================
    // 4. NORMALIZACIÓN Y COMPROBACIÓN DEL ROL
    // =========================================================

    private static String normalizarRol(String rol) {

        if (rol == null || rol.isBlank()) {
            throw new IllegalArgumentException(
                    "No se recibió un rol válido para la sesión."
            );
        }

        String rolNormalizado =
                rol.trim().toUpperCase(Locale.ROOT);

        switch (rolNormalizado) {

            case "ADMIN":
            case "ADMINISTRADOR":
                return ROL_ADMINISTRADOR;

            case "USER":
            case "USUARIO":
                return ROL_USUARIO;

            default:
                throw new IllegalArgumentException(
                        "Rol no reconocido: " + rol
                );
        }
    }

    public String getRol() {
        return rolActual;
    }

    public boolean esAdministrador() {
        return esAdministrador;
    }

    // =========================================================
    // 5. INICIALIZACIÓN
    // =========================================================

    private void inicializarVista() {

        setLayout(new BorderLayout(0, 18));

        setBackground(EstilosMovimiento.FONDO);

        setBorder(
                new EmptyBorder(20, 22, 22, 22)
        );

        agregarEncabezado();

        if (esAdministrador) {
            agregarPanelAdministrador();
        } else {
            agregarPanelUsuario();
        }
    }

    // =========================================================
    // 6. ENCABEZADO
    // =========================================================

    private void agregarEncabezado() {

        JPanel encabezado = new JPanel(
                new BorderLayout(15, 5)
        );

        encabezado.setBackground(
                EstilosMovimiento.BLANCO
        );

        encabezado.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                EstilosMovimiento.BORDE
                        ),
                        new EmptyBorder(17, 20, 17, 20)
                )
        );

        JPanel informacion = new JPanel(
                new GridLayout(2, 1, 0, 5)
        );

        informacion.setOpaque(false);

        JLabel titulo = EstilosMovimiento.crearTitulo(
                "Gestión de movimientos"
        );

        JLabel subtitulo = EstilosMovimiento.crearTextoSecundario(
                "Control de entradas, salidas y ajustes de inventario"
        );

        informacion.add(titulo);
        informacion.add(subtitulo);

        JLabel etiquetaRol = new JLabel(
                esAdministrador
                        ? "ADMINISTRADOR"
                        : "USUARIO"
        );

        etiquetaRol.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        etiquetaRol.setForeground(
                esAdministrador
                        ? EstilosMovimiento.EXITO
                        : EstilosMovimiento.AZUL_PRINCIPAL
        );

        etiquetaRol.setOpaque(true);

        etiquetaRol.setBackground(
                esAdministrador
                        ? new Color(230, 245, 238)
                        : EstilosMovimiento.AZUL_CLARO
        );

        etiquetaRol.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        etiquetaRol.setBorder(
                new EmptyBorder(9, 14, 9, 14)
        );

        encabezado.add(
                informacion,
                BorderLayout.CENTER
        );

        encabezado.add(
                etiquetaRol,
                BorderLayout.EAST
        );

        add(
                encabezado,
                BorderLayout.NORTH
        );
    }

    // =========================================================
    // 7. PANEL DEL ADMINISTRADOR
    // =========================================================

    private void agregarPanelAdministrador() {

        JTabbedPane pestanas = new JTabbedPane();

        pestanas.setFont(
                EstilosMovimiento.TEXTO_NEGRITA
        );

        pestanas.setBackground(
                EstilosMovimiento.BLANCO
        );

        pestanas.addTab(
                "  Entrada  ",
                crearFormulario(TipoOperacion.ENTRADA)
        );

        pestanas.addTab(
                "  Salida  ",
                crearFormulario(TipoOperacion.SALIDA)
        );

        pestanas.addTab(
                "  Ajuste físico  ",
                crearFormulario(TipoOperacion.AJUSTE)
        );

        JPanel contenedor = new JPanel(
                new BorderLayout()
        );

        contenedor.setOpaque(false);

        contenedor.add(
                pestanas,
                BorderLayout.CENTER
        );

        add(
                contenedor,
                BorderLayout.CENTER
        );
    }

    // =========================================================
    // 8. PANEL DEL USUARIO
    // =========================================================

    private void agregarPanelUsuario() {

        JPanel contenedor = new JPanel(
                new BorderLayout(0, 15)
        );

        contenedor.setOpaque(false);

        JLabel titulo = EstilosMovimiento.crearSubtitulo(
                "Acceso de consulta"
        );

        JTextArea informacion = new JTextArea();

        informacion.setEditable(false);
        informacion.setFocusable(false);
        informacion.setLineWrap(true);
        informacion.setWrapStyleWord(true);

        informacion.setFont(
                EstilosMovimiento.TEXTO_NORMAL
        );

        informacion.setForeground(
                EstilosMovimiento.TEXTO
        );

        informacion.setBackground(
                EstilosMovimiento.BLANCO
        );

        informacion.setText(
                "Tu cuenta tiene permisos de usuario.\n\n"
                + "Desde este perfil no está permitido:\n\n"
                + "• Registrar entradas de inventario.\n"
                + "• Registrar salidas de inventario.\n"
                + "• Realizar ajustes de existencias.\n"
                + "• Modificar movimientos registrados.\n\n"
                + "Para consultar los movimientos históricos, "
                + "utiliza el módulo Kardex del menú principal, "
                + "si está habilitado para tu cuenta.\n\n"
                + "Las operaciones que modifican las existencias "
                + "están reservadas al administrador."
        );

        informacion.setBorder(
                new EmptyBorder(5, 2, 5, 2)
        );

        JPanel tarjeta = new JPanel(
                new BorderLayout(0, 12)
        );

        tarjeta.setBackground(
                EstilosMovimiento.BLANCO
        );

        tarjeta.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                EstilosMovimiento.BORDE
                        ),
                        new EmptyBorder(18, 20, 18, 20)
                )
        );

        tarjeta.add(
                titulo,
                BorderLayout.NORTH
        );

        tarjeta.add(
                informacion,
                BorderLayout.CENTER
        );

        contenedor.add(
                tarjeta,
                BorderLayout.NORTH
        );

        add(
                contenedor,
                BorderLayout.CENTER
        );
    }

    // =========================================================
    // 9. CREAR FORMULARIO
    // =========================================================

    private static final double TASA_IGV = 0.18;

    private JPanel crearFormulario(TipoOperacion tipo) {

        FormularioMovimiento formulario =
                new FormularioMovimiento(tipo);

        JPanel principal = new JPanel(
                new BorderLayout(0, 15)
        );

        principal.setOpaque(false);

        // -----------------------------------------------------
        // Información del formulario
        // -----------------------------------------------------

        JPanel informacion = new JPanel(
                new GridLayout(2, 1, 0, 5)
        );

        informacion.setOpaque(false);

        JLabel titulo;
        JLabel descripcion;

        switch (tipo) {

            case ENTRADA:

                titulo = EstilosMovimiento.crearSubtitulo(
                        "Registrar entrada de productos"
                );

                descripcion =
                        EstilosMovimiento.crearTextoSecundario(
                                "La entrada actualizará el stock y "
                                + "el costo promedio ponderado móvil."
                        );

                break;

            case SALIDA:

                titulo = EstilosMovimiento.crearSubtitulo(
                        "Registrar salida de productos"
                );

                descripcion =
                        EstilosMovimiento.crearTextoSecundario(
                                "El sistema comprobará las existencias "
                                + "antes de registrar la salida."
                        );

                break;

            default:

                titulo = EstilosMovimiento.crearSubtitulo(
                        "Registrar ajuste físico"
                );

                descripcion =
                        EstilosMovimiento.crearTextoSecundario(
                                "Ingresa el stock físico contado. "
                                + "La justificación es obligatoria."
                        );

                break;
        }

        informacion.add(titulo);
        informacion.add(descripcion);

        // -----------------------------------------------------
        // Campos
        // -----------------------------------------------------

        JPanel campos = new JPanel(
                new GridLayout(0, 2, 16, 14)
        );

        campos.setBackground(
                EstilosMovimiento.BLANCO
        );

        campos.setBorder(
                new EmptyBorder(16, 16, 16, 16)
        );

        agregarCampo(
                campos,
                "ID del producto *",
                formulario.txtIdProducto
        );

        agregarCampo(
                campos,
                "ID del almacén *",
                formulario.txtIdAlmacen
        );

        agregarCampo(
                campos,
                "Documento de referencia *",
                formulario.txtDocumento
        );

        String etiquetaCantidad;

        switch (tipo) {

            case ENTRADA:
                etiquetaCantidad = "Cantidad de entrada *";
                break;

            case SALIDA:
                etiquetaCantidad = "Cantidad de salida *";
                break;

            default:
                etiquetaCantidad = "Cantidad física final *";
                break;
        }

        agregarCampo(
                campos,
                etiquetaCantidad,
                formulario.txtCantidad
        );

        if (tipo == TipoOperacion.ENTRADA) {

            agregarCampo(
                    campos,
                    "Costo unitario *",
                    formulario.txtCosto
            );

            agregarCampoComponente(
                    campos,
                    "El costo ingresado...",
                    formulario.cmbIgv
            );
        }

        if (tipo == TipoOperacion.SALIDA) {

            agregarCampo(
                    campos,
                    "Precio de venta unitario * (0 si es consumo)",
                    formulario.txtPrecioVenta
            );

            agregarCampoComponente(
                    campos,
                    "El precio ingresado...",
                    formulario.cmbIgv
            );
        }

        // -----------------------------------------------------
        // Observación o justificación
        // -----------------------------------------------------

        JPanel observacionPanel = new JPanel(
                new BorderLayout(0, 7)
        );

        observacionPanel.setBackground(
                EstilosMovimiento.BLANCO
        );

        JLabel etiquetaObservacion =
                EstilosMovimiento.crearEtiqueta(
                        tipo == TipoOperacion.AJUSTE
                                ? "Justificación del ajuste *"
                                : "Observación (opcional)"
                );

        formulario.txtObservacion.setRows(4);

        formulario.txtObservacion.setLineWrap(true);
        formulario.txtObservacion.setWrapStyleWord(true);

        EstilosMovimiento.configurarArea(
                formulario.txtObservacion
        );

        JScrollPane desplazamiento = new JScrollPane(
                formulario.txtObservacion
        );

        desplazamiento.setPreferredSize(
                new Dimension(300, 100)
        );

        desplazamiento.setBorder(
                BorderFactory.createLineBorder(
                        EstilosMovimiento.BORDE
                )
        );

        observacionPanel.add(
                etiquetaObservacion,
                BorderLayout.NORTH
        );

        observacionPanel.add(
                desplazamiento,
                BorderLayout.CENTER
        );

        // -----------------------------------------------------
        // Botón de registro
        // -----------------------------------------------------

        JButton botonRegistrar = new JButton(
                obtenerTextoBoton(tipo)
        );

        EstilosMovimiento.configurarBotonPrimario(
                botonRegistrar
        );

        botonRegistrar.setPreferredSize(
                new Dimension(210, 43)
        );

        botonRegistrar.addActionListener(
                evento -> registrarMovimiento(
                        formulario,
                        botonRegistrar
                )
        );

        JPanel panelBoton = new JPanel(
                new BorderLayout()
        );

        panelBoton.setOpaque(false);

        panelBoton.add(
                botonRegistrar,
                BorderLayout.EAST
        );

        // -----------------------------------------------------
        // Cuerpo del formulario
        // -----------------------------------------------------

        JPanel cuerpo = new JPanel(
                new BorderLayout(0, 15)
        );

        cuerpo.setBackground(
                EstilosMovimiento.BLANCO
        );

        cuerpo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                EstilosMovimiento.BORDE
                        ),
                        new EmptyBorder(18, 18, 18, 18)
                )
        );

        cuerpo.add(
                campos,
                BorderLayout.NORTH
        );

        cuerpo.add(
                observacionPanel,
                BorderLayout.CENTER
        );

        cuerpo.add(
                panelBoton,
                BorderLayout.SOUTH
        );

        principal.add(
                informacion,
                BorderLayout.NORTH
        );

        principal.add(
                cuerpo,
                BorderLayout.CENTER
        );

        JScrollPane desplazamientoPrincipal =
                new JScrollPane(principal);

        desplazamientoPrincipal.setBorder(null);

        desplazamientoPrincipal.setOpaque(false);
        desplazamientoPrincipal.getViewport().setOpaque(false);

        desplazamientoPrincipal.getVerticalScrollBar()
                .setUnitIncrement(16);

        JPanel resultado = new JPanel(
                new BorderLayout()
        );

        resultado.setOpaque(false);

        resultado.add(
                desplazamientoPrincipal,
                BorderLayout.CENTER
        );

        return resultado;
    }

    // =========================================================
    // 10. AGREGAR CAMPO
    // =========================================================

    private void agregarCampo(
            JPanel contenedor,
            String texto,
            JTextField campo
    ) {

        JPanel panel = new JPanel(
                new BorderLayout(0, 7)
        );

        panel.setOpaque(false);

        JLabel etiqueta =
                EstilosMovimiento.crearEtiqueta(texto);

        EstilosMovimiento.configurarCampo(campo);

        campo.setPreferredSize(
                new Dimension(200, 38)
        );

        panel.add(
                etiqueta,
                BorderLayout.NORTH
        );

        panel.add(
                campo,
                BorderLayout.CENTER
        );

        contenedor.add(panel);
    }

    private void agregarCampoComponente(
            JPanel contenedor,
            String texto,
            JComponent componente
    ) {

        JPanel panel = new JPanel(new BorderLayout(0, 7));

        panel.setOpaque(false);

        componente.setPreferredSize(new Dimension(200, 38));

        panel.add(EstilosMovimiento.crearEtiqueta(texto), BorderLayout.NORTH);
        panel.add(componente, BorderLayout.CENTER);

        contenedor.add(panel);
    }

    // =========================================================
    // 11. TEXTO DE LOS BOTONES
    // =========================================================

    private String obtenerTextoBoton(TipoOperacion tipo) {

        switch (tipo) {

            case ENTRADA:
                return "Registrar entrada";

            case SALIDA:
                return "Registrar salida";

            default:
                return "Registrar ajuste";
        }
    }

    // =========================================================
    // 12. REGISTRAR MOVIMIENTO
    // =========================================================

    private void registrarMovimiento(
            FormularioMovimiento formulario,
            JButton boton
    ) {

        // -----------------------------------------------------
        // Protección por rol en la interfaz
        // -----------------------------------------------------

        if (!esAdministrador) {

            JOptionPane.showMessageDialog(
                    this,
                    "Tu cuenta no tiene permisos para registrar "
                    + "movimientos.",
                    "Acceso restringido",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        // -----------------------------------------------------
        // Evitar envíos repetidos
        // -----------------------------------------------------

        if (!boton.isEnabled()) {
            return;
        }

        final int idProducto;
        final int idAlmacen;
        final String documento;
        final double cantidad;
        final double costo;
        final double precioVenta;
        final boolean incluyeIgv;
        final String observacion;

        // -----------------------------------------------------
        // Validar los datos
        // -----------------------------------------------------

        try {

            idProducto = validarId(
                    formulario.txtIdProducto.getText(),
                    "producto"
            );

            idAlmacen = validarId(
                    formulario.txtIdAlmacen.getText(),
                    "almacén"
            );

            documento = validarDocumento(
                    formulario.txtDocumento.getText()
            );

            boolean permitirCero =
                    formulario.tipo == TipoOperacion.AJUSTE;

            BigDecimal cantidadDecimal = validarNumero(
                    formulario.txtCantidad.getText(),
                    permitirCero,
                    MAX_DECIMALES_CANTIDAD,
                    PATRON_CANTIDAD,
                    "cantidad"
            );

            if (cantidadDecimal.compareTo(CANTIDAD_MAXIMA) > 0) {

                throw new IllegalArgumentException(
                        "La cantidad supera el máximo permitido."
                );
            }

            cantidad = cantidadDecimal.doubleValue();

            if (!Double.isFinite(cantidad)) {

                throw new IllegalArgumentException(
                        "La cantidad ingresada no es un número válido."
                );
            }

            if (formulario.tipo == TipoOperacion.ENTRADA) {

                BigDecimal costoDecimal = validarNumero(
                        formulario.txtCosto.getText(),
                        true,
                        MAX_DECIMALES_COSTO,
                        PATRON_COSTO,
                        "costo unitario"
                );

                if (costoDecimal.compareTo(COSTO_MAXIMO) > 0) {

                    throw new IllegalArgumentException(
                            "El costo unitario supera el máximo permitido."
                    );
                }

                costo = costoDecimal.doubleValue();

                if (!Double.isFinite(costo)) {

                    throw new IllegalArgumentException(
                            "El costo unitario no es válido."
                    );
                }

            } else {

                costo = 0.0;
            }

            if (formulario.tipo == TipoOperacion.SALIDA) {

                BigDecimal precioDecimal = validarNumero(
                        formulario.txtPrecioVenta.getText(),
                        true,
                        MAX_DECIMALES_COSTO,
                        PATRON_COSTO,
                        "precio de venta"
                );

                if (precioDecimal.compareTo(COSTO_MAXIMO) > 0) {

                    throw new IllegalArgumentException(
                            "El precio de venta supera el máximo permitido."
                    );
                }

                precioVenta = precioDecimal.doubleValue();

            } else {

                precioVenta = 0.0;
            }

            incluyeIgv = formulario.cmbIgv != null
                    && formulario.cmbIgv.getSelectedIndex() == 1;

            observacion = validarObservacion(
                    formulario.txtObservacion.getText(),
                    formulario.tipo == TipoOperacion.AJUSTE
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Validación de datos",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        // -----------------------------------------------------
        // Confirmar la operación
        // -----------------------------------------------------

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                crearMensajeConfirmacion(
                        formulario.tipo,
                        idProducto,
                        idAlmacen,
                        cantidad
                ),
                "Confirmar movimiento",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        // -----------------------------------------------------
        // Bloquear el botón mientras se procesa
        // -----------------------------------------------------

        boton.setEnabled(false);
        boton.setText("Procesando...");

        // -----------------------------------------------------
        // Ejecutar la operación en segundo plano
        // -----------------------------------------------------

        SwingWorker<Boolean, Void> trabajador =
                new SwingWorker<>() {

            @Override
            protected Boolean doInBackground()
                    throws Exception {

                switch (formulario.tipo) {

                    case ENTRADA:

                        return movimientoController
                                .registrarMovimientoEntrada(
                                        idProducto,
                                        idAlmacen,
                                        documento,
                                        cantidad,
                                        costo,
                                        incluyeIgv,
                                        TASA_IGV,
                                        observacion
                                );

                    case SALIDA:

                        return movimientoController
                                .registrarMovimientoSalida(
                                        idProducto,
                                        idAlmacen,
                                        documento,
                                        cantidad,
                                        precioVenta,
                                        incluyeIgv,
                                        TASA_IGV,
                                        observacion
                                );

                    case AJUSTE:

                        return movimientoController
                                .registrarMovimientoAjuste(
                                        idProducto,
                                        idAlmacen,
                                        documento,
                                        cantidad,
                                        observacion
                                );

                    default:

                        throw new IllegalStateException(
                                "Tipo de movimiento no reconocido."
                        );
                }
            }

            @Override
            protected void done() {

                try {

                    boolean registrado = get();

                    if (registrado) {

                        JOptionPane.showMessageDialog(
                                MovimientoView.this,
                                "El movimiento se registró correctamente.\n\n"
                                + "La operación fue procesada por "
                                + "el sistema de inventario.",
                                "Movimiento registrado",
                                JOptionPane.INFORMATION_MESSAGE
                        );

                        limpiarFormulario(formulario);

                    } else {

                        JOptionPane.showMessageDialog(
                                MovimientoView.this,
                                "No se pudo confirmar el registro "
                                + "del movimiento.",
                                "Operación no completada",
                                JOptionPane.WARNING_MESSAGE
                        );
                    }

                } catch (InterruptedException ex) {

                    Thread.currentThread().interrupt();

                    mostrarError(
                            "La operación fue interrumpida."
                    );

                } catch (ExecutionException ex) {

                    Throwable causa = ex.getCause();

                    String mensaje = obtenerMensajeError(causa);

                    mostrarError(mensaje);

                } catch (Exception ex) {

                    mostrarError(
                            obtenerMensajeError(ex)
                    );

                } finally {

                    boton.setEnabled(true);

                    boton.setText(
                            obtenerTextoBoton(formulario.tipo)
                    );
                }
            }
        };

        trabajador.execute();
    }

    // =========================================================
    // 13. MENSAJE DE CONFIRMACIÓN
    // =========================================================

    private String crearMensajeConfirmacion(
            TipoOperacion tipo,
            int idProducto,
            int idAlmacen,
            double cantidad
    ) {

        String operacion;

        switch (tipo) {

            case ENTRADA:
                operacion = "ENTRADA";
                break;

            case SALIDA:
                operacion = "SALIDA";
                break;

            default:
                operacion = "AJUSTE FÍSICO";
                break;
        }

        return "¿Deseas registrar esta operación?\n\n"
                + "Tipo: " + operacion + "\n"
                + "Producto: " + idProducto + "\n"
                + "Almacén: " + idAlmacen + "\n"
                + "Cantidad: " + cantidad + "\n\n"
                + "Verifica que los datos sean correctos.";
    }

    // =========================================================
    // 14. VALIDAR IDENTIFICADORES
    // =========================================================

    private int validarId(
            String texto,
            String nombre
    ) {

        if (texto == null || texto.isBlank()) {

            throw new IllegalArgumentException(
                    "El ID del " + nombre + " es obligatorio."
            );
        }

        String valor = texto.trim();

        if (!valor.matches("^[0-9]+$")) {

            throw new IllegalArgumentException(
                    "El ID del " + nombre
                    + " debe contener únicamente números enteros."
            );
        }

        try {

            long idLong = Long.parseLong(valor);

            if (idLong <= 0) {

                throw new IllegalArgumentException(
                        "El ID del " + nombre
                        + " debe ser mayor que cero."
                );
            }

            if (idLong > Integer.MAX_VALUE) {

                throw new IllegalArgumentException(
                        "El ID del " + nombre
                        + " supera el valor máximo permitido."
                );
            }

            return (int) idLong;

        } catch (NumberFormatException ex) {

            throw new IllegalArgumentException(
                    "El ID del " + nombre
                    + " supera el valor permitido."
            );
        }
    }

    // =========================================================
    // 15. VALIDAR CANTIDAD Y COSTO
    // =========================================================

    private BigDecimal validarNumero(
            String texto,
            boolean permitirCero,
            int maxDecimales,
            Pattern patron,
            String nombre
    ) {

        if (texto == null || texto.isBlank()) {

            throw new IllegalArgumentException(
                    "El campo " + nombre + " es obligatorio."
            );
        }

        String normalizado =
                texto.trim().replace(',', '.');

        if (!patron.matcher(normalizado).matches()) {

            throw new IllegalArgumentException(
                    "El campo " + nombre
                    + " tiene un formato numérico inválido.\n"
                    + "Utiliza números y como máximo "
                    + maxDecimales + " decimales."
            );
        }

        final BigDecimal valor;

        try {

            valor = new BigDecimal(normalizado);

        } catch (NumberFormatException ex) {

            throw new IllegalArgumentException(
                    "El valor de " + nombre + " no es válido."
            );
        }

        if (valor.compareTo(CERO) < 0) {

            throw new IllegalArgumentException(
                    "El campo " + nombre
                    + " no puede contener valores negativos."
            );
        }

        if (!permitirCero && valor.compareTo(CERO) == 0) {

            throw new IllegalArgumentException(
                    "El campo " + nombre
                    + " debe ser mayor que cero."
            );
        }

        if (valor.scale() > maxDecimales) {

            throw new IllegalArgumentException(
                    "El campo " + nombre
                    + " excede la cantidad permitida de decimales ("
                    + maxDecimales + ")."
            );
        }

        return valor;
    }

    // =========================================================
    // 16. VALIDAR DOCUMENTO
    // =========================================================

    private String validarDocumento(String texto) {

        if (texto == null || texto.isBlank()) {

            throw new IllegalArgumentException(
                    "El documento de referencia es obligatorio."
            );
        }

        String documento =
                texto.trim().toUpperCase(Locale.ROOT);

        if (documento.length() > MAX_DOCUMENTO) {

            throw new IllegalArgumentException(
                    "El documento de referencia no puede exceder los "
                    + MAX_DOCUMENTO + " caracteres."
            );
        }

        if (!PATRON_DOCUMENTO.matcher(documento).matches()) {

            throw new IllegalArgumentException(
                    "El documento de referencia contiene caracteres no válidos.\n"
                    + "Debe iniciar con una letra o número y solo puede "
                    + "contener letras, números, puntos, guiones y barras."
            );
        }

        return documento;
    }

    // =========================================================
    // 17. VALIDAR OBSERVACIÓN Y JUSTIFICACIÓN
    // =========================================================

    private String validarObservacion(
            String texto,
            boolean esObligatorio
    ) {

        if (texto == null) {
            texto = "";
        }

        String observacion = texto.trim();

        if (esObligatorio && observacion.isBlank()) {

            throw new IllegalArgumentException(
                    "La justificación del ajuste físico es obligatoria."
            );
        }

        if (esObligatorio && observacion.length() < 5) {

            throw new IllegalArgumentException(
                    "La justificación debe contener al menos 5 caracteres."
            );
        }

        if (observacion.length() > MAX_OBSERVACION) {

            throw new IllegalArgumentException(
                    "La observación no puede exceder los "
                    + MAX_OBSERVACION + " caracteres."
            );
        }

        for (int i = 0; i < observacion.length(); i++) {

            char caracter = observacion.charAt(i);

            if (Character.isISOControl(caracter)
                    && caracter != '\n'
                    && caracter != '\t') {

                throw new IllegalArgumentException(
                        "La observación contiene caracteres no permitidos."
                );
            }
        }

        return observacion;
    }

    // =========================================================
    // 18. LIMPIAR FORMULARIO
    // =========================================================

    private void limpiarFormulario(
            FormularioMovimiento formulario
    ) {

        formulario.txtIdProducto.setText("");
        formulario.txtIdAlmacen.setText("");
        formulario.txtDocumento.setText("");
        formulario.txtCantidad.setText("");

        if (formulario.txtCosto != null) {
            formulario.txtCosto.setText("");
        }

        if (formulario.txtPrecioVenta != null) {
            formulario.txtPrecioVenta.setText("");
        }

        if (formulario.cmbIgv != null) {
            formulario.cmbIgv.setSelectedIndex(0);
        }

        formulario.txtObservacion.setText("");
    }

    // =========================================================
    // 19. OBTENER MENSAJE DE ERROR
    // =========================================================

    private String obtenerMensajeError(Throwable error) {

        Throwable causa = error;

        while (causa != null && causa.getCause() != null) {
            causa = causa.getCause();
        }

        if (causa == null
                || causa.getMessage() == null
                || causa.getMessage().isBlank()) {

            return "Se produjo un error al registrar el movimiento.";
        }

        return causa.getMessage();
    }

    // =========================================================
    // 20. MOSTRAR ERROR
    // =========================================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error en la operación",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // =========================================================
    // 21. ENUMERACIÓN DE OPERACIONES
    // =========================================================

    public enum TipoOperacion {
        ENTRADA,
        SALIDA,
        AJUSTE
    }

    // =========================================================
    // 22. CLASE AUXILIAR DEL FORMULARIO
    // =========================================================

    private static class FormularioMovimiento {

        final TipoOperacion tipo;

        final JTextField txtIdProducto;
        final JTextField txtIdAlmacen;
        final JTextField txtDocumento;
        final JTextField txtCantidad;
        final JTextField txtCosto;
        final JTextField txtPrecioVenta;
        final JComboBox<String> cmbIgv;

        final JTextArea txtObservacion;

        FormularioMovimiento(TipoOperacion tipo) {

            this.tipo = tipo;

            this.txtIdProducto = new JTextField();
            this.txtIdAlmacen = new JTextField();
            this.txtDocumento = new JTextField();
            this.txtCantidad = new JTextField();

            this.txtCosto =
                    tipo == TipoOperacion.ENTRADA
                            ? new JTextField()
                            : null;

            this.txtPrecioVenta =
                    tipo == TipoOperacion.SALIDA
                            ? new JTextField()
                            : null;

            this.cmbIgv =
                    (tipo == TipoOperacion.ENTRADA
                            || tipo == TipoOperacion.SALIDA)
                            ? new JComboBox<>(new String[]{
                                    "Es valor SIN IGV (neto)",
                                    "Incluye IGV (18 %)"})
                            : null;

            this.txtObservacion = new JTextArea();
        }
    }
}
