package pe.edu.inventario.modelo.venta;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/** Cabecera de una venta con sus totales, pago y datos de anulación. */
public class Venta {
    private static final BigDecimal CERO = BigDecimal.ZERO.setScale(2);
    private static final AtomicLong SECUENCIA = new AtomicLong();

    private String idVenta = String.format("V-%08d", SECUENCIA.incrementAndGet());
    /** Token único por venta: evita cobros duplicados (ver ControlIdempotencia). */
    private String tokenTransaccion = UUID.randomUUID().toString();
    private LocalDateTime fechaEmision;
    private TipoVenta tipoVenta = TipoVenta.NORMAL;
    private String idCliente;
    private String nombreCliente;
    private String idUsuario;
    private RolUsuario rolUsuario = RolUsuario.USUARIO;
    private EstadoVenta estado = EstadoVenta.EMITIDA;

    private BigDecimal subtotal = CERO;
    private BigDecimal descuentoTotal = CERO;
    private BigDecimal impuestos = CERO;
    private BigDecimal total = CERO;

    private String metodoPago;
    private BigDecimal montoRecibido = CERO;
    private BigDecimal vuelto = CERO;
    private String comprobante;

    private String motivoAnulacion;
    private String usuarioAutoriza;

    private List<DetalleVenta> detalles = new ArrayList<>();

    // ---- Líneas de detalle ----
    public void agregarDetalle(DetalleVenta d) { detalles.add(d); }
    public void quitarDetalle(int indice) { detalles.remove(indice); }

    /** @return la línea con ese código de producto, o null si no existe. */
    public DetalleVenta buscarDetalle(String codigoProducto) {
        for (DetalleVenta d : detalles) {
            if (d.getCodigoProducto() != null && d.getCodigoProducto().equalsIgnoreCase(codigoProducto)) {
                return d;
            }
        }
        return null;
    }

    // ---- Getters / setters ----
    public String getIdVenta() { return idVenta; }
    public void setIdVenta(String v) { this.idVenta = v; }
    public String getTokenTransaccion() { return tokenTransaccion; }
    public void setTokenTransaccion(String v) { this.tokenTransaccion = v; }
    public LocalDateTime getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(LocalDateTime v) { this.fechaEmision = v; }
    public TipoVenta getTipoVenta() { return tipoVenta; }
    public void setTipoVenta(TipoVenta v) { this.tipoVenta = v; }
    public String getIdCliente() { return idCliente; }
    public void setIdCliente(String v) { this.idCliente = v; }
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String v) { this.nombreCliente = v; }
    public String getIdUsuario() { return idUsuario; }
    public void setIdUsuario(String v) { this.idUsuario = v; }
    public RolUsuario getRolUsuario() { return rolUsuario; }
    public void setRolUsuario(RolUsuario v) { this.rolUsuario = v; }
    public EstadoVenta getEstado() { return estado; }
    public void setEstado(EstadoVenta v) { this.estado = v; }
    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal v) { this.subtotal = v; }
    public BigDecimal getDescuentoTotal() { return descuentoTotal; }
    public void setDescuentoTotal(BigDecimal v) { this.descuentoTotal = v; }
    public BigDecimal getImpuestos() { return impuestos; }
    public void setImpuestos(BigDecimal v) { this.impuestos = v; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal v) { this.total = v; }
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String v) { this.metodoPago = v; }
    public BigDecimal getMontoRecibido() { return montoRecibido; }
    public void setMontoRecibido(BigDecimal v) { this.montoRecibido = v; }
    public BigDecimal getVuelto() { return vuelto; }
    public void setVuelto(BigDecimal v) { this.vuelto = v; }
    public String getComprobante() { return comprobante; }
    public void setComprobante(String v) { this.comprobante = v; }
    public String getMotivoAnulacion() { return motivoAnulacion; }
    public void setMotivoAnulacion(String v) { this.motivoAnulacion = v; }
    public String getUsuarioAutoriza() { return usuarioAutoriza; }
    public void setUsuarioAutoriza(String v) { this.usuarioAutoriza = v; }
    public List<DetalleVenta> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleVenta> v) { this.detalles = v == null ? new ArrayList<>() : v; }
}
