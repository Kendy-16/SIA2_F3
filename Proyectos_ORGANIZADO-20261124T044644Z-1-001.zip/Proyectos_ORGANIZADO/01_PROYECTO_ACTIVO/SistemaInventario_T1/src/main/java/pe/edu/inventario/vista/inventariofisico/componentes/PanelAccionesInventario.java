package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Botones de acciones del panel principal. Los deshabilitados dependen del perfil. */
public class PanelAccionesInventario extends JPanel {
    /** Acciones que dispara el panel. */
    public interface Acciones {
        void nuevaToma();
        void registrarConteo();
        void conciliar();
        void verDetalles();
        void historial();
        void reporte();
    }

    public PanelAccionesInventario(Acciones a, PermisosVistaInventario permisos) {
        super(new FlowLayout(FlowLayout.LEFT, 8, 4));
        setOpaque(false);
        JButton nueva = botonPrimario("Nueva toma física");
        JButton conteo = botonSecundario("Registrar conteo");
        JButton conciliar = botonSecundario("Conciliar");
        JButton detalle = botonSecundario("Ver detalles");
        JButton historial = botonSecundario("Historial completo");
        JButton reporte = botonSecundario("Reporte");
        nueva.setEnabled(permisos.puedeCrearToma());
        conteo.setEnabled(permisos.puedeRegistrarConteo());
        conciliar.setEnabled(permisos.puedeConciliar());
        nueva.addActionListener(e -> a.nuevaToma());
        conteo.addActionListener(e -> a.registrarConteo());
        conciliar.addActionListener(e -> a.conciliar());
        detalle.addActionListener(e -> a.verDetalles());
        historial.addActionListener(e -> a.historial());
        reporte.addActionListener(e -> a.reporte());
        for (JButton b : new JButton[]{nueva, conteo, conciliar, detalle, historial, reporte}) add(b);
    }
}
