package pe.edu.inventario.modelo.venta;

public enum TipoVenta {
    NORMAL,
    MAYORISTA
}
