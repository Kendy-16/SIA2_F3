# Cotizaciones

Pendiente. Emisión de cotizaciones a clientes.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
