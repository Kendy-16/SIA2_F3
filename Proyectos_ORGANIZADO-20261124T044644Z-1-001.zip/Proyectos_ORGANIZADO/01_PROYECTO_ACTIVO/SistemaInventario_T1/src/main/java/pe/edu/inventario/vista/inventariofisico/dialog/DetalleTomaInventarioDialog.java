package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Detalle de una toma en pestañas: general, productos y conteos, diferencias y auditoría. */
public class DetalleTomaInventarioDialog extends JDialog {
    /** Todo lo que necesita la ventana, cargado en una sola operación en segundo plano. */
    private record Datos(Toma toma, boolean ciego, List<Producto> productos, List<Diferencia> diferencias, List<String> auditoria) { }

    private final PanelInformacionToma general = new PanelInformacionToma();
    private final TablaConteoModel productos = new TablaConteoModel();
    private final JTable tablaProductos = new JTable(productos);
    private final TablaDiferenciasModel diferencias = new TablaDiferenciasModel();
    private final JTable tablaDiferencias = new JTable(diferencias);
    private final PanelAuditoria auditoria = new PanelAuditoria();

    public DetalleTomaInventarioDialog(Window owner, InventarioFisicoController controller, long idToma) {
        super(owner, "Detalle de toma física · " + idToma, ModalityType.APPLICATION_MODAL);
        setSize(960, 660); setLocationRelativeTo(owner); setLayout(new BorderLayout());

        estiloTabla(tablaProductos);
        tablaProductos.setDefaultRenderer(BigDecimal.class, new CantidadRenderer());
        tablaProductos.getColumnModel().getColumn(7).setCellRenderer(new EstadoConteoRenderer());
        estiloTabla(tablaDiferencias);
        tablaDiferencias.setDefaultRenderer(BigDecimal.class, new DiferenciaRenderer());
        tablaDiferencias.getColumnModel().getColumn(3).setCellRenderer(new MonedaRenderer());
        tablaDiferencias.getColumnModel().getColumn(4).setCellRenderer(new DiferenciaRenderer());

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("General", general);
        tabs.addTab("Productos y conteos", new JScrollPane(tablaProductos));
        tabs.addTab("Diferencias", new JScrollPane(tablaDiferencias));
        tabs.addTab("Auditoría", auditoria);
        add(tabs, BorderLayout.CENTER);

        JButton verConteo = botonSecundario("Ver conteo del producto"), verAuditoria = botonSecundario("Auditoría completa"), cerrar = botonSecundario("Cerrar");
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(verConteo); abajo.add(verAuditoria); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);
        cerrar.addActionListener(e -> dispose());
        verAuditoria.addActionListener(e -> new AuditoriaTomaDialog(this, controller, idToma).setVisible(true));
        verConteo.addActionListener(e -> {
            int fila = tablaProductos.getSelectedRow();
            if (fila < 0) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_PRODUCTO); return; }
            Producto p = productos.getProducto(tablaProductos.convertRowIndexToModel(fila));
            new DetalleConteoDialog(this, p, p.stockSistema() == null).setVisible(true);
        });

        TareaAsincrona.ejecutar(this, () -> {
            Toma toma = controller.listarTomas("", null).stream().filter(t -> t.id() == idToma).findFirst().orElse(null);
            boolean ciego = controller.esConteoCiego(idToma);
            // El stock del sistema solo se oculta mientras el conteo ciego está en curso.
            boolean ocultar = ciego && toma != null && (toma.estado() == EstadoToma.ABIERTA || toma.estado() == EstadoToma.EN_CONTEO);
            return new Datos(toma, ocultar, controller.listarProductosToma(idToma, ocultar), controller.listarDiferencias(idToma), controller.listarAuditoria(idToma));
        }, d -> {
            general.mostrar(d.toma());
            productos.setFilas(d.productos(), d.ciego());
            diferencias.setDiferencias(d.diferencias());
            auditoria.setEventos(d.auditoria());
        });
    }
}
