
package pe.edu.inventario.vista.producto;

import pe.edu.inventario.controlador.CategoriaController;
import pe.edu.inventario.modelo.Categoria;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * View for category management.
 *
 * Supports registration, search, update and deletion.
 */
public class CategoriaView extends JPanel {

    // ==========================================
    // 1. CONSTANTS
    // ==========================================

    private static final int MIN_NOMBRE = 3;
    private static final int MAX_NOMBRE = 120;
    private static final int MAX_DESCRIPCION = 500;

    // ==========================================
    // 2. ATTRIBUTES
    // ==========================================

    private final CategoriaController controlador;

    private JTextField txtNombre;
    private JTextArea txtDescripcion;
    private JTextField txtBuscar;

    private JTable tablaCategorias;

    private DefaultTableModel modeloTabla;

    private TableRowSorter<DefaultTableModel> ordenadorTabla;

    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnBuscar;
    private JButton btnMostrarTodos;

    private JLabel lblEstado;

    private int idSeleccionado = 0;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public CategoriaView() {

        controlador = new CategoriaController();

        configurarPanel();
        inicializarComponentes();
        registrarEventos();

        cargarCategorias();
    }

    // ==========================================
    // 4. CONFIGURE PANEL
    // ==========================================

    private void configurarPanel() {

        setLayout(new BorderLayout(12, 12));

        setBorder(
                BorderFactory.createEmptyBorder(
                        15, 15, 15, 15
                )
        );
    }

    // ==========================================
    // 5. INITIALIZE COMPONENTS
    // ==========================================

    private void inicializarComponentes() {

        // --------------------------------------
        // 5.1. TITLE
        // --------------------------------------

        JLabel lblTitulo = new JLabel(
                "GESTION DE CATEGORIAS",
                SwingConstants.CENTER
        );

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 22)
        );

        // --------------------------------------
        // 5.2. FORM
        // --------------------------------------

        JPanel panelFormulario =
                new JPanel(new GridBagLayout());

        panelFormulario.setBorder(
                BorderFactory.createTitledBorder(
                        "Datos de la categoria"
                )
        );

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(6, 8, 6, 8);

        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.anchor = GridBagConstraints.WEST;

        // Name
        txtNombre = new JTextField(25);

        txtNombre.setToolTipText(
                "Ingrese un nombre de entre 3 y 120 caracteres."
        );

        limitarLongitud(txtNombre, MAX_NOMBRE);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;

        panelFormulario.add(
                new JLabel("Nombre: *"),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        panelFormulario.add(txtNombre, gbc);

        // Description
        txtDescripcion = new JTextArea(3, 25);

        txtDescripcion.setLineWrap(true);

        txtDescripcion.setWrapStyleWord(true);

        txtDescripcion.setToolTipText(
                "Descripcion opcional. Maximo 500 caracteres."
        );

        limitarLongitud(
                txtDescripcion,
                MAX_DESCRIPCION
        );

        JScrollPane scrollDescripcion =
                new JScrollPane(txtDescripcion);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;

        panelFormulario.add(
                new JLabel("Descripcion:"),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        panelFormulario.add(scrollDescripcion, gbc);

        // --------------------------------------
        // 5.3. BUTTONS
        // --------------------------------------

        JPanel panelBotones =
                new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));

        btnGuardar = new JButton("Guardar");

        btnActualizar = new JButton("Actualizar");

        btnEliminar = new JButton("Eliminar");

        btnLimpiar = new JButton("Limpiar");

        btnActualizar.setEnabled(false);

        btnEliminar.setEnabled(false);

        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        // --------------------------------------
        // 5.4. SEARCH
        // --------------------------------------

        JPanel panelBusqueda =
                new JPanel(new FlowLayout(FlowLayout.LEFT));

        txtBuscar = new JTextField(20);

        limitarLongitud(txtBuscar, 100);

        btnBuscar = new JButton("Buscar");

        btnMostrarTodos = new JButton("Mostrar todos");

        panelBusqueda.add(
                new JLabel("Buscar categoria:")
        );

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnMostrarTodos);

        // --------------------------------------
        // 5.5. TABLE
        // --------------------------------------

        modeloTabla = new DefaultTableModel(
                new Object[]{
                    "ID",
                    "Nombre",
                    "Descripcion"
                },
                0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna
            ) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columna) {

                return columna == 0
                        ? Integer.class
                        : String.class;
            }
        };

        tablaCategorias = new JTable(modeloTabla);

        tablaCategorias.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaCategorias.setAutoCreateRowSorter(true);

        tablaCategorias.setRowHeight(25);

        ordenadorTabla =
                (TableRowSorter<DefaultTableModel>)
                        tablaCategorias.getRowSorter();

        JScrollPane scrollTabla =
                new JScrollPane(tablaCategorias);

        scrollTabla.setBorder(
                BorderFactory.createTitledBorder(
                        "Categorias registradas"
                )
        );

        // --------------------------------------
        // 5.6. STATUS
        // --------------------------------------

        lblEstado = new JLabel(
                "Listo para gestionar categorias."
        );

        lblEstado.setFont(
                new Font("Arial", Font.PLAIN, 11)
        );

        // --------------------------------------
        // 5.7. ORGANIZE LAYOUT
        // --------------------------------------

        JPanel panelSuperior =
                new JPanel(new BorderLayout(5, 5));

        JPanel panelDatos =
                new JPanel(new BorderLayout(5, 5));

        panelDatos.add(
                panelFormulario,
                BorderLayout.CENTER
        );

        panelDatos.add(
                panelBotones,
                BorderLayout.SOUTH
        );

        panelSuperior.add(
                lblTitulo,
                BorderLayout.NORTH
        );

        panelSuperior.add(
                panelDatos,
                BorderLayout.CENTER
        );

        JPanel panelCentral =
                new JPanel(new BorderLayout(5, 5));

        panelCentral.add(
                panelBusqueda,
                BorderLayout.NORTH
        );

        panelCentral.add(
                scrollTabla,
                BorderLayout.CENTER
        );

        add(panelSuperior, BorderLayout.NORTH);

        add(panelCentral, BorderLayout.CENTER);

        add(lblEstado, BorderLayout.SOUTH);
    }

    // ==========================================
    // 6. REGISTER EVENTS
    // ==========================================

    private void registrarEventos() {

        btnGuardar.addActionListener(
                e -> guardarCategoria()
        );

        btnActualizar.addActionListener(
                e -> actualizarCategoria()
        );

        btnEliminar.addActionListener(
                e -> eliminarCategoria()
        );

        btnLimpiar.addActionListener(
                e -> limpiarCampos()
        );

        btnBuscar.addActionListener(
                e -> buscarCategoria()
        );

        btnMostrarTodos.addActionListener(
                e -> mostrarTodos()
        );

        txtBuscar.addActionListener(
                e -> buscarCategoria()
        );

        tablaCategorias.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {
                        cargarCategoriaSeleccionada();
                    }
                });
    }

    // ==========================================
    // 7. GET FORM DATA
    // ==========================================

    private Categoria obtenerDatosFormulario() {

        String nombre = txtNombre.getText().trim();

        String descripcion = txtDescripcion.getText().trim();

        if (nombre.isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre de la categoria es obligatorio."
            );
        }

        int longitud =
                nombre.codePointCount(0, nombre.length());

        if (longitud < MIN_NOMBRE || longitud > MAX_NOMBRE) {
            throw new IllegalArgumentException(
                    "El nombre debe tener entre 3 y 120 caracteres."
            );
        }

        if (descripcion.codePointCount(
                0,
                descripcion.length()
        ) > MAX_DESCRIPCION) {

            throw new IllegalArgumentException(
                    "La descripcion no puede superar 500 caracteres."
            );
        }

        return new Categoria(
                idSeleccionado,
                nombre,
                descripcion.isEmpty() ? null : descripcion
        );
    }

    // ==========================================
    // 8. REGISTER CATEGORY
    // ==========================================

    private void guardarCategoria() {

        try {

            Categoria categoria = obtenerDatosFormulario();

            boolean resultado =
                    controlador.registrarCategoria(categoria);

            if (resultado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Categoria registrada correctamente.",
                        "Registro exitoso",
                        JOptionPane.INFORMATION_MESSAGE
                );

                limpiarCampos();

                cargarCategorias();
            }

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(e.getMessage());

        } catch (SQLException e) {

            mostrarError(
                    "No se pudo registrar la categoria: "
                    + e.getMessage()
            );
        }
    }

    // ==========================================
    // 9. UPDATE CATEGORY
    // ==========================================

    private void actualizarCategoria() {

        if (idSeleccionado <= 0) {

            mostrarAdvertencia(
                    "Seleccione una categoria de la tabla."
            );

            return;
        }

        try {

            Categoria categoria = obtenerDatosFormulario();

            boolean resultado =
                    controlador.actualizarCategoria(categoria);

            if (resultado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Categoria actualizada correctamente.",
                        "Actualizacion exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                limpiarCampos();

                cargarCategorias();
            }

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(e.getMessage());

        } catch (SQLException e) {

            mostrarError(
                    "No se pudo actualizar la categoria: "
                    + e.getMessage()
            );
        }
    }

    // ==========================================
    // 10. DELETE CATEGORY
    // ==========================================

    private void eliminarCategoria() {

        if (idSeleccionado <= 0) {

            mostrarAdvertencia(
                    "Seleccione una categoria de la tabla."
            );

            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "Desea eliminar la categoria seleccionada?",
                "Confirmar eliminacion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean resultado =
                    controlador.eliminarCategoria(idSeleccionado);

            if (resultado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Categoria eliminada correctamente.",
                        "Eliminacion exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                limpiarCampos();

                cargarCategorias();

            } else {

                mostrarAdvertencia(
                        "No se encontro la categoria."
                );
            }

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(e.getMessage());

        } catch (SQLException e) {

            mostrarError(e.getMessage());
        }
    }

    // ==========================================
    // 11. LOAD CATEGORIES
    // ==========================================

    private void cargarCategorias() {

        try {

            ArrayList<Categoria> categorias =
                    controlador.listarCategorias();

            modeloTabla.setRowCount(0);

            for (Categoria categoria : categorias) {

                if (categoria == null) {
                    continue;
                }

                modeloTabla.addRow(
                        new Object[]{
                            categoria.getIdCategoria(),
                            categoria.getNombre(),
                            categoria.getDescripcion()
                    });
            }

            actualizarEstado(
                    categorias.size()
                    + " categorias encontradas."
            );

        } catch (SQLException e) {

            mostrarError(
                    "No se pudieron cargar las categorias: "
                    + e.getMessage()
            );
        }
    }

    // ==========================================
    // 12. LOAD SELECTED CATEGORY
    // ==========================================

    private void cargarCategoriaSeleccionada() {

        int filaVista = tablaCategorias.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo =
                tablaCategorias.convertRowIndexToModel(filaVista);

        idSeleccionado = (Integer)
                modeloTabla.getValueAt(filaModelo, 0);

        txtNombre.setText(
                String.valueOf(
                        modeloTabla.getValueAt(filaModelo, 1)
                )
        );

        Object descripcion =
                modeloTabla.getValueAt(filaModelo, 2);

        txtDescripcion.setText(
                descripcion == null
                        ? ""
                        : descripcion.toString()
        );

        actualizarBotones();

        actualizarEstado(
                "Categoria seleccionada: "
                + txtNombre.getText()
        );
    }

    // ==========================================
    // 13. SEARCH CATEGORY
    // ==========================================

    private void buscarCategoria() {

        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {

            mostrarTodos();

            return;
        }

        try {

            String expresion =
                    "(?i)" + Pattern.quote(texto);

            ordenadorTabla.setRowFilter(
                    RowFilter.regexFilter(
                            expresion,
                            1,
                            2
                    )
            );

            int resultados = tablaCategorias.getRowCount();

            actualizarEstado(
                    resultados + " resultados encontrados."
            );

            if (resultados == 0) {

                actualizarEstado(
                        "No se encontraron categorias."
                );
            }

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(
                    "El criterio de busqueda no es valido."
            );
        }
    }

    // ==========================================
    // 14. SHOW ALL CATEGORIES
    // ==========================================

    private void mostrarTodos() {

        txtBuscar.setText("");

        ordenadorTabla.setRowFilter(null);

        actualizarEstado(
                "Mostrando todas las categorias."
        );
    }

    // ==========================================
    // 15. CLEAR FORM
    // ==========================================

    private void limpiarCampos() {

        txtNombre.setText("");

        txtDescripcion.setText("");

        idSeleccionado = 0;

        tablaCategorias.clearSelection();

        actualizarBotones();

        actualizarEstado(
                "Formulario listo para registrar una categoria."
        );

        txtNombre.requestFocusInWindow();
    }

    // ==========================================
    // 16. UPDATE BUTTON STATES
    // ==========================================

    private void actualizarBotones() {

        boolean seleccionado = idSeleccionado > 0;

        btnGuardar.setEnabled(!seleccionado);

        btnActualizar.setEnabled(seleccionado);

        btnEliminar.setEnabled(seleccionado);
    }

    // ==========================================
    // 17. LIMIT FIELD LENGTH
    // ==========================================

    private void limitarLongitud(
            JTextComponent componente,
            int longitudMaxima
    ) {

        AbstractDocument documento =
                (AbstractDocument) componente.getDocument();

        documento.setDocumentFilter(
                new DocumentFilter() {

            @Override
            public void insertString(
                    FilterBypass fb,
                    int offset,
                    String texto,
                    AttributeSet atributos
            ) throws BadLocationException {

                if (texto != null) {

                    replace(
                            fb,
                            offset,
                            0,
                            texto,
                            atributos
                    );
                }
            }

            @Override
            public void replace(
                    FilterBypass fb,
                    int offset,
                    int longitud,
                    String texto,
                    AttributeSet atributos
            ) throws BadLocationException {

                if (texto == null) {
                    texto = "";
                }

                int nuevaLongitud =
                        fb.getDocument().getLength()
                        - longitud
                        + texto.length();

                if (nuevaLongitud <= longitudMaxima) {

                    fb.replace(
                            offset,
                            longitud,
                            texto,
                            atributos
                    );

                } else {

                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    // ==========================================
    // 18. SHOW WARNING
    // ==========================================

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validacion",
                JOptionPane.WARNING_MESSAGE
        );
    }

    // ==========================================
    // 19. SHOW ERROR
    // ==========================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // ==========================================
    // 20. UPDATE STATUS
    // ==========================================

    private void actualizarEstado(String mensaje) {

        lblEstado.setText(mensaje);
    }
}
