package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.ImagenProducto;
import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Acceso a datos de las imágenes de productos.
 *
 * Toda operación SQL se mantiene en esta clase.
 */
public class ImagenProductoDAO {

    public void guardar(ImagenProducto imagen) throws SQLException {

        String sql = """
                INSERT INTO imagenes_productos (
                    id_producto,
                    pixabay_id,
                    ruta_local,
                    fuente,
                    pagina_fuente,
                    autor
                )
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(id_producto) DO UPDATE SET
                    pixabay_id = excluded.pixabay_id,
                    ruta_local = excluded.ruta_local,
                    fuente = excluded.fuente,
                    pagina_fuente = excluded.pagina_fuente,
                    autor = excluded.autor,
                    fecha_guardado = CURRENT_TIMESTAMP
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setLong(1, imagen.getIdProducto());
            sentencia.setLong(2, imagen.getPixabayId());
            sentencia.setString(3, imagen.getRutaLocal());
            sentencia.setString(4, imagen.getFuente());
            sentencia.setString(5, imagen.getPaginaFuente());
            sentencia.setString(6, imagen.getAutor());

            sentencia.executeUpdate();
        }
    }

    public ImagenProducto buscarPorProducto(long idProducto)
            throws SQLException {

        String sql = """
                SELECT id_imagen,
                       id_producto,
                       pixabay_id,
                       ruta_local,
                       fuente,
                       pagina_fuente,
                       autor,
                       fecha_guardado
                FROM imagenes_productos
                WHERE id_producto = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setLong(1, idProducto);

            try (ResultSet resultado = sentencia.executeQuery()) {

                if (!resultado.next()) {
                    return null;
                }

                ImagenProducto imagen = new ImagenProducto();

                imagen.setIdImagen(resultado.getInt("id_imagen"));
                imagen.setIdProducto(resultado.getLong("id_producto"));
                imagen.setPixabayId(resultado.getLong("pixabay_id"));
                imagen.setRutaLocal(resultado.getString("ruta_local"));
                imagen.setFuente(resultado.getString("fuente"));
                imagen.setPaginaFuente(resultado.getString("pagina_fuente"));
                imagen.setAutor(resultado.getString("autor"));

                String fecha = resultado.getString("fecha_guardado");

                if (fecha != null) {
                    imagen.setFechaGuardado(
                            java.time.LocalDateTime.parse(
                                    fecha.replace(" ", "T")
                            )
                    );
                }

                return imagen;
            }
        }
    }

    public void eliminarPorProducto(long idProducto)
            throws SQLException {

        String sql = """
                DELETE FROM imagenes_productos
                WHERE id_producto = ?
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setLong(1, idProducto);
            sentencia.executeUpdate();
        }
    }

    public String obtenerCache(String termino)
            throws SQLException {

        String sql = """
                SELECT respuesta_json
                FROM cache_busqueda_imagenes
                WHERE termino = ?
                  AND fecha_consulta >= ?
                """;

        long limite = System.currentTimeMillis() / 1000 - 86400;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setString(1, termino);
            sentencia.setLong(2, limite);

            try (ResultSet resultado = sentencia.executeQuery()) {
                return resultado.next()
                        ? resultado.getString("respuesta_json")
                        : null;
            }
        }
    }

    public void guardarCache(String termino, String respuestaJson)
            throws SQLException {

        String sql = """
                INSERT INTO cache_busqueda_imagenes (
                    termino,
                    respuesta_json,
                    fecha_consulta
                )
                VALUES (?, ?, ?)
                ON CONFLICT(termino) DO UPDATE SET
                    respuesta_json = excluded.respuesta_json,
                    fecha_consulta = excluded.fecha_consulta
                """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql)) {

            sentencia.setString(1, termino);
            sentencia.setString(2, respuestaJson);
            sentencia.setLong(
                    3,
                    System.currentTimeMillis() / 1000
            );

            sentencia.executeUpdate();
        }
    }
}