package pe.edu.inventario.servicio.producto;

import pe.edu.inventario.modelo.producto.Producto;
import pe.edu.inventario.modelo.venta.TipoVenta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Catálogo de productos en memoria. Resuelve la búsqueda por código de barras o nombre
 * y el precio según la modalidad de venta (normal o mayorista).
 */
public class ProductoService {

    private final Map<String, Producto> catalogo = new LinkedHashMap<>();

    public void registrar(Producto producto) {
        catalogo.put(producto.getCodigo().toUpperCase(), producto);
    }

    public Producto buscarPorCodigo(String codigo) {
        return codigo == null ? null : catalogo.get(codigo.trim().toUpperCase());
    }

    /** Primero intenta coincidencia exacta por código; si no, busca por nombre (contiene). */
    public Producto buscarPorCodigoONombre(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }
        Producto porCodigo = buscarPorCodigo(texto);
        if (porCodigo != null) {
            return porCodigo;
        }
        String buscado = texto.trim().toLowerCase();
        for (Producto p : catalogo.values()) {
            if (p.getNombre().toLowerCase().contains(buscado)) {
                return p;
            }
        }
        return null;
    }

    public BigDecimal obtenerPrecio(Producto producto, TipoVenta tipo) {
        // Si es normal usa el precio de lista; si es mayorista, el precio por volumen.
        return tipo == TipoVenta.MAYORISTA ? producto.getPrecioMayorista() : producto.getPrecioNormal();
    }

    public List<Producto> listar() {
        return new ArrayList<>(catalogo.values());
    }
}
