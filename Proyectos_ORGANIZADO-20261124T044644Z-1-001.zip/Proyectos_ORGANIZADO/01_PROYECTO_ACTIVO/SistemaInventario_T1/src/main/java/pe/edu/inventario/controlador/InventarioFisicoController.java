
package pe.edu.inventario.controlador;
import pe.edu.inventario.modelo.DetalleInventarioFisico;
import pe.edu.inventario.servicio.InventarioFisicoService;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * Controlador del modulo de inventario fisico.
 *
 * Coordina las solicitudes de la interfaz grafica
 * con el servicio de inventario fisico.
 *
 * No contiene consultas SQL ni reglas de persistencia.
 */
public class InventarioFisicoController {

    // =========================================================
    // 1. ATRIBUTOS
    // =========================================================

    private final InventarioFisicoService inventarioFisicoService;

    // =========================================================
    // 2. CONSTRUCTORES
    // =========================================================

    /**
     * Constructor predeterminado.
     */
    public InventarioFisicoController() {
        this(new InventarioFisicoService());
    }

    /**
     * Constructor con inyeccion de dependencias.
     *
     * @param inventarioFisicoService servicio de inventario fisico
     */
    public InventarioFisicoController(
            InventarioFisicoService inventarioFisicoService
    ) {

        if (inventarioFisicoService == null) {
            throw new IllegalArgumentException(
                    "El servicio de inventario fisico es obligatorio."
            );
        }

        this.inventarioFisicoService = inventarioFisicoService;
    }

    // =========================================================
    // 3. CREAR CONTEO
    // =========================================================

    /**
     * Crea una nueva toma de inventario.
     *
     * @param idAlmacen identificador del almacen
     * @param modo modalidad del conteo
     * @param observacion observacion general
     * @return identificador de la toma creada
     */
    public int crearConteo(
            int idAlmacen,
            String modo,
            String observacion
    ) throws SQLException {

        return inventarioFisicoService.crearConteo(
                idAlmacen,
                modo,
                observacion
        );
    }

    // =========================================================
    // 4. REGISTRAR CANTIDAD FISICA
    // =========================================================

    /**
     * Registra la cantidad encontrada de un producto.
     *
     * @param idToma identificador del conteo
     * @param idProducto identificador del producto
     * @param cantidadFisica cantidad encontrada
     * @param observacion observacion del producto
     */
    public void registrarCantidadFisica(
            int idToma,
            int idProducto,
            BigDecimal cantidadFisica,
            String observacion
    ) throws SQLException {

        inventarioFisicoService.registrarCantidadFisica(
                idToma,
                idProducto,
                cantidadFisica,
                observacion
        );
    }

    // =========================================================
    // 5. LISTAR DETALLES
    // =========================================================

    /**
     * Consulta los productos incluidos en una toma.
     *
     * @param idToma identificador del conteo
     * @return lista de detalles del inventario fisico
     */
    public List<DetalleInventarioFisico> listarDetalle(
            int idToma
    ) throws SQLException {

        return inventarioFisicoService.listarDetalle(idToma);
    }

    // =========================================================
    // 6. PROCESAR CONTEO
    // =========================================================

    /**
     * Procesa el conteo fisico completo.
     *
     * Delega al servicio la operacion, que a su vez
     * invoca el DAO para ejecutar la transaccion.
     *
     * @param idToma identificador del conteo
     * @return resultado entero devuelto por el DAO
     */
    public int procesarConteo(
            int idToma
    ) throws SQLException {

        return inventarioFisicoService.procesarConteo(idToma);
    }
        // =========================================================
    // CONSULTAR ESTADO DE LA TOMA
    // =========================================================

    /**
     * Consulta el estado actual de una toma.
     *
     * @param idToma identificador de la toma
     * @return estado de la toma
     * @throws SQLException si ocurre un error de consulta
     */
    public String obtenerEstadoConteo(int idToma) throws SQLException {

        return inventarioFisicoService.obtenerEstadoConteo(idToma);
    }

    // =========================================================
    // COMPROBAR ALMACEN ACTIVO
    // =========================================================

    /**
     * Comprueba si un almacen existe y esta activo.
     *
     * @param idAlmacen identificador del almacen
     * @return true si el almacen esta activo
     * @throws SQLException si ocurre un error de consulta
     */
    public boolean existeAlmacenActivo(int idAlmacen) throws SQLException {

        return inventarioFisicoService.existeAlmacenActivo(idAlmacen);
    }
}
