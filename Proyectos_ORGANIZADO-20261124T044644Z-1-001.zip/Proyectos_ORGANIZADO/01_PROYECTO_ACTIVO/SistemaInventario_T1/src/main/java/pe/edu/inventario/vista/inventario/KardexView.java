package pe.edu.inventario.vista.inventario;

import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.modelo.Kardex;
import pe.edu.inventario.modelo.Producto;

import pe.edu.inventario.servicio.AlmacenService;
import pe.edu.inventario.servicio.KardexService;
import pe.edu.inventario.servicio.ProductoService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Locale;

public class KardexView extends JPanel {

    // ==================================================
    // 1. SERVICIOS
    // ==================================================

    private final ProductoService productoService;
    private final AlmacenService almacenService;
    private final KardexService kardexService;

    // ==================================================
    // 2. COMPONENTES
    // ==================================================

    private JComboBox<Producto> cmbProducto;
    private JComboBox<Almacen> cmbAlmacen;

    private JTextField txtFechaDesde;
    private JTextField txtFechaHasta;

    private JButton btnConsultar;
    private JButton btnLimpiar;

    private JTable tablaKardex;
    private DefaultTableModel modeloTabla;

    private JLabel lblEstado;

    // ==================================================
    // 3. COLORES
    // ==================================================

    private static final Color COLOR_PRINCIPAL =
            new Color(31, 78, 121);

    private static final Color COLOR_FONDO =
            new Color(245, 247, 250);

    private static final Color COLOR_BLANCO =
            Color.WHITE;

    private static final Color COLOR_TEXTO =
            new Color(45, 55, 72);

    private static final Color COLOR_VERDE =
            new Color(39, 125, 78);

    private static final Color COLOR_ROJO =
            new Color(180, 55, 55);

    // ==================================================
    // 4. FORMATOS
    // ==================================================

    private static final DateTimeFormatter FORMATO_FECHA_HORA =
            DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss")
                    .withResolverStyle(ResolverStyle.STRICT);

    private static final DecimalFormat FORMATO_CANTIDAD =
            new DecimalFormat(
                    "#,##0.###",
                    DecimalFormatSymbols.getInstance(Locale.US)
            );

    private static final DecimalFormat FORMATO_COSTO =
            new DecimalFormat(
                    "#,##0.000000",
                    DecimalFormatSymbols.getInstance(Locale.US)
            );

    private static final DecimalFormat FORMATO_MONEDA =
            new DecimalFormat(
                    "#,##0.00",
                    DecimalFormatSymbols.getInstance(Locale.US)
            );

    private static final BigDecimal CERO =
            BigDecimal.ZERO;

    // ==================================================
    // 5. CONSTRUCTOR
    // ==================================================

    public KardexView() {

        this.productoService = new ProductoService();
        this.almacenService = new AlmacenService();
        this.kardexService = new KardexService();

        configurarPanel();
        inicializarComponentes();
        cargarCatalogos();
    }

    // ==================================================
    // 6. CONFIGURACIÓN GENERAL
    // ==================================================

    private void configurarPanel() {

        setLayout(new BorderLayout(12, 12));

        setBackground(COLOR_FONDO);

        setBorder(
                new EmptyBorder(18, 20, 18, 20)
        );
    }

    // ==================================================
    // 7. INICIALIZAR COMPONENTES
    // ==================================================

    private void inicializarComponentes() {

        add(crearEncabezado(), BorderLayout.NORTH);

        JPanel panelCentral = new JPanel(new BorderLayout(10, 12));

        panelCentral.setOpaque(false);

        panelCentral.add(
                crearPanelFiltros(),
                BorderLayout.NORTH
        );

        panelCentral.add(
                crearPanelTabla(),
                BorderLayout.CENTER
        );

        add(panelCentral, BorderLayout.CENTER);

        add(
                crearPanelEstado(),
                BorderLayout.SOUTH
        );
    }

    // ==================================================
    // 8. ENCABEZADO
    // ==================================================

    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(COLOR_PRINCIPAL);

        panel.setBorder(
                new EmptyBorder(18, 22, 18, 22)
        );

        JLabel titulo = new JLabel(
                "KARDEX VALORIZADO",
                SwingConstants.LEFT
        );

        titulo.setForeground(COLOR_BLANCO);

        titulo.setFont(
                new Font("Arial", Font.BOLD, 23)
        );

        JLabel subtitulo = new JLabel(
                "Control cronológico de entradas, salidas y "
                        + "existencias al costo promedio móvil"
        );

        subtitulo.setForeground(COLOR_BLANCO);

        subtitulo.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        JPanel textos = new JPanel(
                new GridLayout(2, 1, 0, 5)
        );

        textos.setOpaque(false);

        textos.add(titulo);
        textos.add(subtitulo);

        panel.add(textos, BorderLayout.CENTER);

        return panel;
    }

    // ==================================================
    // 9. PANEL DE FILTROS
    // ==================================================

    private JPanel crearPanelFiltros() {

        JPanel panel = new JPanel(new BorderLayout(10, 12));

        panel.setBackground(COLOR_BLANCO);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 225, 232)
                        ),
                        new EmptyBorder(15, 16, 15, 16)
                )
        );

        JLabel titulo = new JLabel(
                "CONSULTA DEL KARDEX"
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 15)
        );

        titulo.setForeground(COLOR_PRINCIPAL);

        panel.add(titulo, BorderLayout.NORTH);

        JPanel campos = new JPanel(
                new GridLayout(2, 4, 12, 8)
        );

        campos.setOpaque(false);

        campos.add(crearEtiqueta("Producto"));
        campos.add(crearEtiqueta("Almacén"));
        campos.add(crearEtiqueta("Fecha desde"));
        campos.add(crearEtiqueta("Fecha hasta"));

        cmbProducto = new JComboBox<>();

        cmbAlmacen = new JComboBox<>();

        txtFechaDesde = new JTextField();

        txtFechaHasta = new JTextField();

        configurarCampo(txtFechaDesde);
        configurarCampo(txtFechaHasta);

        txtFechaDesde.setToolTipText(
                "Formato obligatorio: AAAA-MM-DD"
        );

        txtFechaHasta.setToolTipText(
                "Formato obligatorio: AAAA-MM-DD"
        );

        campos.add(cmbProducto);
        campos.add(cmbAlmacen);
        campos.add(txtFechaDesde);
        campos.add(txtFechaHasta);

        panel.add(campos, BorderLayout.CENTER);

        JPanel botones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 10, 0)
        );

        botones.setOpaque(false);

        btnConsultar = new JButton("Consultar");

        btnLimpiar = new JButton("Limpiar filtros");

        configurarBotonPrincipal(btnConsultar);

        configurarBotonSecundario(btnLimpiar);

        btnConsultar.addActionListener(
                e -> consultarKardex()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFiltros()
        );

        botones.add(btnLimpiar);
        botones.add(btnConsultar);

        panel.add(botones, BorderLayout.SOUTH);

        return panel;
    }

    // ==================================================
    // 10. PANEL DE TABLA
    // ==================================================

    private JPanel crearPanelTabla() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(COLOR_BLANCO);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 225, 232)
                        ),
                        new EmptyBorder(12, 12, 12, 12)
                )
        );

        JLabel titulo = new JLabel(
                "MOVIMIENTOS Y VALORIZACIÓN"
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 15)
        );

        titulo.setForeground(COLOR_PRINCIPAL);

        titulo.setBorder(
                new EmptyBorder(0, 0, 10, 0)
        );

        String[] columnas = {
                "Fecha",
                "Tipo",
                "Documento",
                "Entrada",
                "Costo entrada",
                "Importe entrada",
                "Salida",
                "Costo salida",
                "Importe salida",
                "Saldo",
                "Costo promedio",
                "Valor saldo"
        };

        modeloTabla = new DefaultTableModel(
                columnas,
                0
        ) {
            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna
            ) {
                return false;
            }
        };

        tablaKardex = new JTable(modeloTabla);

        tablaKardex.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );

        tablaKardex.setRowHeight(27);

        tablaKardex.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaKardex.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        tablaKardex.setFillsViewportHeight(true);

        tablaKardex.setGridColor(
                new Color(225, 230, 235)
        );

        tablaKardex.setShowGrid(true);

        JTableHeader encabezado =
                tablaKardex.getTableHeader();

        encabezado.setFont(
                new Font("Arial", Font.BOLD, 11)
        );

        encabezado.setBackground(COLOR_PRINCIPAL);

        encabezado.setForeground(COLOR_BLANCO);

        encabezado.setReorderingAllowed(false);

        configurarAnchoColumnas();

        JScrollPane scroll = new JScrollPane(tablaKardex);

        scroll.getViewport().setBackground(COLOR_BLANCO);

        panel.add(titulo, BorderLayout.NORTH);

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // ==================================================
    // 11. ANCHO DE COLUMNAS
    // ==================================================

    private void configurarAnchoColumnas() {

        int[] anchos = {
                145, 95, 110, 85,
                110, 125, 85, 110,
                125, 90, 125, 125
        };

        for (int i = 0; i < anchos.length; i++) {

            tablaKardex.getColumnModel()
                    .getColumn(i)
                    .setPreferredWidth(anchos[i]);
        }
    }

    // ==================================================
    // 12. PANEL DE ESTADO
    // ==================================================

    private JPanel crearPanelEstado() {

        JPanel panel = new JPanel(
                new BorderLayout()
        );

        panel.setOpaque(false);

        panel.setBorder(
                new EmptyBorder(5, 2, 0, 2)
        );

        lblEstado = new JLabel(
                "Seleccione un producto para consultar su Kardex."
        );

        lblEstado.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );

        lblEstado.setForeground(COLOR_TEXTO);

        panel.add(lblEstado, BorderLayout.WEST);

        return panel;
    }

    // ==================================================
    // 13. CARGAR PRODUCTOS Y ALMACENES
    // ==================================================

    private void cargarCatalogos() {

        try {

            cmbProducto.removeAllItems();

            cmbAlmacen.removeAllItems();

            ArrayList<Producto> productos =
                    productoService.listar();

            ArrayList<Almacen> almacenes =
                    almacenService.listar();

            if (productos == null) {

                throw new SQLException(
                        "No se pudo obtener la lista de productos."
                );
            }

            if (almacenes == null) {

                throw new SQLException(
                        "No se pudo obtener la lista de almacenes."
                );
            }

            configurarRenderizadorProducto();

            configurarRenderizadorAlmacen();

            for (Producto producto : productos) {

                if (producto == null
                        || producto.getIdProducto() <= 0) {

                    continue;
                }

                cmbProducto.addItem(producto);
            }

            // null representa todos los almacenes.

            cmbAlmacen.addItem(null);

            for (Almacen almacen : almacenes) {

                if (almacen == null
                        || almacen.getIdAlmacen() <= 0) {

                    continue;
                }

                cmbAlmacen.addItem(almacen);
            }

            boolean existenProductos =
                    cmbProducto.getItemCount() > 0;

            cmbProducto.setEnabled(existenProductos);

            cmbAlmacen.setEnabled(true);

            btnConsultar.setEnabled(existenProductos);

            if (!existenProductos) {

                lblEstado.setText(
                        "No existen productos registrados."
                );
            }

        } catch (SQLException | RuntimeException ex) {

            btnConsultar.setEnabled(false);

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudieron cargar los productos "
                            + "y almacenes.\n\n"
                            + ex.getMessage(),
                    "Error al cargar información",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==================================================
    // 14. RENDERIZADOR DE PRODUCTOS
    // ==================================================

    private void configurarRenderizadorProducto() {

        cmbProducto.setRenderer(
                new DefaultListCellRenderer() {

                    @Override
                    public Component getListCellRendererComponent(
                            JList<?> lista,
                            Object valor,
                            int indice,
                            boolean seleccionado,
                            boolean tieneFoco
                    ) {

                        super.getListCellRendererComponent(
                                lista,
                                valor,
                                indice,
                                seleccionado,
                                tieneFoco
                        );

                        if (valor instanceof Producto) {

                            Producto producto = (Producto) valor;

                            setText(
                                    producto.getCodigo()
                                            + " - "
                                            + producto.getNombre()
                            );
                        }

                        return this;
                    }
                }
        );
    }

    // ==================================================
    // 15. RENDERIZADOR DE ALMACENES
    // ==================================================

    private void configurarRenderizadorAlmacen() {

        cmbAlmacen.setRenderer(
                new DefaultListCellRenderer() {

                    @Override
                    public Component getListCellRendererComponent(
                            JList<?> lista,
                            Object valor,
                            int indice,
                            boolean seleccionado,
                            boolean tieneFoco
                    ) {

                        super.getListCellRendererComponent(
                                lista,
                                valor,
                                indice,
                                seleccionado,
                                tieneFoco
                        );

                        if (valor == null) {

                            setText("Todos los almacenes");

                        } else if (valor instanceof Almacen) {

                            Almacen almacen = (Almacen) valor;

                            setText(
                                    almacen.getNombre()
                                            + " - "
                                            + almacen.getUbicacion()
                            );
                        }

                        return this;
                    }
                }
        );
    }

    // ==================================================
    // 16. CONSULTAR KARDEX
    // ==================================================

    private void consultarKardex() {

        Producto productoSeleccionado =
                (Producto) cmbProducto.getSelectedItem();

        Almacen almacenSeleccionado =
                (Almacen) cmbAlmacen.getSelectedItem();

        // ----------------------------------------------
        // VALIDAR PRODUCTO
        // ----------------------------------------------

        if (productoSeleccionado == null) {

            mostrarAdvertencia(
                    "Debe seleccionar un producto."
            );

            return;
        }

        if (productoSeleccionado.getIdProducto() <= 0) {

            mostrarAdvertencia(
                    "El producto seleccionado no tiene un ID válido."
            );

            return;
        }

        // ----------------------------------------------
        // VALIDAR ALMACÉN
        // ----------------------------------------------

        Integer idAlmacen = null;

        if (almacenSeleccionado != null) {

            if (almacenSeleccionado.getIdAlmacen() <= 0) {

                mostrarAdvertencia(
                        "El almacén seleccionado no es válido."
                );

                return;
            }

            idAlmacen =
                    almacenSeleccionado.getIdAlmacen();
        }

        // ----------------------------------------------
        // VALIDAR FECHAS
        // ----------------------------------------------

        String textoDesde =
                txtFechaDesde.getText().trim();

        String textoHasta =
                txtFechaHasta.getText().trim();

        LocalDate fechaDesde = null;
        LocalDate fechaHasta = null;

        boolean filtroPorPeriodo =
                !textoDesde.isEmpty()
                        || !textoHasta.isEmpty();

        if (filtroPorPeriodo) {

            if (textoDesde.isEmpty()
                    || textoHasta.isEmpty()) {

                mostrarAdvertencia(
                        "Debe ingresar ambas fechas: "
                                + "fecha desde y fecha hasta."
                );

                return;
            }

            try {

                fechaDesde = LocalDate.parse(
                        textoDesde,
                        DateTimeFormatter.ISO_LOCAL_DATE
                );

                fechaHasta = LocalDate.parse(
                        textoHasta,
                        DateTimeFormatter.ISO_LOCAL_DATE
                );

            } catch (DateTimeParseException ex) {

                mostrarAdvertencia(
                        "Las fechas no tienen un formato válido.\n"
                                + "Utilice AAAA-MM-DD.\n"
                                + "Ejemplo: 2026-11-01"
                );

                return;
            }

            if (fechaHasta.isBefore(fechaDesde)) {

                mostrarAdvertencia(
                        "La fecha hasta no puede ser anterior "
                                + "a la fecha desde."
                );

                return;
            }
        }

        // ----------------------------------------------
        // CONSULTAR HISTORIAL COMPLETO
        // ----------------------------------------------

        try {

            ArrayList<Kardex> registros;

            if (idAlmacen == null) {

                registros =
                        kardexService.consultarPorProducto(
                                productoSeleccionado.getIdProducto()
                        );

            } else {

                registros =
                        kardexService.consultarPorProductoYAlmacen(
                                productoSeleccionado.getIdProducto(),
                                idAlmacen
                        );
            }

            if (registros == null) {

                throw new SQLException(
                        "El servicio devolvió una lista nula."
                );
            }

            modeloTabla.setRowCount(0);

            int cantidadMovimientos = 0;

            // ------------------------------------------
            // CALCULAR SALDO INICIAL DEL PERIODO
            // ------------------------------------------

            BigDecimal saldoInicial = CERO;

            BigDecimal promedioInicial = CERO;

            BigDecimal valorInicial = CERO;

            if (filtroPorPeriodo) {

                for (Kardex registro : registros) {

                    if (registro == null) {
                        continue;
                    }

                    LocalDate fechaMovimiento =
                            obtenerFecha(registro).toLocalDate();

                    if (fechaMovimiento.isBefore(fechaDesde)) {

                        saldoInicial = registro.getSaldo();

                        promedioInicial =
                                registro.getCostoPromedio();

                        valorInicial =
                                registro.getValorSaldo();
                    }
                }

                agregarFilaSaldoInicial(
                        fechaDesde,
                        saldoInicial,
                        promedioInicial,
                        valorInicial
                );
            }

            // ------------------------------------------
            // MOSTRAR MOVIMIENTOS DEL PERIODO
            // ------------------------------------------

            for (Kardex registro : registros) {

                if (registro == null) {
                    continue;
                }

                LocalDate fechaMovimiento =
                        obtenerFecha(registro).toLocalDate();

                if (filtroPorPeriodo) {

                    if (fechaMovimiento.isBefore(fechaDesde)) {
                        continue;
                    }

                    if (fechaMovimiento.isAfter(fechaHasta)) {
                        continue;
                    }
                }

                agregarFilaMovimiento(registro);

                cantidadMovimientos++;
            }

            // ------------------------------------------
            // MOSTRAR RESULTADO
            // ------------------------------------------

            lblEstado.setText(
                    "Producto: "
                            + productoSeleccionado.getCodigo()
                            + " | Movimientos encontrados: "
                            + cantidadMovimientos
                            + (filtroPorPeriodo
                            ? " | Periodo: "
                            + fechaDesde
                            + " al "
                            + fechaHasta
                            : " | Historial completo")
            );

            if (cantidadMovimientos == 0) {

                lblEstado.setText(
                        lblEstado.getText()
                                + " | No existen movimientos en el periodo."
                );
            }

        } catch (SQLException ex) {

            mostrarError(
                    "No se pudo consultar el Kardex.\n\n"
                            + ex.getMessage()
            );

        } catch (DateTimeParseException ex) {

            mostrarError(
                    "Se encontró una fecha inválida "
                            + "en los registros del Kardex."
            );

        } catch (RuntimeException ex) {

            mostrarError(
                    "Ocurrió un error al procesar los movimientos.\n\n"
                            + ex.getMessage()
            );
        }
    }

    // ==================================================
    // 17. OBTENER FECHA DEL MOVIMIENTO
    // ==================================================

    private LocalDateTime obtenerFecha(Kardex registro) {

        if (registro.getFecha() == null
                || registro.getFecha().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Existe un movimiento sin fecha."
            );
        }

        return LocalDateTime.parse(
                registro.getFecha(),
                FORMATO_FECHA_HORA
        );
    }

    // ==================================================
    // 18. AGREGAR SALDO INICIAL
    // ==================================================

    private void agregarFilaSaldoInicial(
            LocalDate fechaDesde,
            BigDecimal saldo,
            BigDecimal costoPromedio,
            BigDecimal valorSaldo
    ) {

        modeloTabla.addRow(
                new Object[]{

                        fechaDesde.toString(),

                        "SALDO INICIAL",

                        "-",

                        "-",

                        "-",

                        "-",

                        "-",

                        "-",

                        "-",

                        formatoCantidad(saldo),

                        formatoCosto(costoPromedio),

                        formatoMoneda(valorSaldo)
                }
        );
    }

    // ==================================================
    // 19. AGREGAR MOVIMIENTO
    // ==================================================

    private void agregarFilaMovimiento(Kardex registro) {

        BigDecimal entrada =
                registro.getEntrada();

        BigDecimal salida =
                registro.getSalida();

        BigDecimal costoUnitario =
                registro.getCostoUnitario();

        BigDecimal importeEntrada =
                entrada.multiply(costoUnitario);

        BigDecimal importeSalida =
                salida.multiply(costoUnitario);

        String costoEntrada = "-";
        String importeEntradaTexto = "-";

        String costoSalida = "-";
        String importeSalidaTexto = "-";

        if (entrada.compareTo(CERO) > 0) {

            costoEntrada =
                    formatoCosto(costoUnitario);

            importeEntradaTexto =
                    formatoMoneda(importeEntrada);
        }

        if (salida.compareTo(CERO) > 0) {

            costoSalida =
                    formatoCosto(costoUnitario);

            importeSalidaTexto =
                    formatoMoneda(importeSalida);
        }

        modeloTabla.addRow(
                new Object[]{

                        registro.getFecha(),

                        registro.getTipo(),

                        registro.getDocumento(),

                        formatoCantidad(entrada),

                        costoEntrada,

                        importeEntradaTexto,

                        formatoCantidad(salida),

                        costoSalida,

                        importeSalidaTexto,

                        formatoCantidad(registro.getSaldo()),

                        formatoCosto(registro.getCostoPromedio()),

                        formatoMoneda(registro.getValorSaldo())
                }
        );
    }

    // ==================================================
    // 20. FORMATEAR CANTIDADES
    // ==================================================

    private String formatoCantidad(BigDecimal valor) {

        if (valor == null) {
            return "0";
        }

        return FORMATO_CANTIDAD.format(valor);
    }

    // ==================================================
    // 21. FORMATEAR COSTOS UNITARIOS
    // ==================================================

    private String formatoCosto(BigDecimal valor) {

        if (valor == null) {
            return "S/ 0.000000";
        }

        return "S/ " + FORMATO_COSTO.format(valor);
    }

    // ==================================================
    // 22. FORMATEAR IMPORTES
    // ==================================================

    private String formatoMoneda(BigDecimal valor) {

        if (valor == null) {
            return "S/ 0.00";
        }

        return "S/ " + FORMATO_MONEDA.format(valor);
    }

    // ==================================================
    // 23. LIMPIAR FILTROS
    // ==================================================

    private void limpiarFiltros() {

        txtFechaDesde.setText("");

        txtFechaHasta.setText("");

        if (cmbAlmacen.getItemCount() > 0) {

            cmbAlmacen.setSelectedIndex(0);
        }

        if (cmbProducto.getItemCount() > 0) {

            cmbProducto.setSelectedIndex(0);
        }

        modeloTabla.setRowCount(0);

        lblEstado.setText(
                "Seleccione un producto para consultar su Kardex."
        );
    }

    // ==================================================
    // 24. COMPONENTES AUXILIARES
    // ==================================================

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        etiqueta.setForeground(COLOR_TEXTO);

        return etiqueta;
    }

    private void configurarCampo(JTextField campo) {

        campo.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );

        campo.setPreferredSize(
                new Dimension(150, 30)
        );

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(200, 208, 218)
                        ),
                        new EmptyBorder(5, 8, 5, 8)
                )
        );
    }

    private void configurarBotonPrincipal(JButton boton) {

        boton.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        boton.setForeground(COLOR_BLANCO);

        boton.setBackground(COLOR_PRINCIPAL);

        boton.setFocusPainted(false);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setBorder(
                new EmptyBorder(9, 18, 9, 18)
        );
    }

    private void configurarBotonSecundario(JButton boton) {

        boton.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        boton.setForeground(COLOR_PRINCIPAL);

        boton.setBackground(COLOR_BLANCO);

        boton.setFocusPainted(false);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                COLOR_PRINCIPAL
                        ),
                        new EmptyBorder(8, 14, 8, 14)
                )
        );
    }

    // ==================================================
    // 25. MENSAJES
    // ==================================================

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validación",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}