
package pe.edu.inventario.vista;

import pe.edu.inventario.controlador.ProductoController;
import pe.edu.inventario.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProductoView extends JPanel {

    private final ProductoController controller;

    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtDescripcion;
    private JTextField txtStockMinimo;
    private JTextField txtBuscar;

    private JComboBox<String> cmbUnidad;

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    private int idProductoSeleccionado = 0;

    public ProductoView() {

        controller = new ProductoController();

        configurarPanel();
        inicializarComponentes();
        listarProductos();
    }

    private void configurarPanel() {

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    }

    private void inicializarComponentes() {

        JLabel titulo = new JLabel(
                "GESTIÓN DE PRODUCTOS",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 22));

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.add(titulo, BorderLayout.NORTH);

        JPanel formulario = new JPanel(new GridLayout(5, 2, 10, 8));
        formulario.setBorder(
                BorderFactory.createTitledBorder("Datos del producto")
        );

        txtCodigo = new JTextField();
        txtNombre = new JTextField();
        txtDescripcion = new JTextField();
        txtStockMinimo = new JTextField();

        cmbUnidad = new JComboBox<>(new String[]{
            "UNIDAD", "KILOGRAMO", "GRAMO",
            "LITRO", "METRO", "CAJA", "PAQUETE"
        });

        formulario.add(new JLabel("Código:"));
        formulario.add(txtCodigo);

        formulario.add(new JLabel("Nombre:"));
        formulario.add(txtNombre);

        formulario.add(new JLabel("Descripción:"));
        formulario.add(txtDescripcion);

        formulario.add(new JLabel("Unidad de medida:"));
        formulario.add(cmbUnidad);

        formulario.add(new JLabel("Stock mínimo:"));
        formulario.add(txtStockMinimo);

        JPanel panelBotones = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 10, 10)
        );

        JButton btnRegistrar = new JButton("Registrar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel panelFormulario = new JPanel(new BorderLayout(5, 5));
        panelFormulario.add(formulario, BorderLayout.CENTER);
        panelFormulario.add(panelBotones, BorderLayout.SOUTH);

        panelSuperior.add(panelFormulario, BorderLayout.CENTER);

        txtBuscar = new JTextField(15);
        JButton btnBuscar = new JButton("Buscar");
        JButton btnMostrarTodos = new JButton("Mostrar todos");

        JPanel panelBusqueda = new JPanel(
                new FlowLayout(FlowLayout.LEFT)
        );

        panelBusqueda.add(new JLabel("Buscar por código:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnMostrarTodos);

        modeloTabla = new DefaultTableModel(
                new Object[]{
                    "ID", "Código", "Nombre", "Descripción",
                    "Unidad", "Stock mínimo"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setAutoCreateRowSorter(true);

        JScrollPane scrollTabla = new JScrollPane(tabla);
        scrollTabla.setBorder(
                BorderFactory.createTitledBorder("Productos registrados")
        );

        JPanel panelCentral = new JPanel(new BorderLayout(5, 5));
        panelCentral.add(panelBusqueda, BorderLayout.NORTH);
        panelCentral.add(scrollTabla, BorderLayout.CENTER);

        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);

        btnRegistrar.addActionListener(e -> registrarProducto());
        btnActualizar.addActionListener(e -> actualizarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnBuscar.addActionListener(e -> buscarProducto());
        btnMostrarTodos.addActionListener(e -> listarProductos());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                cargarProductoSeleccionado();
            }
        });
    }

    // Registrar producto
    private void registrarProducto() {

        try {
            Producto producto = obtenerDatosFormulario();

            boolean resultado = controller.registrarProducto(producto);

            if (resultado) {
                JOptionPane.showMessageDialog(
                        this,
                        "Producto registrado correctamente."
                );

                limpiarFormulario();
                listarProductos();
            }

        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());

        } catch (SQLException e) {
            mostrarError("Error al registrar el producto: " + e.getMessage());
        }
    }

    // Actualizar producto
    private void actualizarProducto() {

        if (idProductoSeleccionado == 0) {
            mostrarError("Seleccione un producto de la tabla.");
            return;
        }

        try {
            Producto producto = obtenerDatosFormulario();
            producto.setIdProducto(idProductoSeleccionado);

            boolean resultado = controller.actualizarProducto(producto);

            if (resultado) {
                JOptionPane.showMessageDialog(
                        this,
                        "Producto actualizado correctamente."
                );

                limpiarFormulario();
                listarProductos();
            }

        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());

        } catch (SQLException e) {
            mostrarError("Error al actualizar: " + e.getMessage());
        }
    }

    // Eliminar producto
    private void eliminarProducto() {

        if (idProductoSeleccionado == 0) {
            mostrarError("Seleccione un producto de la tabla.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de eliminar este producto?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            boolean resultado = controller.eliminarProducto(
                    idProductoSeleccionado
            );

            if (resultado) {
                JOptionPane.showMessageDialog(
                        this,
                        "Producto eliminado correctamente."
                );

                limpiarFormulario();
                listarProductos();
            } else {
                mostrarError("No se encontró el producto.");
            }

        } catch (SQLException e) {
            mostrarError(
                    "No se pudo eliminar. El producto podría estar "
                    + "relacionado con movimientos o inventario.\n"
                    + e.getMessage()
            );
        }
    }

    // Buscar por código
    private void buscarProducto() {

        String codigo = txtBuscar.getText().trim();

        if (codigo.isEmpty()) {
            mostrarError("Ingrese el código que desea buscar.");
            return;
        }

        try {
            Producto producto = controller.buscarProducto(codigo);

            modeloTabla.setRowCount(0);

            if (producto != null) {
                agregarFila(producto);
            } else {
                mostrarError("No se encontró el producto.");
            }

        } catch (SQLException e) {
            mostrarError("Error al buscar: " + e.getMessage());
        }
    }

    // Listar todos los productos
    private void listarProductos() {

        try {
            ArrayList<Producto> productos =
                    controller.listarProductos();

            modeloTabla.setRowCount(0);

            for (Producto producto : productos) {
                agregarFila(producto);
            }

        } catch (SQLException e) {
            mostrarError("Error al listar productos: " + e.getMessage());
        }
    }

    // Agregar producto a la tabla
    private void agregarFila(Producto producto) {

        modeloTabla.addRow(new Object[]{
            producto.getIdProducto(),
            producto.getCodigo(),
            producto.getNombre(),
            producto.getDescripcion(),
            producto.getUnidadMedida(),
            producto.getStockMinimo()
        });
    }

    // Cargar datos al seleccionar una fila
    private void cargarProductoSeleccionado() {

        int fila = tabla.getSelectedRow();

        if (fila < 0) {
            return;
        }

        int filaModelo = tabla.convertRowIndexToModel(fila);

        idProductoSeleccionado = Integer.parseInt(
                modeloTabla.getValueAt(filaModelo, 0).toString()
        );

        txtCodigo.setText(
                modeloTabla.getValueAt(filaModelo, 1).toString()
        );

        txtNombre.setText(
                modeloTabla.getValueAt(filaModelo, 2).toString()
        );

        Object descripcion = modeloTabla.getValueAt(filaModelo, 3);

        txtDescripcion.setText(
                descripcion == null ? "" : descripcion.toString()
        );

        cmbUnidad.setSelectedItem(
                modeloTabla.getValueAt(filaModelo, 4).toString()
        );

        txtStockMinimo.setText(
                modeloTabla.getValueAt(filaModelo, 5).toString()
        );
    }

    // Obtener información del formulario
    private Producto obtenerDatosFormulario() {

        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String unidad = cmbUnidad.getSelectedItem().toString();

        if (txtStockMinimo.getText().trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Ingrese el stock mínimo."
            );
        }

        double stockMinimo;

        try {
            stockMinimo = Double.parseDouble(
                    txtStockMinimo.getText().trim()
            );
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "El stock mínimo debe ser numérico."
            );
        }

        Producto producto = new Producto();

        producto.setCodigo(codigo);
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setUnidadMedida(unidad);
        producto.setStockMinimo(stockMinimo);

        // Categoría y proveedor se incorporarán al conectar sus catálogos.
        producto.setIdCategoria(null);
        producto.setIdProveedor(null);

        return producto;
    }

    // Limpiar formulario
    private void limpiarFormulario() {

        txtCodigo.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtStockMinimo.setText("");

        cmbUnidad.setSelectedIndex(0);

        idProductoSeleccionado = 0;

        tabla.clearSelection();
        txtCodigo.requestFocus();
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Aviso",
                JOptionPane.WARNING_MESSAGE
        );
    }
}
