package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Pestaña de historial de tomas con filtro, detalle, auditoría y exportación. */
public class HistorialInventarioFisicoView extends JPanel {
    private final InventarioFisicoController controller;
    private final PermisosVistaInventario permisos;
    private final PanelFiltrosInventario filtros = new PanelFiltrosInventario();
    private final TablaHistorialModel modelo = new TablaHistorialModel();
    private final JTable tabla = new JTable(modelo);

    public HistorialInventarioFisicoView(InventarioFisicoController controller, PermisosVistaInventario permisos) {
        super(new BorderLayout(10, 10));
        this.controller = controller; this.permisos = permisos;
        setOpaque(false);
        estiloTabla(tabla);
        tabla.setDefaultRenderer(Object.class, rendererTexto());
        tabla.setDefaultRenderer(Integer.class, rendererTexto());
        tabla.getColumnModel().getColumn(2).setCellRenderer(new FechaRenderer());
        tabla.getColumnModel().getColumn(3).setCellRenderer(new FechaRenderer());
        tabla.getColumnModel().getColumn(7).setCellRenderer(new EstadoTomaRenderer());

        JButton ver = botonPrimario("Ver toma seleccionada"), auditoria = botonSecundario("Auditoría"), exportar = botonSecundario("Exportar CSV");
        exportar.setEnabled(permisos.puedeExportar());
        JPanel arriba = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        arriba.setOpaque(false);
        arriba.add(filtros); arriba.add(ver); arriba.add(auditoria); arriba.add(exportar);
        add(arriba, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        filtros.alCambiar(this::cargar);
        ver.addActionListener(e -> abrir(false));
        auditoria.addActionListener(e -> abrir(true));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { if (e.getClickCount() == 2) abrir(false); }
        });
        exportar.addActionListener(e -> {
            try {
                java.io.File f = ExportadorVistaInventario.exportarConDialogo(this, modelo, "historial-inventario-fisico");
                if (f != null) MensajesInventarioFisico.informacion(this, "Archivo guardado en " + f.getAbsolutePath());
            } catch (java.io.IOException ex) { MensajesInventarioFisico.error(this, ex); }
        });
        cargar();
    }

    /** Recarga la lista aplicando los filtros actuales. */
    public final void cargar() {
        String texto = filtros.getTexto(); EstadoToma estado = filtros.getEstado();
        TareaAsincrona.ejecutar(this, () -> controller.listarTomas(texto, estado), modelo::setFilas);
    }

    private void abrir(boolean soloAuditoria) {
        int fila = tabla.getSelectedRow();
        Toma t = fila < 0 ? null : modelo.getToma(tabla.convertRowIndexToModel(fila));
        if (t == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_TOMA_TABLA); return; }
        Window w = SwingUtilities.getWindowAncestor(this);
        if (soloAuditoria) new AuditoriaTomaDialog(w, controller, t.id()).setVisible(true);
        else new DetalleTomaInventarioDialog(w, controller, t.id()).setVisible(true);
    }
}
