package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/**
 * Ventana principal del módulo de inventario físico. Reúne las pestañas Resumen, Conciliación,
 * Historial y Reportes. No contiene SQL ni modifica existencias o costos: todo pasa por el controlador.
 */
public class InventarioFisicoView extends JFrame {
    private final InventarioFisicoController controller;
    private final PermisosVistaInventario permisos;
    private final JTabbedPane tabs = new JTabbedPane();
    private final PanelResumenInventario resumen = new PanelResumenInventario();
    private final PanelFiltrosInventario filtros = new PanelFiltrosInventario();
    private final TablaTomasModel modelo = new TablaTomasModel();
    private final JTable tabla = new JTable(modelo);
    private final ConciliacionInventarioView conciliacion;
    private final HistorialInventarioFisicoView historial;
    private final ReporteInventarioFisicoView reporte;
    private final JLabel estado = new JLabel("Listo");

    /** Punto de integración con la ventana principal; abre con perfil administrador. */
    public InventarioFisicoView(InventarioFisicoController controller) {
        this(controller, PermisosVistaInventario.administrador());
    }

    public InventarioFisicoView(InventarioFisicoController controller, PermisosVistaInventario permisos) {
        this.controller = java.util.Objects.requireNonNull(controller, "El controlador es obligatorio.");
        this.permisos = java.util.Objects.requireNonNull(permisos, "Los permisos son obligatorios.");
        setTitle("Sistema de Inventario · Inventario físico");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(1120, 720));
        setSize(1380, 850);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        conciliacion = new ConciliacionInventarioView(controller, permisos, this::refrescarTodo);
        historial = new HistorialInventarioFisicoView(controller, permisos);
        reporte = new ReporteInventarioFisicoView(controller, permisos);

        add(new PanelEncabezadoModulo("INVENTARIO FÍSICO", "Conteo, conciliación y control de diferencias por almacén",
                "Usuario: sesión autenticada · " + permisos.descripcion(), "Los permisos se validan también en el servicio"), BorderLayout.NORTH);
        tabs.setBorder(new EmptyBorder(12, 18, 8, 18));
        tabs.setFont(tabs.getFont().deriveFont(Font.BOLD, 13f));
        tabs.addTab("Resumen", construirResumen());
        tabs.addTab("Conciliación", conciliacion);
        tabs.addTab("Historial", historial);
        tabs.addTab("Reportes", reporte);
        add(tabs, BorderLayout.CENTER);
        add(construirBarraEstado(), BorderLayout.SOUTH);
        refrescarTodo();
    }

    private JComponent construirResumen() {
        JPanel raiz = new JPanel(new BorderLayout(12, 12));
        raiz.setOpaque(false);
        JPanel norte = new JPanel(new BorderLayout(10, 12));
        norte.setOpaque(false);
        norte.add(resumen, BorderLayout.NORTH);
        norte.add(new PanelAccionesInventario(new PanelAccionesInventario.Acciones() {
            @Override public void nuevaToma() { abrirNuevaToma(); }
            @Override public void registrarConteo() { conSeleccion(InventarioFisicoView.this::abrirConteo); }
            @Override public void conciliar() { conSeleccion(InventarioFisicoView.this::irAConciliacion); }
            @Override public void verDetalles() { conSeleccion(InventarioFisicoView.this::abrirDetalle); }
            @Override public void historial() { tabs.setSelectedIndex(2); }
            @Override public void reporte() { tabs.setSelectedIndex(3); }
        }, permisos), BorderLayout.SOUTH);
        raiz.add(norte, BorderLayout.NORTH);

        estiloTabla(tabla);
        tabla.setDefaultRenderer(Object.class, rendererTexto());
        tabla.setDefaultRenderer(Integer.class, rendererTexto());
        tabla.getColumnModel().getColumn(2).setCellRenderer(new FechaRenderer());
        tabla.getColumnModel().getColumn(8).setCellRenderer(new EstadoTomaRenderer());
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { if (e.getClickCount() == 2) conSeleccion(InventarioFisicoView.this::abrirDetalle); }
        });
        JPanel caja = tarjeta(new BorderLayout(8, 8));
        JLabel titulo = new JLabel("Tomas físicas");
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 15f));
        titulo.setForeground(TEXT);
        JPanel cabecera = new JPanel(new BorderLayout(0, 8));
        cabecera.setOpaque(false);
        cabecera.add(titulo, BorderLayout.NORTH);
        cabecera.add(filtros, BorderLayout.SOUTH);
        caja.add(cabecera, BorderLayout.NORTH);
        caja.add(new JScrollPane(tabla), BorderLayout.CENTER);
        raiz.add(caja, BorderLayout.CENTER);
        filtros.alCambiar(this::cargarTomas);
        return raiz;
    }

    private JComponent construirBarraEstado() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDE));
        estado.setBorder(new EmptyBorder(7, 18, 7, 18));
        estado.setForeground(MUTED);
        estado.setFont(estado.getFont().deriveFont(11f));
        p.add(estado, BorderLayout.CENTER);
        return p;
    }

    // ---- Datos ----
    /** Recarga todas las pestañas; se invoca después de cualquier cambio. */
    public void refrescarTodo() {
        TareaAsincrona.ejecutar(this, controller::obtenerResumen, resumen::actualizar);
        cargarTomas();
        historial.cargar();
        conciliacion.recargarTomas();
        reporte.cargar();
    }

    private void cargarTomas() {
        String texto = filtros.getTexto(); EstadoToma e = filtros.getEstado();
        estado.setText("Cargando tomas...");
        TareaAsincrona.ejecutar(this, () -> controller.listarTomas(texto, e), lista -> {
            modelo.setFilas(lista);
            estado.setText("Tomas encontradas: " + lista.size());
        });
    }

    // ---- Acciones ----
    private Toma tomaSeleccionada() {
        int fila = tabla.getSelectedRow();
        return fila < 0 ? null : modelo.getToma(tabla.convertRowIndexToModel(fila));
    }

    private void conSeleccion(java.util.function.LongConsumer accion) {
        Toma t = tomaSeleccionada();
        if (t == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_TOMA_TABLA); return; }
        accion.accept(t.id());
    }

    private void abrirNuevaToma() {
        new NuevaTomaInventarioDialog(this, controller, t -> { refrescarTodo(); abrirConteo(t.id()); }).setVisible(true);
    }

    private void abrirConteo(long idToma) {
        new RegistroConteoView(this, controller, idToma, permisos, this::refrescarTodo, () -> irAConciliacion(idToma)).setVisible(true);
    }

    private void abrirDetalle(long idToma) { new DetalleTomaInventarioDialog(this, controller, idToma).setVisible(true); }

    private void irAConciliacion(long idToma) {
        tabs.setSelectedIndex(1);
        conciliacion.seleccionarToma(idToma);
    }
}
