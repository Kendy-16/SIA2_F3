
package pe.edu.inventario.enums;

import java.util.Locale;

/**
 * Defines the allowed states of an inventory movement.
 */
public enum EstadoMovimiento {

    REGISTRADO("Registrado"),
    ANULADO("Anulado");

    // ==========================================
    // 1. ATTRIBUTES
    // ==========================================

    private final String descripcion;

    // ==========================================
    // 2. CONSTRUCTOR
    // ==========================================

    private EstadoMovimiento(String descripcion) {

        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "La descripcion del estado es obligatoria."
            );
        }

        this.descripcion = descripcion.trim();
    }

    // ==========================================
    // 3. GET DESCRIPTION
    // ==========================================

    public String getDescripcion() {
        return descripcion;
    }

    // ==========================================
    // 4. GET DATABASE CODE
    // ==========================================

    public String getCodigo() {
        return name();
    }

    // ==========================================
    // 5. CONVERT TEXT TO ENUM
    // ==========================================

    public static EstadoMovimiento desdeValor(String valor) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    "El estado del movimiento no puede ser nulo."
            );
        }

        String normalizado = valor.trim();

        if (normalizado.isEmpty()) {
            throw new IllegalArgumentException(
                    "Debe seleccionar un estado de movimiento."
            );
        }

        normalizado = normalizado.toUpperCase(Locale.ROOT);

        for (EstadoMovimiento estado : values()) {

            if (estado.name().equals(normalizado)
                    || estado.descripcion.equalsIgnoreCase(normalizado)) {

                return estado;
            }
        }

        throw new IllegalArgumentException(
                "Estado no valido. Use REGISTRADO o ANULADO."
        );
    }

    // ==========================================
    // 6. CHECK REGISTERED STATE
    // ==========================================

    public boolean esRegistrado() {
        return this == REGISTRADO;
    }

    // ==========================================
    // 7. CHECK CANCELLED STATE
    // ==========================================

    public boolean esAnulado() {
        return this == ANULADO;
    }

    // ==========================================
    // 8. CHECK IF MOVEMENT CAN BE CANCELLED
    // ==========================================

    public boolean puedeAnularse() {
        return this == REGISTRADO;
    }

    // ==========================================
    // 9. CHECK FINAL STATE
    // ==========================================

    public boolean esEstadoFinal() {
        return this == ANULADO;
    }

    // ==========================================
    // 10. VALIDATE TEXT WITHOUT THROWING EXCEPTION
    // ==========================================

    public static boolean esValido(String valor) {

        try {
            desdeValor(valor);
            return true;

        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // ==========================================
    // 11. DISPLAY DESCRIPTION IN SWING
    // ==========================================

    @Override
    public String toString() {
        return descripcion;
    }
}
