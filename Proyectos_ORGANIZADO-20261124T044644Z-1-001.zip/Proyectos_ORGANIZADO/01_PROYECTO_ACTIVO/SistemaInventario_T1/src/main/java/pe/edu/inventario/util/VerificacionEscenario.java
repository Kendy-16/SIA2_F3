package pe.edu.inventario.util;

import pe.edu.inventario.controlador.MovimientoController;
import pe.edu.inventario.migracion.AdministradorMigraciones;
import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.modelo.dao.ReporteDAO;
import pe.edu.inventario.servicio.LoginService;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

/**
 * Verificación del escenario de prueba T1 (casos C01 a C12).
 * Invoca controlador, servicio, DAO y reportes (las mismas clases que la interfaz).
 *
 * IMPORTANTE: crea su propia base. Ejecútelo desde una CARPETA VACÍA:
 *   cd carpeta_vacia
 *   java -cp RUTA\\target\\classes;sqlite-jdbc.jar;slf4j-api.jar pe.edu.inventario.util.VerificacionEscenario RUTA\\database\\datos_prueba.sql
 * Si ya existe database/inventario.db en la carpeta actual, se niega a ejecutar.
 */
public class VerificacionEscenario {
  static List<String> out = new ArrayList<>();
  static void r(String cod, String res, boolean ok){ out.add(cod+"|"+(ok?"OK":"FALLA")+"|"+res); }
  static double q(String s) throws Exception { try(Connection c=ConexionDB.conectar();Statement st=c.createStatement();ResultSet rs=st.executeQuery(s)){return rs.next()?rs.getDouble(1):Double.NaN;} }
  static void x(String s) throws Exception { try(Connection c=ConexionDB.conectar();Statement st=c.createStatement()){st.executeUpdate(s);} }
  static boolean near(double a,double b,double t){return Math.abs(a-b)<=t;}
  static String kd(String doc) throws Exception {
    try(Connection c=ConexionDB.conectar();Statement st=c.createStatement();ResultSet rs=st.executeQuery("select entrada,salida,saldo,costo_unitario,costo_promedio,valor_saldo from kardex where documento='"+doc+"'")){
      rs.next(); return String.format(Locale.ROOT,"entrada=%.0f salida=%.0f saldo=%.0f costo_unit=%.6f CP=%.6f valor=%.2f",rs.getDouble(1),rs.getDouble(2),rs.getDouble(3),rs.getDouble(4),rs.getDouble(5),rs.getDouble(6)); } }
  static String ig(String doc) throws Exception { return String.format(Locale.ROOT,"%.2f", q("select d.igv_monto from detalle_movimientos d join movimientos m on m.id_movimiento=d.id_movimiento where m.documento='"+doc+"'")); }
  public static void main(String[] a) throws Exception {
    if (a.length < 1 || Files.exists(Path.of("database/inventario.db"))) {
      System.err.println("Uso: ejecutar desde una carpeta vacía (sin database/inventario.db) pasando la ruta de datos_prueba.sql");
      System.exit(2);
    }
    ConexionDB.inicializar(); AdministradorMigraciones.ejecutar();
    String sql = Files.readString(Path.of(a[0]));
    for (String s : sql.split(";\\s*\\n")) { String t=s.replaceAll("(?m)^\\s*--.*$","").trim(); if(!t.isEmpty()) x(t); }
    // C01
    LoginService ls = new LoginService();
    ls.registrarPrimerAdministrador("admin.demo","ClaveSegura#2026".toCharArray());
    boolean auth = ls.verificarCredenciales("admin.demo","ClaveSegura#2026");
    String rol = ls.obtenerRol("admin.demo");
    r("C01","autenticado="+auth+"; rol="+rol, auth && "ADMINISTRADOR".equals(rol));
    MovimientoController adm = new MovimientoController("ADMINISTRADOR");
    // C02
    adm.registrarMovimientoEntrada(1,1,"FAC-001",100,11.80,true,0.18,"Compra");
    r("C02", kd("FAC-001")+"; IGV línea="+ig("FAC-001"), near(q("select valor_saldo from kardex where documento='FAC-001'"),1000,0.005)&&near(q("select igv_monto from detalle_movimientos limit 1"),180,0.005));
    adm.registrarMovimientoEntrada(1,1,"FAC-002",50,14.16,true,0.18,"Compra");
    r("C03", kd("FAC-002")+"; IGV línea="+ig("FAC-002"), near(q("select costo_promedio from kardex where documento='FAC-002'"),10.666667,1e-6)&&near(q("select valor_saldo from kardex where documento='FAC-002'"),1600,0.005));
    adm.registrarMovimientoSalida(1,1,"BV-001",80,15.00,false,0.18,"Venta");
    r("C04", kd("BV-001")+"; IGV débito="+ig("BV-001"), near(q("select saldo from kardex where documento='BV-001'"),70,1e-9)&&near(q("select valor_saldo from kardex where documento='BV-001'"),746.67,0.005));
    adm.registrarMovimientoEntrada(1,1,"FAC-003",30,13.00,false,0.18,"Compra");
    r("C05", kd("FAC-003")+"; IGV línea="+ig("FAC-003"), near(q("select costo_promedio from kardex where documento='FAC-003'"),11.366667,1e-6)&&near(q("select valor_saldo from kardex where documento='FAC-003'"),1136.67,0.005));
    adm.registrarMovimientoSalida(1,1,"BV-002",40,23.60,true,0.18,"Venta");
    r("C06", kd("BV-002")+"; IGV débito="+ig("BV-002"), near(q("select saldo from kardex where documento='BV-002'"),60,1e-9)&&near(q("select valor_saldo from kardex where documento='BV-002'"),682.00,0.005));
    // C07
    double filas0=q("select count(*) from kardex"); String msg="(sin error)";
    try{ adm.registrarMovimientoSalida(1,1,"BV-003",100,15.00,false,0.18,"x"); }catch(Throwable t){ msg=t.getMessage(); }
    r("C07","mensaje: "+msg+"; stock="+(int)q("select cantidad from inventario")+"; filas kardex antes/después="+(int)filas0+"/"+(int)q("select count(*) from kardex"), !msg.equals("(sin error)")&&filas0==q("select count(*) from kardex")&&q("select cantidad from inventario")==60);
    // C08
    String m1="(sin error)",m2="(sin error)",m3="(sin error)";
    try{ adm.registrarMovimientoEntrada(1,1,"FAC-009",10,-5,false,0.18,"x"); }catch(Throwable t){ m1=t.getMessage(); }
    try{ adm.registrarMovimientoEntrada(999,1,"FAC-010",10,5,false,0.18,"x"); }catch(Throwable t){ m2=t.getMessage(); }
    try{ adm.registrarMovimientoEntrada(1,999,"FAC-011",10,5,false,0.18,"x"); }catch(Throwable t){ m3=t.getMessage(); }
    r("C08","costo negativo: "+m1+" | producto inexistente: "+m2+" | almacén inexistente: "+m3+"; filas kardex="+(int)q("select count(*) from kardex"), !m1.equals("(sin error)")&&!m2.equals("(sin error)")&&!m3.equals("(sin error)")&&q("select count(*) from kardex")==5);
    // C12 (antes del ajuste)
    ReporteDAO rd = new ReporteDAO();
    StringBuilder sb=new StringBuilder();
    for(Object[] f: rd.inventarioValorizado()) sb.append("valorizado="+Arrays.toString(f)+"; ");
    for(Object[] f: rd.utilidadBruta()) sb.append("utilidad="+Arrays.toString(f)+"; ");
    for(Object[] f: rd.resumenIgv()) sb.append("igv="+Arrays.toString(f)+"; ");
    r("C12", sb.toString(), true);
    // C09
    String sinJust="(sin error)";
    try{ adm.registrarMovimientoAjuste(1,1,"AJ-000",58,""); }catch(Throwable t){ sinJust=t.getMessage(); }
    boolean aj=adm.registrarMovimientoAjuste(1,1,"AJ-001",58,"Conteo físico: faltan 2 unidades");
    r("C09","sin justificación: "+sinJust+"; con justificación: "+kd("AJ-001"), !sinJust.equals("(sin error)")&&aj&&near(q("select valor_saldo from kardex where documento='AJ-001'"),659.27,0.005));
    // C10
    x("INSERT INTO tomas_inventario_fisico(id_almacen,modo,estado) VALUES (1,'GENERAL','ABIERTO')");
    String m10="(sin error)";
    try{ adm.registrarMovimientoEntrada(1,1,"FAC-012",10,5,false,0.18,"x"); }catch(Throwable t){ m10=t.getMessage(); }
    x("UPDATE tomas_inventario_fisico SET estado='ANULADO'");
    r("C10","con toma abierta: "+m10, !m10.equals("(sin error)"));
    // C11
    String m11="(sin error)";
    try{ new MovimientoController("USUARIO").registrarMovimientoEntrada(1,1,"FAC-013",10,5,false,0.18,"x"); }catch(Throwable t){ m11=t.getClass().getSimpleName()+": "+t.getMessage(); }
    r("C11","rol USUARIO: "+m11, !m11.equals("(sin error)"));
    // kardex final
    try(Connection c=ConexionDB.conectar();Statement st=c.createStatement();ResultSet rs=st.executeQuery("select documento,tipo,entrada,salida,costo_unitario,costo_promedio,saldo,valor_saldo from kardex order by id_kardex")){
      while(rs.next()) out.add(String.format(Locale.ROOT,"K|%s|%s|%.0f|%.0f|%.6f|%.6f|%.0f|%.2f",rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getDouble(4),rs.getDouble(5),rs.getDouble(6),rs.getDouble(7),rs.getDouble(8))); }
    out.forEach(System.out::println);
  }
}