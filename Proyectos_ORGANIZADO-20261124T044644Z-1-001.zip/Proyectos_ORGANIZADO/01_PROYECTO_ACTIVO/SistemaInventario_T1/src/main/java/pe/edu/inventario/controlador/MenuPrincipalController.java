package pe.edu.inventario.controlador;

import pe.edu.inventario.vista.producto.ProductoView;
import pe.edu.inventario.vista.producto.CategoriaView;
import pe.edu.inventario.vista.producto.ProveedorView;

import javax.swing.JPanel;

public class MenuPrincipalController {

    // Constructor
    public MenuPrincipalController() {
    }

    // Open product management
    public JPanel abrirGestionProductos() {
        return new ProductoView();
    }

    // Open category management
    public JPanel abrirGestionCategorias() {
        return new CategoriaView();
    }

    // Open supplier management
    public JPanel abrirGestionProveedores() {
        return new ProveedorView();
    }
}