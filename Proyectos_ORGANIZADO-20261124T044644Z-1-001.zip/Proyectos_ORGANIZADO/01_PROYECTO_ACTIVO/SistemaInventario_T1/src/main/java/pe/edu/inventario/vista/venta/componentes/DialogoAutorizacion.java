package pe.edu.inventario.vista.venta.componentes;

import javax.swing.*;
import java.awt.*;

/**
 * Este diálogo salta cuando se requiere credencial de Administrador 
 * en medio de una operación de un Cajero/Usuario normal.
 */
public class DialogoAutorizacion extends JDialog {
    
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnAutorizar;
    private JButton btnCancelar;
    private boolean autorizado = false;
    private String idAdminAutorizador = null;

    public DialogoAutorizacion(Frame parent, String accionRequerida) {
        super(parent, "Autorización Requerida", true); // Modal
        setLayout(new GridLayout(4, 1, 10, 10));
        setSize(300, 200);
        setLocationRelativeTo(parent);

        add(new JLabel("Acción: " + accionRequerida, SwingConstants.CENTER));

        JPanel panelUser = new JPanel(new FlowLayout());
        panelUser.add(new JLabel("Usuario Admin:"));
        txtUsuario = new JTextField(12);
        panelUser.add(txtUsuario);

        JPanel panelPass = new JPanel(new FlowLayout());
        panelPass.add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField(12);
        panelPass.add(txtPassword);

        JPanel panelBotones = new JPanel(new FlowLayout());
        btnAutorizar = new JButton("Autorizar");
        btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnAutorizar);
        panelBotones.add(btnCancelar);

        add(panelUser);
        add(panelPass);
        add(panelBotones);

        // Eventos
        btnAutorizar.addActionListener(e -> validarCredenciales());
        btnCancelar.addActionListener(e -> dispose());
    }

    private void validarCredenciales() {
        String user = txtUsuario.getText();
        String pass = new String(txtPassword.getPassword());
        
        // Aquí llamaríamos a SeguridadService para validar user/pass y obtener el Rol
        // Simulamos validación exitosa de un administrador:
        if (user.equals("admin") && pass.equals("1234")) {
            this.autorizado = true;
            this.idAdminAutorizador = user; // Guardar quién autorizó
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas o sin privilegios.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isAutorizado() { return autorizado; }
    public String getIdAdminAutorizador() { return idAdminAutorizador; }
}
