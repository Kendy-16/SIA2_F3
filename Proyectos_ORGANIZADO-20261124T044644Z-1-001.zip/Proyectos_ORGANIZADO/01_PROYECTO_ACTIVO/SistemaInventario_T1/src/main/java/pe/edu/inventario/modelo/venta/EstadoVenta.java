package pe.edu.inventario.modelo.venta;

/** Estados posibles de una venta. */
public enum EstadoVenta {
    /** Venta en construcción en la pantalla (aún no cobrada). */
    EN_PROCESO,
    /** Venta cobrada y registrada en Caja y Kardex. */
    COMPLETADA,
    /** Venta anulada por un administrador (stock y dinero revertidos). */
    ANULADA,
    /** Estado de la versión anterior del módulo; se mantiene por compatibilidad. */
    EMITIDA
}
