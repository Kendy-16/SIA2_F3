package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Filas del panel principal: una toma por fila. */
public class TablaTomasModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"Código", "Almacén", "Inicio", "Responsable", "Productos", "Contados", "Diferencias", "Avance", "Estado"};
    private List<Toma> filas = new ArrayList<>();

    public void setFilas(List<Toma> nuevas) { filas = new ArrayList<>(nuevas); fireTableDataChanged(); }
    public Toma getToma(int fila) { return fila < 0 || fila >= filas.size() ? null : filas.get(fila); }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) {
        return switch (c) { case 2 -> LocalDateTime.class; case 4, 5, 6 -> Integer.class; case 8 -> EstadoToma.class; default -> String.class; };
    }
    @Override public Object getValueAt(int r, int c) {
        Toma t = filas.get(r);
        return switch (c) {
            case 0 -> t.codigo(); case 1 -> t.almacen(); case 2 -> t.fechaInicio(); case 3 -> t.responsable();
            case 4 -> t.totalProductos(); case 5 -> t.productosContados(); case 6 -> t.productosDiferencia();
            case 7 -> t.avancePorcentaje() + "%"; default -> t.estado();
        };
    }
}
