package pe.edu.inventario.vista.venta;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.modelo.venta.TipoVenta;

import javax.swing.*;
import java.awt.*;

/**
 * Requisito 3.2: VENTA MAYORISTA
 * Difiere de la normal porque exige un cliente registrado, aplica el precio por volumen
 * (con cantidad mínima por producto) e incluye el selector de "Condición Mayorista".
 */
public class VentaMayoristaView extends VentaBaseView {

    private final JComboBox<String> cbCondicionMayorista; // Extra para Mayoristas

    public VentaMayoristaView(VentaController controller, RolUsuario rol, String idUsuario) {
        super(controller, TipoVenta.MAYORISTA, rol, idUsuario, "Generar Venta Mayorista (F12)");

        // Componente exclusivo de Mayorista, se inserta arriba de los paneles comunes
        JPanel panelCondicion = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelCondicion.add(new JLabel("Condición Mayorista:"));
        cbCondicionMayorista = new JComboBox<>(new String[]{"Volumen Estándar", "Distribuidor Autorizado"});
        panelCondicion.add(cbCondicionMayorista);
        panelSuperior.add(panelCondicion, 0);
    }

    public String getCondicionMayorista() {
        return (String) cbCondicionMayorista.getSelectedItem();
    }
}
