
package pe.edu.inventario.controlador;

import pe.edu.inventario.modelo.Producto;
import pe.edu.inventario.servicio.ProductoService;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Controlador encargado de gestionar las operaciones de productos.
 */
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController() {
        this.productoService = new ProductoService();
    }

    // Registrar un producto
    public boolean registrarProducto(Producto producto)
            throws SQLException {

        return productoService.registrar(producto);
    }

    // Obtener todos los productos
    public ArrayList<Producto> listarProductos()
            throws SQLException {

        return productoService.listar();
    }

    // Buscar un producto por código
    public Producto buscarProducto(String codigo)
            throws SQLException {

        return productoService.buscarPorCodigo(codigo);
    }

    // Actualizar un producto
    public boolean actualizarProducto(Producto producto)
            throws SQLException {

        return productoService.actualizar(producto);
    }

    // Eliminar un producto
    public boolean eliminarProducto(int idProducto)
            throws SQLException {

        return productoService.eliminar(idProducto);
    }
}
