package pe.edu.inventario.servicio.cliente;

import java.util.HashMap;
import java.util.Map;

/**
 * Registro de clientes en memoria (documento -> nombre o razón social).
 * El documento "00000000" es el cliente genérico "Público en general" de la venta normal.
 */
public class ClienteService {

    public static final String CLIENTE_GENERICO = "00000000";

    private final Map<String, String> clientes = new HashMap<>();

    public ClienteService() {
        clientes.put(CLIENTE_GENERICO, "Público en general");
    }

    public void registrar(String documento, String nombre) {
        clientes.put(documento, nombre);
    }

    /** @return el nombre del cliente, o null si el documento no está registrado. */
    public String buscarNombre(String documento) {
        return documento == null ? null : clientes.get(documento.trim());
    }

    public boolean esGenerico(String documento) {
        return CLIENTE_GENERICO.equals(documento);
    }
}
