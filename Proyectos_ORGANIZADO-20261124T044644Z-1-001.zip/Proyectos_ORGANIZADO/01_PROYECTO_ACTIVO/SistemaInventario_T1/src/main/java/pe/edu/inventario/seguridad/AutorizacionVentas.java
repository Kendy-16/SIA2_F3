package pe.edu.inventario.seguridad;

import pe.edu.inventario.modelo.venta.RolUsuario;

/** Reglas de autorización del módulo de ventas. (Clase de apoyo) */
public final class AutorizacionVentas {
    private AutorizacionVentas() {}

    private static boolean esAdmin(RolUsuario r) { return r == RolUsuario.ADMINISTRADOR; }

    /** Requisito 4: solo el administrador aplica descuentos manuales. */
    public static boolean puedeAplicarDescuentoManual(RolUsuario r) { return esAdmin(r); }
    /** Requisito 12: solo el administrador anula ventas. */
    public static boolean puedeAnularVenta(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeModificarPrecio(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeAutorizarDescuentoEspecial(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeAutorizarAnulacion(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeAutorizarDevolucion(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeVerCostosYGanancias(RolUsuario r) { return esAdmin(r); }
    public static boolean puedeVerAuditoria(RolUsuario r) { return esAdmin(r); }
}
