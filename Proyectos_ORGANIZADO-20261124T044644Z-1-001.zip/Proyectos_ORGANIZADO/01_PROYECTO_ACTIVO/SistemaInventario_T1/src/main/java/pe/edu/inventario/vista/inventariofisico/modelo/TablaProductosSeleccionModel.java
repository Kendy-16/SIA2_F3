package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Productos que se pueden incluir en una toma; la columna "Seleccionar" es editable y actualiza el conjunto al instante. */
public class TablaProductosSeleccionModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"Seleccionar", "Código", "Producto", "Categoría", "Unidad", "Stock"};
    private List<Producto> filas = new ArrayList<>();
    private final Set<Long> seleccionados;

    /** @param seleccionados conjunto de ids marcados (se modifica directamente). */
    public TablaProductosSeleccionModel(Set<Long> seleccionados) { this.seleccionados = seleccionados; }

    public void setFilas(List<Producto> nuevas) { filas = new ArrayList<>(nuevas); fireTableDataChanged(); }
    public Producto getProducto(int fila) { return filas.get(fila); }
    public Set<Long> getSeleccionados() { return seleccionados; }

    public void marcarVisibles(boolean marcar) {
        for (Producto p : filas) { if (marcar) seleccionados.add(p.id()); else seleccionados.remove(p.id()); }
        fireTableDataChanged();
    }

    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) { return c == 0 ? Boolean.class : c == 5 ? BigDecimal.class : String.class; }
    @Override public boolean isCellEditable(int r, int c) { return c == 0; }
    @Override public void setValueAt(Object v, int r, int c) {
        if (c != 0) return;
        long id = filas.get(r).id();
        if (Boolean.TRUE.equals(v)) seleccionados.add(id); else seleccionados.remove(id);
        fireTableCellUpdated(r, c);
    }
    @Override public Object getValueAt(int r, int c) {
        Producto p = filas.get(r);
        return switch (c) {
            case 0 -> seleccionados.contains(p.id()); case 1 -> p.codigo(); case 2 -> p.nombre();
            case 3 -> p.categoria(); case 4 -> p.unidad(); default -> p.stockSistema();
        };
    }
}
