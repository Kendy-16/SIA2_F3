
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.Kardex;
import pe.edu.inventario.modelo.ConexionDB;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Objects;

public class KardexDAO {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final String COLUMNAS =
            "id_kardex, " +
            "id_producto, " +
            "id_almacen, " +
            "fecha, " +
            "tipo, " +
            "documento, " +
            "entrada, " +
            "salida, " +
            "saldo, " +
            "costo_unitario, " +
            "costo_promedio, " +
            "valor_saldo";

    private static final int TIEMPO_MAXIMO_CONSULTA = 30;

    // ==========================================
    // 2. CONSULTAR POR PRODUCTO
    // ==========================================

    public ArrayList<Kardex> listarPorProducto(
            int idProducto
    ) throws SQLException {

        validarIdProducto(idProducto);

        return consultar(
                idProducto,
                null,
                null,
                null
        );
    }

    // ==========================================
    // 3. CONSULTAR POR PRODUCTO Y ALMACEN
    // ==========================================

    public ArrayList<Kardex> listarPorProductoYAlmacen(
            int idProducto,
            int idAlmacen
    ) throws SQLException {

        validarIdProducto(idProducto);
        validarIdAlmacen(idAlmacen);

        return consultar(
                idProducto,
                idAlmacen,
                null,
                null
        );
    }

    // ==========================================
    // 4. CONSULTAR POR PERIODO
    // ==========================================

    public ArrayList<Kardex> listarPorPeriodo(
            int idProducto,
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) throws SQLException {

        validarIdProducto(idProducto);

        if (idAlmacen != null) {
            validarIdAlmacen(idAlmacen);
        }

        validarPeriodo(fechaDesde, fechaHasta);

        return consultar(
                idProducto,
                idAlmacen,
                fechaDesde,
                fechaHasta
        );
    }

    // ==========================================
    // 5. CONSULTA GENERAL CON FILTROS
    // ==========================================

    private ArrayList<Kardex> consultar(
            int idProducto,
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) throws SQLException {

        ArrayList<Kardex> registros = new ArrayList<>();

        String sql = construirConsulta(
                idAlmacen,
                fechaDesde,
                fechaHasta
        );

        try (Connection conexion = ConexionDB.conectar()) {

            if (conexion == null || conexion.isClosed()) {
                throw new SQLException(
                        "No se pudo establecer la conexion con SQLite."
                );
            }

            // Verify that the requested product exists.
            verificarProducto(conexion, idProducto);

            // Verify the warehouse only when it is filtered.
            if (idAlmacen != null) {
                verificarAlmacen(conexion, idAlmacen);
            }

            try (PreparedStatement sentencia =
                         conexion.prepareStatement(sql)) {

                sentencia.setQueryTimeout(
                        TIEMPO_MAXIMO_CONSULTA
                );

                int posicion = 1;

                sentencia.setInt(
                        posicion++,
                        idProducto
                );

                if (idAlmacen != null) {

                    sentencia.setInt(
                            posicion++,
                            idAlmacen
                    );
                }

                if (fechaDesde != null) {

                    sentencia.setString(
                            posicion++,
                            fechaDesde.toString()
                    );
                }

                if (fechaHasta != null) {

                    sentencia.setString(
                            posicion,
                            fechaHasta.toString()
                    );
                }

                try (ResultSet resultado =
                             sentencia.executeQuery()) {

                    while (resultado.next()) {

                        Kardex kardex =
                                mapearKardex(resultado);

                        registros.add(kardex);
                    }
                }
            }

        } catch (SQLException ex) {

            throw traducirError(ex);
        }

        return registros;
    }

    // ==========================================
    // 6. CONSTRUIR CONSULTA SQL
    // ==========================================

    private String construirConsulta(
            Integer idAlmacen,
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) {

        StringBuilder sql = new StringBuilder();

        sql.append("SELECT ");
        sql.append(COLUMNAS);
        sql.append(" FROM kardex ");
        sql.append(" WHERE id_producto = ? ");

        if (idAlmacen != null) {
            sql.append(" AND id_almacen = ? ");
        }

        if (fechaDesde != null) {
            sql.append(" AND date(fecha) >= date(?) ");
        }

        if (fechaHasta != null) {
            sql.append(" AND date(fecha) <= date(?) ");
        }

        sql.append(
                " ORDER BY fecha ASC, id_kardex ASC"
        );

        return sql.toString();
    }

    // ==========================================
    // 7. VERIFICAR PRODUCTO
    // ==========================================

    private void verificarProducto(
            Connection conexion,
            int idProducto
    ) throws SQLException {

        String sql =
                "SELECT 1 " +
                "FROM productos " +
                "WHERE id_producto = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idProducto);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {

                    throw new SQLException(
                            "El producto seleccionado no existe."
                    );
                }
            }
        }
    }

    // ==========================================
    // 8. VERIFICAR ALMACEN
    // ==========================================

    private void verificarAlmacen(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT 1 " +
                "FROM almacenes " +
                "WHERE id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {

                    throw new SQLException(
                            "El almacen seleccionado no existe."
                    );
                }
            }
        }
    }

    // ==========================================
    // 9. MAPEAR RESULTADO A OBJETO KARDEX
    // ==========================================

    private Kardex mapearKardex(
            ResultSet resultado
    ) throws SQLException {

        int idKardex =
                resultado.getInt("id_kardex");

        int idProducto =
                resultado.getInt("id_producto");

        int idAlmacen =
                resultado.getInt("id_almacen");

        String fecha =
                resultado.getString("fecha");

        String tipo =
                resultado.getString("tipo");

        String documento =
                resultado.getString("documento");

        try {

            return new Kardex(

                    idKardex,

                    idProducto,

                    idAlmacen,

                    fecha,

                    tipo,

                    documento,

                    obtenerDecimal(resultado, "entrada"),

                    obtenerDecimal(resultado, "salida"),

                    obtenerDecimal(resultado, "saldo"),

                    obtenerDecimal(resultado, "costo_unitario"),

                    obtenerDecimal(resultado, "costo_promedio"),

                    obtenerDecimal(resultado, "valor_saldo")
            );

        } catch (IllegalArgumentException ex) {

            throw new SQLException(
                    "Registro de kardex inconsistente. ID: "
                            + idKardex + ". " + ex.getMessage(),
                    ex
            );
        }
    }

    // ==========================================
    // 10. OBTENER DECIMALES DE SQLITE
    // ==========================================

    private BigDecimal obtenerDecimal(
            ResultSet resultado,
            String columna
    ) throws SQLException {

        String valor = resultado.getString(columna);

        if (valor == null || valor.isBlank()) {

            throw new SQLException(
                    "El campo numerico " + columna +
                    " no puede ser nulo o vacio."
            );
        }

        try {

            BigDecimal decimal = new BigDecimal(valor);

            if (decimal.signum() < 0
                    && !columna.equals("entrada")
                    && !columna.equals("salida")) {

                throw new SQLException(
                        "El campo " + columna +
                        " contiene un valor negativo."
                );
            }

            return decimal;

        } catch (NumberFormatException ex) {

            throw new SQLException(
                    "El campo " + columna +
                    " contiene un valor numerico invalido.",
                    ex
            );
        }
    }

    // ==========================================
    // 11. VALIDAR ID DE PRODUCTO
    // ==========================================

    private void validarIdProducto(int idProducto) {

        if (idProducto <= 0) {

            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }
    }

    // ==========================================
    // 12. VALIDAR ID DE ALMACEN
    // ==========================================

    private void validarIdAlmacen(int idAlmacen) {

        if (idAlmacen <= 0) {

            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // 13. VALIDAR PERIODO
    // ==========================================

    private void validarPeriodo(
            LocalDate fechaDesde,
            LocalDate fechaHasta
    ) {

        if (fechaDesde == null || fechaHasta == null) {

            throw new IllegalArgumentException(
                    "Debe especificar las dos fechas."
            );
        }

        try {

            LocalDate fechaInicial =
                    LocalDate.parse(fechaDesde.toString());

            LocalDate fechaFinal =
                    LocalDate.parse(fechaHasta.toString());

            if (fechaInicial.isAfter(fechaFinal)) {

                throw new IllegalArgumentException(
                        "La fecha inicial no puede ser posterior a la fecha final."
                );
            }

        } catch (DateTimeParseException ex) {

            throw new IllegalArgumentException(
                    "El periodo contiene fechas invalidas.",
                    ex
            );
        }
    }

    // ==========================================
    // 14. TRADUCIR ERRORES SQL
    // ==========================================

    private SQLException traducirError(SQLException ex) {

        String mensaje = ex.getMessage() == null
                ? ""
                : ex.getMessage().toLowerCase();

        if (mensaje.contains("no such table")) {

            return new SQLException(
                    "No existe la tabla requerida para consultar el kardex.",
                    ex
            );
        }

        if (mensaje.contains("no such column")) {

            return new SQLException(
                    "La estructura de la tabla kardex no coincide con las consultas.",
                    ex
            );
        }

        if (mensaje.contains("database is locked")) {

            return new SQLException(
                    "La base de datos esta ocupada. Intente nuevamente.",
                    ex
            );
        }

        return ex;
    }

}
