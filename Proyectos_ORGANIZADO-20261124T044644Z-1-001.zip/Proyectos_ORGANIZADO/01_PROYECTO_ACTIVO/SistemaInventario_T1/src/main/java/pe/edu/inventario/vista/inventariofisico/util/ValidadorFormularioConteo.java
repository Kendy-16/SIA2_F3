package pe.edu.inventario.vista.inventariofisico.util;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Set;

/** Valida la cantidad ingresada al registrar un conteo físico. */
public final class ValidadorFormularioConteo {
    private static final Set<String> UNIDADES_ENTERAS = Set.of("UNIDAD", "CAJA", "PAQUETE");
    private static final int MAX_DECIMALES = 3;

    private ValidadorFormularioConteo() { }

    /** Resultado: o bien una cantidad válida o bien un mensaje de error. */
    public static final class Resultado {
        private final BigDecimal cantidad;
        private final String error;
        private Resultado(BigDecimal cantidad, String error) { this.cantidad = cantidad; this.error = error; }
        public boolean esValido() { return error == null; }
        public BigDecimal cantidad() { return cantidad; }
        public String error() { return error; }
    }

    public static Resultado validar(String texto, String unidad, boolean segundoConteo, boolean segundoPermitido) {
        if (texto == null || texto.isBlank()) return new Resultado(null, "Ingresa una cantidad válida.");
        BigDecimal qty;
        try {
            qty = new BigDecimal(texto.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            return new Resultado(null, "Ingresa una cantidad válida.");
        }
        if (qty.signum() < 0 || qty.stripTrailingZeros().scale() > MAX_DECIMALES) {
            return new Resultado(null, "La cantidad debe ser cero o mayor y no superar 3 decimales.");
        }
        String u = unidad == null ? "" : unidad.toUpperCase(Locale.ROOT);
        if (UNIDADES_ENTERAS.contains(u) && qty.stripTrailingZeros().scale() > 0) {
            return new Resultado(null, "La unidad " + u + " solo admite cantidades enteras.");
        }
        if (segundoConteo && !segundoPermitido) {
            return new Resultado(null, "El segundo conteo no está habilitado para esta toma.");
        }
        return new Resultado(qty, null);
    }
}
