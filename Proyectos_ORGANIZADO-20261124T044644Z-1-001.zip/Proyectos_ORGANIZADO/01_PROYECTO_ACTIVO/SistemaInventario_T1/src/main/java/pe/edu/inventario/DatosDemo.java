package pe.edu.inventario;

import pe.edu.inventario.modelo.producto.Producto;
import pe.edu.inventario.servicio.cliente.ClienteService;
import pe.edu.inventario.servicio.producto.ProductoService;
import pe.edu.inventario.servicio.venta.KardexService;

import java.math.BigDecimal;

/**
 * Datos de ejemplo (catálogo, stock y clientes) para poder probar el módulo sin base de datos.
 */
public final class DatosDemo {

    private DatosDemo() { }

    public static void cargar(ProductoService productos, KardexService kardex, ClienteService clientes) {
        agregar(productos, kardex, "P001", "Teclado USB",            "100.00", "85.00",  6, 50);
        agregar(productos, kardex, "P002", "Mouse óptico",            "30.00",  "24.50", 10, 50);
        agregar(productos, kardex, "P003", "Cable HDMI 2m",           "25.00",  "19.90", 12, 40);
        agregar(productos, kardex, "P004", "Memoria USB 64GB",        "45.00",  "38.00", 10, 30);
        agregar(productos, kardex, "P005", "Audífonos con micrófono", "80.00",  "68.00",  6, 25);
        agregar(productos, kardex, "P006", "Router WiFi",            "150.00", "129.00",  5,  8); // poco stock a propósito

        clientes.registrar("45678912", "María Quispe Huamán");
        clientes.registrar("20601234567", "Distribuidora Andina S.A.C.");
        clientes.registrar("10456789123", "Comercial Los Andes E.I.R.L.");
    }

    private static void agregar(ProductoService productos, KardexService kardex, String codigo, String nombre,
                                String precioNormal, String precioMayorista, int minimoMayorista, int stock) {
        productos.registrar(new Producto(codigo, nombre, new BigDecimal(precioNormal),
                new BigDecimal(precioMayorista), minimoMayorista));
        kardex.cargarStockInicial(codigo, stock);
    }
}
