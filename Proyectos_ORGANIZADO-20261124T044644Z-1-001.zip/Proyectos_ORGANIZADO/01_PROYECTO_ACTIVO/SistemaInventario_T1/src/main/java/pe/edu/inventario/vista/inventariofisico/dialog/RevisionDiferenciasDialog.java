package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Revisión de las diferencias de una toma: detalle, solicitud y decisión de ajustes. */
public class RevisionDiferenciasDialog extends JDialog {
    private final InventarioFisicoController controller;
    private final long idToma;
    private final PermisosVistaInventario permisos;
    private final Runnable alCambiar;
    private final PanelDiferencias panel = new PanelDiferencias();
    private final TablaAjustesModel ajustes = new TablaAjustesModel();
    private final JTable tablaAjustes = new JTable(ajustes);

    public RevisionDiferenciasDialog(Window owner, InventarioFisicoController controller, long idToma, PermisosVistaInventario permisos, Runnable alCambiar) {
        super(owner, "Revisión de diferencias · toma " + idToma, ModalityType.APPLICATION_MODAL);
        this.controller = controller; this.idToma = idToma; this.permisos = permisos; this.alCambiar = alCambiar;
        setSize(1000, 600); setLocationRelativeTo(owner); setLayout(new BorderLayout(8, 8));

        estiloTabla(tablaAjustes);
        tablaAjustes.setDefaultRenderer(Object.class, new EstadoAjusteRenderer());
        tablaAjustes.setDefaultRenderer(BigDecimal.class, new CantidadRenderer());
        tablaAjustes.getColumnModel().getColumn(3).setCellRenderer(new MonedaRenderer());
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Diferencias", panel);
        tabs.addTab("Ajustes solicitados", new JScrollPane(tablaAjustes));
        tabs.setBorder(new EmptyBorder(10, 12, 0, 12));
        add(tabs, BorderLayout.CENTER);

        JButton detalle = botonSecundario("Detalle"), solicitar = botonSecundario("Solicitar ajuste"), decidir = botonPrimario("Aprobar / rechazar"),
                actualizar = botonSecundario("Actualizar"), cerrar = botonSecundario("Cerrar");
        solicitar.setEnabled(permisos.puedeSolicitarAjuste());
        decidir.setEnabled(permisos.puedeAprobarAjuste() || permisos.puedeRechazarAjuste());
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        for (JButton b : new JButton[]{detalle, solicitar, decidir, actualizar, cerrar}) abajo.add(b);
        add(abajo, BorderLayout.SOUTH);

        detalle.addActionListener(e -> con(seleccionada(tabs), d -> new DetalleDiferenciaDialog(this, controller, idToma, d, this::despuesDeCambio).setVisible(true)));
        solicitar.addActionListener(e -> con(seleccionada(tabs), d -> new SolicitudAjusteDialog(this, controller, idToma, d, this::despuesDeCambio).setVisible(true)));
        decidir.addActionListener(e -> con(seleccionada(tabs), d -> new AprobacionAjusteDialog(this, controller, idToma, d, permisos, this::despuesDeCambio).setVisible(true)));
        actualizar.addActionListener(e -> cargar());
        cerrar.addActionListener(e -> dispose());
        cargar();
    }

    private Diferencia seleccionada(JTabbedPane tabs) {
        if (tabs.getSelectedIndex() == 0) return panel.getSeleccionada();
        int fila = tablaAjustes.getSelectedRow();
        return fila < 0 ? null : ajustes.getDiferencia(tablaAjustes.convertRowIndexToModel(fila));
    }

    private void con(Diferencia d, Consumer<Diferencia> accion) {
        if (d == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_DIFERENCIA); return; }
        accion.accept(d);
    }

    private void despuesDeCambio() { cargar(); alCambiar.run(); }

    private void cargar() {
        TareaAsincrona.ejecutar(this, () -> controller.listarDiferencias(idToma), lista -> { panel.setDiferencias(lista); ajustes.setDiferencias(lista); });
    }
}
