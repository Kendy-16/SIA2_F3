package pe.edu.inventario.seguridad;

import java.util.HashSet;
import java.util.Set;

/**
 * Garantiza que una transacción de venta no se procese más de una vez,
 * previniendo errores de "doble clic" o problemas de red.
 */
public class ControlIdempotencia {

    // Almacena los tokens/IDs de transacciones que ya fueron procesadas en esta sesión.
    // En un sistema real distribuido, esto usaría Redis o una tabla temporal en BD.
    private static final Set<String> transaccionesProcesadas = new HashSet<>();

    /**
     * Intenta registrar el inicio de una transacción.
     * @param tokenTransaccion Un UUID único generado al iniciar el pago.
     * @return true si es seguro proceder, false si la transacción ya está en proceso/procesada.
     */
    public static synchronized boolean iniciarTransaccion(String tokenTransaccion) {
        if (transaccionesProcesadas.contains(tokenTransaccion)) {
            return false; // Bloquea la operación: Ya fue procesada
        }
        transaccionesProcesadas.add(tokenTransaccion);
        return true;
    }

    /**
     * Libera el token cuando la transacción FALLÓ (por ejemplo, stock insuficiente),
     * para que el cajero pueda corregir la venta y reintentar con el mismo token.
     */
    public static synchronized void liberarTransaccion(String tokenTransaccion) {
        transaccionesProcesadas.remove(tokenTransaccion);
    }

    /**
     * Limpia el registro (útil para mantenimiento de memoria o cierres de sesión)
     */
    public static synchronized void limpiarTransaccionesAntiguas() {
        transaccionesProcesadas.clear();
    }
}
