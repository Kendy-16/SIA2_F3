package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Bitácora de una toma: un evento por fila. */
public class TablaAuditoriaModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"N°", "Evento"};
    private List<String> filas = new ArrayList<>();

    public void setEventos(List<String> eventos) { filas = new ArrayList<>(eventos); fireTableDataChanged(); }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) { return c == 0 ? Integer.class : String.class; }
    @Override public Object getValueAt(int r, int c) { return c == 0 ? r + 1 : filas.get(r); }
}
