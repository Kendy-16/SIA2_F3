package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Almacén, alcance de la toma y categoría de referencia. */
public class PanelSeleccionAlmacen extends JPanel {
    public static final String TODOS = "Todos los productos";
    public static final String SELECCIONADOS = "Productos seleccionados";
    private static final String CARGANDO = "Cargando...";

    private final JComboBox<String> almacen = new JComboBox<>(new String[]{CARGANDO});
    private final JComboBox<String> alcance = new JComboBox<>(new String[]{TODOS, SELECCIONADOS});
    private final JComboBox<String> categoria = new JComboBox<>();

    public PanelSeleccionAlmacen() {
        super(new GridBagLayout());
        setOpaque(false);
        fila(0, "Almacén", almacen);
        fila(1, "Alcance", alcance);
        fila(2, "Categoría (referencia de filtro)", categoria);
    }

    private void fila(int y, String etiqueta, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 5, 6, 5); g.fill = GridBagConstraints.HORIZONTAL; g.gridy = y;
        g.gridx = 0; g.weightx = 0; add(new JLabel(etiqueta + ":"), g);
        g.gridx = 1; g.weightx = 1; add(c, g);
    }

    public void cargar(List<String> almacenes, List<String> categorias) {
        almacen.removeAllItems();
        almacenes.forEach(almacen::addItem);
        categoria.removeAllItems();
        categorias.forEach(categoria::addItem);
    }

    public boolean almacenListo() {
        String a = getAlmacen();
        return a != null && !a.isBlank() && !CARGANDO.equals(a);
    }

    public String getAlmacen() { return (String) almacen.getSelectedItem(); }
    public String getAlcance() { return (String) alcance.getSelectedItem(); }
    public String getCategoria() { return (String) categoria.getSelectedItem(); }
    public boolean esSeleccionados() { return SELECCIONADOS.equals(getAlcance()); }
    public void alCambiarAlcance(Runnable r) { alcance.addActionListener(e -> r.run()); }
}
