package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Productos ya contados una vez, candidatos a un segundo conteo. */
public class TablaSegundoConteoModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"Código", "Producto", "Unidad", "Conteo 1", "Conteo 2", "Estado"};
    private List<Producto> filas = new ArrayList<>();

    /** Solo se muestran los productos que ya tienen primer conteo. */
    public void setProductos(List<Producto> todos) {
        filas = todos.stream().filter(p -> p.cantidadContada() != null).toList();
        fireTableDataChanged();
    }
    public Producto getProducto(int fila) { return fila < 0 || fila >= filas.size() ? null : filas.get(fila); }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) { return c == 3 || c == 4 ? BigDecimal.class : c == 5 ? EstadoConteo.class : String.class; }
    @Override public Object getValueAt(int r, int c) {
        Producto p = filas.get(r);
        return switch (c) { case 0 -> p.codigo(); case 1 -> p.nombre(); case 2 -> p.unidad(); case 3 -> p.cantidadContada(); case 4 -> p.segundoConteo(); default -> p.estado(); };
    }
}
