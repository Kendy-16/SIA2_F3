package pe.edu.inventario.dao.venta;

import pe.edu.inventario.modelo.venta.Venta;

import java.util.List;

/** Acceso a datos de ventas. Implementaciones: VentaDAOMemoria (sin BD) o una versión JDBC/SQLite. */
public interface VentaDAO {
    /** Guarda una venta nueva. @throws IllegalStateException si el id ya existe. */
    void guardar(Venta venta) throws Exception;

    /** @return la venta o null si no existe. */
    Venta buscarPorId(String idVenta);

    /**
     * @param fechaInicio DD/MM/YYYY (vacío = sin límite inferior)
     * @param fechaFin    DD/MM/YYYY (vacío = sin límite superior)
     * @param tipoVenta   "TODAS", "NORMAL" o "MAYORISTA"
     */
    List<Venta> listarHistorialPorFiltro(String fechaInicio, String fechaFin, String tipoVenta);

    void actualizarEstado(String idVenta, String estado, String motivo, String idAdmin) throws Exception;
}
