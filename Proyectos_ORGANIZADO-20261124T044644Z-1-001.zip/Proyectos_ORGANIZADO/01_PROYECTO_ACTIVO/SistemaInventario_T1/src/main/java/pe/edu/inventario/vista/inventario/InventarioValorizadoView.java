package pe.edu.inventario.vista.inventario;

import pe.edu.inventario.modelo.dao.ReporteDAO;
import pe.edu.inventario.vista.reportes.PanelReporteTabla;

import java.awt.BorderLayout;
import javax.swing.JPanel;

/** Inventario valorizado al costo promedio móvil. */
public class InventarioValorizadoView extends JPanel {

    public InventarioValorizadoView() {
        super(new BorderLayout());

        ReporteDAO dao = new ReporteDAO();

        add(new PanelReporteTabla(
                "Inventario valorizado al costo promedio",
                "Valor = cantidad × costo promedio (valores sin IGV, en S/).",
                new String[]{"Código", "Producto", "Almacén", "Cantidad",
                        "Costo promedio", "Valor total"},
                new String[]{null, null, null, "%.3f", "%.6f", "%,.2f"},
                dao::inventarioValorizado,
                filas -> String.format(java.util.Locale.US,
                        "Valor total del inventario: S/ %,.2f",
                        PanelReporteTabla.sumar(filas, 5))
        ), BorderLayout.CENTER);
    }
}
