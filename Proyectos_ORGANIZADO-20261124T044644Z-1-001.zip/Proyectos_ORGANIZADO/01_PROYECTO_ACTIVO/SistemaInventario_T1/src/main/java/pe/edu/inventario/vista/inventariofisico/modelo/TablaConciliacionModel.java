package pe.edu.inventario.vista.inventariofisico.modelo;

import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/** Resultado de la conciliación: sistema contra físico, con valorización. */
public class TablaConciliacionModel extends AbstractTableModel {
    private static final String[] COLUMNAS = {"Código", "Producto", "Sistema", "Físico", "Diferencia", "Costo prom.", "Valor diferencia", "Tipo", "Revisión"};
    private List<Diferencia> filas = new ArrayList<>();

    public void setFilas(List<Diferencia> nuevas) { filas = new ArrayList<>(nuevas); fireTableDataChanged(); }
    public Diferencia getDiferencia(int fila) { return fila < 0 || fila >= filas.size() ? null : filas.get(fila); }
    public List<Diferencia> getFilas() { return Collections.unmodifiableList(filas); }
    @Override public int getRowCount() { return filas.size(); }
    @Override public int getColumnCount() { return COLUMNAS.length; }
    @Override public String getColumnName(int c) { return COLUMNAS[c]; }
    @Override public Class<?> getColumnClass(int c) {
        return switch (c) { case 2, 3, 4, 5, 6 -> BigDecimal.class; case 7 -> TipoDiferencia.class; default -> String.class; };
    }
    @Override public Object getValueAt(int r, int c) {
        Diferencia d = filas.get(r);
        return switch (c) {
            case 0 -> d.producto().codigo(); case 1 -> d.producto().nombre(); case 2 -> d.stockSistema(); case 3 -> d.cantidadFisica();
            case 4 -> d.diferencia(); case 5 -> d.costoPromedio(); case 6 -> d.valorDiferencia(); case 7 -> d.tipo(); default -> d.estadoRevision();
        };
    }
}
