package pe.edu.inventario.vista.venta;

import pe.edu.inventario.controlador.venta.VentaController;
import pe.edu.inventario.modelo.venta.RolUsuario;
import pe.edu.inventario.modelo.venta.TipoVenta;
import pe.edu.inventario.modelo.venta.Venta;
import pe.edu.inventario.seguridad.AutorizacionVentas;
import pe.edu.inventario.servicio.venta.VentaException;
import pe.edu.inventario.vista.venta.componentes.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;

/**
 * Base común de VentaView (normal) y VentaMayoristaView: arma los paneles reutilizables,
 * conecta los eventos con el controlador y refresca la pantalla. Las subclases solo
 * personalizan lo que las diferencia (Requisitos 3.1 y 3.2).
 */
public abstract class VentaBaseView extends JPanel {

    protected final VentaController controller;
    protected final TipoVenta tipo;
    protected final RolUsuario rol;
    protected final String idUsuario;

    protected final PanelCliente panelCliente = new PanelCliente();
    protected final PanelProductos panelProductos = new PanelProductos();
    protected final TablaDetalleVenta tablaDetalle = new TablaDetalleVenta();
    protected final PanelTotales panelTotales = new PanelTotales();
    protected final PanelPago panelPago = new PanelPago();

    protected final JPanel panelSuperior = new JPanel(new GridLayout(0, 1));
    protected final JButton btnConfirmarPago;
    private final JButton btnDescuento = new JButton("Descuento manual (Admin)");
    private final JButton btnQuitar = new JButton("Quitar línea");
    private final JButton btnNuevaVenta = new JButton("Cancelar / Nueva venta");

    protected VentaBaseView(VentaController controller, TipoVenta tipo, RolUsuario rol,
                            String idUsuario, String textoBotonConfirmar) {
        this.controller = controller;
        this.tipo = tipo;
        this.rol = rol;
        this.idUsuario = idUsuario;

        setLayout(new BorderLayout());

        // 1. Zona Superior (Cliente y Búsqueda de Productos). Las subclases pueden insertar más paneles.
        panelSuperior.add(panelCliente);
        panelSuperior.add(panelProductos);

        // 2. Zona Central (Tabla + acciones sobre la línea seleccionada)
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnDescuento.setEnabled(AutorizacionVentas.puedeAplicarDescuentoManual(rol));
        if (!btnDescuento.isEnabled()) {
            btnDescuento.setToolTipText("Solo el perfil ADMINISTRADOR puede aplicar descuentos manuales");
        }
        acciones.add(btnDescuento);
        acciones.add(btnQuitar);
        acciones.add(btnNuevaVenta);

        JPanel centro = new JPanel(new BorderLayout());
        centro.add(tablaDetalle, BorderLayout.CENTER);
        centro.add(acciones, BorderLayout.SOUTH);

        // 3. Zona Inferior (Totales, Pago y botón de confirmación)
        btnConfirmarPago = new JButton(textoBotonConfirmar);
        btnConfirmarPago.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel totalesYPago = new JPanel(new GridLayout(1, 2, 10, 0));
        totalesYPago.add(panelTotales);
        totalesYPago.add(panelPago); // Requisito 9: justo antes del botón de confirmar

        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.add(totalesYPago, BorderLayout.CENTER);
        panelInferior.add(btnConfirmarPago, BorderLayout.EAST);

        add(panelSuperior, BorderLayout.NORTH);
        add(centro, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        conectarEventos();
        nuevaVenta();
    }

    private void conectarEventos() {
        panelCliente.addBuscarListener(e -> buscarCliente());
        panelProductos.addAgregarListener(e -> agregarProducto());
        panelPago.addCambioListener(this::actualizarVuelto);
        btnQuitar.addActionListener(e -> quitarLinea());
        btnDescuento.addActionListener(e -> aplicarDescuento());
        btnNuevaVenta.addActionListener(e -> nuevaVenta());
        btnConfirmarPago.addActionListener(e -> confirmar());

        // Atajo F12 = Confirmar y pagar
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("F12"), "confirmarVenta");
        getActionMap().put("confirmarVenta", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btnConfirmarPago.isEnabled()) {
                    confirmar();
                }
            }
        });
    }

    /** Descarta la venta actual (si la hay) y empieza una nueva con el cliente por defecto del tipo de venta. */
    protected void nuevaVenta() {
        controller.iniciarNuevaVenta(tipo, rol, idUsuario);
        Venta v = controller.getVentaActual();
        panelCliente.setDocumento(v.getIdCliente() == null ? "" : v.getIdCliente());
        panelCliente.setNombre(v.getNombreCliente() == null ? "" : v.getNombreCliente());
        panelProductos.limpiarEntrada();
        panelPago.limpiar();
        refrescar();
    }

    private void buscarCliente() {
        try {
            panelCliente.setNombre(controller.setCliente(panelCliente.getDocumento()));
        } catch (IllegalArgumentException ex) {
            panelCliente.setNombre("");
            mostrarError(ex.getMessage());
        }
    }

    private void agregarProducto() {
        try {
            controller.agregarProducto(panelProductos.getCodigo(), panelProductos.getCantidad());
            panelProductos.limpiarEntrada();
            refrescar();
        } catch (IllegalArgumentException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void quitarLinea() {
        try {
            controller.quitarLinea(tablaDetalle.getFilaSeleccionada());
            refrescar();
        } catch (IllegalArgumentException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void aplicarDescuento() {
        if (tablaDetalle.getFilaSeleccionada() < 0) {
            mostrarError("Seleccione una línea del detalle.");
            return;
        }
        String texto = JOptionPane.showInputDialog(this, "Descuento (%) para la línea seleccionada:",
                "Descuento manual", JOptionPane.QUESTION_MESSAGE);
        if (texto == null) {
            return; // canceló
        }
        try {
            controller.aplicarDescuentoManual(tablaDetalle.getFilaSeleccionada(), parsearMonto(texto));
            refrescar();
        } catch (IllegalArgumentException | SecurityException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void confirmar() {
        btnConfirmarPago.setEnabled(false); // evita el doble clic mientras se procesa
        try {
            BigDecimal recibido = panelPago.esEfectivo() ? parsearMonto(panelPago.getMontoRecibido()) : null;
            String comprobante = controller.procesarPagoYConfirmar(panelPago.getMetodoPago(), recibido);

            Venta v = controller.getVentaActual();
            JOptionPane.showMessageDialog(this,
                    "Venta registrada correctamente.\n\nComprobante: " + comprobante
                            + "\nTotal: S/ " + v.getTotal().toPlainString()
                            + "\nVuelto: S/ " + v.getVuelto().toPlainString(),
                    "Venta exitosa", JOptionPane.INFORMATION_MESSAGE);
            nuevaVenta();
        } catch (VentaException | IllegalArgumentException | SecurityException ex) {
            mostrarError(ex.getMessage());
        } finally {
            btnConfirmarPago.setEnabled(true);
        }
    }

    private void actualizarVuelto() {
        if (!panelPago.esEfectivo()) {
            panelPago.setVuelto("0.00");
            return;
        }
        try {
            panelPago.setVuelto(controller.calcularVuelto(parsearMonto(panelPago.getMontoRecibido())).toPlainString());
        } catch (IllegalArgumentException ex) {
            panelPago.setVuelto("0.00"); // mientras el cajero escribe, el texto puede ser inválido
        }
    }

    protected void refrescar() {
        Venta v = controller.getVentaActual();
        tablaDetalle.mostrarDetalles(v.getDetalles());
        panelTotales.actualizarTotales(v.getSubtotal().toPlainString(), v.getDescuentoTotal().toPlainString(),
                v.getImpuestos().toPlainString(), v.getTotal().toPlainString());
        actualizarVuelto();
    }

    private BigDecimal parsearMonto(String texto) {
        try {
            return new BigDecimal(texto.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Monto o porcentaje inválido: '" + texto + "'");
        }
    }

    protected void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Atención", JOptionPane.WARNING_MESSAGE);
    }
}
