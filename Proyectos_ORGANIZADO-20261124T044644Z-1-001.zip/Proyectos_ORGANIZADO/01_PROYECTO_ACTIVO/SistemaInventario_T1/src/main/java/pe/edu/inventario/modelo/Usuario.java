
package pe.edu.inventario.modelo;

/**
 * Represents a system user.
 */
public class Usuario {

    private int idUsuario;
    private String usuario;
    private String passwordHash;
    private String passwordSalt;
    private boolean activo;
    private int intentosFallidos;
    private Long bloqueadoHasta;
    private String rol = "USUARIO";

    public Usuario() {
    }

    public Usuario(
            int idUsuario,
            String usuario,
            String passwordHash,
            String passwordSalt,
            boolean activo,
            int intentosFallidos,
            Long bloqueadoHasta
    ) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.passwordHash = passwordHash;
        this.passwordSalt = passwordSalt;
        this.activo = activo;
        this.intentosFallidos = intentosFallidos;
        this.bloqueadoHasta = bloqueadoHasta;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getPasswordSalt() {
        return passwordSalt;
    }

    public void setPasswordSalt(String passwordSalt) {
        this.passwordSalt = passwordSalt;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public int getIntentosFallidos() {
        return intentosFallidos;
    }

    public void setIntentosFallidos(int intentosFallidos) {
        this.intentosFallidos = intentosFallidos;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = (rol == null || rol.trim().isEmpty())
                ? "USUARIO"
                : rol.trim().toUpperCase();
    }

    public Long getBloqueadoHasta() {
        return bloqueadoHasta;
    }

    public void setBloqueadoHasta(Long bloqueadoHasta) {
        this.bloqueadoHasta = bloqueadoHasta;
    }
}
