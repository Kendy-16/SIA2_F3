
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.DetalleInventarioFisico;
import pe.edu.inventario.modelo.dao.InventarioFisicoDAO;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Servicio encargado de las reglas de negocio del inventario fisico.
 *
 * Responsabilidades:
 * - Validar los datos de las tomas de inventario.
 * - Validar cantidades y observaciones.
 * - Comprobar almacenes y estados de las tomas.
 * - Verificar que los productos pertenezcan al conteo.
 * - Exigir observaciones ante diferencias significativas.
 * - Delegar las operaciones de persistencia al DAO.
 *
 * El DAO es responsable de ejecutar las operaciones de escritura
 * y el procesamiento de inventario dentro de transacciones JDBC.
 */
public class InventarioFisicoService {

    // =========================================================
    // 1. CONSTANTES
    // =========================================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final int ESCALA_CANTIDAD = 3;

    private static final int LONGITUD_MAXIMA_OBSERVACION = 500;

    private static final int LONGITUD_MINIMA_OBSERVACION_CRITICA = 5;

    private static final int LONGITUD_MAXIMA_MODO = 20;

    private static final BigDecimal PORCENTAJE_DIFERENCIA_CRITICA =
            new BigDecimal("0.20");

    private static final BigDecimal IMPACTO_VALORIZADO_CRITICO =
            new BigDecimal("10000.00");

    private static final String MODO_GENERAL = "GENERAL";
    private static final String MODO_PARCIAL = "PARCIAL";
    private static final String MODO_CICLICO = "CICLICO";

    private static final String ESTADO_ABIERTO = "ABIERTO";
    private static final String ESTADO_PROCESADO = "PROCESADO";
    private static final String ESTADO_ANULADO = "ANULADO";

    // =========================================================
    // 2. ATRIBUTOS
    // =========================================================

    private final InventarioFisicoDAO inventarioFisicoDAO;

    // =========================================================
    // 3. CONSTRUCTORES
    // =========================================================

    /**
     * Constructor predeterminado.
     */
    public InventarioFisicoService() {
        this(new InventarioFisicoDAO());
    }

    /**
     * Constructor con inyeccion de dependencias.
     *
     * @param inventarioFisicoDAO DAO de inventario fisico
     */
    public InventarioFisicoService(
            InventarioFisicoDAO inventarioFisicoDAO
    ) {

        if (inventarioFisicoDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de inventario fisico es obligatorio."
            );
        }

        this.inventarioFisicoDAO = inventarioFisicoDAO;
    }

    // =========================================================
    // 4. CREAR CONTEO FISICO
    // =========================================================

    /**
     * Crea una nueva toma de inventario para un almacen.
     *
     * Comprueba que el almacen exista y se encuentre activo.
     *
     * El DAO vuelve a validar estas condiciones dentro de su
     * transaccion para evitar inconsistencias por concurrencia.
     *
     * @param idAlmacen identificador del almacen
     * @param modo GENERAL, PARCIAL o CICLICO
     * @param observacion observacion general
     * @return identificador de la toma creada
     * @throws SQLException si ocurre un error de persistencia
     */
    public int crearConteo(
            int idAlmacen,
            String modo,
            String observacion
    ) throws SQLException {

        validarIdAlmacen(idAlmacen);

        String modoValidado = validarModo(modo);

        String observacionValidada =
                validarObservacionOpcional(
                        observacion,
                        "La observacion del conteo"
                );

        if (!inventarioFisicoDAO.existeAlmacenActivo(idAlmacen)) {
            throw new IllegalArgumentException(
                    "El almacen seleccionado no existe o se encuentra inactivo."
            );
        }

        int idToma = inventarioFisicoDAO.crearConteo(
                idAlmacen,
                modoValidado,
                observacionValidada
        );

        if (idToma <= 0) {
            throw new SQLException(
                    "No se pudo crear la toma de inventario."
            );
        }

        return idToma;
    }

    // =========================================================
    // 5. REGISTRAR CANTIDAD FISICA
    // =========================================================

    /**
     * Registra la cantidad encontrada de un producto.
     *
     * Validaciones:
     * - La toma debe estar abierta.
     * - El producto debe pertenecer a la toma.
     * - La cantidad debe ser valida y no negativa.
     * - Las diferencias significativas requieren observacion.
     *
     * El DAO debe repetir las validaciones de estado y
     * consistencia necesarias dentro de su transaccion.
     *
     * @param idToma identificador de la toma
     * @param idProducto identificador del producto
     * @param cantidadFisica cantidad encontrada
     * @param observacion observacion del producto
     * @throws SQLException si ocurre un error de persistencia
     */
    public void registrarCantidadFisica(
            int idToma,
            int idProducto,
            BigDecimal cantidadFisica,
            String observacion
    ) throws SQLException {

        validarIdToma(idToma);
        validarIdProducto(idProducto);

        BigDecimal cantidadValidada =
                validarCantidad(cantidadFisica);

        String observacionValidada =
                validarObservacionOpcional(
                        observacion,
                        "La observacion del producto"
                );

        // Comprobar que el conteo siga abierto.
        validarTomaAbierta(idToma);

        // Recuperar el detalle para comprobar el producto
        // y evaluar la importancia de la diferencia.
        DetalleInventarioFisico detalle =
                buscarDetalleProducto(idToma, idProducto);

        validarObservacionPorDiferencia(
                detalle,
                cantidadValidada,
                observacionValidada
        );

        // Delegar el registro al DAO.
        inventarioFisicoDAO.registrarCantidadFisica(
                idToma,
                idProducto,
                cantidadValidada,
                observacionValidada
        );
    }

    // =========================================================
    // 6. CONSULTAR DETALLES DEL CONTEO
    // =========================================================

    /**
     * Recupera los productos asociados a una toma.
     *
     * Comprueba que el resultado del DAO no sea nulo y que
     * los elementos recuperados sean validos.
     *
     * @param idToma identificador de la toma
     * @return lista de detalles del inventario
     * @throws SQLException si ocurre un error de consulta
     */
    public List<DetalleInventarioFisico> listarDetalle(
            int idToma
    ) throws SQLException {

        validarIdToma(idToma);

        List<DetalleInventarioFisico> detalles =
                inventarioFisicoDAO.listarDetalle(idToma);

        if (detalles == null) {
            throw new SQLException(
                    "El DAO devolvio una lista nula de detalles."
            );
        }

        Set<Integer> productosRegistrados = new HashSet<>();

        for (DetalleInventarioFisico detalle : detalles) {

            if (detalle == null) {
                throw new SQLException(
                        "El detalle del inventario contiene un registro nulo."
                );
            }

            if (detalle.getIdProducto() <= 0) {
                throw new SQLException(
                        "Se encontro un producto con identificador invalido."
                );
            }

            if (!productosRegistrados.add(detalle.getIdProducto())) {
                throw new SQLException(
                        "El conteo contiene productos duplicados."
                );
            }

            validarDatosSnapshot(detalle);
        }

        return detalles;
    }

    // =========================================================
    // 7. PROCESAR CONTEO FISICO
    // =========================================================

    /**
     * Procesa una toma de inventario.
     *
     * El DAO debe garantizar:
     * - Que la toma siga abierta.
     * - Que todos los productos hayan sido contados.
     * - Que no existan cambios incompatibles en el stock.
     * - Que se actualicen las existencias.
     * - Que se registren los movimientos correspondientes.
     * - Que se actualice el Kardex.
     * - Que todo se ejecute en una sola transaccion.
     *
     * @param idToma identificador de la toma
     * @return resultado entero definido por el DAO
     * @throws SQLException si ocurre un error durante el proceso
     */
    public int procesarConteo(
            int idToma
    ) throws SQLException {

        validarIdToma(idToma);

        validarTomaAbierta(idToma);

        // El DAO vuelve a verificar el estado, los pendientes
        // y la consistencia del inventario dentro de la transaccion.
        return inventarioFisicoDAO.procesarConteo(idToma);
    }

    // =========================================================
    // 8. VALIDAR MODO DE CONTEO
    // =========================================================

    private String validarModo(String modo) {

        if (modo == null || modo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Debe seleccionar el modo del inventario fisico."
            );
        }

        String valor = modo.trim().toUpperCase(Locale.ROOT);

        if (valor.length() > LONGITUD_MAXIMA_MODO) {
            throw new IllegalArgumentException(
                    "El modo del inventario supera la longitud permitida."
            );
        }

        switch (valor) {

            case MODO_GENERAL:
            case MODO_PARCIAL:
            case MODO_CICLICO:
                return valor;

            default:
                throw new IllegalArgumentException(
                        "Modo invalido. Seleccione GENERAL, PARCIAL o CICLICO."
                );
        }
    }

    // =========================================================
    // 9. VALIDAR CANTIDADES
    // =========================================================

    private BigDecimal validarCantidad(BigDecimal cantidad) {

        if (cantidad == null) {
            throw new IllegalArgumentException(
                    "La cantidad fisica es obligatoria."
            );
        }

        if (cantidad.signum() < 0) {
            throw new IllegalArgumentException(
                    "La cantidad fisica no puede ser negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    "La cantidad fisica supera el maximo permitido."
            );
        }

        try {

            return cantidad.setScale(
                    ESCALA_CANTIDAD,
                    RoundingMode.UNNECESSARY
            );

        } catch (ArithmeticException ex) {

            throw new IllegalArgumentException(
                    "La cantidad fisica admite como maximo "
                            + ESCALA_CANTIDAD + " decimales.",
                    ex
            );
        }
    }

    // =========================================================
    // 10. VALIDAR OBSERVACIONES
    // =========================================================

    /**
     * Normaliza y valida una observacion opcional.
     *
     * @param observacion texto recibido
     * @param nombreCampo nombre del campo para los mensajes
     * @return observacion normalizada o null si esta vacia
     */
    private String validarObservacionOpcional(
            String observacion,
            String nombreCampo
    ) {

        if (observacion == null) {
            return null;
        }

        String texto = observacion.trim()
                .replaceAll("\\s+", " ");

        if (texto.isEmpty()) {
            return null;
        }

        if (texto.length() > LONGITUD_MAXIMA_OBSERVACION) {
            throw new IllegalArgumentException(
                    nombreCampo + " no puede superar "
                            + LONGITUD_MAXIMA_OBSERVACION + " caracteres."
            );
        }

        for (int i = 0; i < texto.length(); i++) {

            char caracter = texto.charAt(i);

            if (Character.isISOControl(caracter)) {
                throw new IllegalArgumentException(
                        nombreCampo + " contiene caracteres no permitidos."
                );
            }
        }

        return texto;
    }

    // =========================================================
    // 11. BUSCAR PRODUCTO DENTRO DEL CONTEO
    // =========================================================

    /**
     * Busca un producto dentro del snapshot de la toma.
     *
     * @param idToma identificador de la toma
     * @param idProducto identificador del producto
     * @return detalle encontrado
     * @throws SQLException si ocurre un error de consulta
     */
    private DetalleInventarioFisico buscarDetalleProducto(
            int idToma,
            int idProducto
    ) throws SQLException {

        List<DetalleInventarioFisico> detalles =
                listarDetalle(idToma);

        for (DetalleInventarioFisico detalle : detalles) {

            if (detalle.getIdProducto() == idProducto) {
                return detalle;
            }
        }

        throw new IllegalArgumentException(
                "El producto seleccionado no pertenece a esta toma de inventario."
        );
    }

    // =========================================================
    // 12. VALIDAR DIFERENCIAS SIGNIFICATIVAS
    // =========================================================

    /**
     * Exige una observacion cuando la diferencia alcanza:
     * - El 20 % o mas del stock del sistema.
     * - Un impacto valorizado igual o superior a 10 000.
     *
     * La diferencia se evalua utilizando el stock y costo
     * promedio guardados en el snapshot del conteo.
     *
     * @param detalle detalle del producto
     * @param cantidadFisica cantidad encontrada
     * @param observacion observacion ingresada
     */
    private void validarObservacionPorDiferencia(
            DetalleInventarioFisico detalle,
            BigDecimal cantidadFisica,
            String observacion
    ) {

        BigDecimal stockSistema = detalle.getStockSistema();
        BigDecimal costoPromedio = detalle.getCostoPromedio();

        BigDecimal diferencia = cantidadFisica
                .subtract(stockSistema)
                .abs();

        // Diferencia porcentual: se calcula solo cuando
        // el stock del sistema es mayor que cero.
        boolean diferenciaPorcentualCritica = false;

        if (stockSistema.signum() > 0) {

            BigDecimal limiteDiferencia =
                    stockSistema.multiply(
                            PORCENTAJE_DIFERENCIA_CRITICA
                    );

            diferenciaPorcentualCritica =
                    diferencia.compareTo(limiteDiferencia) >= 0;
        }

        // Impacto valorizado absoluto de la diferencia.
        BigDecimal impactoValorizado =
                diferencia.multiply(costoPromedio);

        boolean impactoCritico =
                impactoValorizado.compareTo(
                        IMPACTO_VALORIZADO_CRITICO
                ) >= 0;

        if (diferenciaPorcentualCritica || impactoCritico) {

            if (observacion == null
                    || observacion.trim().length()
                    < LONGITUD_MINIMA_OBSERVACION_CRITICA) {

                throw new IllegalArgumentException(
                        "La diferencia encontrada es significativa. "
                                + "Debe ingresar una observacion de al menos "
                                + LONGITUD_MINIMA_OBSERVACION_CRITICA
                                + " caracteres."
                );
            }
        }
    }

    // =========================================================
    // 13. VALIDAR DATOS DEL SNAPSHOT
    // =========================================================

    /**
     * Comprueba la integridad de los valores recuperados
     * desde el detalle de la toma.
     */
    private void validarDatosSnapshot(
            DetalleInventarioFisico detalle
    ) throws SQLException {

        BigDecimal stockSistema = detalle.getStockSistema();

        BigDecimal costoPromedio = detalle.getCostoPromedio();

        if (stockSistema == null || costoPromedio == null) {
            throw new SQLException(
                    "El snapshot contiene cantidades o costos nulos."
            );
        }

        if (stockSistema.signum() < 0) {
            throw new SQLException(
                    "El snapshot contiene un stock del sistema negativo."
            );
        }

        if (costoPromedio.signum() < 0) {
            throw new SQLException(
                    "El snapshot contiene un costo promedio negativo."
            );
        }

        if (stockSistema.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El stock del snapshot supera el maximo permitido."
            );
        }
    }

    // =========================================================
    // 14. VALIDAR ESTADO DE LA TOMA
    // =========================================================

    /**
     * Impide modificar o procesar tomas cerradas.
     *
     * @param idToma identificador de la toma
     * @throws SQLException si ocurre un error de consulta
     */
    private void validarTomaAbierta(
            int idToma
    ) throws SQLException {

        String estado = obtenerEstadoConteo(idToma);

        if (!ESTADO_ABIERTO.equals(estado)) {

            throw new IllegalArgumentException(
                    "La toma de inventario no esta abierta. "
                            + "Estado actual: " + estado + "."
            );
        }
    }

    /**
     * Consulta el estado actual de una toma.
     *
     * @param idToma identificador de la toma
     * @return ABIERTO, PROCESADO o ANULADO
     * @throws SQLException si ocurre un error de consulta
     */
    public String obtenerEstadoConteo(
            int idToma
    ) throws SQLException {

        validarIdToma(idToma);

        String estado = inventarioFisicoDAO.obtenerEstadoConteo(idToma);

        if (estado == null || estado.trim().isEmpty()) {
            throw new SQLException(
                    "No se pudo determinar el estado de la toma."
            );
        }

        String estadoNormalizado =
                estado.trim().toUpperCase(Locale.ROOT);

        switch (estadoNormalizado) {

            case ESTADO_ABIERTO:
            case ESTADO_PROCESADO:
            case ESTADO_ANULADO:
                return estadoNormalizado;

            default:
                throw new SQLException(
                        "La base de datos devolvio un estado de toma desconocido: "
                                + estado
                );
        }
    }

    // =========================================================
    // 15. COMPROBAR ALMACEN ACTIVO
    // =========================================================

    /**
     * Comprueba si un almacen existe y esta activo.
     *
     * @param idAlmacen identificador del almacen
     * @return true si esta activo; false en caso contrario
     * @throws SQLException si ocurre un error de consulta
     */
    public boolean existeAlmacenActivo(
            int idAlmacen
    ) throws SQLException {

        validarIdAlmacen(idAlmacen);

        return inventarioFisicoDAO.existeAlmacenActivo(idAlmacen);
    }

    // =========================================================
    // 16. VALIDAR IDENTIFICADORES
    // =========================================================

    private void validarIdAlmacen(int idAlmacen) {

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "Debe seleccionar un almacen valido."
            );
        }
    }

    private void validarIdToma(int idToma) {

        if (idToma <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del conteo debe ser positivo."
            );
        }
    }

    private void validarIdProducto(int idProducto) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del producto debe ser positivo."
            );
        }
    }
}
