package pe.edu.inventario.vista.inventariofisico.renderer;

import pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Colorea el estado de conteo de un producto (EstadoConteo). */
public class EstadoConteoRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focus, int row, int col) {
        Component c = super.getTableCellRendererComponent(table, value, selected, focus, row, col);
        setBorder(new EmptyBorder(2, 7, 2, 7));
        FormatoInventarioFisico.aplicarCebra(c, table, row, selected);
        setHorizontalAlignment(SwingConstants.LEFT);
        if (!selected) {
            Color f = FormatoInventarioFisico.TEXT;
            if (value instanceof EstadoConteo e) {
                f = switch (e) {
                    case PENDIENTE -> FormatoInventarioFisico.AMBER;
                    case CONTADO, REVISADO -> FormatoInventarioFisico.GREEN;
                    case SEGUNDO_CONTEO -> FormatoInventarioFisico.BLUE;
                };
            }
            setForeground(f);
        }
        setFont(getFont().deriveFont(Font.BOLD));
        return c;
    }
}
