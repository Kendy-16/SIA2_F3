package pe.edu.inventario.vista.inventariofisico.util;

import pe.edu.inventario.modelo.venta.RolUsuario;

/**
 * Qué botones habilita la vista según el perfil. Es solo una ayuda visual:
 * la autorización real se vuelve a validar en el servicio.
 */
public final class PermisosVistaInventario {
    private final RolUsuario rol;

    public PermisosVistaInventario(RolUsuario rol) { this.rol = rol == null ? RolUsuario.USUARIO : rol; }

    public static PermisosVistaInventario administrador() { return new PermisosVistaInventario(RolUsuario.ADMINISTRADOR); }

    public RolUsuario rol() { return rol; }
    private boolean esAdmin() { return rol == RolUsuario.ADMINISTRADOR; }

    public boolean puedeCrearToma() { return true; }
    public boolean puedeRegistrarConteo() { return true; }
    public boolean puedeConciliar() { return true; }
    public boolean puedeSolicitarAjuste() { return true; }
    public boolean puedeAprobarAjuste() { return esAdmin(); }
    public boolean puedeRechazarAjuste() { return esAdmin(); }
    public boolean puedeCerrarToma() { return esAdmin(); }
    public boolean puedeExportar() { return true; }

    public String descripcion() { return "Perfil: " + rol; }
}
