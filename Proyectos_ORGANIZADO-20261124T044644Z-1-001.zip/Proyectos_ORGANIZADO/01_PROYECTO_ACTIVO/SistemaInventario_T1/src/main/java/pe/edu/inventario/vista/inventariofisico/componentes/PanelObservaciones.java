package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Área de texto con título, usada para observaciones, motivos y explicaciones. */
public class PanelObservaciones extends JPanel {
    private final JTextArea area;

    public PanelObservaciones(String titulo, int filas) {
        super(new BorderLayout(5, 5));
        setOpaque(false);
        area = new JTextArea(filas, 34);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        add(new JLabel(titulo), BorderLayout.NORTH);
        add(new JScrollPane(area), BorderLayout.CENTER);
    }

    public String getTexto() { return area.getText(); }
    public void setTexto(String t) { area.setText(t == null ? "" : t); area.setCaretPosition(0); }
    public void setEditable(boolean editable) { area.setEditable(editable); }
}
