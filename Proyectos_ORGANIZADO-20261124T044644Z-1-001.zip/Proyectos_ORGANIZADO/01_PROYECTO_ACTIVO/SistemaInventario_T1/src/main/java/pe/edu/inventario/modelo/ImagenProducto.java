package pe.edu.inventario.modelo;

import java.time.LocalDateTime;

/**
 * Representa una imagen asociada a un producto.
 *
 * También contiene los datos temporales de una imagen
 * obtenida desde Pixabay durante una búsqueda.
 */
public class ImagenProducto {

    private int idImagen;
    private long idProducto;
    private long pixabayId;

    private String rutaLocal;
    private String fuente;
    private String paginaFuente;
    private String autor;
    private LocalDateTime fechaGuardado;

    // Datos temporales de búsqueda en Pixabay.
    private String vistaPreviaUrl;
    private String imagenUrl;
    private String etiquetas;

    public ImagenProducto() {
        this.fuente = "Pixabay";
    }

    public ImagenProducto(
            long pixabayId,
            String vistaPreviaUrl,
            String imagenUrl,
            String paginaFuente,
            String autor,
            String etiquetas) {

        this.pixabayId = pixabayId;
        this.vistaPreviaUrl = vistaPreviaUrl;
        this.imagenUrl = imagenUrl;
        this.paginaFuente = paginaFuente;
        this.autor = autor;
        this.etiquetas = etiquetas;
        this.fuente = "Pixabay";
    }

    public int getIdImagen() {
        return idImagen;
    }

    public void setIdImagen(int idImagen) {
        this.idImagen = idImagen;
    }

    public long getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(long idProducto) {
        this.idProducto = idProducto;
    }

    public long getPixabayId() {
        return pixabayId;
    }

    public void setPixabayId(long pixabayId) {
        this.pixabayId = pixabayId;
    }

    public String getRutaLocal() {
        return rutaLocal;
    }

    public void setRutaLocal(String rutaLocal) {
        this.rutaLocal = rutaLocal;
    }

    public String getFuente() {
        return fuente;
    }

    public void setFuente(String fuente) {
        this.fuente = fuente;
    }

    public String getPaginaFuente() {
        return paginaFuente;
    }

    public void setPaginaFuente(String paginaFuente) {
        this.paginaFuente = paginaFuente;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public LocalDateTime getFechaGuardado() {
        return fechaGuardado;
    }

    public void setFechaGuardado(LocalDateTime fechaGuardado) {
        this.fechaGuardado = fechaGuardado;
    }

    public String getVistaPreviaUrl() {
        return vistaPreviaUrl;
    }

    public void setVistaPreviaUrl(String vistaPreviaUrl) {
        this.vistaPreviaUrl = vistaPreviaUrl;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }

    public String getEtiquetas() {
        return etiquetas;
    }

    public void setEtiquetas(String etiquetas) {
        this.etiquetas = etiquetas;
    }

    @Override
    public String toString() {
        return etiquetas == null || etiquetas.isBlank()
                ? "Imagen Pixabay " + pixabayId
                : etiquetas + " - " + autor;
    }
}