
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.modelo.Producto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/**
 * DAO encargado del acceso a datos de la entidad Producto.
 *
 * Realiza operaciones CRUD mediante JDBC y SQLite.
 */
public class ProductoDAO {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final int MAX_CODIGO = 30;
    private static final int MAX_NOMBRE = 120;
    private static final int MAX_DESCRIPCION = 500;

    private static final double STOCK_MAXIMO = 1_000_000_000.0;

    private static final String PATRON_CODIGO =
            "[A-Z0-9][A-Z0-9._/-]{0,29}";

    private static final Set<String> UNIDADES_VALIDAS = Set.of(
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    );

    private static final Set<String> UNIDADES_ENTERAS = Set.of(
            "UNIDAD",
            "CAJA",
            "PAQUETE"
    );

    private static final String COLUMNAS_PRODUCTO = """
            id_producto, codigo, nombre, descripcion,
            id_categoria, id_proveedor, unidad_medida, stock_minimo
            """;

    // ==========================================
    // 2. REGISTRAR PRODUCTO
    // ==========================================

    public boolean insertar(Producto producto) throws SQLException {

        validarDatosBasicos(producto);

        String sql = """
            INSERT INTO productos (
                codigo,
                nombre,
                descripcion,
                id_categoria,
                id_proveedor,
                unidad_medida,
                stock_minimo
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            asignarParametros(pstmt, producto);

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas == 1;

        } catch (SQLException e) {

            throw traducirErrorIntegridad(e);
        }
    }

    // ==========================================
    // 3. LISTAR TODOS LOS PRODUCTOS
    // ==========================================

    public ArrayList<Producto> listar() throws SQLException {

        ArrayList<Producto> productos = new ArrayList<>();

        String sql = """
            SELECT
            """ + COLUMNAS_PRODUCTO + """
            FROM productos
            ORDER BY nombre COLLATE NOCASE, id_producto
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {

                productos.add(mapearProducto(rs));
            }
        }

        return productos;
    }

    // ==========================================
    // 4. BUSCAR PRODUCTO POR ID
    // ==========================================

    public Producto buscarPorId(int idProducto) throws SQLException {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        String sql = """
            SELECT
            """ + COLUMNAS_PRODUCTO + """
            FROM productos
            WHERE id_producto = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, idProducto);

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 5. BUSCAR PRODUCTO POR CÓDIGO
    // ==========================================

    public Producto buscarPorCodigo(String codigo) throws SQLException {

        String codigoNormalizado = normalizarCodigo(codigo);

        String sql = """
            SELECT
            """ + COLUMNAS_PRODUCTO + """
            FROM productos
            WHERE codigo = ? COLLATE NOCASE
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, codigoNormalizado);

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 6. ACTUALIZAR PRODUCTO
    // ==========================================

    public boolean actualizar(Producto producto) throws SQLException {

        validarDatosBasicos(producto);

        if (producto.getIdProducto() <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        String sql = """
            UPDATE productos
            SET
                codigo = ?,
                nombre = ?,
                descripcion = ?,
                id_categoria = ?,
                id_proveedor = ?,
                unidad_medida = ?,
                stock_minimo = ?
            WHERE id_producto = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            asignarParametros(pstmt, producto);

            pstmt.setInt(8, producto.getIdProducto());

            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 1) {
                throw new SQLException(
                        "Se modificaron varios registros cuando "
                        + "solamente debía actualizarse uno."
                );
            }

            return filasAfectadas == 1;

        } catch (SQLException e) {

            throw traducirErrorIntegridad(e);
        }
    }

    // ==========================================
    // 7. ELIMINAR PRODUCTO
    // ==========================================

    public boolean eliminar(int idProducto) throws SQLException {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        String sql = """
            DELETE FROM productos
            WHERE id_producto = ?
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, idProducto);

            int filasAfectadas = pstmt.executeUpdate();

            if (filasAfectadas > 1) {
                throw new SQLException(
                        "La eliminación afectó más registros de los esperados."
                );
            }

            return filasAfectadas == 1;

        } catch (SQLException e) {

            throw traducirErrorIntegridad(e);
        }
    }

    // ==========================================
    // 8. ASIGNAR PARÁMETROS DEL PRODUCTO
    // ==========================================

    private void asignarParametros(
            PreparedStatement pstmt,
            Producto producto
    ) throws SQLException {

        pstmt.setString(1, producto.getCodigo());
        pstmt.setString(2, producto.getNombre());

        if (producto.getDescripcion() == null) {
            pstmt.setNull(3, Types.VARCHAR);
        } else {
            pstmt.setString(3, producto.getDescripcion());
        }

        if (producto.getIdCategoria() == null) {
            pstmt.setNull(4, Types.INTEGER);
        } else {
            pstmt.setInt(4, producto.getIdCategoria());
        }

        if (producto.getIdProveedor() == null) {
            pstmt.setNull(5, Types.INTEGER);
        } else {
            pstmt.setInt(5, producto.getIdProveedor());
        }

        pstmt.setString(6, producto.getUnidadMedida());
        pstmt.setDouble(7, producto.getStockMinimo());
    }

    // ==========================================
    // 9. VALIDACIONES BÁSICAS DE PERSISTENCIA
    // ==========================================

    private void validarDatosBasicos(Producto producto) {

        if (producto == null) {
            throw new IllegalArgumentException(
                    "El producto no puede ser nulo."
            );
        }

        // Código
        if (producto.getCodigo() == null
                || producto.getCodigo().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "El código del producto es obligatorio."
            );
        }

        String codigo = producto.getCodigo()
                .trim()
                .toUpperCase(Locale.ROOT);

        if (codigo.length() > MAX_CODIGO
                || !codigo.matches(PATRON_CODIGO)) {

            throw new IllegalArgumentException(
                    "El código del producto no tiene un formato válido."
            );
        }

        producto.setCodigo(codigo);

        // Nombre
        if (producto.getNombre() == null
                || producto.getNombre().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "El nombre del producto es obligatorio."
            );
        }

        String nombre = producto.getNombre().trim();

        if (nombre.codePointCount(0, nombre.length()) < 2
                || nombre.codePointCount(0, nombre.length()) > MAX_NOMBRE) {

            throw new IllegalArgumentException(
                    "El nombre debe tener entre 2 y 120 caracteres."
            );
        }

        producto.setNombre(nombre);

        // Descripción
        if (producto.getDescripcion() != null
                && producto.getDescripcion()
                        .codePointCount(
                                0,
                                producto.getDescripcion().length()
                        ) > MAX_DESCRIPCION) {

            throw new IllegalArgumentException(
                    "La descripción supera los 500 caracteres."
            );
        }

        // Categoría
        if (producto.getIdCategoria() != null
                && producto.getIdCategoria() <= 0) {

            throw new IllegalArgumentException(
                    "El ID de la categoría debe ser positivo."
            );
        }

        // Proveedor
        if (producto.getIdProveedor() != null
                && producto.getIdProveedor() <= 0) {

            throw new IllegalArgumentException(
                    "El ID del proveedor debe ser positivo."
            );
        }

        // Unidad de medida
        if (producto.getUnidadMedida() == null
                || producto.getUnidadMedida().trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "La unidad de medida es obligatoria."
            );
        }

        String unidad = producto.getUnidadMedida()
                .trim()
                .toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidad)) {
            throw new IllegalArgumentException(
                    "La unidad de medida no está permitida."
            );
        }

        producto.setUnidadMedida(unidad);

        // Stock mínimo
        double stock = producto.getStockMinimo();

        if (!Double.isFinite(stock)) {
            throw new IllegalArgumentException(
                    "El stock mínimo debe ser un número finito."
            );
        }

        if (stock < 0 || stock > STOCK_MAXIMO) {
            throw new IllegalArgumentException(
                    "El stock mínimo debe estar entre 0 y 1 000 000 000."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(stock)
                .stripTrailingZeros();

        if (valor.scale() > 3) {
            throw new IllegalArgumentException(
                    "El stock mínimo admite máximo tres decimales."
            );
        }

        if (UNIDADES_ENTERAS.contains(unidad)
                && stock != Math.floor(stock)) {

            throw new IllegalArgumentException(
                    "La unidad seleccionada requiere cantidades enteras."
            );
        }
    }

    // ==========================================
    // 10. NORMALIZAR CÓDIGO
    // ==========================================

    private String normalizarCodigo(String codigo) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Ingrese el código del producto."
            );
        }

        codigo = codigo.trim().toUpperCase(Locale.ROOT);

        if (codigo.length() > MAX_CODIGO
                || !codigo.matches(PATRON_CODIGO)) {

            throw new IllegalArgumentException(
                    "El formato del código no es válido."
            );
        }

        return codigo;
    }

    // ==========================================
    // 11. MAPEAR REGISTRO A OBJETO PRODUCTO
    // ==========================================

    private Producto mapearProducto(ResultSet rs) throws SQLException {

        int idCategoria = rs.getInt("id_categoria");
        Integer categoria = rs.wasNull() ? null : idCategoria;

        int idProveedor = rs.getInt("id_proveedor");
        Integer proveedor = rs.wasNull() ? null : idProveedor;

        return new Producto(
                rs.getInt("id_producto"),
                rs.getString("codigo"),
                rs.getString("nombre"),
                rs.getString("descripcion"),
                categoria,
                proveedor,
                rs.getString("unidad_medida"),
                rs.getDouble("stock_minimo")
        );
    }

    // ==========================================
    // 12. TRADUCIR ERRORES DE INTEGRIDAD SQLITE
    // ==========================================

    private SQLException traducirErrorIntegridad(SQLException e) {

        String mensaje = e.getMessage();

        if (mensaje == null) {
            return e;
        }

        String error = mensaje.toLowerCase(Locale.ROOT);

        // Código duplicado
        if (error.contains("unique constraint failed")) {
            return new SQLException(
                    "No se pudo guardar el producto porque "
                    + "el código ya está registrado.",
                    e
            );
        }

        // Relación con categorías, proveedores o movimientos
        if (error.contains("foreign key constraint failed")) {
            return new SQLException(
                    "No se puede completar la operación porque "
                    + "el producto tiene registros relacionados "
                    + "o utiliza una categoría o proveedor inexistente.",
                    e
            );
        }

        // Restricciones CHECK
        if (error.contains("check constraint failed")) {
            return new SQLException(
                    "Los datos del producto no cumplen "
                    + "las restricciones de la base de datos.",
                    e
            );
        }

        // Campos obligatorios
        if (error.contains("not null constraint failed")) {
            return new SQLException(
                    "Falta ingresar un dato obligatorio del producto.",
                    e
            );
        }

        return e;
    }
}
