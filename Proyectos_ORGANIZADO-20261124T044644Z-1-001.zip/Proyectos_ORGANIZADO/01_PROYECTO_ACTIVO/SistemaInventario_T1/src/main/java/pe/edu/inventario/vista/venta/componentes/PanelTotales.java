package pe.edu.inventario.vista.venta.componentes;

import javax.swing.*;
import java.awt.*;

// 4. Panel inferior de sumatorias (Subtotal, Descuento, IGV, Total)
public class PanelTotales extends JPanel {
    private JLabel lblSubtotal;
    private JLabel lblDescuento;
    private JLabel lblIgv;
    private JLabel lblTotal;

    public PanelTotales() {
        setLayout(new GridLayout(4, 2, 5, 5));
        setBorder(BorderFactory.createTitledBorder("Totales"));

        lblSubtotal = new JLabel("0.00");
        lblDescuento = new JLabel("0.00");
        lblIgv = new JLabel("0.00");
        lblTotal = new JLabel("0.00");

        // Formato para resaltar el TOTAL
        lblTotal.setFont(new Font("Arial", Font.BOLD, 18));
        lblTotal.setForeground(Color.RED);

        add(new JLabel("Subtotal: S/")); add(lblSubtotal);
        add(new JLabel("Descuento: S/")); add(lblDescuento);
        add(new JLabel("IGV (18%): S/")); add(lblIgv);
        add(new JLabel("TOTAL: S/")); add(lblTotal);
    }

    public void actualizarTotales(String sub, String descuento, String igv, String total) {
        lblSubtotal.setText(sub);
        lblDescuento.setText(descuento);
        lblIgv.setText(igv);
        lblTotal.setText(total);
    }
}
