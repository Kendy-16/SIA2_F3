# Cajas

Pendiente. Apertura/cierre de caja y arqueo.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
