package pe.edu.inventario.servicio.venta;

import pe.edu.inventario.modelo.venta.DetalleVenta;
import pe.edu.inventario.modelo.venta.Venta;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;

/**
 * Genera el comprobante (Boleta o Factura). Si el cliente se identifica con RUC (11 dígitos)
 * se emite Factura; en cualquier otro caso, Boleta. El ticket se guarda como .txt.
 */
public class DocumentoService {

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    private static final String LINEA = "------------------------------------------------";

    private final Path directorio;
    private int correlativoBoleta = 0;
    private int correlativoFactura = 0;

    public DocumentoService() {
        this(Paths.get("comprobantes"));
    }

    public DocumentoService(Path directorio) {
        this.directorio = directorio;
    }

    /**
     * Numera el comprobante, lo asigna a la venta y guarda el ticket en disco.
     * @return el número del comprobante (ej. B001-00000001)
     */
    public synchronized String generarComprobante(Venta venta) {
        boolean factura = venta.getIdCliente() != null && venta.getIdCliente().length() == 11;
        String numero = factura
                ? String.format("F001-%08d", ++correlativoFactura)
                : String.format("B001-%08d", ++correlativoBoleta);
        venta.setComprobante(numero);

        try {
            Files.createDirectories(directorio);
            Files.write(directorio.resolve(numero + ".txt"),
                    formatearTicket(venta).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            // Un fallo al escribir el archivo no debe tumbar una venta ya cobrada.
            System.err.println("Aviso: no se pudo guardar el ticket " + numero + ": " + e.getMessage());
        }
        return numero;
    }

    public String formatearTicket(Venta v) {
        boolean factura = v.getComprobante() != null && v.getComprobante().startsWith("F");
        StringBuilder sb = new StringBuilder();
        sb.append(LINEA).append('\n');
        sb.append(String.format("%-48s%n", "        SISTEMA DE INVENTARIO - VENTAS"));
        sb.append(factura ? "FACTURA ELECTRONICA " : "BOLETA DE VENTA ELECTRONICA ")
          .append(v.getComprobante() == null ? "(SIN NUMERAR)" : v.getComprobante()).append('\n');
        sb.append(LINEA).append('\n');
        sb.append("Venta:    ").append(v.getIdVenta()).append(" (").append(v.getTipoVenta()).append(")\n");
        sb.append("Estado:   ").append(v.getEstado()).append('\n');
        if (v.getFechaEmision() != null) {
            sb.append("Fecha:    ").append(v.getFechaEmision().format(FORMATO_FECHA)).append('\n');
        }
        sb.append("Cliente:  ").append(v.getIdCliente()).append(" - ")
          .append(v.getNombreCliente() == null ? "" : v.getNombreCliente()).append('\n');
        sb.append("Atendido: ").append(v.getIdUsuario()).append(" (").append(v.getRolUsuario()).append(")\n");
        sb.append(LINEA).append('\n');
        for (DetalleVenta d : v.getDetalles()) {
            String nombre = d.getNombreProducto() == null ? d.getCodigoProducto() : d.getNombreProducto();
            if (nombre.length() > 22) {
                nombre = nombre.substring(0, 22);
            }
            sb.append(String.format("%-22s %3d x %8s = %9s%n", nombre, d.getCantidad(),
                    d.getPrecioUnitario().toPlainString(), d.getSubtotalLinea().toPlainString()));
            if (d.getPorcentajeDescuento().signum() > 0) {
                sb.append(String.format("   (dscto %s%%)%n", d.getPorcentajeDescuento().stripTrailingZeros().toPlainString()));
            }
        }
        sb.append(LINEA).append('\n');
        sb.append(String.format("%-30s S/ %12s%n", "SUBTOTAL", v.getSubtotal().toPlainString()));
        sb.append(String.format("%-30s S/ %12s%n", "DESCUENTO", v.getDescuentoTotal().toPlainString()));
        sb.append(String.format("%-30s S/ %12s%n", "IGV (18%)", v.getImpuestos().toPlainString()));
        sb.append(String.format("%-30s S/ %12s%n", "TOTAL", v.getTotal().toPlainString()));
        sb.append(LINEA).append('\n');
        sb.append("Pago:     ").append(v.getMetodoPago()).append('\n');
        sb.append(String.format("Recibido: S/ %s   Vuelto: S/ %s%n",
                v.getMontoRecibido().toPlainString(), v.getVuelto().toPlainString()));
        if (v.getMotivoAnulacion() != null) {
            sb.append(LINEA).append('\n');
            sb.append("ANULADA por ").append(v.getUsuarioAutoriza()).append(": ")
              .append(v.getMotivoAnulacion()).append('\n');
        }
        sb.append(LINEA).append('\n');
        return sb.toString();
    }
}
