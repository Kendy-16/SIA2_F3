package pe.edu.inventario.vista.reportes;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Function;

/**
 * Panel genérico de reporte: título, tabla, botón Actualizar y totales.
 * Formatos por columna: null = texto; "%,.2f", "%.3f", "%.4f"...
 */
public class PanelReporteTabla extends JPanel {

    private final DefaultTableModel modelo;
    private final JTable tabla;
    private final JLabel lblTotales = new JLabel(" ");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final Callable<List<Object[]>> origen;
    private final Function<List<Object[]>, String> totales;

    public PanelReporteTabla(
            String titulo,
            String descripcion,
            String[] columnas,
            String[] formatos,
            Callable<List<Object[]>> origen,
            Function<List<Object[]>, String> totales
    ) {
        super(new BorderLayout(0, 10));
        this.origen = origen;
        this.totales = totales;

        setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(lblTitulo.getFont().deriveFont(Font.BOLD, 20f));

        JLabel lblDescripcion = new JLabel(descripcion);

        JPanel cabecera = new JPanel(new BorderLayout(0, 4));
        cabecera.setOpaque(false);
        cabecera.add(lblTitulo, BorderLayout.NORTH);
        cabecera.add(lblDescripcion, BorderLayout.CENTER);
        cabecera.add(btnActualizar, BorderLayout.EAST);
        add(cabecera, BorderLayout.NORTH);

        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        tabla.setRowHeight(26);
        tabla.setAutoCreateRowSorter(true);

        for (int i = 0; i < formatos.length && i < columnas.length; i++) {
            if (formatos[i] != null) {
                final String f = formatos[i];
                tabla.getColumnModel().getColumn(i).setCellRenderer(
                        new DefaultTableCellRenderer() {
                            {
                                setHorizontalAlignment(SwingConstants.RIGHT);
                            }

                            @Override
                            protected void setValue(Object valor) {
                                if (valor instanceof Number) {
                                    setText(String.format(
                                            java.util.Locale.US, f,
                                            ((Number) valor).doubleValue()));
                                } else {
                                    super.setValue(valor);
                                }
                            }
                        });
            }
        }

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        lblTotales.setFont(lblTotales.getFont().deriveFont(Font.BOLD, 14f));
        add(lblTotales, BorderLayout.SOUTH);

        btnActualizar.addActionListener(e -> cargar());

        cargar();
    }

    /** Vuelve a consultar la base de datos. */
    public void cargar() {

        btnActualizar.setEnabled(false);

        new SwingWorker<List<Object[]>, Void>() {

            @Override
            protected List<Object[]> doInBackground() throws Exception {
                return origen.call();
            }

            @Override
            protected void done() {
                try {
                    List<Object[]> filas = get();
                    modelo.setRowCount(0);
                    for (Object[] fila : filas) {
                        modelo.addRow(fila);
                    }
                    lblTotales.setText(
                            filas.isEmpty()
                                    ? "Sin datos para mostrar."
                                    : totales.apply(filas));
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                            PanelReporteTabla.this,
                            "No fue posible cargar el reporte.",
                            "Reporte",
                            JOptionPane.ERROR_MESSAGE);
                } finally {
                    btnActualizar.setEnabled(true);
                }
            }
        }.execute();
    }

    /** Suma de una columna numérica. */
    public static double sumar(List<Object[]> filas, int columna) {
        double total = 0;
        for (Object[] f : filas) {
            if (f[columna] instanceof Number) {
                total += ((Number) f[columna]).doubleValue();
            }
        }
        return total;
    }
}
