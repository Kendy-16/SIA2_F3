# Clientes

Pendiente. Registro y consulta de clientes (necesario para ventas).

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
