package pe.edu.inventario.vista.venta;

import pe.edu.inventario.modelo.venta.Venta;
import pe.edu.inventario.modelo.venta.DetalleVenta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class DetalleVentaView extends JDialog {

    private JTable tablaDetalle;
    private DefaultTableModel modelo;
    private JLabel lblTotal;
    private JLabel lblCliente;

    public DetalleVentaView(Frame parent, Venta venta) {
        super(parent, "Detalle Completo de Venta: " + venta.getIdVenta(), true);
        setLayout(new BorderLayout(10, 10));
        setSize(600, 400);
        setLocationRelativeTo(parent);

        // Cabecera informativa
        JPanel panelCabecera = new JPanel(new GridLayout(2, 2));
        panelCabecera.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelCabecera.add(new JLabel("Fecha: " + venta.getFechaEmision()));
        panelCabecera.add(new JLabel("Tipo: " + venta.getTipoVenta()));
        lblCliente = new JLabel("Cliente Doc: " + venta.getIdCliente());
        panelCabecera.add(lblCliente);
        panelCabecera.add(new JLabel("Estado: " + venta.getEstado()));

        // Tabla de productos
        String[] columnas = {"Código", "Producto", "Cant.", "P. Unit", "Dscto", "Subtotal"};
        modelo = new DefaultTableModel(columnas, 0);
        tablaDetalle = new JTable(modelo);

        for (DetalleVenta det : venta.getDetalles()) {
            modelo.addRow(new Object[]{
                det.getCodigoProducto(), det.getNombreProducto(), det.getCantidad(),
                det.getPrecioUnitario(), det.getPorcentajeDescuento() + "%", det.getSubtotalLinea()
            });
        }

        // Pie de totales
        JPanel panelPie = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        lblTotal = new JLabel("TOTAL GENERAL: S/ " + venta.getTotal());
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
        panelPie.add(lblTotal);

        add(panelCabecera, BorderLayout.NORTH);
        add(new JScrollPane(tablaDetalle), BorderLayout.CENTER);
        add(panelPie, BorderLayout.SOUTH);
    }
}
