
package pe.edu.inventario.controlador;

import pe.edu.inventario.servicio.LoginService;

import java.sql.SQLException;

public class LoginController {

    private final LoginService loginService;

    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public LoginController() {
        this.loginService = new LoginService();
    }

    // Dependency injection
    public LoginController(LoginService loginService) {

        if (loginService == null) {
            throw new IllegalArgumentException(
                    "El servicio de autenticacion es obligatorio."
            );
        }

        this.loginService = loginService;
    }

    // ==========================================
    // VERIFY CREDENTIALS
    // ==========================================

    public boolean verificarCredenciales(
            String usuario,
            String password
    ) {

        try {

            return loginService.verificarCredenciales(
                    usuario,
                    password
            );

        } catch (SQLException ex) {

            throw new IllegalStateException(
                    "No fue posible verificar las credenciales.",
                    ex
            );
        }
    }

    // ==========================================
    // GET ROLE
    // ==========================================

    public String obtenerRol(String usuario) {

        try {

            return loginService.obtenerRol(usuario);

        } catch (SQLException ex) {

            // Ante la duda, el rol con menos privilegios.
            return "USUARIO";
        }
    }

    // ==========================================
    // CHECK REGISTERED USERS
    // ==========================================

    public boolean hayUsuariosRegistrados() {

        try {

            return loginService.hayUsuariosRegistrados();

        } catch (SQLException ex) {

            throw new IllegalStateException(
                    "No fue posible consultar los usuarios.",
                    ex
            );
        }
    }

    // ==========================================
    // REGISTER FIRST ADMINISTRATOR
    // ==========================================

    public void registrarPrimerAdministrador(
            String usuario,
            char[] password
    ) {

        try {

            loginService.registrarPrimerAdministrador(
                    usuario,
                    password
            );

        } catch (SQLException ex) {

            throw new IllegalStateException(
                    "No fue posible registrar el administrador.",
                    ex
            );
        }
    }
}
