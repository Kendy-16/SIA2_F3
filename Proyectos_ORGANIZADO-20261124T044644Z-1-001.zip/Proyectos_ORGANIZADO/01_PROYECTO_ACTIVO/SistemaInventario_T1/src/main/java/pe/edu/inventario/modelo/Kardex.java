
package pe.edu.inventario.modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

public final class Kardex {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final BigDecimal VALOR_MAXIMO =
            new BigDecimal("1000000000000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;

    private static final int MAX_DECIMALES_COSTO = 6;

    private static final int MAX_DOCUMENTO = 50;

    private static final Set<String> TIPOS_VALIDOS = Set.of(
            "ENTRADA",
            "SALIDA",
            "AJUSTE"
    );

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile(
                    "^[A-Z0-9][A-Z0-9._/-]{0,49}$"
            );

    private static final DateTimeFormatter FORMATO_FECHA =
            DateTimeFormatter.ofPattern(
                    "uuuu-MM-dd HH:mm:ss",
                    Locale.ROOT
            ).withResolverStyle(ResolverStyle.STRICT);

    // ==========================================
    // 2. ATRIBUTOS INMUTABLES
    // ==========================================

    private final int idKardex;
    private final int idProducto;
    private final int idAlmacen;

    private final String fecha;
    private final String tipo;
    private final String documento;

    private final BigDecimal entrada;
    private final BigDecimal salida;
    private final BigDecimal saldo;

    private final BigDecimal costoUnitario;
    private final BigDecimal costoPromedio;
    private final BigDecimal valorSaldo;

    // ==========================================
    // 3. CONSTRUCTOR COMPLETO
    // ==========================================

    public Kardex(
            int idKardex,
            int idProducto,
            int idAlmacen,
            String fecha,
            String tipo,
            String documento,
            BigDecimal entrada,
            BigDecimal salida,
            BigDecimal saldo,
            BigDecimal costoUnitario,
            BigDecimal costoPromedio,
            BigDecimal valorSaldo
    ) {

        // Validate identifiers
        validarIdentificadores(
                idKardex,
                idProducto,
                idAlmacen
        );

        // Normalize and validate text
        this.fecha = validarFecha(fecha);

        this.tipo = validarTipo(tipo);

        this.documento = validarDocumento(documento);

        // Validate quantities
        this.entrada = validarCantidad(
                entrada,
                "La entrada"
        );

        this.salida = validarCantidad(
                salida,
                "La salida"
        );

        this.saldo = validarCantidad(
                saldo,
                "El saldo"
        );

        // Validate costs
        this.costoUnitario = validarCosto(
                costoUnitario,
                "El costo unitario"
        );

        this.costoPromedio = validarCosto(
                costoPromedio,
                "El costo promedio"
        );

        // Validate total inventory value
        this.valorSaldo = validarValorSaldo(valorSaldo);

        // Validate movement consistency
        validarCoherenciaMovimiento();

        // Validate inventory valuation
        validarValorizacion();

        // Assign identifiers
        this.idKardex = idKardex;
        this.idProducto = idProducto;
        this.idAlmacen = idAlmacen;
    }

    // ==========================================
    // 4. VALIDAR IDENTIFICADORES
    // ==========================================

    private void validarIdentificadores(
            int idKardex,
            int idProducto,
            int idAlmacen
    ) {

        if (idKardex < 0) {
            throw new IllegalArgumentException(
                    "El ID del kardex no puede ser negativo."
            );
        }

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // 5. VALIDAR FECHA
    // ==========================================

    private String validarFecha(String fecha) {

        if (fecha == null || fecha.isBlank()) {
            throw new IllegalArgumentException(
                    "La fecha del kardex es obligatoria."
            );
        }

        String normalizada = fecha.trim().replace('T', ' ');

        try {

            LocalDateTime fechaValidada =
                    LocalDateTime.parse(
                            normalizada,
                            FORMATO_FECHA
                    );

            return fechaValidada.format(FORMATO_FECHA);

        } catch (DateTimeParseException ex) {

            throw new IllegalArgumentException(
                    "La fecha debe tener el formato yyyy-MM-dd HH:mm:ss.",
                    ex
            );
        }
    }

    // ==========================================
    // 6. VALIDAR TIPO DE MOVIMIENTO
    // ==========================================

    private String validarTipo(String tipo) {

        if (tipo == null || tipo.isBlank()) {
            throw new IllegalArgumentException(
                    "El tipo de movimiento es obligatorio."
            );
        }

        String normalizado =
                tipo.trim().toUpperCase(Locale.ROOT);

        if (!TIPOS_VALIDOS.contains(normalizado)) {
            throw new IllegalArgumentException(
                    "El tipo debe ser ENTRADA, SALIDA o AJUSTE."
            );
        }

        return normalizado;
    }

    // ==========================================
    // 7. VALIDAR DOCUMENTO
    // ==========================================

    private String validarDocumento(String documento) {

        if (documento == null || documento.isBlank()) {
            throw new IllegalArgumentException(
                    "El documento es obligatorio."
            );
        }

        String normalizado =
                documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(
                        normalizado
                ).matches()) {

            throw new IllegalArgumentException(
                    "El documento tiene un formato no valido."
            );
        }

        return normalizado;
    }

    // ==========================================
    // 8. VALIDAR CANTIDADES
    // ==========================================

    private BigDecimal validarCantidad(
            BigDecimal valor,
            String nombreCampo
    ) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    nombreCampo + " no puede ser nula."
            );
        }

        if (valor.signum() < 0) {
            throw new IllegalArgumentException(
                    nombreCampo + " no puede ser negativa."
            );
        }

        BigDecimal normalizado =
                valor.stripTrailingZeros();

        if (normalizado.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    nombreCampo + " supera el limite permitido."
            );
        }

        if (normalizado.scale() > MAX_DECIMALES_CANTIDAD) {
            throw new IllegalArgumentException(
                    nombreCampo + " admite como maximo 3 decimales."
            );
        }

        return normalizado.setScale(
                MAX_DECIMALES_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // ==========================================
    // 9. VALIDAR COSTOS
    // ==========================================

    private BigDecimal validarCosto(
            BigDecimal valor,
            String nombreCampo
    ) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    nombreCampo + " no puede ser nulo."
            );
        }

        if (valor.signum() < 0) {
            throw new IllegalArgumentException(
                    nombreCampo + " no puede ser negativo."
            );
        }

        BigDecimal normalizado =
                valor.stripTrailingZeros();

        if (normalizado.compareTo(COSTO_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    nombreCampo + " supera el limite permitido."
            );
        }

        if (normalizado.scale() > MAX_DECIMALES_COSTO) {
            throw new IllegalArgumentException(
                    nombreCampo + " admite como maximo 6 decimales."
            );
        }

        return normalizado.setScale(
                MAX_DECIMALES_COSTO,
                RoundingMode.UNNECESSARY
        );
    }

    // ==========================================
    // 10. VALIDAR VALOR DEL SALDO
    // ==========================================

    private BigDecimal validarValorSaldo(
            BigDecimal valor
    ) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    "El valor del saldo es obligatorio."
            );
        }

        if (valor.signum() < 0) {
            throw new IllegalArgumentException(
                    "El valor del saldo no puede ser negativo."
            );
        }

        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El valor del saldo supera el limite permitido."
            );
        }

        return valor.setScale(
                MAX_DECIMALES_COSTO,
                RoundingMode.HALF_UP
        );
    }

    // ==========================================
    // 11. VALIDAR COHERENCIA DEL MOVIMIENTO
    // ==========================================

    private void validarCoherenciaMovimiento() {

        boolean tieneEntrada = entrada.signum() > 0;

        boolean tieneSalida = salida.signum() > 0;

        switch (tipo) {

            case "ENTRADA":

                if (!tieneEntrada || tieneSalida) {
                    throw new IllegalArgumentException(
                            "Una ENTRADA debe tener entrada positiva y salida cero."
                    );
                }

                break;

            case "SALIDA":

                if (tieneEntrada || !tieneSalida) {
                    throw new IllegalArgumentException(
                            "Una SALIDA debe tener salida positiva y entrada cero."
                    );
                }

                break;

            case "AJUSTE":

                if (tieneEntrada == tieneSalida) {
                    throw new IllegalArgumentException(
                            "Un AJUSTE debe tener entrada o salida, pero no ambas."
                    );
                }

                break;

            default:

                throw new IllegalArgumentException(
                        "Tipo de movimiento no reconocido."
                );
        }

        // Exits and adjustments use the current average cost.
        if (!tipo.equals("ENTRADA")
                && costoUnitario.compareTo(costoPromedio) != 0) {

            throw new IllegalArgumentException(
                    "En salidas y ajustes, el costo unitario debe coincidir con el costo promedio."
            );
        }
    }

    // ==========================================
    // 12. VALIDAR VALORIZACION
    // ==========================================

    private void validarValorizacion() {

        BigDecimal valorCalculado =
                saldo.multiply(costoPromedio)
                        .setScale(
                                MAX_DECIMALES_COSTO,
                                RoundingMode.HALF_UP
                        );

        if (valorSaldo.compareTo(valorCalculado) != 0) {

            throw new IllegalArgumentException(
                    "El valor del saldo no coincide con la cantidad por el costo promedio."
            );
        }
    }

    // ==========================================
    // 13. GETTERS
    // ==========================================

    public int getIdKardex() {
        return idKardex;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public int getIdAlmacen() {
        return idAlmacen;
    }

    public String getFecha() {
        return fecha;
    }

    public String getTipo() {
        return tipo;
    }

    public String getDocumento() {
        return documento;
    }

    public BigDecimal getEntrada() {
        return entrada;
    }

    public BigDecimal getSalida() {
        return salida;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public BigDecimal getCostoUnitario() {
        return costoUnitario;
    }

    public BigDecimal getCostoPromedio() {
        return costoPromedio;
    }

    public BigDecimal getValorSaldo() {
        return valorSaldo;
    }

    // ==========================================
    // 14. METODOS AUXILIARES
    // ==========================================

    public boolean esEntrada() {
        return tipo.equals("ENTRADA");
    }

    public boolean esSalida() {
        return tipo.equals("SALIDA");
    }

    public boolean esAjuste() {
        return tipo.equals("AJUSTE");
    }

    public boolean tieneEntrada() {
        return entrada.signum() > 0;
    }

    public boolean tieneSalida() {
        return salida.signum() > 0;
    }

    public boolean tieneSaldo() {
        return saldo.signum() > 0;
    }

    @Override
    public String toString() {

        return "Kardex{" +
                "idKardex=" + idKardex +
                ", idProducto=" + idProducto +
                ", idAlmacen=" + idAlmacen +
                ", fecha='" + fecha + '\'' +
                ", tipo='" + tipo + '\'' +
                ", documento='" + documento + '\'' +
                ", entrada=" + entrada +
                ", salida=" + salida +
                ", saldo=" + saldo +
                ", costoPromedio=" + costoPromedio +
                ", valorSaldo=" + valorSaldo +
                '}';
    }
}
