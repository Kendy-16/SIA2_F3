
package pe.edu.inventario.modelo;

import java.math.BigDecimal;

public class DetalleInventarioFisico {

    private final int idDetalle;
    private final int idToma;
    private final int idProducto;

    private final String codigoProducto;
    private final String nombreProducto;
    private final String unidadMedida;

    private final BigDecimal stockSistema;
    private BigDecimal cantidadFisica;
    private BigDecimal diferencia;

    private final BigDecimal costoPromedio;
    private BigDecimal impactoValorizado;

    private String observacion;

    public DetalleInventarioFisico(
            int idDetalle,
            int idToma,
            int idProducto,
            String codigoProducto,
            String nombreProducto,
            String unidadMedida,
            BigDecimal stockSistema,
            BigDecimal cantidadFisica,
            BigDecimal costoPromedio,
            String observacion
    ) {

        if (idToma <= 0 || idProducto <= 0) {
            throw new IllegalArgumentException(
                    "Los identificadores deben ser positivos."
            );
        }

        this.idDetalle = idDetalle;
        this.idToma = idToma;
        this.idProducto = idProducto;

        this.codigoProducto = codigoProducto;
        this.nombreProducto = nombreProducto;
        this.unidadMedida = unidadMedida;

        this.stockSistema = validarDecimal(
                stockSistema, "Stock del sistema"
        );

        this.cantidadFisica = cantidadFisica == null
                ? null
                : validarDecimal(cantidadFisica, "Cantidad física");

        this.costoPromedio = validarDecimal(
                costoPromedio, "Costo promedio"
        );

        this.observacion = observacion;

        calcularDiferencia();
    }

    private BigDecimal validarDecimal(
            BigDecimal valor,
            String campo
    ) {

        if (valor == null || valor.signum() < 0) {
            throw new IllegalArgumentException(
                    campo + " no puede ser nulo ni negativo."
            );
        }

        return valor;
    }

    public void calcularDiferencia() {

        if (cantidadFisica == null) {
            diferencia = null;
            impactoValorizado = null;
            return;
        }

        diferencia = cantidadFisica.subtract(stockSistema);

        impactoValorizado = diferencia
                .multiply(costoPromedio)
                .setScale(6, java.math.RoundingMode.HALF_UP);
    }

    public boolean estaContado() {
        return cantidadFisica != null;
    }

    public boolean tieneFaltante() {
        return diferencia != null
                && diferencia.signum() < 0;
    }

    public boolean tieneSobrante() {
        return diferencia != null
                && diferencia.signum() > 0;
    }

    public boolean estaConforme() {
        return diferencia != null
                && diferencia.signum() == 0;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public int getIdToma() {
        return idToma;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public BigDecimal getStockSistema() {
        return stockSistema;
    }

    public BigDecimal getCantidadFisica() {
        return cantidadFisica;
    }

    public BigDecimal getDiferencia() {
        return diferencia;
    }

    public BigDecimal getCostoPromedio() {
        return costoPromedio;
    }

    public BigDecimal getImpactoValorizado() {
        return impactoValorizado;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setCantidadFisica(BigDecimal cantidadFisica) {

        this.cantidadFisica = cantidadFisica == null
                ? null
                : validarDecimal(cantidadFisica, "Cantidad física");

        calcularDiferencia();
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
}
