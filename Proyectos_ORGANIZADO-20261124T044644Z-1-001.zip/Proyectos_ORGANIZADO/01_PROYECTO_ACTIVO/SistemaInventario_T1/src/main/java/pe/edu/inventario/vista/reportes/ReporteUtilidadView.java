package pe.edu.inventario.vista.reportes;

import pe.edu.inventario.modelo.dao.ReporteDAO;

import java.awt.BorderLayout;
import javax.swing.JPanel;

/** Utilidad bruta por artículo: ventas netas - costo de ventas. */
public class ReporteUtilidadView extends JPanel {

    public ReporteUtilidadView() {
        super(new BorderLayout());

        ReporteDAO dao = new ReporteDAO();

        add(new PanelReporteTabla(
                "Utilidad bruta por artículo",
                "Ventas netas (sin IGV) menos costo de ventas al costo promedio.",
                new String[]{"Código", "Producto", "Cant. vendida",
                        "Ventas netas", "Costo de ventas",
                        "Utilidad bruta", "Margen %"},
                new String[]{null, null, "%.3f", "%,.2f", "%,.2f", "%,.2f", "%.2f"},
                dao::utilidadBruta,
                filas -> String.format(java.util.Locale.US,
                        "Ventas: S/ %,.2f   |   Costo: S/ %,.2f   |   Utilidad bruta: S/ %,.2f",
                        PanelReporteTabla.sumar(filas, 3),
                        PanelReporteTabla.sumar(filas, 4),
                        PanelReporteTabla.sumar(filas, 5))
        ), BorderLayout.CENTER);
    }
}
