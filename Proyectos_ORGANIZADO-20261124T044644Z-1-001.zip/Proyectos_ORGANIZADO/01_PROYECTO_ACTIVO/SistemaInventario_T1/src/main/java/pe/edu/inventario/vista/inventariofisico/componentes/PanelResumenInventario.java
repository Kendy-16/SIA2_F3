package pe.edu.inventario.vista.inventariofisico.componentes;

import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.PermisosVistaInventario;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Cinco tarjetas con los indicadores generales del inventario físico. */
public class PanelResumenInventario extends JPanel {
    private static final String[] NOMBRES = {"Tomas realizadas", "Tomas abiertas", "Tomas conciliadas", "Productos con diferencias", "Ajustes pendientes"};
    private final JLabel[] valores = new JLabel[NOMBRES.length];

    public PanelResumenInventario() {
        super(new GridLayout(1, NOMBRES.length, 10, 0));
        setOpaque(false);
        for (int i = 0; i < NOMBRES.length; i++) {
            JPanel card = new JPanel(new BorderLayout(4, 7));
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDE), new EmptyBorder(13, 14, 13, 14)));
            JLabel nombre = new JLabel(NOMBRES[i]);
            nombre.setForeground(MUTED);
            nombre.setFont(nombre.getFont().deriveFont(11f));
            valores[i] = new JLabel(SIN_DATO);
            valores[i].setForeground(NAVY);
            valores[i].setFont(valores[i].getFont().deriveFont(Font.BOLD, 25f));
            card.add(nombre, BorderLayout.NORTH);
            card.add(valores[i], BorderLayout.CENTER);
            add(card);
        }
    }

    public void actualizar(Resumen r) {
        valores[0].setText(String.valueOf(r.tomasRealizadas()));
        valores[1].setText(String.valueOf(r.tomasAbiertas()));
        valores[2].setText(String.valueOf(r.tomasConciliadas()));
        valores[3].setText(String.valueOf(r.productosConDiferencias()));
        valores[4].setText(String.valueOf(r.ajustesPendientes()));
    }
}
