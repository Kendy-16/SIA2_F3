package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/**
 * Registra el segundo conteo. Lista los productos que ya tienen primer conteo; el usuario elige uno
 * (llega preseleccionado el de la pantalla de conteo) e ingresa la nueva cantidad.
 */
public class SegundoConteoDialog extends JDialog {
    private final InventarioFisicoController controller;
    private final long idToma;
    private final Runnable alGuardar;
    private final TablaSegundoConteoModel modelo = new TablaSegundoConteoModel();
    private final JTable tabla = new JTable(modelo);
    private final JLabel producto = new JLabel("Selecciona un producto de la lista");
    private final JTextField cantidad = new JTextField(10);
    private final PanelObservaciones observacion = new PanelObservaciones("Observación:", 3);

    public SegundoConteoDialog(Window owner, InventarioFisicoController controller, long idToma, List<Producto> productos,
                               Producto inicial, Runnable alGuardar) {
        super(owner, "Segundo conteo", ModalityType.APPLICATION_MODAL);
        this.controller = controller; this.idToma = idToma; this.alGuardar = alGuardar;
        setSize(760, 560); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));

        modelo.setProductos(productos);
        estiloTabla(tabla);
        tabla.setDefaultRenderer(Object.class, rendererTexto());
        tabla.setDefaultRenderer(BigDecimal.class, new CantidadRenderer());
        tabla.getColumnModel().getColumn(5).setCellRenderer(new EstadoConteoRenderer());
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(12, 14, 0, 14), scroll.getBorder()));
        add(scroll, BorderLayout.NORTH);
        scroll.setPreferredSize(new Dimension(700, 200));

        JPanel form = new JPanel(new BorderLayout(8, 8));
        form.setBorder(new EmptyBorder(0, 20, 8, 20));
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        fila.add(producto);
        fila.add(new JLabel("Segundo conteo:"));
        fila.add(cantidad);
        form.add(fila, BorderLayout.NORTH);
        form.add(observacion, BorderLayout.CENTER);
        add(form, BorderLayout.CENTER);

        JButton cancelar = botonSecundario("Cancelar"), guardar = botonPrimario("Guardar segundo conteo");
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(cancelar); abajo.add(guardar);
        add(abajo, BorderLayout.SOUTH);

        tabla.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) mostrar(); });
        cancelar.addActionListener(e -> dispose());
        guardar.addActionListener(e -> guardar());
        cantidad.addActionListener(e -> guardar());

        if (inicial != null) {
            for (int i = 0; i < modelo.getRowCount(); i++) {
                if (modelo.getProducto(i).id() == inicial.id()) { int v = tabla.convertRowIndexToView(i); tabla.setRowSelectionInterval(v, v); break; }
            }
        }
    }

    private Producto seleccionado() {
        int fila = tabla.getSelectedRow();
        return fila < 0 ? null : modelo.getProducto(tabla.convertRowIndexToModel(fila));
    }

    private void mostrar() {
        Producto p = seleccionado();
        if (p == null) { producto.setText("Selecciona un producto de la lista"); cantidad.setText(""); observacion.setTexto(""); return; }
        producto.setText(p.codigo() + " · " + p.nombre() + " (" + p.unidad() + ") · 1.er conteo: " + cantidad(p.cantidadContada()));
        cantidad.setText(p.segundoConteo() == null ? "" : cantidad(p.segundoConteo()));
        observacion.setTexto(p.observacion());
    }

    private void guardar() {
        Producto p = seleccionado();
        if (p == null) { MensajesInventarioFisico.advertencia(this, MensajesInventarioFisico.SELECCIONA_PRODUCTO); return; }
        ValidadorFormularioConteo.Resultado r = ValidadorFormularioConteo.validar(cantidad.getText(), p.unidad(), true, true);
        if (!r.esValido()) { MensajesInventarioFisico.advertencia(this, r.error()); return; }
        String obs = observacion.getTexto();
        TareaAsincrona.ejecutar(this, () -> { controller.registrarConteo(idToma, p.id(), r.cantidad(), obs, true); return true; },
                ok -> { alGuardar.run(); dispose(); });
    }
}
