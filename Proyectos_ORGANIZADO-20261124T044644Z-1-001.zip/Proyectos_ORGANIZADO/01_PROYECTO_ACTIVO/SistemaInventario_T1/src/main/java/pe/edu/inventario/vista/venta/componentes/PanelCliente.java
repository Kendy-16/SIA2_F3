package pe.edu.inventario.vista.venta.componentes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

// 1. Panel para buscar y seleccionar Cliente
public class PanelCliente extends JPanel {
    private JTextField txtDocumento;
    private JTextField txtNombre;
    private JButton btnBuscar;

    public PanelCliente() {
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setBorder(BorderFactory.createTitledBorder("Datos del Cliente"));

        txtDocumento = new JTextField(12);
        txtNombre = new JTextField(30);
        txtNombre.setEditable(false);
        btnBuscar = new JButton("Buscar");

        add(new JLabel("Doc/RUC:"));
        add(txtDocumento);
        add(btnBuscar);
        add(new JLabel("Nombre:"));
        add(txtNombre);
    }

    // Métodos para obtener/setear datos desde el Controlador
    public String getDocumento() { return txtDocumento.getText(); }
    public void setDocumento(String documento) { this.txtDocumento.setText(documento); }
    public void setNombre(String nombre) { this.txtNombre.setText(nombre); }

    /** El listener se dispara con el botón Buscar y con Enter dentro del campo de documento. */
    public void addBuscarListener(ActionListener listener) {
        btnBuscar.addActionListener(listener);
        txtDocumento.addActionListener(listener);
    }
}
