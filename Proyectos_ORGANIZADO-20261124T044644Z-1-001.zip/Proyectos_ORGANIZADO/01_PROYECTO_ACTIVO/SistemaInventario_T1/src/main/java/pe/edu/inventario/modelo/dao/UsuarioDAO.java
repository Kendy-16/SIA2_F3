
package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Handles database operations for users.
 */
public class UsuarioDAO {

    // ==========================================
    // 1. SEARCH USER
    // ==========================================

    public Usuario buscarPorUsuario(String nombreUsuario)
            throws SQLException {

        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "El nombre de usuario es obligatorio."
            );
        }

        String sql = """
            SELECT
                id_usuario,
                usuario,
                password_hash,
                password_salt,
                activo,
                intentos_fallidos,
                bloqueado_hasta,
                rol
            FROM usuarios
            WHERE usuario = ? COLLATE NOCASE
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, nombreUsuario.trim());

            try (ResultSet rs = pstmt.executeQuery()) {

                if (rs.next()) {

                    return mapearUsuario(rs);
                }
            }
        }

        return null;
    }

    // ==========================================
    // 2. CHECK IF USERS EXIST
    // ==========================================

    public boolean existeUsuarios() throws SQLException {

        String sql = """
            SELECT EXISTS(
                SELECT 1 FROM usuarios LIMIT 1
            )
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            return rs.next() && rs.getInt(1) == 1;
        }
    }

    // ==========================================
    // 3. INSERT FIRST ADMINISTRATOR
    // ==========================================

    public boolean insertar(Usuario usuario) throws SQLException {

        if (usuario == null) {
            throw new IllegalArgumentException(
                    "El usuario no puede ser nulo."
            );
        }

        String sql = """
            INSERT INTO usuarios (
                usuario,
                password_hash,
                password_salt,
                activo,
                intentos_fallidos,
                rol
            )
            VALUES (?, ?, ?, ?, 0, ?)
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setString(1, usuario.getUsuario());
            pstmt.setString(2, usuario.getPasswordHash());
            pstmt.setString(3, usuario.getPasswordSalt());
            pstmt.setInt(4, usuario.isActivo() ? 1 : 0);
            pstmt.setString(5, usuario.getRol());

            return pstmt.executeUpdate() == 1;
        }
    }

    // ==========================================
    // 4. UPDATE FAILED LOGIN ATTEMPTS
    // ==========================================

    public void actualizarIntentos(
            int idUsuario,
            int intentos,
            Long bloqueadoHasta
    ) throws SQLException {

        if (idUsuario <= 0) {
            throw new IllegalArgumentException(
                    "El ID de usuario debe ser positivo."
            );
        }

        if (intentos < 0 || intentos > 5) {
            throw new IllegalArgumentException(
                    "La cantidad de intentos no es valida."
            );
        }

        String sql = """
            UPDATE usuarios
            SET intentos_fallidos = ?,
                bloqueado_hasta = ?
            WHERE id_usuario = ?
              AND activo = 1
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, intentos);

            if (bloqueadoHasta == null) {
                pstmt.setNull(2, Types.BIGINT);
            } else {
                pstmt.setLong(2, bloqueadoHasta);
            }

            pstmt.setInt(3, idUsuario);

            if (pstmt.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo actualizar el estado de acceso."
                );
            }
        }
    }

    // ==========================================
    // 5. REGISTER SUCCESSFUL ACCESS
    // ==========================================

    public void registrarAccesoExitoso(int idUsuario)
            throws SQLException {

        if (idUsuario <= 0) {
            throw new IllegalArgumentException(
                    "El ID de usuario debe ser positivo."
            );
        }

        String sql = """
            UPDATE usuarios
            SET intentos_fallidos = 0,
                bloqueado_hasta = NULL,
                ultimo_acceso = CURRENT_TIMESTAMP
            WHERE id_usuario = ?
              AND activo = 1
            """;

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement pstmt = conexion.prepareStatement(sql)) {

            pstmt.setInt(1, idUsuario);

            if (pstmt.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar el acceso del usuario."
                );
            }
        }
    }

    // ==========================================
    // 6. MAP DATABASE RECORD
    // ==========================================

    private Usuario mapearUsuario(ResultSet rs)
            throws SQLException {

        long bloqueo = rs.getLong("bloqueado_hasta");

        Long bloqueadoHasta = rs.wasNull()
                ? null
                : bloqueo;

        Usuario u = new Usuario(
                rs.getInt("id_usuario"),
                rs.getString("usuario"),
                rs.getString("password_hash"),
                rs.getString("password_salt"),
                rs.getInt("activo") == 1,
                rs.getInt("intentos_fallidos"),
                bloqueadoHasta
        );

        u.setRol(rs.getString("rol"));

        return u;
    }
}
