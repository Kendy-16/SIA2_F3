# Devoluciones

Pendiente. Devoluciones de compra y de venta.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
