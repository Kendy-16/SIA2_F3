package pe.edu.inventario.servicio.venta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Caja en memoria (Requisito 9): registra los ingresos por venta, valida que el
 * medio de pago esté habilitado y lleva el saldo.
 */
public class CajaService {

    public static final String EFECTIVO = "Efectivo";

    public static class MovimientoCaja {
        private final String idVenta;
        private final String tipo; // INGRESO | EGRESO
        private final BigDecimal monto;
        private final String metodoPago;

        MovimientoCaja(String idVenta, String tipo, BigDecimal monto, String metodoPago) {
            this.idVenta = idVenta;
            this.tipo = tipo;
            this.monto = monto;
            this.metodoPago = metodoPago;
        }

        public String getIdVenta() { return idVenta; }
        public String getTipo() { return tipo; }
        public BigDecimal getMonto() { return monto; }
        public String getMetodoPago() { return metodoPago; }

        @Override
        public String toString() {
            return String.format("%-10s %-7s S/ %9s  %s", idVenta, tipo, monto.toPlainString(), metodoPago);
        }
    }

    private final Set<String> mediosHabilitados = new LinkedHashSet<>(Arrays.asList(
            EFECTIVO, "Tarjeta Crédito/Débito", "Transferencia / Yape / Plin"));
    private final List<MovimientoCaja> movimientos = new ArrayList<>();
    private BigDecimal saldo = BigDecimal.ZERO;

    public synchronized boolean medioHabilitado(String metodoPago) {
        return metodoPago != null && mediosHabilitados.contains(metodoPago);
    }

    public synchronized Set<String> getMediosHabilitados() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(mediosHabilitados));
    }

    public synchronized void registrarIngresoVenta(String idVenta, BigDecimal total, String metodoPago)
            throws VentaException {
        if (!medioHabilitado(metodoPago)) {
            throw new VentaException("Medio de pago no habilitado: " + metodoPago);
        }
        movimientos.add(new MovimientoCaja(idVenta, "INGRESO", total, metodoPago));
        saldo = saldo.add(total);
    }

    /** Devuelve el dinero a caja cuando se anula una venta o se revierte una operación fallida. */
    public synchronized void registrarReversaVenta(String idVenta, BigDecimal total, String metodoPago) {
        movimientos.add(new MovimientoCaja(idVenta, "EGRESO", total, metodoPago));
        saldo = saldo.subtract(total);
    }

    public synchronized BigDecimal getSaldo() { return saldo; }

    public synchronized List<MovimientoCaja> getMovimientos() {
        return Collections.unmodifiableList(new ArrayList<>(movimientos));
    }
}
