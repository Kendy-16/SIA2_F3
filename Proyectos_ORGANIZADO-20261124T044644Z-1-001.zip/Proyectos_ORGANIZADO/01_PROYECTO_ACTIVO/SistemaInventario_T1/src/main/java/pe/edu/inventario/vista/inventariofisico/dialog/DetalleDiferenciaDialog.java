package pe.edu.inventario.vista.inventariofisico.dialog;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Detalle de una diferencia con la posibilidad de guardar una explicación. */
public class DetalleDiferenciaDialog extends JDialog {
    public DetalleDiferenciaDialog(Window owner, InventarioFisicoController controller, long idToma, Diferencia d, Runnable alGuardar) {
        super(owner, "Detalle de diferencia", ModalityType.APPLICATION_MODAL);
        setSize(590, 520); setLocationRelativeTo(owner); setLayout(new BorderLayout(10, 10));
        JPanel datos = new JPanel(new GridLayout(0, 2, 8, 8));
        datos.setBorder(new EmptyBorder(18, 20, 8, 20));
        par(datos, "Código", d.producto().codigo());
        par(datos, "Producto", d.producto().nombre());
        par(datos, "Almacén / ubicación", d.producto().ubicacion());
        par(datos, "Stock del sistema", cantidad(d.stockSistema()));
        par(datos, "Cantidad física", cantidad(d.cantidadFisica()));
        par(datos, "Diferencia", cantidad(d.diferencia()));
        par(datos, "Costo promedio", moneda(d.costoPromedio()));
        par(datos, "Valor de diferencia", moneda(d.valorDiferencia()));
        par(datos, "Clasificación", String.valueOf(d.tipo()));
        par(datos, "Estado del ajuste", d.estadoRevision());
        add(datos, BorderLayout.NORTH);

        PanelObservaciones nota = new PanelObservaciones("Observaciones / explicación:", 5);
        nota.setTexto(d.motivo());
        nota.setBorder(new EmptyBorder(0, 20, 8, 20));
        add(nota, BorderLayout.CENTER);

        JButton guardar = botonPrimario("Guardar observación"), cerrar = botonSecundario("Cerrar");
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT)); abajo.add(guardar); abajo.add(cerrar);
        add(abajo, BorderLayout.SOUTH);
        guardar.addActionListener(e -> TareaAsincrona.ejecutar(this,
                () -> { controller.guardarObservacion(idToma, d.producto().id(), nota.getTexto()); return true; },
                ok -> { alGuardar.run(); dispose(); }));
        cerrar.addActionListener(e -> dispose());
    }

    private static void par(JPanel panel, String etiqueta, String valor) {
        JLabel l = etiquetaSecundaria(etiqueta + ":");
        JLabel v = new JLabel(texto(valor)); v.setForeground(TEXT);
        panel.add(l); panel.add(v);
    }
}
