package pe.edu.inventario.vista.inventariofisico;

import pe.edu.inventario.controlador.contrato.InventarioFisicoController;
import pe.edu.inventario.vista.inventariofisico.componentes.*;
import pe.edu.inventario.vista.inventariofisico.dialog.*;
import pe.edu.inventario.vista.inventariofisico.modelo.*;
import pe.edu.inventario.vista.inventariofisico.renderer.*;
import pe.edu.inventario.vista.inventariofisico.util.*;
import pe.edu.inventario.modelo.inventariofisico.InventarioFisicoModels.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

import static pe.edu.inventario.vista.inventariofisico.util.FormatoInventarioFisico.*;

/** Pestaña de reportes: indicadores, gráfico de barras y vista previa exportable. */
public class ReporteInventarioFisicoView extends JPanel {
    private final InventarioFisicoController controller;
    private final PermisosVistaInventario permisos;
    private final PanelResumenInventario resumen = new PanelResumenInventario();
    private final GraficoIndicadores grafico = new GraficoIndicadores();
    private final TablaReporteModel modelo = new TablaReporteModel();

    public ReporteInventarioFisicoView(InventarioFisicoController controller, PermisosVistaInventario permisos) {
        super(new BorderLayout(12, 12));
        this.controller = controller; this.permisos = permisos;
        setOpaque(false);
        add(resumen, BorderLayout.NORTH);
        add(grafico, BorderLayout.CENTER);
        JButton actualizar = botonSecundario("Actualizar indicadores"), vista = botonPrimario("Vista previa / exportar");
        vista.setEnabled(permisos.puedeExportar());
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        abajo.setOpaque(false);
        abajo.add(actualizar); abajo.add(vista);
        add(abajo, BorderLayout.SOUTH);
        actualizar.addActionListener(e -> cargar());
        vista.addActionListener(e -> new VistaPreviaReporteDialog(SwingUtilities.getWindowAncestor(this),
                "Indicadores del inventario físico", modelo, permisos).setVisible(true));
        cargar();
    }

    public final void cargar() {
        TareaAsincrona.ejecutar(this, controller::obtenerResumen, r -> { resumen.actualizar(r); grafico.setDatos(r); modelo.setResumen(r); });
    }

    /** Gráfico de barras horizontales dibujado con Java2D. */
    private static final class GraficoIndicadores extends JPanel {
        private Resumen datos = new Resumen(0, 0, 0, 0, 0);

        GraficoIndicadores() { setBackground(Color.WHITE); setBorder(bordeTarjeta()); }

        void setDatos(Resumen r) { datos = r; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT); g2.setFont(getFont().deriveFont(Font.BOLD, 15f));
            g2.drawString("Indicadores del inventario físico", 20, 28);
            String[] etiquetas = {"Tomas abiertas", "Conciliadas", "Productos con diferencias", "Ajustes pendientes"};
            int[] valores = {datos.tomasAbiertas(), datos.tomasConciliadas(), datos.productosConDiferencias(), datos.ajustesPendientes()};
            Color[] colores = {BLUE, GREEN, AMBER, RED};
            int max = 1;
            for (int v : valores) max = Math.max(max, v);
            int anchoMax = Math.max(100, getWidth() - 290), y = 70;
            for (int i = 0; i < valores.length; i++) {
                g2.setColor(MUTED); g2.setFont(getFont().deriveFont(12f)); g2.drawString(etiquetas[i], 22, y + 17);
                int w = (int) (anchoMax * (valores[i] / (double) max));
                g2.setColor(colores[i]); g2.fillRoundRect(230, y, Math.max(3, w), 24, 8, 8);
                g2.setColor(TEXT); g2.drawString(String.valueOf(valores[i]), 240 + w, y + 17);
                y += 62;
            }
            g2.dispose();
        }
    }
}
