package pe.edu.inventario.servicio;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import pe.edu.inventario.modelo.ImagenProducto;
import pe.edu.inventario.modelo.dao.ImagenProductoDAO;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de búsqueda y almacenamiento de imágenes de Pixabay.
 */
public class ImagenProductoService {

    private static final String API_URL =
            "https://pixabay.com/api/";

    private static final int MAX_RESULTADOS = 12;
    private static final int MAX_BYTES_IMAGEN = 15 * 1024 * 1024;

    private static final Path DIRECTORIO_IMAGENES =
            Paths.get("data", "imagenes-productos");

    private final ImagenProductoDAO imagenDAO;
    private final HttpClient clienteHttp;

    public ImagenProductoService() {
        this.imagenDAO = new ImagenProductoDAO();

        this.clienteHttp = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    /**
     * Busca imágenes en Pixabay.
     *
     * Primero consulta la caché local.
     * Si no existe una respuesta vigente, consulta la API.
     */
    public List<ImagenProducto> buscarImagenes(String termino)
            throws IOException, InterruptedException {

        if (termino == null || termino.isBlank()) {
            throw new IllegalArgumentException(
                    "Debes escribir el nombre del producto."
            );
        }

        String busqueda = termino.trim().replaceAll("\\s+", " ");

        try {
            String cache = imagenDAO.obtenerCache(busqueda);

            if (cache != null && !cache.isBlank()) {
                return convertirRespuesta(cache);
            }

        } catch (java.sql.SQLException ex) {
            throw new IOException(
                    "No se pudo consultar la caché de imágenes.",
                    ex
            );
        }

        String apiKey = System.getenv("PIXABAY_API_KEY");

        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException(
                    "No está configurada la variable PIXABAY_API_KEY."
            );
        }

        String url = API_URL
                + "?key=" + URLEncoder.encode(
                        apiKey,
                        StandardCharsets.UTF_8
                )
                + "&q=" + URLEncoder.encode(
                        busqueda,
                        StandardCharsets.UTF_8
                )
                + "&lang=es"
                + "&image_type=photo"
                + "&safesearch=true"
                + "&per_page=" + MAX_RESULTADOS
                + "&order=popular";

        HttpRequest solicitud = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> respuesta = clienteHttp.send(
                solicitud,
                HttpResponse.BodyHandlers.ofString(
                        StandardCharsets.UTF_8
                )
        );

        if (respuesta.statusCode() != 200) {
            throw new IOException(
                    "Pixabay respondió con código HTTP "
                            + respuesta.statusCode()
            );
        }

        String json = respuesta.body();

        List<ImagenProducto> imagenes = convertirRespuesta(json);

        try {
            imagenDAO.guardarCache(busqueda, json);
        } catch (java.sql.SQLException ex) {
            throw new IOException(
                    "Las imágenes se encontraron, pero no se pudo "
                            + "guardar la caché.",
                    ex
            );
        }

        return imagenes;
    }

    /**
     * Convierte el JSON recibido de Pixabay en objetos del modelo.
     */
    private List<ImagenProducto> convertirRespuesta(String json)
            throws IOException {

        List<ImagenProducto> imagenes = new ArrayList<>();

        try {
            JsonObject raiz = JsonParser.parseString(json)
                    .getAsJsonObject();

            if (!raiz.has("hits")
                    || !raiz.get("hits").isJsonArray()) {

                throw new IOException(
                        "La respuesta de Pixabay no contiene resultados."
                );
            }

            JsonArray resultados = raiz.getAsJsonArray("hits");

            for (JsonElement elemento : resultados) {

                JsonObject objeto = elemento.getAsJsonObject();

                long id = obtenerLong(objeto, "id");
                String preview = obtenerTexto(objeto, "previewURL");
                String imagen = obtenerTexto(objeto, "webformatURL");
                String pagina = obtenerTexto(objeto, "pageURL");
                String autor = obtenerTexto(objeto, "user");
                String etiquetas = obtenerTexto(objeto, "tags");

                if (id <= 0 || imagen == null || pagina == null) {
                    continue;
                }

                ImagenProducto resultado = new ImagenProducto(
                        id,
                        preview,
                        imagen,
                        pagina,
                        autor,
                        etiquetas
                );

                imagenes.add(resultado);
            }

            return imagenes;

        } catch (RuntimeException ex) {
            throw new IOException(
                    "No se pudo interpretar la respuesta de Pixabay.",
                    ex
            );
        }
    }

    private String obtenerTexto(JsonObject objeto, String campo) {

        if (!objeto.has(campo)
                || objeto.get(campo).isJsonNull()) {
            return null;
        }

        return objeto.get(campo).getAsString();
    }

    private long obtenerLong(JsonObject objeto, String campo) {

        if (!objeto.has(campo)
                || objeto.get(campo).isJsonNull()) {
            return 0;
        }

        return objeto.get(campo).getAsLong();
    }

    /**
     * Descarga la imagen seleccionada y la asocia con un producto.
     */
    public ImagenProducto guardarImagen(
            long idProducto,
            ImagenProducto seleccionada)
            throws IOException, InterruptedException,
            java.sql.SQLException {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del producto no es válido."
            );
        }

        if (seleccionada == null
                || seleccionada.getPixabayId() <= 0) {

            throw new IllegalArgumentException(
                    "Debes seleccionar una imagen válida."
            );
        }

        validarUrl(seleccionada.getImagenUrl());

        Files.createDirectories(DIRECTORIO_IMAGENES);

        String nombreArchivo = "producto_"
                + idProducto
                + "_pixabay_"
                + seleccionada.getPixabayId()
                + ".jpg";

        Path destino = DIRECTORIO_IMAGENES.resolve(nombreArchivo)
                .toAbsolutePath()
                .normalize();

        if (!destino.startsWith(
                DIRECTORIO_IMAGENES.toAbsolutePath().normalize()
        )) {
            throw new IOException(
                    "La ruta de almacenamiento no es válida."
            );
        }

        HttpRequest solicitud = HttpRequest.newBuilder()
                .uri(URI.create(seleccionada.getImagenUrl()))
                .timeout(Duration.ofSeconds(30))
                .header("User-Agent", "SistemaInventario/1.0")
                .GET()
                .build();

        HttpResponse<InputStream> respuesta = clienteHttp.send(
                solicitud,
                HttpResponse.BodyHandlers.ofInputStream()
        );

        if (respuesta.statusCode() != 200) {
            try (InputStream cuerpo = respuesta.body()) {
                cuerpo.transferTo(java.io.OutputStream.nullOutputStream());
            }
            throw new IOException(
                    "No se pudo descargar la imagen. HTTP "
                            + respuesta.statusCode()
            );
        }

        byte[] contenido;
        try (InputStream cuerpo = respuesta.body()) {
            contenido = cuerpo.readNBytes(MAX_BYTES_IMAGEN + 1);
        }

        if (contenido.length == 0
                || contenido.length > MAX_BYTES_IMAGEN) {
            throw new IOException(
                    "El tamaño de la imagen supera el límite permitido de 15 MB."
            );
        }

        BufferedImage imagenDescargada = ImageIO.read(
                new ByteArrayInputStream(contenido)
        );

        if (imagenDescargada == null) {
            throw new IOException(
                    "El archivo recibido no es una imagen compatible."
            );
        }

        if (imagenDescargada.getWidth() > 12000
                || imagenDescargada.getHeight() > 12000) {

            throw new IOException(
                    "Las dimensiones de la imagen son demasiado grandes."
            );
        }

        boolean guardada = ImageIO.write(
                imagenDescargada,
                "jpg",
                destino.toFile()
        );

        if (!guardada) {
            throw new IOException(
                    "No se pudo guardar la imagen en formato JPG."
            );
        }

        ImagenProducto imagen = new ImagenProducto();

        imagen.setIdProducto(idProducto);
        imagen.setPixabayId(seleccionada.getPixabayId());
        imagen.setRutaLocal(destino.toString());
        imagen.setFuente("Pixabay");
        imagen.setPaginaFuente(seleccionada.getPaginaFuente());
        imagen.setAutor(seleccionada.getAutor());

        try {
            imagenDAO.guardar(imagen);
        } catch (java.sql.SQLException ex) {
            Files.deleteIfExists(destino);
            throw ex;
        }

        return imagen;
    }

    /**
     * Obtiene la imagen actualmente asociada a un producto.
     */
    public ImagenProducto obtenerImagen(long idProducto)
            throws java.sql.SQLException {

        return imagenDAO.buscarPorProducto(idProducto);
    }

    private void validarUrl(String url) throws IOException {

        if (url == null || url.isBlank()) {
            throw new IOException(
                    "La dirección de la imagen está vacía."
            );
        }

        URI uri;

        try {
            uri = URI.create(url);
        } catch (IllegalArgumentException ex) {
            throw new IOException(
                    "La dirección de la imagen no es válida.",
                    ex
            );
        }

        String host = uri.getHost();

        if (!"https".equalsIgnoreCase(uri.getScheme())
                || host == null
                || uri.getRawUserInfo() != null
                || (uri.getPort() != -1 && uri.getPort() != 443)
                || !(host.equalsIgnoreCase("pixabay.com")
                        || host.toLowerCase(java.util.Locale.ROOT)
                                .endsWith(".pixabay.com"))) {

            throw new IOException(
                    "La imagen no procede de un dominio permitido."
            );
        }
    }
}