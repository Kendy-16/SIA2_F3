# Reportes

Pendiente. Plantillas de reportes (stock, kardex, valorización).

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
