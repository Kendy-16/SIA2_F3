# Comprobantes

Pendiente. Plantillas de comprobantes de venta/compra.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
