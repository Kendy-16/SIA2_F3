# Códigos de barras

Pendiente. Recurso para generación/lectura de códigos de barras.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
