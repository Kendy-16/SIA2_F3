# Pruebas automatizadas

Sin pruebas automatizadas todavía. Los casos manuales irán en docs/CASOS_DE_PRUEBA.md.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
