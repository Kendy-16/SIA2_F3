# Parche T1 — IGV, roles, vistas y casos de prueba

## Cómo aplicarlo (2 minutos)
1. Cierra la aplicación y **haz copia de `database/inventario.db`**.
2. Descomprime este ZIP **encima** de la carpeta `SistemaInventario_T1` (acepta reemplazar archivos; mantiene las mismas rutas).
3. Ejecuta `EJECUTAR_SISTEMA.cmd` (o `mvn clean compile` y luego `mvn exec:java`).
   Al arrancar se aplican solas las migraciones V005 y V006.
4. (Opcional) cargar catálogos de prueba: `sqlite3 database/inventario.db < database/datos_prueba.sql`
   o ejecutar ese archivo en DB Browser for SQLite.

## Qué cambia
| Tema | Cambio |
|---|---|
| **Roles** | El login devuelve el rol y abre `MenuPrincipalView(rol)`. Archivos: `Usuario`, `UsuarioDAO`, `LoginService`, `LoginController`, `LoginView`. V006 promueve a ADMINISTRADOR al usuario más antiguo si no hay ninguno (tu usuario `kelly` queda como administrador). |
| **IGV** | V006 agrega `igv_tasa`, `igv_monto`, `precio_venta` a `detalle_movimientos`. Entrada y Salida tienen el selector «Es valor SIN IGV / Incluye IGV (18 %)». El **costo promedio se calcula sobre el valor sin IGV**; el IGV queda registrado por línea. Salida pide precio de venta (0 si es consumo). Archivos: `MigracionV006IgvYAdministrador` (nuevo), `AdministradorMigraciones`, `MovimientoDAO`, `MovimientoService`, `MovimientoController`, `MovimientoView`. |
| **Menú** | Inventario físico, Costo promedio, Kardex y Reportes ya no son paneles provisionales: abren `InventarioFisicoView`, `InventarioValorizadoView`, `KardexView` y `ReportesView`. Si alguna pantalla fallara al crearse, el menú abre igual (ver consola). |
| **Reportes (antes vacíos)** | `ExistenciasView`, `InventarioValorizadoView` y nuevos `ReporteUtilidadView`, `ReporteIgvView`, `ReportesView`, `PanelReporteTabla`, `ReporteDAO`. |
| **Datos y pruebas** | `database/datos_prueba.sql`, `docs/CASOS_DE_PRUEBA.md` (12 casos con valores esperados y kardex de referencia). |

## Qué se verificó y qué no
* Compila sin errores con JDK 21 (con un reemplazo mínimo de Gson, igual que la verificación anterior).
* La migración V006 y las 4 consultas de reportes se probaron sobre una copia de tu base con SQLite (Python); los valores del escenario coinciden con la hoja de casos.
* **No se ejecutó la interfaz gráfica ni el controlador JDBC desde Java.** Corre los casos C01–C12 en tu equipo y anota los resultados.

## Notas
* Solo el ADMINISTRADOR registra movimientos (regla que ya existía en `MovimientoController`).
* `ReporteStockView`, `ReporteKardexView`, `ReporteValorizacionView`, `EntradaView`, `SalidaView`, `AjusteInventarioView` siguen en 0 bytes y no hacen falta; puedes borrarlos.
* No subas `inventario.db` a un repositorio público (contiene hash y sal de un usuario).
