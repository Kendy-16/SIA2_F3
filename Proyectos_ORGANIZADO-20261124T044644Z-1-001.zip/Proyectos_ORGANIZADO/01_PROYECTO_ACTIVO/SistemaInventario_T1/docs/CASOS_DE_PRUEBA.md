# Casos de prueba — T1 Inventario físico y valorizado al costo promedio

**Preparación:** `database/datos_prueba.sql` aplicado (producto `CEM-001`, almacén `Principal`) y
la aplicación iniciada con un usuario ADMINISTRADOR (la migración V006 promueve al usuario más antiguo).
Regla: IGV 18 %. **El costo promedio se calcula sobre el valor SIN IGV**; el IGV se registra aparte.
Los IDs de producto/almacén se ingresan en el formulario (con los datos de prueba: producto 1, almacén 1;
verifica en las pantallas de Productos/Almacenes).

Los valores esperados se calcularon aparte (hoja de cálculo / script con redondeo a 6 decimales, igual que el sistema).
La columna «Resultado obtenido» se completa al ejecutar cada caso en la aplicación.

| N.º | Caso | Pasos / datos | Resultado esperado | Resultado obtenido |
|---|---|---|---|---|
| C01 | Login y rol | Ingresar con el administrador | Entra al menú; el encabezado muestra «Administrador» (iniciales AD) | |
| C02 | Entrada con IGV incluido | Movimientos › Entrada: producto 1, almacén 1, doc `FAC-001`, cant. **100**, costo **11.80**, «Incluye IGV» | Costo neto **10.000000**; IGV línea **180.00**; stock **100**; costo promedio **10.000000**; valor saldo **1 000.00** | |
| C03 | Segunda entrada, recálculo del promedio | Entrada: doc `FAC-002`, cant. **50**, costo **14.16**, «Incluye IGV» | Costo neto **12.000000**; IGV **108.00**; stock **150**; costo promedio **10.666667**; valor saldo **1 600.00** | |
| C04 | Salida por venta (costea al promedio) | Salida: doc `BV-001`, cant. **80**, precio **15.00**, «SIN IGV» | Costo de salida **10.666667**; stock **70**; promedio sin cambio **10.666667**; valor saldo **746.67**; IGV débito **216.00** | |
| C05 | Entrada sin IGV | Entrada: doc `FAC-003`, cant. **30**, costo **13.00**, «SIN IGV» | Stock **100**; costo promedio **11.366667**; IGV **70.20**; valor saldo **1 136.67** | |
| C06 | Salida con precio con IGV | Salida: doc `BV-002`, cant. **40**, precio **23.60**, «Incluye IGV» | Precio neto **20.00**; costo **11.366667**; stock **60**; valor saldo **682.00**; IGV débito **144.00** | |
| C07 | Salida mayor al stock | Salida de **100** unidades (stock 60) | Rechazada con mensaje de stock insuficiente; stock sigue en 60; no se agrega fila al kardex | |
| C08 | Validación de datos | Entrada con costo vacío o negativo; producto o almacén inexistente | Mensaje de validación; no se registra nada | |
| C09 | Ajuste por inventario físico | Ajuste: cantidad física final **58**, con justificación | Faltante de 2; movimiento AJUSTE a costo **11.366667**; stock **58**; valor saldo **659.27**. Sin justificación: rechazado | |
| C10 | Conteo abierto bloquea movimientos | Inventario físico: abrir una toma en el almacén; intentar una entrada | Rechazada mientras la toma esté abierta | |
| C11 | Permisos por rol | Con rol `USUARIO`, intentar registrar un movimiento | Acceso denegado (solo el administrador registra movimientos) | |
| C12 | Reportes (tras C02–C06) | Reportes › Inventario valorizado, Utilidad bruta, IGV | Valorizado **682.00** (60 × 11.366667); Utilidad: ventas **2 000.00**, costo **1 308.00**, utilidad **692.00**, margen **34.60 %**; IGV: compras **358.20**, ventas **360.00**, por pagar **1.80** | |

## Kardex de referencia (para verificar a mano en la hoja de cálculo)

| Mov. | Entrada | Salida | Costo unit. | Saldo (und) | Costo promedio | Valor saldo |
|---|---|---|---|---|---|---|
| Compra FAC-001 | 100 | | 10.000000 | 100 | 10.000000 | 1 000.00 |
| Compra FAC-002 | 50 | | 12.000000 | 150 | 10.666667 | 1 600.00 |
| Venta BV-001 | | 80 | 10.666667 | 70 | 10.666667 | 746.67 |
| Compra FAC-003 | 30 | | 13.000000 | 100 | 11.366667 | 1 136.67 |
| Venta BV-002 | | 40 | 11.366667 | 60 | 11.366667 | 682.00 |

Fórmula: `CP = (stock_anterior × CP_anterior + cantidad × costo) / (stock_anterior + cantidad)`, redondeado a 6 decimales.
Ejemplo (compra FAC-002): `(100 × 10.000000 + 50 × 12.000000) / (100 + 50) = 1 600 / 150 = 10.666667`.
