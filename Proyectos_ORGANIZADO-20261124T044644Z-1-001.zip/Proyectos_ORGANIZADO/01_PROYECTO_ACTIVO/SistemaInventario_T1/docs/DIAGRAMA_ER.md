# Diagrama entidad–relación

Generado a partir del esquema real de `database/inventario.db` (migraciones V001–V004 aplicadas).

> **Nota:** la migración **V005 (roles de usuario)** se aplica automáticamente en el primer arranque
> (`AdministradorMigraciones`) y agrega la columna `usuarios.rol` (`ADMINISTRADOR` | `USUARIO`, por defecto `USUARIO`).
> Esa columna todavía no aparece en el archivo `.db` entregado.

```mermaid
erDiagram
    almacenes {
        INTEGER id_almacen PK
        TEXT nombre
        TEXT ubicacion
        INTEGER activo
    }
    cache_busqueda_imagenes {
        TEXT termino PK
        TEXT respuesta_json
        INTEGER fecha_consulta
    }
    categorias {
        INTEGER id_categoria PK
        TEXT nombre
        TEXT descripcion
    }
    detalle_movimientos {
        INTEGER id_detalle PK
        INTEGER id_movimiento FK
        INTEGER id_producto FK
        REAL cantidad
        REAL costo_unitario
    }
    detalle_toma_inventario {
        INTEGER id_detalle PK
        INTEGER id_toma FK
        INTEGER id_producto FK
        REAL stock_sistema
        REAL cantidad_fisica
        REAL diferencia
        REAL costo_promedio
        REAL impacto_valorizado
        TEXT observacion
    }
    imagenes_productos {
        INTEGER id_imagen PK
        INTEGER id_producto FK
        INTEGER pixabay_id
        TEXT ruta_local
        TEXT fuente
        TEXT pagina_fuente
        TEXT autor
        TEXT fecha_guardado
    }
    inventario {
        INTEGER id_inventario PK
        INTEGER id_producto FK
        INTEGER id_almacen FK
        REAL cantidad
        REAL costo_promedio
    }
    kardex {
        INTEGER id_kardex PK
        INTEGER id_producto FK
        INTEGER id_almacen FK
        TEXT fecha
        TEXT tipo
        TEXT documento
        REAL entrada
        REAL salida
        REAL saldo
        REAL costo_unitario
        REAL costo_promedio
        REAL valor_saldo
    }
    movimientos {
        INTEGER id_movimiento PK
        TEXT tipo
        TEXT fecha
        TEXT documento
        TEXT observacion
        INTEGER id_almacen FK
    }
    productos {
        INTEGER id_producto PK
        TEXT codigo
        TEXT nombre
        TEXT descripcion
        INTEGER id_categoria FK
        INTEGER id_proveedor FK
        TEXT unidad_medida
        REAL stock_minimo
        INTEGER activo
    }
    proveedores {
        INTEGER id_proveedor PK
        TEXT razon_social
        TEXT ruc
        TEXT telefono
        TEXT correo
        TEXT direccion
    }
    schema_migrations {
        TEXT version PK
        TEXT descripcion
        TEXT aplicada_en
    }
    tomas_inventario_fisico {
        INTEGER id_toma PK
        INTEGER id_almacen FK
        TEXT fecha
        TEXT modo
        TEXT estado
        TEXT observacion
        TEXT creado_en
        TEXT procesado_en
    }
    usuarios {
        INTEGER id_usuario PK
        TEXT usuario
        TEXT password_hash
        TEXT password_salt
        INTEGER activo
        INTEGER intentos_fallidos
        INTEGER bloqueado_hasta
        TEXT creado_en
        TEXT ultimo_acceso
    }
    productos ||--o{ detalle_movimientos : "id_producto"
    movimientos ||--o{ detalle_movimientos : "id_movimiento"
    productos ||--o{ detalle_toma_inventario : "id_producto"
    tomas_inventario_fisico ||--o{ detalle_toma_inventario : "id_toma"
    productos ||--o{ imagenes_productos : "id_producto"
    almacenes ||--o{ inventario : "id_almacen"
    productos ||--o{ inventario : "id_producto"
    almacenes ||--o{ kardex : "id_almacen"
    productos ||--o{ kardex : "id_producto"
    almacenes ||--o{ movimientos : "id_almacen"
    proveedores ||--o{ productos : "id_proveedor"
    categorias ||--o{ productos : "id_categoria"
    almacenes ||--o{ tomas_inventario_fisico : "id_almacen"
```

## Tablas (14)

| Tabla | Columnas |
|---|---|
| `almacenes` | 4 |
| `cache_busqueda_imagenes` | 3 |
| `categorias` | 3 |
| `detalle_movimientos` | 5 |
| `detalle_toma_inventario` | 9 |
| `imagenes_productos` | 8 |
| `inventario` | 5 |
| `kardex` | 12 |
| `movimientos` | 6 |
| `productos` | 9 |
| `proveedores` | 6 |
| `schema_migrations` | 3 |
| `tomas_inventario_fisico` | 8 |
| `usuarios` | 9 |
