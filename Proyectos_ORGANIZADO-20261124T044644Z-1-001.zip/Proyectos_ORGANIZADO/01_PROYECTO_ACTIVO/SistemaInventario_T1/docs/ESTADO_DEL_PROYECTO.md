# Estado del proyecto — SistemaInventario_T1

Aplicación de escritorio en **Java 21 + Swing + SQLite** (patrón vista / controlador / servicio / DAO), paquete `pe.edu.inventario`.
Este documento resume lo que hay en la versión activa, con datos comprobados sobre los archivos (no estimaciones).

## Verificación realizada

| Comprobación | Resultado |
|---|---|
| Compilación de los 60 archivos `.java` con contenido (JDK 21, `javac`) | **0 errores** (solo el aviso `unchecked` de `CategoriaView`, el mismo de tu `compilacion.txt`) |
| Integridad de `database/inventario.db` (`PRAGMA quick_check`) | `ok` |
| Tablas / registros | 14 tablas; todas vacías salvo `schema_migrations` (4) y `usuarios` (1) |
| Líneas de código Java | 27 238 |

> Gson y `sqlite-jdbc` no estaban disponibles en el entorno de verificación (sin acceso a Maven Central), por lo que se compiló con clases
> mínimas de reemplazo para Gson. **Ejecuta `mvn clean compile` en tu equipo para la confirmación definitiva**; no se ejecutó la interfaz gráfica.

## Módulos

| Módulo | Estado | Evidencia |
|---|---|---|
| Login (bloqueo por intentos, hash + sal) | Implementado | `LoginView`, `LoginService`, `UsuarioDAO` |
| Menú principal con roles | Implementado, **rol sin conectar al login** (ver hallazgo 1) | `MenuPrincipalView(String rol)` |
| Productos + imágenes Pixabay | Implementado | `ProductoView`, `ImagenProducto*` |
| Categorías, Proveedores, Almacenes | Implementado | `*View`, `*Service`, `*DAO` |
| Kardex | Implementado | `KardexView`, `KardexDAO`, `KardexService` |
| Inventario físico (tomas de inventario) | Implementado | `InventarioFisicoView` (76 KB), `InventarioFisicoDAO` |
| Movimientos: entrada, salida, ajuste | Implementado en `MovimientoView` (3 pestañas) | `MovimientoView`, `MovimientoDAO`, `MovimientoController` |
| Migraciones V001–V005 | Implementado | `AdministradorMigraciones` |
| Existencias, Inventario valorizado | **Vista vacía (0 bytes)** | `ExistenciasView`, `InventarioValorizadoView` |
| Reportes (stock, kardex, valorización) | **Vistas vacías (0 bytes)** | `vista/reportes/*` |
| Historial de movimientos | **Vacío en esta versión** (existe en la versión Login) | `HistorialMovimientosView`, `MovimientoHistorial` |
| Compras, Ventas, Cajas, Devoluciones, Cotizaciones, Clientes, Códigos de barras, Administración de usuarios | Pendiente (carpetas reservadas con `README.md`) | `vista/*` |

Archivos `.java` de 0 bytes (14): `MovimientoHistorial`, `CatalogoDAO`, `InventarioDAO`, `ExistenciasView`, `InventarioValorizadoView`,
`AjusteInventarioView`, `EntradaView`, `HistorialMovimientosView`, `SalidaView`, `CampoFormulario`, `PanelResumen`,
`ReporteKardexView`, `ReporteStockView`, `ReporteValorizacionView`. Compilan sin problema (archivo vacío), pero no aportan funcionalidad.

## Hallazgos que conviene decidir (no se modificó ningún código)

1. **El rol nunca llega al menú.** `LoginView.abrirMenuPrincipal()` (≈ línea 672) llama a `new MenuPrincipalView()`, que asume `"USUARIO"`.
   Además, ni `Usuario` ni `UsuarioDAO` mencionan la columna `rol` (nada la escribe) y la migración V005 deja a los usuarios existentes como `USUARIO`.
   Resultado: hoy ninguna cuenta alcanza las opciones de `ADMINISTRADOR`. Arreglo mínimo: que el login devuelva el rol, que el primer
   usuario se cree como `ADMINISTRADOR` y que se use `new MenuPrincipalView(rol)`.
2. **La base de datos entregada aún no tiene V005.** Tiene V001–V004; V005 se aplica sola en el primer arranque (`Main` → `AdministradorMigraciones`).
3. **Historial de movimientos:** la versión `Instalacion_Login` tiene la vista (`HistorialMovimientosView`, 23 KB) y el modelo (`MovimientoHistorial`, 18 KB),
   pero su `listarHistorial()` está dentro de un `MovimientoDAO` dañado. Es recuperable; ver `04_VERSIONES_ANTERIORES/LEEME.md`.
4. **Primer administrador:** `Main` de la versión activa abre el login directamente. La versión Login tenía un asistente de “crear primer administrador”
   (12 a 128 caracteres de contraseña); hoy esa función existe en `CrearAdministradorInicial` (ejecutable aparte) pero no se invoca desde `Main`.
5. **Documentos vacíos:** `database/datos_prueba.sql`, `docs/CASOS_DE_PRUEBA.md` y `docs/INFORME_TECNICO_PLANTILLA.md` tienen 0 bytes.
   (`docs/DIAGRAMA_ER.md` se generó desde el esquema real.)
6. **Privacidad:** `database/inventario.db` guarda el hash y la sal de un usuario. No compartas el paquete públicamente tal cual.

## Cómo ejecutar (Windows)

1. Instala JDK 21 y Maven.
2. (Opcional, para buscar imágenes) `setx PIXABAY_API_KEY "TU_CLAVE"` y abre una consola nueva.
3. En la carpeta del proyecto: `EJECUTAR_SISTEMA.cmd` (respalda la BD, compila con `mvn clean compile` y arranca con `mvn exec:java`).
