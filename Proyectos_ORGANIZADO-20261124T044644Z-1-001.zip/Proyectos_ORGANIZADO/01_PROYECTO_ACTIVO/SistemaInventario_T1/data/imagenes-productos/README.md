# Imágenes de productos

Aquí se guardan las imágenes descargadas desde Pixabay (módulo Productos → Buscar imagen). Se crea contenido en tiempo de ejecución.

Estado general del proyecto: ver `docs/ESTADO_DEL_PROYECTO.md`.
