package pe.edu.inventario;

import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.migracion.AdministradorMigraciones;
import pe.edu.inventario.vista.MenuPrincipalView;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        ConexionDB.inicializar();
        AdministradorMigraciones.ejecutar();

        SwingUtilities.invokeLater(() -> {
            MenuPrincipalView ventana = new MenuPrincipalView();
            ventana.setVisible(true);
        });
    }
}
