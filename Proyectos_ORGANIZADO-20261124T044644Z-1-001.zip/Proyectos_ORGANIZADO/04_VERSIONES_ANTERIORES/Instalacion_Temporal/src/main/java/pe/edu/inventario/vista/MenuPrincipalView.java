
package pe.edu.inventario.vista;

import javax.swing.*;
import java.awt.*;

import pe.edu.inventario.vista.producto.ProductoView;
import pe.edu.inventario.vista.producto.ProveedorView;
import pe.edu.inventario.vista.almacen.AlmacenView;

public class MenuPrincipalView extends JFrame {

    // ==========================================
    // 1. ATRIBUTOS
    // ==========================================

    private JTabbedPane pestanas;

    private static final Color COLOR_PRINCIPAL =
            new Color(31, 78, 121);

    private static final Color COLOR_BLANCO =
            Color.WHITE;

    private static final Color COLOR_FONDO =
            new Color(245, 247, 250);

    private static final Font FUENTE_TITULO =
            new Font("Arial", Font.BOLD, 25);

    private static final Font FUENTE_SUBTITULO =
            new Font("Arial", Font.PLAIN, 15);

    private static final Font FUENTE_SECCION =
            new Font("Arial", Font.BOLD, 22);

    private static final int ANCHO_VENTANA = 1200;
    private static final int ALTO_VENTANA = 750;

    // ==========================================
    // 2. CONSTRUCTOR
    // ==========================================

    public MenuPrincipalView() {

        configurarVentana();
        inicializarComponentes();
    }

    // ==========================================
    // 3. CONFIGURACION DE LA VENTANA
    // ==========================================

    private void configurarVentana() {

        setTitle("SISTEMA DE INVENTARIO FISICO Y VALORADO");

        setSize(ANCHO_VENTANA, ALTO_VENTANA);

        setMinimumSize(new Dimension(900, 600));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setResizable(true);

        setBackground(COLOR_FONDO);
    }

    // ==========================================
    // 4. INICIALIZACION DE COMPONENTES
    // ==========================================

    private void inicializarComponentes() {

        JPanel panelPrincipal =
                new JPanel(new BorderLayout());

        panelPrincipal.setBackground(COLOR_BLANCO);

        // --------------------------------------
        // 4.1. ENCABEZADO
        // --------------------------------------

        JPanel encabezado =
                new JPanel(new BorderLayout());

        encabezado.setBackground(COLOR_PRINCIPAL);

        encabezado.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 25, 20, 25
                )
        );

        JLabel titulo = new JLabel(
                "SISTEMA DE INVENTARIO",
                SwingConstants.CENTER
        );

        titulo.setForeground(COLOR_BLANCO);
        titulo.setFont(FUENTE_TITULO);

        JLabel subtitulo = new JLabel(
                "Inventario fisico y valorado al costo promedio",
                SwingConstants.CENTER
        );

        subtitulo.setForeground(COLOR_BLANCO);
        subtitulo.setFont(FUENTE_SUBTITULO);

        JPanel textos =
                new JPanel(new GridLayout(2, 1, 0, 5));

        textos.setOpaque(false);

        textos.add(titulo);
        textos.add(subtitulo);

        encabezado.add(textos, BorderLayout.CENTER);

        // --------------------------------------
        // 4.2. PESTANAS DEL SISTEMA
        // --------------------------------------

        pestanas = new JTabbedPane();

        pestanas.setTabPlacement(JTabbedPane.TOP);

        pestanas.setTabLayoutPolicy(
                JTabbedPane.SCROLL_TAB_LAYOUT
        );

        pestanas.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        // --------------------------------------
        // INICIO
        // --------------------------------------

        pestanas.addTab(
                "Inicio",
                crearPanelInicio()
        );

        // --------------------------------------
        // PRODUCTOS
        // --------------------------------------

        pestanas.addTab(
                "Productos",
                new ProductoView()
        );

        // --------------------------------------
        // PROVEEDORES
        // --------------------------------------

        pestanas.addTab(
                "Proveedores",
                new ProveedorView()
        );

        // --------------------------------------
        // ALMACENES
        // --------------------------------------

        pestanas.addTab(
                "Almacenes",
                new AlmacenView()
        );

        // --------------------------------------
        // MOVIMIENTOS
        // --------------------------------------

        pestanas.addTab(
                "Movimientos",
                crearPanelModulo(
                        "ENTRADAS Y SALIDAS"
                )
        );

        // --------------------------------------
        // INVENTARIO FISICO
        // --------------------------------------

        pestanas.addTab(
                "Inventario fisico",
                crearPanelModulo(
                        "CONTROL DE INVENTARIO FISICO"
                )
        );

        // --------------------------------------
        // COSTO PROMEDIO
        // --------------------------------------

        pestanas.addTab(
                "Costo promedio",
                crearPanelModulo(
                        "VALORIZACION AL COSTO PROMEDIO"
                )
        );

        // --------------------------------------
        // KARDEX
        // --------------------------------------

        pestanas.addTab(
                "Kardex",
                crearPanelModulo(
                        "KARDEX VALORIZADO"
                )
        );

        // --------------------------------------
        // REPORTES
        // --------------------------------------

        pestanas.addTab(
                "Reportes",
                crearPanelModulo(
                        "REPORTES DEL INVENTARIO"
                )
        );

        // Seleccionar Inicio al abrir

        pestanas.setSelectedIndex(0);

        // --------------------------------------
        // 4.3. PIE DE PAGINA
        // --------------------------------------

        JLabel pie = new JLabel(
                "Sistema de Inventario - Proyecto T1",
                SwingConstants.CENTER
        );

        pie.setFont(
                new Font("Arial", Font.PLAIN, 12)
        );

        pie.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 10, 10, 10
                )
        );

        // --------------------------------------
        // 4.4. AGREGAR COMPONENTES PRINCIPALES
        // --------------------------------------

        panelPrincipal.add(
                encabezado,
                BorderLayout.NORTH
        );

        panelPrincipal.add(
                pestanas,
                BorderLayout.CENTER
        );

        panelPrincipal.add(
                pie,
                BorderLayout.SOUTH
        );

        setContentPane(panelPrincipal);
    }

    // ==========================================
    // 5. PANEL DE INICIO
    // ==========================================

    private JPanel crearPanelInicio() {

        JPanel panel =
                new JPanel(new BorderLayout(15, 15));

        panel.setBackground(COLOR_FONDO);

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        30, 30, 30, 30
                )
        );

        JLabel bienvenida = new JLabel(
                "Bienvenido al Sistema de Inventario",
                SwingConstants.CENTER
        );

        bienvenida.setFont(
                new Font("Arial", Font.BOLD, 23)
        );

        bienvenida.setForeground(COLOR_PRINCIPAL);

        JTextArea descripcion = new JTextArea();

        descripcion.setText(
                "\n"
                + "Este sistema permite gestionar y controlar las existencias "
                + "de productos mediante un inventario fisico y valorado.\n\n"

                + "FUNCIONES PRINCIPALES:\n\n"

                + "1. Gestion de productos y categorias.\n"
                + "2. Administracion de proveedores.\n"
                + "3. Administracion de almacenes.\n"
                + "4. Registro de entradas y salidas.\n"
                + "5. Control y conciliacion del inventario fisico.\n"
                + "6. Valorizacion mediante el metodo de costo promedio ponderado.\n"
                + "7. Consulta del Kardex por producto.\n"
                + "8. Generacion de reportes de inventario.\n"
        );

        descripcion.setEditable(false);
        descripcion.setFocusable(false);

        descripcion.setFont(
                new Font("Arial", Font.PLAIN, 16)
        );

        descripcion.setBackground(COLOR_FONDO);

        descripcion.setLineWrap(true);
        descripcion.setWrapStyleWord(true);

        descripcion.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 20, 15, 20
                )
        );

        JScrollPane scrollDescripcion =
                new JScrollPane(descripcion);

        scrollDescripcion.setBorder(null);

        scrollDescripcion.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );

        panel.add(
                bienvenida,
                BorderLayout.NORTH
        );

        panel.add(
                scrollDescripcion,
                BorderLayout.CENTER
        );

        return panel;
    }

    // ==========================================
    // 6. PANELES PROVISIONALES
    // ==========================================

    private JPanel crearPanelModulo(String nombre) {

        // Validar que el nombre del modulo exista.

        if (nombre == null) {

            throw new IllegalArgumentException(
                    "El nombre del modulo es obligatorio."
            );
        }

        nombre = nombre.trim();

        if (nombre.isEmpty()) {

            throw new IllegalArgumentException(
                    "El nombre del modulo no puede estar vacio."
            );
        }

        if (nombre.length() > 100) {

            throw new IllegalArgumentException(
                    "El nombre del modulo no puede superar 100 caracteres."
            );
        }

        JPanel panel =
                new JPanel(new BorderLayout(10, 10));

        panel.setBackground(COLOR_FONDO);

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        JLabel titulo = new JLabel(
                nombre,
                SwingConstants.CENTER
        );

        titulo.setFont(FUENTE_SECCION);
        titulo.setForeground(COLOR_PRINCIPAL);

        JLabel mensaje = new JLabel(
                "Modulo pendiente de implementacion.",
                SwingConstants.CENTER
        );

        mensaje.setFont(
                new Font("Arial", Font.PLAIN, 15)
        );

        panel.add(
                titulo,
                BorderLayout.NORTH
        );

        panel.add(
                mensaje,
                BorderLayout.CENTER
        );

        return panel;
    }

}


   
