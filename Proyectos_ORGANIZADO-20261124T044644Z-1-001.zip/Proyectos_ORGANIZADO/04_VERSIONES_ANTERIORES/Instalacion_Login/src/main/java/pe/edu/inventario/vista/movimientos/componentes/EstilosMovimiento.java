
package pe.edu.inventario.vista.movimientos.componentes;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.JTableHeader;

/**
 * Centraliza los estilos visuales del modulo de movimientos.
 *
 * Mantiene una apariencia moderna y uniforme para:
 * - Entradas.
 * - Salidas.
 * - Ajustes fisicos.
 * - Historial de movimientos.
 *
 * No contiene logica de negocio ni acceso a la base de datos.
 */
public final class EstilosMovimiento {

    // =====================================================
    // 1. PALETA DE COLORES
    // =====================================================

    public static final Color AZUL_PRINCIPAL =
            new Color(71, 103, 145);

    public static final Color AZUL_OSCURO =
            new Color(48, 67, 91);

    public static final Color AZUL_CLARO =
            new Color(235, 241, 248);

    public static final Color FONDO =
            new Color(246, 247, 249);

    public static final Color BLANCO =
            Color.WHITE;

    public static final Color TEXTO =
            new Color(38, 48, 61);

    public static final Color TEXTO_SECUNDARIO =
            new Color(111, 121, 135);

    public static final Color BORDE =
            new Color(226, 230, 235);

    public static final Color EXITO =
            new Color(22, 128, 82);

    public static final Color EXITO_CLARO =
            new Color(232, 246, 238);

    public static final Color ADVERTENCIA =
            new Color(174, 112, 28);

    public static final Color ADVERTENCIA_CLARO =
            new Color(251, 245, 231);

    public static final Color ERROR =
            new Color(190, 65, 65);

    public static final Color ERROR_CLARO =
            new Color(251, 237, 237);

    public static final Color INFORMACION =
            new Color(71, 103, 145);

    public static final Color INFORMACION_CLARO =
            new Color(235, 241, 248);

    public static final Color FONDO_DESHABILITADO =
            new Color(241, 243, 246);

    public static final Color TABLA_SELECCION =
            new Color(235, 241, 248);

    public static final Color TABLA_LINEA =
            new Color(237, 240, 243);


    // =====================================================
    // 2. TIPOGRAFIAS
    // =====================================================

    public static final String FUENTE =
            "Segoe UI";

    public static final Font TITULO =
            new Font(FUENTE, Font.BOLD, 23);

    public static final Font SUBTITULO =
            new Font(FUENTE, Font.BOLD, 16);

    public static final Font TEXTO_NORMAL =
            new Font(FUENTE, Font.PLAIN, 13);

    public static final Font TEXTO_NEGRITA =
            new Font(FUENTE, Font.BOLD, 13);

    public static final Font TEXTO_PEQUENO =
            new Font(FUENTE, Font.PLAIN, 12);

    public static final Font BOTON =
            new Font(FUENTE, Font.BOLD, 13);

    public static final Font TABLA =
            new Font(FUENTE, Font.PLAIN, 12);

    public static final Font TABLA_ENCABEZADO =
            new Font(FUENTE, Font.BOLD, 12);


    // =====================================================
    // 3. BORDES
    // =====================================================

    public static final Border BORDE_CAMPO =
            BorderFactory.createCompoundBorder(
                    new LineBorder(BORDE, 1, true),
                    new EmptyBorder(7, 10, 7, 10)
            );

    public static final Border BORDE_PANEL =
            BorderFactory.createCompoundBorder(
                    new LineBorder(BORDE, 1, true),
                    new EmptyBorder(16, 16, 16, 16)
            );

    public static final Border MARGEN_PANEL =
            new EmptyBorder(18, 20, 18, 20);

    public static final Border BORDE_TARJETA =
            new LineBorder(BORDE, 1, true);


    // =====================================================
    // 4. CONSTRUCTOR PRIVADO
    // =====================================================

    private EstilosMovimiento() {
        // Clase de utilidades visuales.
    }


    // =====================================================
    // 5. ETIQUETAS
    // =====================================================

    public static JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(TEXTO_NEGRITA);
        etiqueta.setForeground(TEXTO);

        return etiqueta;
    }

    public static JLabel crearTitulo(String texto) {

        JLabel titulo = new JLabel(texto);

        titulo.setFont(TITULO);
        titulo.setForeground(TEXTO);

        return titulo;
    }

    public static JLabel crearSubtitulo(String texto) {

        JLabel subtitulo = new JLabel(texto);

        subtitulo.setFont(SUBTITULO);
        subtitulo.setForeground(TEXTO);

        return subtitulo;
    }

    public static JLabel crearTextoSecundario(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(TEXTO_PEQUENO);
        etiqueta.setForeground(TEXTO_SECUNDARIO);

        return etiqueta;
    }

    public static JLabel crearEtiquetaEstado(
            String texto,
            Color colorTexto,
            Color colorFondo
    ) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(TEXTO_NEGRITA);
        etiqueta.setForeground(colorTexto);
        etiqueta.setOpaque(true);

        etiqueta.setBorder(
                new EmptyBorder(5, 9, 5, 9)
        );

        etiqueta.setBackground(colorFondo);

        return etiqueta;
    }


    // =====================================================
    // 6. CAMPOS DE TEXTO
    // =====================================================

    public static void configurarCampo(JTextField campo) {

        campo.setFont(TEXTO_NORMAL);
        campo.setForeground(TEXTO);
        campo.setBackground(BLANCO);

        campo.setBorder(BORDE_CAMPO);

        campo.setCaretColor(AZUL_PRINCIPAL);

        campo.setMargin(new Insets(7, 10, 7, 10));

        campo.setToolTipText("Ingrese un valor");
    }

    public static void configurarCampoSoloLectura(
            JTextField campo
    ) {

        configurarCampo(campo);

        campo.setEditable(false);
        campo.setBackground(FONDO_DESHABILITADO);
        campo.setForeground(TEXTO_SECUNDARIO);
    }


    // =====================================================
    // 7. LISTAS DESPLEGABLES
    // =====================================================

    public static void configurarCombo(
            JComboBox<?> combo
    ) {

        combo.setFont(TEXTO_NORMAL);
        combo.setForeground(TEXTO);
        combo.setBackground(BLANCO);

        combo.setBorder(
                new LineBorder(BORDE, 1, true)
        );

        combo.setFocusable(true);
    }


    // =====================================================
    // 8. AREAS DE TEXTO
    // =====================================================

    public static void configurarArea(
            JTextArea area
    ) {

        area.setFont(TEXTO_NORMAL);
        area.setForeground(TEXTO);
        area.setBackground(BLANCO);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);

        area.setBorder(
                new EmptyBorder(8, 10, 8, 10)
        );

        area.setCaretColor(AZUL_PRINCIPAL);
    }


    // =====================================================
    // 9. BOTONES
    // =====================================================

    public static void configurarBotonPrimario(
            JButton boton
    ) {

        configurarBotonBase(boton);

        boton.setBackground(AZUL_PRINCIPAL);
        boton.setForeground(BLANCO);

        boton.setBorder(
                new EmptyBorder(10, 18, 10, 18)
        );
    }

    public static void configurarBotonSecundario(
            JButton boton
    ) {

        configurarBotonBase(boton);

        boton.setBackground(BLANCO);
        boton.setForeground(TEXTO);

        boton.setBorder(
                new LineBorder(BORDE, 1, true)
        );

        boton.setMargin(
                new Insets(9, 17, 9, 17)
        );
    }

    public static void configurarBotonPeligro(
            JButton boton
    ) {

        configurarBotonBase(boton);

        boton.setBackground(ERROR);
        boton.setForeground(BLANCO);

        boton.setBorder(
                new EmptyBorder(10, 18, 10, 18)
        );
    }

    public static void configurarBotonExito(
            JButton boton
    ) {

        configurarBotonBase(boton);

        boton.setBackground(EXITO);
        boton.setForeground(BLANCO);

        boton.setBorder(
                new EmptyBorder(10, 18, 10, 18)
        );
    }

    private static void configurarBotonBase(
            JButton boton
    ) {

        boton.setFont(BOTON);

        boton.setFocusPainted(false);
        boton.setOpaque(true);

        boton.setContentAreaFilled(true);
        boton.setBorderPainted(true);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );
    }


    // =====================================================
    // 10. PANELES
    // =====================================================

    public static void configurarPanel(
            JPanel panel
    ) {

        panel.setBackground(BLANCO);
        panel.setBorder(BORDE_PANEL);
    }

    public static void configurarPanelFondo(
            JPanel panel
    ) {

        panel.setBackground(FONDO);
    }

    public static JPanel crearTarjeta() {

        JPanel panel = new JPanel();

        panel.setBackground(BLANCO);
        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BORDE_TARJETA,
                        new EmptyBorder(14, 16, 14, 16)
                )
        );

        return panel;
    }


    // =====================================================
    // 11. TABLAS
    // =====================================================

    public static void configurarTabla(
            JTable tabla
    ) {

        tabla.setFont(TABLA);
        tabla.setForeground(TEXTO);
        tabla.setBackground(BLANCO);

        tabla.setSelectionBackground(TABLA_SELECCION);
        tabla.setSelectionForeground(TEXTO);

        tabla.setGridColor(TABLA_LINEA);

        tabla.setRowHeight(34);

        tabla.setShowVerticalLines(false);
        tabla.setShowHorizontalLines(true);

        tabla.setFillsViewportHeight(true);

        tabla.setIntercellSpacing(
                new java.awt.Dimension(0, 1)
        );

        tabla.setSelectionMode(
                javax.swing.ListSelectionModel.SINGLE_SELECTION
        );

        JTableHeader encabezado = tabla.getTableHeader();

        encabezado.setFont(TABLA_ENCABEZADO);
        encabezado.setForeground(TEXTO_SECUNDARIO);
        encabezado.setBackground(FONDO);

        encabezado.setReorderingAllowed(false);
        encabezado.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 1, 0, BORDE
                )
        );
    }


    // =====================================================
    // 12. COMPONENTES DESHABILITADOS
    // =====================================================

    public static void configurarDeshabilitado(
            JTextField campo
    ) {

        campo.setEditable(false);
        campo.setEnabled(false);

        campo.setBackground(FONDO_DESHABILITADO);
        campo.setForeground(TEXTO_SECUNDARIO);
    }

    public static void configurarComponenteDeshabilitado(
            JComponent componente
    ) {

        componente.setEnabled(false);
        componente.setBackground(FONDO_DESHABILITADO);
        componente.setForeground(TEXTO_SECUNDARIO);
    }


    // =====================================================
    // 13. COLORES SEGUN TIPO DE MOVIMIENTO
    // =====================================================

    public static Color obtenerColorTipo(
            String tipo
    ) {

        if (tipo == null) {
            return TEXTO_SECUNDARIO;
        }

        return switch (tipo.trim().toUpperCase()) {

            case "ENTRADA" ->
                    EXITO;

            case "SALIDA" ->
                    ERROR;

            case "AJUSTE" ->
                    ADVERTENCIA;

            default ->
                    TEXTO_SECUNDARIO;
        };
    }

    public static Color obtenerFondoTipo(
            String tipo
    ) {

        if (tipo == null) {
            return FONDO_DESHABILITADO;
        }

        return switch (tipo.trim().toUpperCase()) {

            case "ENTRADA" ->
                    EXITO_CLARO;

            case "SALIDA" ->
                    ERROR_CLARO;

            case "AJUSTE" ->
                    ADVERTENCIA_CLARO;

            default ->
                    FONDO_DESHABILITADO;
        };
    }
}

