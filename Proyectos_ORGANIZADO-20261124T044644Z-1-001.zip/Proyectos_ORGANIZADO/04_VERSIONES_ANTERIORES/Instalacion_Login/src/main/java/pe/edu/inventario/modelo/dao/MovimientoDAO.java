
        if (!Double.isFinite(cantidad)) {
            throw new SQLException(
                    "La cantidad debe ser un numero finito."
            );
        }

        if (cantidad < 0 || (!permitirCero && cantidad == 0)) {
            throw new SQLException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(cantidad).stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La cantidad supera el limite permitido."
            );
        }

        if (valor.scale() > ESCALA_CANTIDAD) {
            throw new SQLException(
                    "La cantidad admite como maximo tres decimales."
            );
        }

        return normalizarCantidad(valor);
    }

    private void validarCantidadEstricitamentePositiva(
            BigDecimal cantidad
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() <= 0) {
            throw new SQLException(
                    "La diferencia del ajuste debe ser mayor que cero."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La diferencia supera el limite permitido."
            );
        }
    }

    private void validarCantidadNoNegativa(
            BigDecimal cantidad,
            String campo
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() < 0) {
            throw new SQLException(
                    campo + " no puede ser nula ni negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    campo + " supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 19. VALIDAR CANTIDAD SEGUN UNIDAD DE MEDIDA
    // =========================================================

    private void validarCantidadUnidad(
            BigDecimal cantidad,
            String unidad
    ) throws SQLException {

        if (cantidad == null || unidad == null) {
            throw new SQLException(
                    "La cantidad y unidad de medida son obligatorias."
            );
        }

        String unidadNormalizada = unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidadNormalizada)) {
            throw new SQLException(
                    "La unidad de medida no esta permitida."
            );
        }

        if (UNIDADES_ENTERAS.contains(unidadNormalizada)
                && cantidad.stripTrailingZeros().scale() > 0) {
            throw new SQLException(
                    "La unidad " + unidadNormalizada
                    + " solamente admite cantidades enteras."
            );
        }
    }

    // =========================================================
    // 20. VALIDAR COSTO UNITARIO
    // =========================================================

    private BigDecimal validarCosto(double costoUnitario)
            throws SQLException {

        if (!Double.isFinite(costoUnitario) || costoUnitario < 0) {
            throw new SQLException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo = BigDecimal.valueOf(costoUnitario)
                .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo unitario supera el limite permitido."
            );
        }

        if (costo.scale() > ESCALA_COSTO) {
            throw new SQLException(
                    "El costo admite como maximo seis decimales."
            );
        }

        return normalizarCosto(costo);
    }

    // =========================================================
    // 21. VALIDAR COSTO PROMEDIO
    // =========================================================

    private void validarCostoPromedio(
            BigDecimal costoPromedio
    ) throws SQLException {

        if (costoPromedio == null) {
            throw new SQLException(
                    "El costo promedio no puede ser nulo."
            );
        }

        if (costoPromedio.signum() < 0) {
            throw new SQLException(
                    "El costo promedio no puede ser negativo."
            );
        }

        if (costoPromedio.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo promedio supera el limite permitido."
            );
        }

        try {
            costoPromedio.setScale(
                    ESCALA_COSTO,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El costo promedio admite como maximo "
                    + ESCALA_COSTO + " decimales.",
                    ex
            );
        }
    }

    // =========================================================
    // 22. VALIDAR STOCK RESULTANTE
    // =========================================================

    private void validarStockMaximo(BigDecimal stock)
            throws SQLException {

        if (stock == null || stock.signum() < 0) {
            throw new SQLException(
                    "El stock resultante no puede ser nulo ni negativo."
            );
        }

        if (stock.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El stock resultante supera el limite permitido."
            );
        }

        try {
            stock.setScale(
                    ESCALA_CANTIDAD,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El stock resultante supera la precision permitida.",
                    ex
            );
        }
    }

    // =========================================================
    // 23. VALIDAR VALOR VALORIZADO
    // =========================================================

    private void validarValorSaldo(BigDecimal valor)
            throws SQLException {

        if (valor == null || valor.signum() < 0) {
            throw new SQLException(
                    "El valor valorizado no puede ser negativo."
            );
        }

        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new SQLException(
                    "El valor valorizado supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 24. VALIDAR DOCUMENTO
    // =========================================================

    private String validarDocumento(String documento)
            throws SQLException {

        if (documento == null || documento.isBlank()) {
            throw new SQLException(
                    "El documento es obligatorio."
            );
        }

        String normalizado = documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(normalizado).matches()) {
            throw new SQLException(
                    "El formato del documento no es valido."
            );
        }

        return normalizado;
    }

    // =========================================================
    // 25. VALIDAR OBSERVACION OPCIONAL
    // =========================================================

    private String validarObservacion(String observacion)
            throws SQLException {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new SQLException(
                    "La observacion contiene caracteres no permitidos."
            );
        }

        String normalizada = observacion.trim().replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new SQLException(
                    "La observacion supera los 500 caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 26. VALIDAR JUSTIFICACION OBLIGATORIA DE AJUSTE
    // =========================================================

    private String validarObservacionObligatoria(String observacion)
            throws SQLException {

        String normalizada = validarObservacion(observacion);

        if (normalizada == null
                || normalizada.length() < MIN_OBSERVACION_AJUSTE) {
            throw new SQLException(
                    "El ajuste requiere una justificacion "
                    + "de al menos cinco caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 27. ASIGNAR TEXTO OPCIONAL
    // =========================================================

    private void asignarTextoOpcional(
            PreparedStatement sentencia,
            int posicion,
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {
            sentencia.setNull(posicion, Types.VARCHAR);
        } else {
            sentencia.setString(posicion, valor);
        }
    }

    // =========================================================
    // 28. DETECTAR CARACTERES DE CONTROL
    // =========================================================

    private boolean contieneCaracteresDeControl(String texto) {
        for (int i = 0; i < texto.length(); i++) {
            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // 29. NORMALIZAR CANTIDAD
    // =========================================================

    private BigDecimal normalizarCantidad(BigDecimal valor) {
        return valor.setScale(
                ESCALA_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 30. NORMALIZAR COSTO
    // =========================================================

    private BigDecimal normalizarCosto(BigDecimal valor) {
        return valor.setScale(
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );
    }

    // =========================================================
    // 31. CONVERTIR NUMERO DE SQLITE A BIGDECIMAL
    // =========================================================

    private BigDecimal decimal(double valor) throws SQLException {
        if (!Double.isFinite(valor)) {
            throw new SQLException(
                    "La base de datos contiene un valor numerico invalido."
            );
        }

        return BigDecimal.valueOf(valor);
    }

    // =========================================================
    // 32. ROLLBACK
    // =========================================================

    private void rollback(Connection conexion, Exception errorOriginal) {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.rollback();
            }
        } catch (SQLException errorRollback) {
            errorOriginal.addSuppressed(errorRollback);
        }
    }

    // =========================================================
    // 33. CLASE INTERNA: INFORMACION DEL PRODUCTO
    // =========================================================

    private static class ProductoInfo {
        private final String unidadMedida;

        private ProductoInfo(String unidadMedida) {
            this.unidadMedida = unidadMedida;
        }
    }

    // =========================================================
    // 34. CLASE INTERNA: INVENTARIO ACTUAL
    // =========================================================

    private static class InventarioActual {
        private final BigDecimal cantidad;
        private final BigDecimal costoPromedio;
        private final boolean existe;

        private InventarioActual(
                BigDecimal cantidad,
                BigDecimal costoPromedio,
                boolean existe
        ) {
            this.cantidad = cantidad;
            this.costoPromedio = costoPromedio;
            this.existe = existe;
        }
    }
}

                throw ex;
            } catch (RuntimeException ex) {
                rollback(conexion, ex);
                throw ex;
            }
        }
    }

    // =========================================================
    // 6. LISTAR HISTORIAL GENERAL DE MOVIMIENTOS
    // =========================================================

    public List<MovimientoHistorial> listarHistorial()
            throws SQLException {

        final String sql = """
                SELECT
                    d.id_detalle,
                    m.id_movimiento,
                    m.id_almacen,
                    d.id_producto,
                    m.fecha,
                    m.tipo,
                    m.documento,
                    m.observacion,
                    a.nombre AS almacen,
                    p.codigo AS codigo_producto,
                    p.nombre AS producto,
                    p.unidad_medida,
                    d.cantidad,
                    d.costo_unitario
                FROM movimientos m
                INNER JOIN detalle_movimientos d
                    ON d.id_movimiento = m.id_movimiento
                INNER JOIN productos p
                    ON p.id_producto = d.id_producto
                INNER JOIN almacenes a
                    ON a.id_almacen = m.id_almacen
                ORDER BY
                    datetime(m.fecha) DESC,
                    m.id_movimiento DESC,
                    d.id_detalle DESC
                """;

        List<MovimientoHistorial> historial = new ArrayList<>();

        try (Connection conexion = ConexionDB.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                int idDetalle = resultado.getInt("id_detalle");
                int idMovimiento = resultado.getInt("id_movimiento");
                int idAlmacen = resultado.getInt("id_almacen");
                int idProducto = resultado.getInt("id_producto");

                String fecha = resultado.getString("fecha");
                String tipo = resultado.getString("tipo");
                String documento = resultado.getString("documento");
                String observacion = resultado.getString("observacion");
                String almacen = resultado.getString("almacen");
                String codigoProducto =
                        resultado.getString("codigo_producto");
                String producto = resultado.getString("producto");
                String unidadMedida = resultado.getString("unidad_medida");

                BigDecimal cantidad = resultado.getBigDecimal("cantidad");
                BigDecimal costoUnitario =
                        resultado.getBigDecimal("costo_unitario");

                if (idDetalle <= 0 || idMovimiento <= 0
                        || idAlmacen <= 0 || idProducto <= 0) {
                    throw new SQLException(
                            "Se encontró un movimiento con identificadores "
                            + "inválidos. ID detalle: " + idDetalle
                    );
                }

                if (fecha == null || fecha.isBlank()) {
                    throw new SQLException(
                            "El movimiento contiene una fecha vacía. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (tipo == null || tipo.isBlank()) {
                    throw new SQLException(
                            "El movimiento no tiene un tipo válido. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (almacen == null || almacen.isBlank()) {
                    throw new SQLException(
                            "El movimiento no tiene un almacén válido. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (codigoProducto == null || codigoProducto.isBlank()) {
                    throw new SQLException(
                            "El producto no tiene un código válido. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (producto == null || producto.isBlank()) {
                    throw new SQLException(
                            "El producto no tiene un nombre válido. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (unidadMedida == null || unidadMedida.isBlank()) {
                    throw new SQLException(
                            "El producto no tiene una unidad de medida. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (cantidad == null || cantidad.signum() <= 0
                        || cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
                    throw new SQLException(
                            "La cantidad del detalle no es válida. "
                            + "ID detalle: " + idDetalle
                    );
                }

                if (costoUnitario == null || costoUnitario.signum() < 0
                        || costoUnitario.compareTo(COSTO_MAXIMO) > 0) {
                    throw new SQLException(
                            "El costo unitario del detalle no es válido. "
                            + "ID detalle: " + idDetalle
                    );
                }

                try {
                    MovimientoHistorial movimiento =
                            new MovimientoHistorial(
                                    idDetalle,
                                    idMovimiento,
                                    idAlmacen,
                                    idProducto,
                                    fecha,
                                    tipo,
                                    documento,
                                    observacion,
                                    almacen,
                                    codigoProducto,
                                    producto,
                                    unidadMedida,
                                    cantidad,
                                    costoUnitario
                            );

                    historial.add(movimiento);

                } catch (IllegalArgumentException ex) {
                    throw new SQLException(
                            "No se pudo construir el registro del historial. "
                            + "ID detalle: " + idDetalle,
                            ex
                    );
                }
            }
        }

        return historial;
    }

    // =========================================================
    // 7. CONFIGURAR Y ADQUIRIR BLOQUEO SQLITE
    // =========================================================

    /**
     * Configura el tiempo máximo de espera ante un bloqueo SQLite.
     * Debe ejecutarse antes de iniciar la transacción.
     */
    private void configurarBloqueo(Connection conexion)
            throws SQLException {

        if (conexion == null || conexion.isClosed()) {
            throw new SQLException(
                    "No se puede configurar el bloqueo: "
                    + "la conexión no está disponible."
            );
        }

        try (Statement sentencia = conexion.createStatement()) {
            sentencia.execute("PRAGMA busy_timeout = " + BUSY_TIMEOUT_MS);
        }
    }

    /**
     * Fuerza la adquisición del bloqueo de escritura SQLite mediante
     * una actualización inocua de la fila del almacén.
     *
     * Se invoca después de desactivar auto-commit y antes de consultar
     * existencias, de modo que la comprobación de stock y las escrituras
     * quedan protegidas por la misma transacción.
     */
    private void adquirirBloqueoEscritura(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        if (conexion == null || conexion.isClosed()) {
            throw new SQLException(
                    "No se puede adquirir el bloqueo: "
                    + "la conexión no está disponible."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del almacén debe ser positivo."
            );
        }

        final String sql =
                "UPDATE almacenes "
                + "SET nombre = nombre "
                + "WHERE id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            int filasAfectadas = sentencia.executeUpdate();

            if (filasAfectadas != 1) {
                throw new SQLException(
                        "No se pudo adquirir el bloqueo de escritura. "
                        + "El almacén no existe o no está disponible."
                );
            }
        }
    }

    // =========================================================
    // 8. VALIDAR IDENTIFICADORES
    // =========================================================

    private void validarIdentificadores(int idProducto, int idAlmacen) {
        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // =========================================================
    // 9. BUSCAR PRODUCTO Y VALIDAR ESTADO ACTIVO
    // =========================================================

    private ProductoInfo buscarProducto(
            Connection conexion,
            int idProducto
    ) throws SQLException {

        String sql =
                "SELECT unidad_medida, activo "
                + "FROM productos "
                + "WHERE id_producto = ?";

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idProducto);

            try (ResultSet resultado = sentencia.executeQuery()) {
                if (!resultado.next()) {
                    throw new SQLException(
                            "El producto seleccionado no existe."
                    );
                }

                if (resultado.getInt("activo") != 1) {
                    throw new SQLException(
                            "El producto esta inactivo. "
                            + "No se permiten movimientos."
                    );
                }

                String unidad = resultado.getString("unidad_medida");

                if (unidad == null || unidad.isBlank()) {
                    throw new SQLException(
                            "El producto no tiene unidad de medida."
                    );
                }

                unidad = unidad.trim().toUpperCase(Locale.ROOT);

                if (!UNIDADES_VALIDAS.contains(unidad)) {
                    throw new SQLException(
                            "La unidad de medida del producto no es valida."
                    );
                }

                return new ProductoInfo(unidad);
            }
        }
    }

    // =========================================================
    // 10. VALIDAR ALMACEN ACTIVO
    // =========================================================

    private void validarAlmacen(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT activo "
                + "FROM almacenes "
                + "WHERE id_almacen = ?";

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado = sentencia.executeQuery()) {
                if (!resultado.next()) {
                    throw new SQLException(
                            "El almacen seleccionado no existe."
                    );
                }

                if (resultado.getInt("activo") != 1) {
                    throw new SQLException(
                            "El almacen esta inactivo. "
                            + "No se permiten movimientos."
                    );
                }
            }
        }
    }

    // =========================================================
    // 11. BLOQUEAR MOVIMIENTOS DURANTE CONTEO FISICO
    // =========================================================

    /**
     * Impide registrar movimientos cuando existe un inventario
     * físico abierto en el almacén seleccionado.
     *
     * Debe ejecutarse dentro de la misma transacción en la que
     * se registra el movimiento y después de adquirir el bloqueo
     * de escritura del almacén.
     *
     * Estados:
     * ABIERTO   = bloquea movimientos.
     * PROCESADO = permite movimientos.
     * ANULADO   = permite movimientos.
     *
     * @param conexion conexión SQLite de la transacción actual
     * @param idAlmacen identificador del almacén
     * @throws SQLException si existe un inventario abierto
     *                      o falla la consulta
     */
    private void validarSinConteoFisicoAbierto(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        if (conexion == null || conexion.isClosed()) {
            throw new SQLException(
                    "La conexión a la base de datos no está disponible."
            );
        }

        if (idAlmacen <= 0) {
            throw new SQLException(
                    "El identificador del almacén no es válido."
            );
        }

        String sql = """
                SELECT id_toma
                FROM tomas_inventario_fisico
                WHERE id_almacen = ?
                  AND estado = 'ABIERTO'
                LIMIT 1
                """;

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, idAlmacen);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    int idToma = rs.getInt("id_toma");

                    throw new SQLException(
                            "No se puede registrar el movimiento. "
                            + "El almacén tiene un inventario físico "
                            + "abierto (ID: " + idToma + "). "
                            + "Finalice o anule el inventario físico "
                            + "antes de registrar entradas, salidas "
                            + "o ajustes."
                    );
                }
            }
        }
    }

    // =========================================================
    // 12. BUSCAR INVENTARIO ACTUAL
    // =========================================================

    private InventarioActual buscarInventario(
            Connection conexion,
            int idProducto,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT cantidad, costo_promedio "
                + "FROM inventario "
                + "WHERE id_producto = ? "
                + "AND id_almacen = ?";

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idProducto);
            sentencia.setInt(2, idAlmacen);

            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    BigDecimal cantidad =
                            decimal(resultado.getDouble("cantidad"));
                    BigDecimal costoPromedio =
                            decimal(resultado.getDouble("costo_promedio"));

                    validarInventarioActual(cantidad, costoPromedio);

                    return new InventarioActual(
                            normalizarCantidad(cantidad),
                            normalizarCosto(costoPromedio),
                            true
                    );
                }
            }
        }

        return new InventarioActual(
                BigDecimal.ZERO.setScale(ESCALA_CANTIDAD),
                BigDecimal.ZERO.setScale(ESCALA_COSTO),
                false
        );
    }

    private void validarInventarioActual(
            BigDecimal cantidad,
            BigDecimal costoPromedio
    ) throws SQLException {

        if (cantidad.signum() < 0
                || cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El inventario contiene una cantidad no valida."
            );
        }

        if (costoPromedio.signum() < 0
                || costoPromedio.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El inventario contiene un costo promedio no valido."
            );
        }
    }

    // =========================================================
    // 13. INSERTAR CABECERA DEL MOVIMIENTO
    // =========================================================

    private int insertarCabecera(
            Connection conexion,
            TipoMovimiento tipo,
            String documento,
            String observacion,
            int idAlmacen
    ) throws SQLException {

        if (tipo == null) {
            throw new SQLException(
                    "El tipo de movimiento es obligatorio."
            );
        }

        String sql =
                "INSERT INTO movimientos "
                + "(tipo, fecha, documento, observacion, id_almacen) "
                + "VALUES (?, datetime('now','localtime'), ?, ?, ?)";

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setString(1, tipo.getCodigo());
            sentencia.setString(2, documento);
            asignarTextoOpcional(sentencia, 3, observacion);
            sentencia.setInt(4, idAlmacen);

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar la cabecera del movimiento."
                );
            }
        }

        try (Statement sentencia = conexion.createStatement();
             ResultSet resultado =
                     sentencia.executeQuery("SELECT last_insert_rowid()")) {

            if (resultado.next()) {
                int id = resultado.getInt(1);

                if (id <= 0) {
                    throw new SQLException(
                            "La base de datos devolvió un ID de movimiento inválido."
                    );
                }

                return id;
            }
        }

        throw new SQLException(
                "No se pudo recuperar el ID del movimiento."
        );
    }

    // =========================================================
    // 14. INSERTAR DETALLE DEL MOVIMIENTO
    // =========================================================

    private void insertarDetalle(
            Connection conexion,
            int idMovimiento,
            int idProducto,
            BigDecimal cantidad,
            BigDecimal costoUnitario
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() <= 0) {
            throw new SQLException(
                    "El detalle del movimiento requiere "
                    + "una cantidad mayor que cero."
            );
        }

        if (costoUnitario == null || costoUnitario.signum() < 0) {
            throw new SQLException(
                    "El costo unitario no es valido."
            );
        }

        String sql =
                "INSERT INTO detalle_movimientos "
                + "(id_movimiento, id_producto, cantidad, costo_unitario) "
                + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idMovimiento);
            sentencia.setInt(2, idProducto);
            sentencia.setDouble(
                    3,
                    normalizarCantidad(cantidad).doubleValue()
            );
            sentencia.setDouble(
                    4,
                    normalizarCosto(costoUnitario).doubleValue()
            );

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar el detalle del movimiento."
                );
            }
        }
    }

    // =========================================================
    // 15. ACTUALIZAR O INSERTAR INVENTARIO
    // =========================================================

    private void guardarInventario(
            Connection conexion,
            int idProducto,
            int idAlmacen,
            boolean existe,
            BigDecimal cantidad,
            BigDecimal costoPromedio
    ) throws SQLException {

        validarStockMaximo(cantidad);
        validarCostoPromedio(costoPromedio);

        String sql;

        if (existe) {
            sql =
                    "UPDATE inventario "
                    + "SET cantidad = ?, costo_promedio = ? "
                    + "WHERE id_producto = ? AND id_almacen = ?";
        } else {
            sql =
                    "INSERT INTO inventario "
                    + "(cantidad, costo_promedio, id_producto, id_almacen) "
                    + "VALUES (?, ?, ?, ?)";
        }

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setDouble(
                    1,
                    normalizarCantidad(cantidad).doubleValue()
            );
            sentencia.setDouble(
                    2,
                    normalizarCosto(costoPromedio).doubleValue()
            );
            sentencia.setInt(3, idProducto);
            sentencia.setInt(4, idAlmacen);

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo guardar el inventario."
                );
            }
        }
    }

    // =========================================================
    // 16. INSERTAR REGISTRO EN KARDEX
    // =========================================================

    private void insertarKardex(
            Connection conexion,
            int idProducto,
            int idAlmacen,
            TipoMovimiento tipo,
            String documento,
            BigDecimal entrada,
            BigDecimal salida,
            BigDecimal saldo,
            BigDecimal costoUnitario,
            BigDecimal costoPromedio
    ) throws SQLException {

        if (tipo == null) {
            throw new SQLException(
                    "El tipo del Kardex es obligatorio."
            );
        }

        validarCantidadNoNegativa(entrada, "Entrada");
        validarCantidadNoNegativa(salida, "Salida");
        validarStockMaximo(saldo);
        validarCostoPromedio(costoPromedio);
        validarCostoPromedio(costoUnitario);

        if (entrada.signum() > 0 && salida.signum() > 0) {
            throw new SQLException(
                    "El Kardex no puede registrar entrada y salida "
                    + "simultaneamente en una misma operacion."
            );
        }

        if (tipo.esEntrada() && entrada.signum() <= 0) {
            throw new SQLException(
                    "Una entrada debe registrar una cantidad positiva."
            );
        }

        if (tipo.esSalida() && salida.signum() <= 0) {
            throw new SQLException(
                    "Una salida debe registrar una cantidad positiva."
            );
        }

        if (tipo.esAjuste() && entrada.signum() == salida.signum()) {
            throw new SQLException(
                    "El ajuste debe tener una direccion definida."
            );
        }

        String sql =
                "INSERT INTO kardex ("
                + "id_producto, id_almacen, fecha, tipo, documento, "
                + "entrada, salida, saldo, costo_unitario, "
                + "costo_promedio, valor_saldo"
                + ") VALUES (?, ?, datetime('now','localtime'), ?, ?, "
                + "?, ?, ?, ?, ?, ?)";

        BigDecimal valorSaldo = saldo.multiply(costoPromedio)
                .setScale(ESCALA_COSTO, RoundingMode.HALF_UP);

        validarValorSaldo(valorSaldo);

        try (PreparedStatement sentencia = conexion.prepareStatement(sql)) {
            sentencia.setInt(1, idProducto);
            sentencia.setInt(2, idAlmacen);
            sentencia.setString(3, tipo.getCodigo());
            sentencia.setString(4, documento);
            sentencia.setDouble(
                    5,
                    normalizarCantidad(entrada).doubleValue()
            );
            sentencia.setDouble(
                    6,
                    normalizarCantidad(salida).doubleValue()
            );
            sentencia.setDouble(
                    7,
                    normalizarCantidad(saldo).doubleValue()
            );
            sentencia.setDouble(
                    8,
                    normalizarCosto(costoUnitario).doubleValue()
            );
            sentencia.setDouble(
                    9,
                    normalizarCosto(costoPromedio).doubleValue()
            );
            sentencia.setDouble(10, valorSaldo.doubleValue());

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar el movimiento en el Kardex."
                );
            }
        }
    }

    // =========================================================
    // 17. CALCULAR COSTO PROMEDIO PONDERADO MOVIL
    // =========================================================

    private BigDecimal calcularPromedio(
            BigDecimal stockActual,
            BigDecimal costoActual,
            BigDecimal cantidadEntrada,
            BigDecimal costoEntrada
    ) throws SQLException {

        if (stockActual == null || costoActual == null
                || cantidadEntrada == null || costoEntrada == null) {
            throw new SQLException(
                    "No se puede calcular el costo promedio con valores nulos."
            );
        }

        if (stockActual.signum() < 0
                || cantidadEntrada.signum() <= 0
                || costoActual.signum() < 0
                || costoEntrada.signum() < 0) {
            throw new SQLException(
                    "Los valores utilizados para calcular "
                    + "el costo promedio no son validos."
            );
        }

        BigDecimal nuevoStock = stockActual.add(cantidadEntrada);

        if (nuevoStock.signum() <= 0) {
            throw new SQLException(
                    "El stock resultante debe ser mayor que cero."
            );
        }

        BigDecimal valorAnterior = stockActual.multiply(costoActual);
        BigDecimal valorEntrada = cantidadEntrada.multiply(costoEntrada);
        BigDecimal nuevoValor = valorAnterior.add(valorEntrada);

        validarValorSaldo(nuevoValor);

        BigDecimal promedio = nuevoValor.divide(
                nuevoStock,
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );

        validarCostoPromedio(promedio);
        return normalizarCosto(promedio);
    }

    // =========================================================
    // 18. VALIDAR CANTIDAD DE MOVIMIENTO
    // =========================================================

    private BigDecimal validarCantidad(
            double cantidad,
            boolean permitirCero
    ) throws SQLException {

        if (!Double.isFinite(cantidad)) {
            throw new SQLException(
                    "La cantidad debe ser un numero finito."
            );
        }

        if (cantidad < 0 || (!permitirCero && cantidad == 0)) {
            throw new SQLException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(cantidad).stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La cantidad supera el limite permitido."
            );
        }

        if (valor.scale() > ESCALA_CANTIDAD) {
            throw new SQLException(
                    "La cantidad admite como maximo tres decimales."
            );
        }

        return normalizarCantidad(valor);
    }

    private void validarCantidadEstricitamentePositiva(
            BigDecimal cantidad
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() <= 0) {
            throw new SQLException(
                    "La diferencia del ajuste debe ser mayor que cero."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La diferencia supera el limite permitido."
            );
        }
    }

    private void validarCantidadNoNegativa(
            BigDecimal cantidad,
            String campo
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() < 0) {
            throw new SQLException(
                    campo + " no puede ser nula ni negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    campo + " supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 19. VALIDAR CANTIDAD SEGUN UNIDAD DE MEDIDA
    // =========================================================

    private void validarCantidadUnidad(
            BigDecimal cantidad,
            String unidad
    ) throws SQLException {

        if (cantidad == null || unidad == null) {
            throw new SQLException(
                    "La cantidad y unidad de medida son obligatorias."
            );
        }

        String unidadNormalizada = unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidadNormalizada)) {
            throw new SQLException(
                    "La unidad de medida no esta permitida."
            );
        }

        if (UNIDADES_ENTERAS.contains(unidadNormalizada)
                && cantidad.stripTrailingZeros().scale() > 0) {
            throw new SQLException(
                    "La unidad " + unidadNormalizada
                    + " solamente admite cantidades enteras."
            );
        }
    }

    // =========================================================
    // 20. VALIDAR COSTO UNITARIO
    // =========================================================

    private BigDecimal validarCosto(double costoUnitario)
            throws SQLException {

        if (!Double.isFinite(costoUnitario) || costoUnitario < 0) {
            throw new SQLException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo = BigDecimal.valueOf(costoUnitario)
                .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo unitario supera el limite permitido."
            );
        }

        if (costo.scale() > ESCALA_COSTO) {
            throw new SQLException(
                    "El costo admite como maximo seis decimales."
            );
        }

        return normalizarCosto(costo);
    }

    // =========================================================
    // 21. VALIDAR COSTO PROMEDIO
    // =========================================================

    private void validarCostoPromedio(
            BigDecimal costoPromedio
    ) throws SQLException {

        if (costoPromedio == null) {
            throw new SQLException(
                    "El costo promedio no puede ser nulo."
            );
        }

        if (costoPromedio.signum() < 0) {
            throw new SQLException(
                    "El costo promedio no puede ser negativo."
            );
        }

        if (costoPromedio.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo promedio supera el limite permitido."
            );
        }

        try {
            costoPromedio.setScale(
                    ESCALA_COSTO,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El costo promedio admite como maximo "
                    + ESCALA_COSTO + " decimales.",
                    ex
            );
        }
    }

    // =========================================================
    // 22. VALIDAR STOCK RESULTANTE
    // =========================================================

    private void validarStockMaximo(BigDecimal stock)
            throws SQLException {

        if (stock == null || stock.signum() < 0) {
            throw new SQLException(
                    "El stock resultante no puede ser nulo ni negativo."
            );
        }

        if (stock.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El stock resultante supera el limite permitido."
            );
        }

        try {
            stock.setScale(
                    ESCALA_CANTIDAD,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El stock resultante supera la precision permitida.",
                    ex
            );
        }
    }

    // =========================================================
    // 23. VALIDAR VALOR VALORIZADO
    // =========================================================

    private void validarValorSaldo(BigDecimal valor)
            throws SQLException {

        if (valor == null || valor.signum() < 0) {
            throw new SQLException(
                    "El valor valorizado no puede ser negativo."
            );
        }

        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new SQLException(
                    "El valor valorizado supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 24. VALIDAR DOCUMENTO
    // =========================================================

    private String validarDocumento(String documento)
            throws SQLException {

        if (documento == null || documento.isBlank()) {
            throw new SQLException(
                    "El documento es obligatorio."
            );
        }

        String normalizado = documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(normalizado).matches()) {
            throw new SQLException(
                    "El formato del documento no es valido."
            );
        }

        return normalizado;
    }

    // =========================================================
    // 25. VALIDAR OBSERVACION OPCIONAL
    // =========================================================

    private String validarObservacion(String observacion)
            throws SQLException {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new SQLException(
                    "La observacion contiene caracteres no permitidos."
            );
        }

        String normalizada = observacion.trim().replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new SQLException(
                    "La observacion supera los 500 caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 26. VALIDAR JUSTIFICACION OBLIGATORIA DE AJUSTE
    // =========================================================

    private String validarObservacionObligatoria(String observacion)
            throws SQLException {

        String normalizada = validarObservacion(observacion);

        if (normalizada == null
                || normalizada.length() < MIN_OBSERVACION_AJUSTE) {
            throw new SQLException(
                    "El ajuste requiere una justificacion "
                    + "de al menos cinco caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 27. ASIGNAR TEXTO OPCIONAL
    // =========================================================

    private void asignarTextoOpcional(
            PreparedStatement sentencia,
            int posicion,
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {
            sentencia.setNull(posicion, Types.VARCHAR);
        } else {
            sentencia.setString(posicion, valor);
        }
    }

    // =========================================================
    // 28. DETECTAR CARACTERES DE CONTROL
    // =========================================================

    private boolean contieneCaracteresDeControl(String texto) {
        for (int i = 0; i < texto.length(); i++) {
            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // 29. NORMALIZAR CANTIDAD
    // =========================================================

    private BigDecimal normalizarCantidad(BigDecimal valor) {
        return valor.setScale(
                ESCALA_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 30. NORMALIZAR COSTO
    // =========================================================

    private BigDecimal normalizarCosto(BigDecimal valor) {
        return valor.setScale(
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );
    }

    // =========================================================
    // 31. CONVERTIR NUMERO DE SQLITE A BIGDECIMAL
    // =========================================================

    private BigDecimal decimal(double valor) throws SQLException {
        if (!Double.isFinite(valor)) {
            throw new SQLException(
                    "La base de datos contiene un valor numerico invalido."
            );
        }

        return BigDecimal.valueOf(valor);
    }

    // =========================================================
    // 32. ROLLBACK
    // =========================================================

    private void rollback(Connection conexion, Exception errorOriginal) {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.rollback();
            }
        } catch (SQLException errorRollback) {
            errorOriginal.addSuppressed(errorRollback);
        }
    }

    // =========================================================
    // 33. CLASE INTERNA: INFORMACION DEL PRODUCTO
    // =========================================================

    private static class ProductoInfo {
        private final String unidadMedida;

        private ProductoInfo(String unidadMedida) {
            this.unidadMedida = unidadMedida;
        }
    }

    // =========================================================
    // 34. CLASE INTERNA: INVENTARIO ACTUAL
    // =========================================================

    private static class InventarioActual {
        private final BigDecimal cantidad;
        private final BigDecimal costoPromedio;
        private final boolean existe;

        private InventarioActual(
                BigDecimal cantidad,
                BigDecimal costoPromedio,
                boolean existe
        ) {
            this.cantidad = cantidad;
            this.costoPromedio = costoPromedio;
            this.existe = existe;
        }
    }
}

        if (!Double.isFinite(cantidad)) {
            throw new SQLException(
                    "La cantidad debe ser un numero finito."
            );
        }

        if (cantidad < 0 || (!permitirCero && cantidad == 0)) {
            throw new SQLException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(cantidad).stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La cantidad supera el limite permitido."
            );
        }

        if (valor.scale() > ESCALA_CANTIDAD) {
            throw new SQLException(
                    "La cantidad admite como maximo tres decimales."
            );
        }

        return normalizarCantidad(valor);
    }

    private void validarCantidadEstricitamentePositiva(
            BigDecimal cantidad
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() <= 0) {
            throw new SQLException(
                    "La diferencia del ajuste debe ser mayor que cero."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La diferencia supera el limite permitido."
            );
        }
    }

    private void validarCantidadNoNegativa(
            BigDecimal cantidad,
            String campo
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() < 0) {
            throw new SQLException(
                    campo + " no puede ser nula ni negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    campo + " supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 19. VALIDAR CANTIDAD SEGUN UNIDAD DE MEDIDA
    // =========================================================

    private void validarCantidadUnidad(
            BigDecimal cantidad,
            String unidad
    ) throws SQLException {

        if (cantidad == null || unidad == null) {
            throw new SQLException(
                    "La cantidad y unidad de medida son obligatorias."
            );
        }

        String unidadNormalizada = unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidadNormalizada)) {
            throw new SQLException(
                    "La unidad de medida no esta permitida."
            );
        }

        if (UNIDADES_ENTERAS.contains(unidadNormalizada)
                && cantidad.stripTrailingZeros().scale() > 0) {
            throw new SQLException(
                    "La unidad " + unidadNormalizada
                    + " solamente admite cantidades enteras."
            );
        }
    }

    // =========================================================
    // 20. VALIDAR COSTO UNITARIO
    // =========================================================

    private BigDecimal validarCosto(double costoUnitario)
            throws SQLException {

        if (!Double.isFinite(costoUnitario) || costoUnitario < 0) {
            throw new SQLException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo = BigDecimal.valueOf(costoUnitario)
                .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo unitario supera el limite permitido."
            );
        }

        if (costo.scale() > ESCALA_COSTO) {
            throw new SQLException(
                    "El costo admite como maximo seis decimales."
            );
        }

        return normalizarCosto(costo);
    }

    // =========================================================
    // 21. VALIDAR COSTO PROMEDIO
    // =========================================================

    private void validarCostoPromedio(
            BigDecimal costoPromedio
    ) throws SQLException {

        if (costoPromedio == null) {
            throw new SQLException(
                    "El costo promedio no puede ser nulo."
            );
        }

        if (costoPromedio.signum() < 0) {
            throw new SQLException(
                    "El costo promedio no puede ser negativo."
            );
        }

        if (costoPromedio.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo promedio supera el limite permitido."
            );
        }

        try {
            costoPromedio.setScale(
                    ESCALA_COSTO,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El costo promedio admite como maximo "
                    + ESCALA_COSTO + " decimales.",
                    ex
            );
        }
    }

    // =========================================================
    // 22. VALIDAR STOCK RESULTANTE
    // =========================================================

    private void validarStockMaximo(BigDecimal stock)
            throws SQLException {

        if (stock == null || stock.signum() < 0) {
            throw new SQLException(
                    "El stock resultante no puede ser nulo ni negativo."
            );
        }

        if (stock.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El stock resultante supera el limite permitido."
            );
        }

        try {
            stock.setScale(
                    ESCALA_CANTIDAD,
                    RoundingMode.UNNECESSARY
            );
        } catch (ArithmeticException ex) {
            throw new SQLException(
                    "El stock resultante supera la precision permitida.",
                    ex
            );
        }
    }

    // =========================================================
    // 23. VALIDAR VALOR VALORIZADO
    // =========================================================

    private void validarValorSaldo(BigDecimal valor)
            throws SQLException {

        if (valor == null || valor.signum() < 0) {
            throw new SQLException(
                    "El valor valorizado no puede ser negativo."
            );
        }

        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new SQLException(
                    "El valor valorizado supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 24. VALIDAR DOCUMENTO
    // =========================================================

    private String validarDocumento(String documento)
            throws SQLException {

        if (documento == null || documento.isBlank()) {
            throw new SQLException(
                    "El documento es obligatorio."
            );
        }

        String normalizado = documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(normalizado).matches()) {
            throw new SQLException(
                    "El formato del documento no es valido."
            );
        }

        return normalizado;
    }

    // =========================================================
    // 25. VALIDAR OBSERVACION OPCIONAL
    // =========================================================

    private String validarObservacion(String observacion)
            throws SQLException {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new SQLException(
                    "La observacion contiene caracteres no permitidos."
            );
        }

        String normalizada = observacion.trim().replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new SQLException(
                    "La observacion supera los 500 caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 26. VALIDAR JUSTIFICACION OBLIGATORIA DE AJUSTE
    // =========================================================

    private String validarObservacionObligatoria(String observacion)
            throws SQLException {

        String normalizada = validarObservacion(observacion);

        if (normalizada == null
                || normalizada.length() < MIN_OBSERVACION_AJUSTE) {
            throw new SQLException(
                    "El ajuste requiere una justificacion "
                    + "de al menos cinco caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 27. ASIGNAR TEXTO OPCIONAL
    // =========================================================

    private void asignarTextoOpcional(
            PreparedStatement sentencia,
            int posicion,
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {
            sentencia.setNull(posicion, Types.VARCHAR);
        } else {
            sentencia.setString(posicion, valor);
        }
    }

    // =========================================================
    // 28. DETECTAR CARACTERES DE CONTROL
    // =========================================================

    private boolean contieneCaracteresDeControl(String texto) {
        for (int i = 0; i < texto.length(); i++) {
            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // 29. NORMALIZAR CANTIDAD
    // =========================================================

    private BigDecimal normalizarCantidad(BigDecimal valor) {
        return valor.setScale(
                ESCALA_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 30. NORMALIZAR COSTO
    // =========================================================

    private BigDecimal normalizarCosto(BigDecimal valor) {
        return valor.setScale(
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );
    }

    // =========================================================
    // 31. CONVERTIR NUMERO DE SQLITE A BIGDECIMAL
    // =========================================================

    private BigDecimal decimal(double valor) throws SQLException {
        if (!Double.isFinite(valor)) {
            throw new SQLException(
                    "La base de datos contiene un valor numerico invalido."
            );
        }

        return BigDecimal.valueOf(valor);
    }

    // =========================================================
    // 32. ROLLBACK
    // =========================================================

    private void rollback(Connection conexion, Exception errorOriginal) {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.rollback();
            }
        } catch (SQLException errorRollback) {
            errorOriginal.addSuppressed(errorRollback);
        }
    }

    // =========================================================
    // 33. CLASE INTERNA: INFORMACION DEL PRODUCTO
    // =========================================================

    private static class ProductoInfo {
        private final String unidadMedida;

        private ProductoInfo(String unidadMedida) {
            this.unidadMedida = unidadMedida;
        }
    }

    // =========================================================
    // 34. CLASE INTERNA: INVENTARIO ACTUAL
    // =========================================================

    private static class InventarioActual {
        private final BigDecimal cantidad;
        private final BigDecimal costoPromedio;
        private final boolean existe;

        private InventarioActual(
                BigDecimal cantidad,
                BigDecimal costoPromedio,
                boolean existe
        ) {
            this.cantidad = cantidad;
            this.costoPromedio = costoPromedio;
            this.existe = existe;
        }
    }
}
