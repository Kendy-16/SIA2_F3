
package pe.edu.inventario.vista.movimientos;

import pe.edu.inventario.controlador.AlmacenController;
import pe.edu.inventario.controlador.MovimientoController;
import pe.edu.inventario.controlador.ProductoController;
import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.modelo.Producto;
import pe.edu.inventario.vista.movimientos.componentes.EstilosMovimiento;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class AjusteInventarioView extends JPanel {

    private final MovimientoController movimientoController;
    private final ProductoController productoController;
    private final AlmacenController almacenController;

    private JComboBox<Producto> cmbProducto;
    private JComboBox<Almacen> cmbAlmacen;

    private JTextField txtDocumento;
    private JTextField txtCantidadFisica;

    private JTextArea txtObservacion;

    private JLabel lblCodigo;
    private JLabel lblUnidad;
    private JLabel lblStockSistema;
    private JLabel lblDiferencia;

    private JButton btnRegistrar;
    private JButton btnLimpiar;

    public AjusteInventarioView() {

        movimientoController = new MovimientoController();
        productoController = new ProductoController();
        almacenController = new AlmacenController();

        inicializarComponentes();
        cargarDatos();
        registrarEventos();
    }

    private void inicializarComponentes() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(22, 25, 22, 25));

        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        encabezado.setOpaque(false);

        JLabel titulo = EstilosMovimiento.crearTitulo(
                "Ajuste de inventario"
        );

        JLabel subtitulo = EstilosMovimiento.crearTextoSecundario(
                "Registra diferencias entre el conteo físico y el stock del sistema."
        );

        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(5));
        encabezado.add(subtitulo);

        add(encabezado, BorderLayout.NORTH);

        JPanel contenido = new JPanel(new BorderLayout(15, 15));
        contenido.setOpaque(false);

        JPanel formulario = crearFormulario();
        JPanel resumen = crearResumen();

        contenido.add(formulario, BorderLayout.CENTER);
        contenido.add(resumen, BorderLayout.SOUTH);

        add(contenido, BorderLayout.CENTER);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        acciones.setOpaque(false);

        btnLimpiar = new JButton("Limpiar");
        btnRegistrar = new JButton("Registrar ajuste");

        EstilosMovimiento.configurarBotonSecundario(btnLimpiar);
        EstilosMovimiento.configurarBotonPrimario(btnRegistrar);

        acciones.add(btnLimpiar);
        acciones.add(btnRegistrar);

        add(acciones, BorderLayout.SOUTH);
    }

    private JPanel crearFormulario() {

        JPanel panel = EstilosMovimiento.crearTarjeta();
        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(9, 10, 9, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        cmbProducto = new JComboBox<>();
        cmbAlmacen = new JComboBox<>();

        txtDocumento = new JTextField();
        txtCantidadFisica = new JTextField();

        txtObservacion = new JTextArea(4, 20);
        txtObservacion.setLineWrap(true);
        txtObservacion.setWrapStyleWord(true);

        EstilosMovimiento.configurarCombo(cmbProducto);
        EstilosMovimiento.configurarCombo(cmbAlmacen);
        EstilosMovimiento.configurarCampo(txtDocumento);
        EstilosMovimiento.configurarCampo(txtCantidadFisica);
        EstilosMovimiento.configurarArea(txtObservacion);

        int fila = 0;

        agregarCampo(panel, gbc, fila++, "Producto", cmbProducto);
        agregarCampo(panel, gbc, fila++, "Almacén", cmbAlmacen);
        agregarCampo(panel, gbc, fila++, "Documento de referencia", txtDocumento);
        agregarCampo(panel, gbc, fila++, "Cantidad física encontrada", txtCantidadFisica);

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 2;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;

        JPanel observacionPanel = new JPanel(new BorderLayout(5, 5));
        observacionPanel.setOpaque(false);

        observacionPanel.add(
                EstilosMovimiento.crearEtiqueta("Justificación del ajuste"),
                BorderLayout.NORTH
        );

        JScrollPane scroll = new JScrollPane(txtObservacion);
        scroll.setPreferredSize(new Dimension(300, 95));

        observacionPanel.add(scroll, BorderLayout.CENTER);

        panel.add(observacionPanel, gbc);

        return panel;
    }

    private JPanel crearResumen() {

        JPanel panel = EstilosMovimiento.crearTarjeta();
        panel.setLayout(new GridLayout(1, 4, 12, 5));

        lblCodigo = crearValorResumen("Código", "-");
        lblUnidad = crearValorResumen("Unidad", "-");
        lblStockSistema = crearValorResumen("Stock del sistema", "-");
        lblDiferencia = crearValorResumen("Diferencia", "-");

        panel.add(crearBloqueResumen("Código", lblCodigo));
        panel.add(crearBloqueResumen("Unidad", lblUnidad));
        panel.add(crearBloqueResumen("Stock del sistema", lblStockSistema));
        panel.add(crearBloqueResumen("Diferencia", lblDiferencia));

        return panel;
    }

    private JLabel crearValorResumen(String nombre, String valor) {
        JLabel etiqueta = new JLabel(valor);
        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 16));
        etiqueta.setForeground(new Color(35, 55, 80));
        return etiqueta;
    }

    private JPanel crearBloqueResumen(String titulo, JLabel valor) {

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel etiqueta = new JLabel(titulo);
        etiqueta.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        etiqueta.setForeground(new Color(110, 120, 135));

        panel.add(etiqueta);
        panel.add(Box.createVerticalStrut(7));
        panel.add(valor);

        return panel;
    }

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int fila,
            String etiqueta,
            JComponent componente
    ) {

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.30;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        panel.add(
                EstilosMovimiento.crearEtiqueta(etiqueta),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 0.70;

        panel.add(componente, gbc);
    }

    private void cargarDatos() {

        try {

            ArrayList<Producto> productos =
                    productoController.listarProductos();

            ArrayList<Almacen> almacenes =
                    almacenController.listarAlmacenes();

            cmbProducto.removeAllItems();
            cmbAlmacen.removeAllItems();

            for (Producto producto : productos) {
                cmbProducto.addItem(producto);
            }

            for (Almacen almacen : almacenes) {
                cmbAlmacen.addItem(almacen);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudieron cargar los productos y almacenes.\n"
                    + e.getMessage(),
                    "Error de carga",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void registrarEventos() {

        cmbProducto.addActionListener(e -> actualizarResumen());

        cmbAlmacen.addActionListener(e -> actualizarResumen());

        txtCantidadFisica.addCaretListener(e -> actualizarDiferencia());

        btnLimpiar.addActionListener(e -> limpiarFormulario());

        btnRegistrar.addActionListener(e -> registrarAjuste());
    }

    private void actualizarResumen() {

        Producto producto =
                (Producto) cmbProducto.getSelectedItem();

        if (producto == null) {
            lblCodigo.setText("-");
            lblUnidad.setText("-");
            return;
        }

        lblCodigo.setText(producto.getCodigo());
        lblUnidad.setText(producto.getUnidadMedida());

        lblStockSistema.setText(
                "Consultar inventario"
        );

        actualizarDiferencia();
    }

    private void actualizarDiferencia() {

        String cantidad = txtCantidadFisica.getText().trim();

        if (cantidad.isEmpty()) {
            lblDiferencia.setText("-");
            return;
        }

        try {

            double valor = Double.parseDouble(cantidad);

            if (!Double.isFinite(valor) || valor < 0) {
                lblDiferencia.setText("Valor inválido");
                return;
            }

            lblDiferencia.setText(
                    "Pendiente de validar"
            );

        } catch (NumberFormatException e) {

            lblDiferencia.setText("Valor inválido");
        }
    }

    private void registrarAjuste() {

        Producto producto =
                (Producto) cmbProducto.getSelectedItem();

        Almacen almacen =
                (Almacen) cmbAlmacen.getSelectedItem();

        String documento = txtDocumento.getText().trim();
        String cantidadTexto = txtCantidadFisica.getText().trim();
        String observacion = txtObservacion.getText().trim();

        if (producto == null) {
            mostrarAdvertencia("Selecciona un producto.");
            return;
        }

        if (almacen == null) {
            mostrarAdvertencia("Selecciona un almacén.");
            return;
        }

        if (documento.isBlank()) {
            mostrarAdvertencia("Ingresa el documento de referencia.");
            txtDocumento.requestFocus();
            return;
        }

        if (cantidadTexto.isBlank()) {
            mostrarAdvertencia("Ingresa la cantidad física encontrada.");
            txtCantidadFisica.requestFocus();
            return;
        }

        if (observacion.length() < 5) {
            mostrarAdvertencia(
                    "La justificación debe tener al menos 5 caracteres."
            );
            txtObservacion.requestFocus();
            return;
        }

        double cantidadFisica;

        try {

            cantidadFisica = Double.parseDouble(
                    cantidadTexto.replace(',', '.')
            );

            if (!Double.isFinite(cantidadFisica)
                    || cantidadFisica < 0) {

                mostrarAdvertencia(
                        "La cantidad física debe ser un número válido mayor o igual a cero."
                );
                return;
            }

        } catch (NumberFormatException e) {

            mostrarAdvertencia(
                    "La cantidad física debe ser numérica."
            );
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Confirmas el ajuste de inventario?\n\n"
                + "Producto: " + producto.getNombre() + "\n"
                + "Almacén: " + almacen.getNombre() + "\n"
                + "Cantidad física: " + cantidadFisica + "\n\n"
                + "Esta operación actualizará el inventario y el Kardex.",
                "Confirmar ajuste",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        btnRegistrar.setEnabled(false);

        try {

            movimientoController.registrarMovimientoAjuste(
                    producto.getIdProducto(),
                    almacen.getIdAlmacen(),
                    documento,
                    cantidadFisica,
                    observacion
            );

            JOptionPane.showMessageDialog(
                    this,
                    "El ajuste de inventario se registró correctamente.",
                    "Ajuste registrado",
                    JOptionPane.INFORMATION_MESSAGE
            );

            limpiarFormulario();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo registrar el ajuste.\n\n"
                    + e.getMessage(),
                    "Error al registrar",
                    JOptionPane.ERROR_MESSAGE
            );

        } finally {

            btnRegistrar.setEnabled(true);
        }
    }

    private void limpiarFormulario() {

        cmbProducto.setSelectedIndex(-1);
        cmbAlmacen.setSelectedIndex(-1);

        txtDocumento.setText("");
        txtCantidadFisica.setText("");
        txtObservacion.setText("");

        lblCodigo.setText("-");
        lblUnidad.setText("-");
        lblStockSistema.setText("-");
        lblDiferencia.setText("-");
    }

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validación",
                JOptionPane.WARNING_MESSAGE
        );
    }
}
