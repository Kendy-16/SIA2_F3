
package pe.edu.inventario.vista.movimientos;

import pe.edu.inventario.modelo.MovimientoHistorial;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;

/**
 * Vista del historial general de movimientos.
 *
 * Presenta los movimientos de entrada, salida y ajuste
 * registrados en el sistema.
 *
 * Permite buscar, filtrar y ordenar los registros.
 *
 * No contiene instrucciones SQL ni acceso directo
 * a la base de datos.
 */
public class HistorialMovimientosView extends JPanel {

    // ==================================================
    // 1. ATRIBUTOS
    // ==================================================

    private JTable tablaHistorial;
    private DefaultTableModel modeloTabla;

    private JComboBox<String> comboTipo;
    private JTextField txtBuscar;

    private JButton btnBuscar;
    private JButton btnLimpiar;

    private JLabel lblTotalRegistros;
    private JLabel lblEstado;

    private TableRowSorter<DefaultTableModel> ordenador;

    // ==================================================
    // 2. CONSTANTES
    // ==================================================

    private static final int MAX_CARACTERES_BUSQUEDA = 100;

    private static final int[] COLUMNAS_BUSQUEDA = {
        4, 5, 6, 7, 12
    };

    private static final String[] TIPOS_MOVIMIENTO = {
        "Todos",
        "ENTRADA",
        "SALIDA",
        "AJUSTE"
    };

    private static final DecimalFormat FORMATO_CANTIDAD =
            crearFormato("#,##0.000");

    private static final DecimalFormat FORMATO_COSTO =
            crearFormato("#,##0.000000");

    // ==================================================
    // 3. CONSTRUCTOR
    // ==================================================

    public HistorialMovimientosView() {

        inicializarComponentes();
    }

    // ==================================================
    // 4. INICIALIZAR COMPONENTES
    // ==================================================

    private void inicializarComponentes() {

        setLayout(new BorderLayout(12, 12));

        setBackground(new Color(245, 247, 250));

        setBorder(
                BorderFactory.createEmptyBorder(
                        20, 20, 20, 20
                )
        );

        // Panel superior: encabezado y filtros.
        JPanel panelSuperior = new JPanel(
                new BorderLayout(10, 12)
        );

        panelSuperior.setOpaque(false);

        panelSuperior.add(
                crearPanelEncabezado(),
                BorderLayout.NORTH
        );

        panelSuperior.add(
                crearPanelFiltros(),
                BorderLayout.CENTER
        );

        add(panelSuperior, BorderLayout.NORTH);

        agregarTabla();

        agregarPie();

        registrarEventos();
    }

    // ==================================================
    // 5. ENCABEZADO
    // ==================================================

    private JPanel crearPanelEncabezado() {

        JPanel panel = new JPanel(
                new BorderLayout(5, 8)
        );

        panel.setOpaque(false);

        JLabel titulo = new JLabel(
                "Historial general de movimientos"
        );

        titulo.setFont(
                new Font("Arial", Font.BOLD, 22)
        );

        JLabel subtitulo = new JLabel(
                "Consulta y revisa los movimientos "
                + "registrados en el inventario."
        );

        subtitulo.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        subtitulo.setForeground(Color.GRAY);

        panel.add(
                titulo,
                BorderLayout.NORTH
        );

        panel.add(
                subtitulo,
                BorderLayout.CENTER
        );

        return panel;
    }

    // ==================================================
    // 6. PANEL DE FILTROS
    // ==================================================

    private JPanel crearPanelFiltros() {

        JPanel panelFiltros = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 10, 8)
        );

        panelFiltros.setBackground(Color.WHITE);

        panelFiltros.setBorder(
                BorderFactory.createTitledBorder(
                        "Filtros del historial"
                )
        );

        JLabel lblTipo = new JLabel("Tipo:");

        comboTipo = new JComboBox<>(
                TIPOS_MOVIMIENTO.clone()
        );

        comboTipo.setPreferredSize(
                new Dimension(130, 30)
        );

        JLabel lblBuscar = new JLabel("Buscar:");

        txtBuscar = new JTextField(20);

        txtBuscar.setToolTipText(
                "Buscar por documento, código, producto o almacén"
        );

        btnBuscar = new JButton("Buscar");

        btnLimpiar = new JButton("Limpiar");

        panelFiltros.add(lblTipo);
        panelFiltros.add(comboTipo);
        panelFiltros.add(lblBuscar);
        panelFiltros.add(txtBuscar);
        panelFiltros.add(btnBuscar);
        panelFiltros.add(btnLimpiar);

        return panelFiltros;
    }

    // ==================================================
    // 7. TABLA
    // ==================================================

    private void agregarTabla() {

        String[] columnas = {
            "ID detalle",
            "ID movimiento",
            "Fecha",
            "Tipo",
            "Documento",
            "Código",
            "Producto",
            "Almacén",
            "Unidad",
            "Cantidad",
            "Costo unitario",
            "Subtotal",
            "Observación"
        };

        modeloTabla = new DefaultTableModel(
                columnas,
                0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna
            ) {

                return false;
            }

            @Override
            public Class<?> getColumnClass(int columna) {

                return switch (columna) {

                    case 0, 1 -> Integer.class;

                    case 9, 10, 11 -> BigDecimal.class;

                    default -> String.class;
                };
            }
        };

        tablaHistorial = new JTable(modeloTabla);

        tablaHistorial.setRowHeight(28);

        tablaHistorial.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaHistorial.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        tablaHistorial.setFillsViewportHeight(true);

        tablaHistorial.setAutoCreateRowSorter(false);

        tablaHistorial.getTableHeader()
                .setReorderingAllowed(false);

        ordenador = new TableRowSorter<>(modeloTabla);

        tablaHistorial.setRowSorter(ordenador);

        configurarAnchosColumnas();

        configurarRenderizadores();

        configurarOrdenamiento();

        JScrollPane scroll = new JScrollPane(
                tablaHistorial
        );

        scroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 225, 230)
                )
        );

        add(scroll, BorderLayout.CENTER);
    }

    // ==================================================
    // 8. ANCHOS DE COLUMNAS
    // ==================================================

    private void configurarAnchosColumnas() {

        int[] anchos = {
            80, 100, 150, 100, 120, 100, 180,
            150, 100, 110, 140, 140, 220
        };

        for (int i = 0; i < anchos.length; i++) {

            tablaHistorial.getColumnModel()
                    .getColumn(i)
                    .setPreferredWidth(anchos[i]);
        }
    }

    // ==================================================
    // 9. RENDERIZADORES
    // ==================================================

    private void configurarRenderizadores() {

        DefaultTableCellRenderer centrado =
                new DefaultTableCellRenderer();

        centrado.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        tablaHistorial.getColumnModel()
                .getColumn(0)
                .setCellRenderer(centrado);

        tablaHistorial.getColumnModel()
                .getColumn(1)
                .setCellRenderer(centrado);

        tablaHistorial.getColumnModel()
                .getColumn(3)
                .setCellRenderer(centrado);

        DefaultTableCellRenderer rendererCantidad =
                crearRendererNumerico(FORMATO_CANTIDAD);

        DefaultTableCellRenderer rendererCosto =
                crearRendererNumerico(FORMATO_COSTO);

        tablaHistorial.getColumnModel()
                .getColumn(9)
                .setCellRenderer(rendererCantidad);

        tablaHistorial.getColumnModel()
                .getColumn(10)
                .setCellRenderer(rendererCosto);

        tablaHistorial.getColumnModel()
                .getColumn(11)
                .setCellRenderer(rendererCosto);
    }

    /**
     * Crea un renderizador independiente para cada formato.
     */
    private DefaultTableCellRenderer crearRendererNumerico(
            DecimalFormat formato
    ) {

        DefaultTableCellRenderer renderer =
                new DefaultTableCellRenderer() {

            @Override
            protected void setValue(Object valor) {

                if (valor == null) {

                    setText("");

                    return;
                }

                if (valor instanceof BigDecimal numero) {

                    setText(formato.format(numero));

                    return;
                }

                setText("");
            }
        };

        renderer.setHorizontalAlignment(
                SwingConstants.RIGHT
        );

        return renderer;
    }

    // ==================================================
    // 10. ORDENAMIENTO
    // ==================================================

    private void configurarOrdenamiento() {

        ordenador.setComparator(
                9,
                (a, b) -> compararBigDecimal(a, b)
        );

        ordenador.setComparator(
                10,
                (a, b) -> compararBigDecimal(a, b)
        );

        ordenador.setComparator(
                11,
                (a, b) -> compararBigDecimal(a, b)
        );
    }

    private int compararBigDecimal(
            Object valorA,
            Object valorB
    ) {

        if (valorA == null && valorB == null) {
            return 0;
        }

        if (valorA == null) {
            return -1;
        }

        if (valorB == null) {
            return 1;
        }

        if (!(valorA instanceof BigDecimal a)
                || !(valorB instanceof BigDecimal b)) {

            return 0;
        }

        return a.compareTo(b);
    }

    // ==================================================
    // 11. PIE DE LA VISTA
    // ==================================================

    private void agregarPie() {

        JPanel panelInferior = new JPanel(
                new BorderLayout()
        );

        panelInferior.setOpaque(false);

        lblTotalRegistros = new JLabel(
                "Total de registros visibles: 0"
        );

        lblTotalRegistros.setFont(
                new Font("Arial", Font.BOLD, 12)
        );

        lblEstado = new JLabel(
                "Esperando consulta."
        );

        lblEstado.setForeground(Color.GRAY);

        panelInferior.add(
                lblTotalRegistros,
                BorderLayout.WEST
        );

        panelInferior.add(
                lblEstado,
                BorderLayout.EAST
        );

        add(panelInferior, BorderLayout.SOUTH);
    }

    // ==================================================
    // 12. EVENTOS
    // ==================================================

    private void registrarEventos() {

        btnBuscar.addActionListener(
                e -> aplicarFiltros()
        );

        txtBuscar.addActionListener(
                e -> aplicarFiltros()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFiltros()
        );
    }

    // ==================================================
    // 13. APLICAR FILTROS
    // ==================================================

    private void aplicarFiltros() {

        // Validar tipo seleccionado.
        Object seleccion = comboTipo.getSelectedItem();

        if (seleccion == null) {

            mostrarError(
                    "Debe seleccionar un tipo de movimiento."
            );

            comboTipo.requestFocusInWindow();

            return;
        }

        String tipo = seleccion.toString().trim();

        if (!esTipoPermitido(tipo)) {

            mostrarError(
                    "El tipo de movimiento seleccionado no es válido."
            );

            comboTipo.requestFocusInWindow();

            return;
        }

        // Validar texto de búsqueda.
        String busqueda = txtBuscar.getText();

        if (busqueda == null) {
            busqueda = "";
        }

        busqueda = busqueda.trim();

        if (busqueda.length() > MAX_CARACTERES_BUSQUEDA) {

            mostrarError(
                    "La búsqueda no puede superar "
                    + MAX_CARACTERES_BUSQUEDA
                    + " caracteres."
            );

            txtBuscar.requestFocusInWindow();

            return;
        }

        if (contieneCaracteresControl(busqueda)) {

            mostrarError(
                    "La búsqueda contiene caracteres no permitidos."
            );

            txtBuscar.requestFocusInWindow();

            return;
        }

        String busquedaNormalizada =
                busqueda.toLowerCase(Locale.ROOT);

        // Construir filtro.
        RowFilter<DefaultTableModel, Integer> filtro =
                new RowFilter<>() {

            @Override
            public boolean include(
                    Entry<? extends DefaultTableModel,
                    ? extends Integer> entrada
            ) {

                String tipoFila =
                        entrada.getStringValue(3);

                // Filtrar por tipo.
                if (!tipo.equals("Todos")
                        && !tipo.equalsIgnoreCase(tipoFila)) {

                    return false;
                }

                // Sin texto de búsqueda.
                if (busquedaNormalizada.isEmpty()) {
                    return true;
                }

                // Buscar en las columnas permitidas.
                for (int columna : COLUMNAS_BUSQUEDA) {

                    String valor =
                            entrada.getStringValue(columna);

                    if (valor != null
                            && valor.toLowerCase(Locale.ROOT)
                                    .contains(busquedaNormalizada)) {

                        return true;
                    }
                }

                return false;
            }
        };

        ordenador.setRowFilter(filtro);

        actualizarTotalVisible();

        lblEstado.setText(
                "Filtros aplicados correctamente."
        );
    }

    // ==================================================
    // 14. VALIDAR TIPO
    // ==================================================

    private boolean esTipoPermitido(String tipo) {

        if (tipo == null) {
            return false;
        }

        for (String permitido : TIPOS_MOVIMIENTO) {

            if (permitido.equals(tipo)) {
                return true;
            }
        }

        return false;
    }

    // ==================================================
    // 15. VALIDAR CARACTERES DE CONTROL
    // ==================================================

    private boolean contieneCaracteresControl(
            String texto
    ) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(
                    texto.charAt(i)
            )) {

                return true;
            }
        }

        return false;
    }

    // ==================================================
    // 16. LIMPIAR FILTROS
    // ==================================================

    private void limpiarFiltros() {

        comboTipo.setSelectedIndex(0);

        txtBuscar.setText("");

        ordenador.setRowFilter(null);

        actualizarTotalVisible();

        lblEstado.setText(
                "Filtros limpiados correctamente."
        );

        txtBuscar.requestFocusInWindow();
    }

    // ==================================================
    // 17. CARGAR REGISTROS
    // ==================================================

    /**
     * Reemplaza los registros mostrados en la tabla.
     *
     * Este método debe ser invocado por el controlador
     * después de consultar los datos mediante el servicio.
     *
     * La lista se procesa en el EDT de Swing.
     */
    public void cargarMovimientos(
            List<MovimientoHistorial> movimientos
    ) {

        if (!SwingUtilities.isEventDispatchThread()) {

            SwingUtilities.invokeLater(
                    () -> cargarMovimientos(movimientos)
            );

            return;
        }

        modeloTabla.setRowCount(0);

        ordenador.setRowFilter(null);

        // Validar lista.
        if (movimientos == null) {

            actualizarTotalVisible();

            lblEstado.setText(
                    "No se recibieron registros."
            );

            return;
        }

        // Validar lista vacía.
        if (movimientos.isEmpty()) {

            actualizarTotalVisible();

            lblEstado.setText(
                    "No existen movimientos registrados."
            );

            return;
        }

        int registrosCargados = 0;

        int registrosOmitidos = 0;

        for (MovimientoHistorial movimiento : movimientos) {

            // Evitar registros nulos.
            if (movimiento == null) {

                registrosOmitidos++;

                continue;
            }

            try {

                modeloTabla.addRow(
                        new Object[]{
                            movimiento.getIdDetalle(),
                            movimiento.getIdMovimiento(),
                            movimiento.getFecha(),
                            movimiento.getTipo(),
                            movimiento.getDocumento(),
                            movimiento.getCodigoProducto(),
                            movimiento.getProducto(),
                            movimiento.getAlmacen(),
                            movimiento.getUnidadMedida(),
                            movimiento.getCantidad(),
                            movimiento.getCostoUnitario(),
                            movimiento.getSubtotal(),
                            movimiento.getObservacion()
                        }
                );

                registrosCargados++;

            } catch (RuntimeException ex) {

                registrosOmitidos++;
            }
        }

        actualizarTotalVisible();

        if (registrosOmitidos > 0) {

            lblEstado.setText(
                    "Se cargaron " + registrosCargados
                    + " registros. Se omitieron "
                    + registrosOmitidos
                    + " registros inválidos."
            );

        } else {

            lblEstado.setText(
                    "Historial cargado correctamente. "
                    + "Registros: " + registrosCargados
            );
        }
    }

    // ==================================================
    // 18. LIMPIAR TABLA
    // ==================================================

    public void limpiarTabla() {

        if (!SwingUtilities.isEventDispatchThread()) {

            SwingUtilities.invokeLater(
                    this::limpiarTabla
            );

            return;
        }

        modeloTabla.setRowCount(0);

        ordenador.setRowFilter(null);

        actualizarTotalVisible();

        lblEstado.setText(
                "La tabla está vacía."
        );
    }

    // ==================================================
    // 19. ACTUALIZAR CONTADOR
    // ==================================================

    private void actualizarTotalVisible() {

        if (tablaHistorial == null
                || lblTotalRegistros == null) {

            return;
        }

        int total = tablaHistorial.getRowCount();

        lblTotalRegistros.setText(
                "Total de registros visibles: " + total
        );
    }

    // ==================================================
    // 20. FORMATO DECIMAL
    // ==================================================

    private static DecimalFormat crearFormato(
            String patron
    ) {

        DecimalFormatSymbols simbolos =
                new DecimalFormatSymbols(
                        Locale.forLanguageTag("es-PE")
                );

        DecimalFormat formato =
                new DecimalFormat(patron, simbolos);

        formato.setGroupingUsed(true);

        formato.setParseBigDecimal(true);

        return formato;
    }

    // ==================================================
    // 21. MOSTRAR MENSAJES
    // ==================================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validación",
                JOptionPane.WARNING_MESSAGE
        );
    }

    // ==================================================
    // 22. GETTERS
    // ==================================================

    public JTable getTablaHistorial() {

        return tablaHistorial;
    }

    public DefaultTableModel getModeloTabla() {

        return modeloTabla;
    }

    public JComboBox<String> getComboTipo() {

        return comboTipo;
    }

    public JTextField getTxtBuscar() {

        return txtBuscar;
    }

    public JButton getBtnBuscar() {

        return btnBuscar;
    }

    public JButton getBtnLimpiar() {

        return btnLimpiar;
    }

    public JLabel getLblTotalRegistros() {

        return lblTotalRegistros;
    }

    public JLabel getLblEstado() {

        return lblEstado;
    }
}
