
package pe.edu.inventario.vista.almacen;

import pe.edu.inventario.controlador.AlmacenController;
import pe.edu.inventario.modelo.Almacen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class AlmacenView extends JPanel {

    // =====================================================
    // COLORES
    // =====================================================

    private static final Color FONDO =
            new Color(244, 247, 251);

    private static final Color BLANCO =
            Color.WHITE;

    private static final Color PRINCIPAL =
            new Color(43, 54, 68);

    private static final Color VERDE =
            new Color(34, 139, 94);

    private static final Color ROJO =
            new Color(190, 65, 65);

    private static final Color GRIS =
            new Color(100, 112, 125);

    private static final Color BORDE =
            new Color(220, 226, 234);

    private static final Color TEXTO =
            new Color(43, 54, 68);

    private static final Color SELECCION =
            new Color(229, 239, 250);

    // =====================================================
    // CONTROLADOR Y COMPONENTES
    // =====================================================

    private final AlmacenController controlador;

    private JTextField txtNombre;
    private JTextField txtUbicacion;
    private JTextField txtBuscar;

    private JTable tablaAlmacenes;
    private DefaultTableModel modeloTabla;

    private JLabel lblTotal;
    private JLabel lblEstado;

    private JButton btnNuevo;
    private JButton btnGuardar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;

    private int idSeleccionado = 0;

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public AlmacenView() {

        controlador = new AlmacenController();

        configurarPanel();
        inicializarComponentes();
        cargarAlmacenes();
        configurarEventos();
    }

    // =====================================================
    // CONFIGURAR PANEL PRINCIPAL
    // =====================================================

    private void configurarPanel() {

        setLayout(new BorderLayout(15, 15));
        setBackground(FONDO);
        setBorder(new EmptyBorder(18, 20, 18, 20));
    }

    // =====================================================
    // INICIALIZAR COMPONENTES
    // =====================================================

    private void inicializarComponentes() {

        add(crearEncabezado(), BorderLayout.NORTH);
        add(crearContenido(), BorderLayout.CENTER);
        add(crearPie(), BorderLayout.SOUTH);
    }

    // =====================================================
    // ENCABEZADO SIN CUADRO AZUL
    // =====================================================

    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(FONDO);
        panel.setBorder(new EmptyBorder(5, 2, 8, 2));

        JPanel textos = new JPanel();

        textos.setLayout(
                new BoxLayout(textos, BoxLayout.Y_AXIS)
        );

        textos.setOpaque(false);

        JLabel titulo = new JLabel("GESTIÓN DE ALMACENES");

        titulo.setFont(
                new Font("Segoe UI", Font.BOLD, 23)
        );

        titulo.setForeground(TEXTO);

        JLabel subtitulo = new JLabel(
                "Administración de almacenes y ubicaciones"
        );

        subtitulo.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        subtitulo.setForeground(GRIS);

        textos.add(titulo);
        textos.add(Box.createVerticalStrut(5));
        textos.add(subtitulo);

        panel.add(textos, BorderLayout.WEST);

        return panel;
    }

    // =====================================================
    // CONTENIDO PRINCIPAL
    // =====================================================

    private JPanel crearContenido() {

        JPanel panel = new JPanel(
                new BorderLayout(15, 15)
        );

        panel.setOpaque(false);

        panel.add(
                crearFormulario(),
                BorderLayout.NORTH
        );

        panel.add(
                crearTabla(),
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // FORMULARIO
    // =====================================================

    private JPanel crearFormulario() {

        JPanel panel = crearPanelBase(
                "DATOS DEL ALMACÉN"
        );

        JPanel campos = new JPanel(
                new GridLayout(1, 2, 15, 10)
        );

        campos.setBackground(BLANCO);

        txtNombre = crearCampo();
        txtUbicacion = crearCampo();

        txtNombre.setToolTipText(
                "Ingrese el nombre del almacén"
        );

        txtUbicacion.setToolTipText(
                "Ingrese la dirección o ubicación del almacén"
        );

        campos.add(
                crearCampoFormulario(
                        "Nombre del almacén",
                        txtNombre
                )
        );

        campos.add(
                crearCampoFormulario(
                        "Ubicación",
                        txtUbicacion
                )
        );

        JPanel botones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 9, 5)
        );

        botones.setBackground(BLANCO);

        btnNuevo = crearBoton(
                "Nuevo",
                GRIS
        );

        btnGuardar = crearBoton(
                "Guardar",
                VERDE
        );

        btnActualizar = crearBoton(
                "Actualizar",
                new Color(79, 110, 160)
        );

        btnEliminar = crearBoton(
                "Eliminar",
                ROJO
        );

        btnLimpiar = crearBoton(
                "Limpiar",
                GRIS
        );

        botones.add(btnNuevo);
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        panel.add(
                campos,
                BorderLayout.CENTER
        );

        panel.add(
                botones,
                BorderLayout.SOUTH
        );

        return panel;
    }

    // =====================================================
    // CAMPO DEL FORMULARIO
    // =====================================================

    private JPanel crearCampoFormulario(
            String etiqueta,
            JTextField campo
    ) {

        JPanel panel = new JPanel(
                new BorderLayout(5, 7)
        );

        panel.setBackground(BLANCO);

        JLabel label = new JLabel(etiqueta);

        label.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        label.setForeground(TEXTO);

        panel.add(
                label,
                BorderLayout.NORTH
        );

        panel.add(
                campo,
                BorderLayout.CENTER
        );

        return panel;
    }

    // =====================================================
    // TABLA DE ALMACENES
    // =====================================================

    private JPanel crearTabla() {

        JPanel panel = crearPanelBase(
                "LISTADO DE ALMACENES"
        );

        // Barra de búsqueda

        JPanel busqueda = new JPanel(
                new BorderLayout(12, 0)
        );

        busqueda.setBackground(BLANCO);

        JLabel etiquetaBuscar = new JLabel("Buscar:");

        etiquetaBuscar.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        etiquetaBuscar.setForeground(TEXTO);

        txtBuscar = crearCampo();

        txtBuscar.setToolTipText(
                "Buscar por nombre o ubicación"
        );

        JButton btnBuscar = crearBoton(
                "Buscar",
                new Color(79, 110, 160)
        );

        JButton btnMostrarTodos = crearBoton(
                "Mostrar todos",
                GRIS
        );

        JPanel accionesBusqueda = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 8, 0)
        );

        accionesBusqueda.setBackground(BLANCO);

        accionesBusqueda.add(btnBuscar);
        accionesBusqueda.add(btnMostrarTodos);

        busqueda.add(
                etiquetaBuscar,
                BorderLayout.WEST
        );

        busqueda.add(
                txtBuscar,
                BorderLayout.CENTER
        );

        busqueda.add(
                accionesBusqueda,
                BorderLayout.EAST
        );

        // Encabezado superior

        JPanel superior = new JPanel(
                new BorderLayout(10, 12)
        );

        superior.setBackground(BLANCO);

        superior.add(
                busqueda,
                BorderLayout.CENTER
        );

        // Modelo de tabla

        modeloTabla = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "NOMBRE DEL ALMACÉN",
                        "UBICACIÓN"
                },
                0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila,
                    int columna
            ) {

                return false;
            }
        };

        tablaAlmacenes = new JTable(modeloTabla);

        tablaAlmacenes.setRowHeight(32);

        tablaAlmacenes.setFont(
                new Font("Segoe UI", Font.PLAIN, 12)
        );

        tablaAlmacenes.setForeground(TEXTO);
        tablaAlmacenes.setBackground(BLANCO);

        tablaAlmacenes.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaAlmacenes.setAutoCreateRowSorter(true);

        tablaAlmacenes.setShowGrid(true);
        tablaAlmacenes.setGridColor(BORDE);
        tablaAlmacenes.setFillsViewportHeight(true);

        tablaAlmacenes.setSelectionBackground(SELECCION);
        tablaAlmacenes.setSelectionForeground(TEXTO);

        // Encabezado de columnas

        tablaAlmacenes.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        tablaAlmacenes.getTableHeader().setBackground(
                new Color(234, 240, 247)
        );

        tablaAlmacenes.getTableHeader().setForeground(TEXTO);

        tablaAlmacenes.getTableHeader().setPreferredSize(
                new Dimension(0, 36)
        );

        // Ancho de columnas

        tablaAlmacenes.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(60);

        tablaAlmacenes.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(240);

        tablaAlmacenes.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(280);

        // Centrar ID

        DefaultTableCellRenderer centrado =
                new DefaultTableCellRenderer();

        centrado.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        tablaAlmacenes.getColumnModel()
                .getColumn(0)
                .setCellRenderer(centrado);

        // Scroll

        JScrollPane scroll = new JScrollPane(
                tablaAlmacenes
        );

        scroll.setBorder(
                new LineBorder(BORDE)
        );

        scroll.setPreferredSize(
                new Dimension(700, 260)
        );

        // Total

        lblTotal = new JLabel(
                "Total de almacenes: 0"
        );

        lblTotal.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        lblTotal.setForeground(GRIS);

        JPanel inferior = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 0, 5)
        );

        inferior.setBackground(BLANCO);
        inferior.add(lblTotal);

        panel.add(
                superior,
                BorderLayout.NORTH
        );

        panel.add(
                scroll,
                BorderLayout.CENTER
        );

        panel.add(
                inferior,
                BorderLayout.SOUTH
        );

        // Eventos de búsqueda

        btnBuscar.addActionListener(
                e -> buscarAlmacenes()
        );

        btnMostrarTodos.addActionListener(e -> {

            txtBuscar.setText("");
            cargarAlmacenes();

        });

        txtBuscar.addActionListener(
                e -> buscarAlmacenes()
        );

        return panel;
    }

    // =====================================================
    // PANEL BASE
    // =====================================================

    private JPanel crearPanelBase(String titulo) {

        JPanel panel = new JPanel(
                new BorderLayout(12, 12)
        );

        panel.setBackground(BLANCO);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(BORDE),
                        new EmptyBorder(15, 16, 15, 16)
                )
        );

        JLabel encabezado = new JLabel(titulo);

        encabezado.setFont(
                new Font("Segoe UI", Font.BOLD, 13)
        );

        encabezado.setForeground(TEXTO);

        panel.add(
                encabezado,
                BorderLayout.NORTH
        );

        return panel;
    }

    // =====================================================
    // PIE
    // =====================================================

    private JPanel crearPie() {

        JPanel panel = new JPanel(
                new BorderLayout()
        );

        panel.setBackground(FONDO);

        lblEstado = new JLabel(
                "Sistema de gestión de almacenes"
        );

        lblEstado.setFont(
                new Font("Segoe UI", Font.PLAIN, 11)
        );

        lblEstado.setForeground(GRIS);

        panel.add(
                lblEstado,
                BorderLayout.WEST
        );

        return panel;
    }

    // =====================================================
    // CONFIGURAR CAMPO
    // =====================================================

    private JTextField crearCampo() {

        JTextField campo = new JTextField();

        campo.setFont(
                new Font("Segoe UI", Font.PLAIN, 13)
        );

        campo.setForeground(TEXTO);
        campo.setBackground(BLANCO);

        campo.setPreferredSize(
                new Dimension(200, 36)
        );

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(BORDE),
                        new EmptyBorder(7, 10, 7, 10)
                )
        );

        return campo;
    }

    // =====================================================
    // CONFIGURAR BOTÓN
    // =====================================================

    private JButton crearBoton(
            String texto,
            Color color
    ) {

        JButton boton = new JButton(texto);

        boton.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        boton.setForeground(Color.WHITE);
        boton.setBackground(color);

        boton.setFocusPainted(false);
        boton.setBorderPainted(false);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setBorder(
                new EmptyBorder(9, 15, 9, 15)
        );

        boton.setPreferredSize(
                new Dimension(105, 36)
        );

        return boton;
    }

    // =====================================================
    // CONFIGURAR EVENTOS
    // =====================================================

    private void configurarEventos() {

        btnNuevo.addActionListener(
                e -> limpiarFormulario()
        );

        btnGuardar.addActionListener(
                e -> registrarAlmacen()
        );

        btnActualizar.addActionListener(
                e -> actualizarAlmacen()
        );

        btnEliminar.addActionListener(
                e -> eliminarAlmacen()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFormulario()
        );

        tablaAlmacenes.getSelectionModel()
                .addListSelectionListener(e -> {

                    if (!e.getValueIsAdjusting()) {
                        seleccionarAlmacen();
                    }
                });
    }

    // =====================================================
    // REGISTRAR ALMACÉN
    // =====================================================

    private void registrarAlmacen() {

        try {

            Almacen almacen = new Almacen();

            almacen.setNombre(
                    txtNombre.getText()
            );

            almacen.setUbicacion(
                    txtUbicacion.getText()
            );

            boolean registrado =
                    controlador.registrarAlmacen(almacen);

            if (registrado) {

                mostrarMensaje(
                        "Almacén registrado correctamente.",
                        "Registro exitoso",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError(
                        "No se pudo registrar el almacén."
                );
            }

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());

        } catch (SQLException ex) {

            mostrarError(
                    "Error de base de datos: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // ACTUALIZAR ALMACÉN
    // =====================================================

    private void actualizarAlmacen() {

        if (idSeleccionado <= 0) {

            mostrarError(
                    "Seleccione un almacén de la tabla."
            );

            return;
        }

        try {

            Almacen almacen = new Almacen();

            almacen.setIdAlmacen(idSeleccionado);

            almacen.setNombre(
                    txtNombre.getText()
            );

            almacen.setUbicacion(
                    txtUbicacion.getText()
            );

            boolean actualizado =
                    controlador.actualizarAlmacen(almacen);

            if (actualizado) {

                mostrarMensaje(
                        "Almacén actualizado correctamente.",
                        "Actualización exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError(
                        "No se encontró el almacén seleccionado."
                );
            }

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());

        } catch (SQLException ex) {

            mostrarError(
                    "Error de base de datos: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // ELIMINAR ALMACÉN
    // =====================================================

    private void eliminarAlmacen() {

        if (idSeleccionado <= 0) {

            mostrarError(
                    "Seleccione un almacén de la tabla."
            );

            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Está seguro de eliminar el almacén seleccionado?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean eliminado =
                    controlador.eliminarAlmacen(idSeleccionado);

            if (eliminado) {

                mostrarMensaje(
                        "Almacén eliminado correctamente.",
                        "Eliminación exitosa",
                        JOptionPane.INFORMATION_MESSAGE
                );

                cargarAlmacenes();
                limpiarFormulario();

            } else {

                mostrarError(
                        "No se pudo encontrar el almacén."
                );
            }

        } catch (SQLException ex) {

            mostrarError(
                    "No se puede eliminar el almacén. "
                    + "Puede tener movimientos o existencias asociadas.\n"
                    + ex.getMessage()
            );

        } catch (IllegalArgumentException ex) {

            mostrarError(ex.getMessage());
        }
    }

    // =====================================================
    // CARGAR ALMACENES
    // =====================================================

    private void cargarAlmacenes() {

        try {

            ArrayList<Almacen> almacenes =
                    controlador.listarAlmacenes();

            modeloTabla.setRowCount(0);

            for (Almacen almacen : almacenes) {

                modeloTabla.addRow(
                        new Object[]{
                                almacen.getIdAlmacen(),
                                almacen.getNombre(),
                                almacen.getUbicacion() == null
                                        ? ""
                                        : almacen.getUbicacion()
                        }
                );
            }

            lblTotal.setText(
                    "Total de almacenes: " + almacenes.size()
            );

            lblEstado.setText(
                    "Listado actualizado correctamente."
            );

        } catch (SQLException ex) {

            mostrarError(
                    "No se pudieron cargar los almacenes: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // BUSCAR ALMACENES
    // =====================================================

    private void buscarAlmacenes() {

        String texto = txtBuscar.getText()
                .trim()
                .toLowerCase();

        if (texto.isEmpty()) {

            cargarAlmacenes();
            return;
        }

        try {

            ArrayList<Almacen> almacenes =
                    controlador.listarAlmacenes();

            modeloTabla.setRowCount(0);

            int encontrados = 0;

            for (Almacen almacen : almacenes) {

                String nombre = almacen.getNombre() == null
                        ? ""
                        : almacen.getNombre().toLowerCase();

                String ubicacion = almacen.getUbicacion() == null
                        ? ""
                        : almacen.getUbicacion().toLowerCase();

                if (nombre.contains(texto)
                        || ubicacion.contains(texto)) {

                    modeloTabla.addRow(
                            new Object[]{
                                    almacen.getIdAlmacen(),
                                    almacen.getNombre(),
                                    almacen.getUbicacion() == null
                                            ? ""
                                            : almacen.getUbicacion()
                            }
                    );

                    encontrados++;
                }
            }

            lblTotal.setText(
                    "Almacenes encontrados: " + encontrados
            );

            lblEstado.setText(
                    "Búsqueda finalizada."
            );

        } catch (SQLException ex) {

            mostrarError(
                    "Error durante la búsqueda: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // SELECCIONAR ALMACÉN
    // =====================================================

    private void seleccionarAlmacen() {

        int filaVista = tablaAlmacenes.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo =
                tablaAlmacenes.convertRowIndexToModel(filaVista);

        idSeleccionado = Integer.parseInt(
                modeloTabla.getValueAt(filaModelo, 0).toString()
        );

        txtNombre.setText(
                modeloTabla.getValueAt(filaModelo, 1).toString()
        );

        Object ubicacion =
                modeloTabla.getValueAt(filaModelo, 2);

        txtUbicacion.setText(
                ubicacion == null ? "" : ubicacion.toString()
        );

        lblEstado.setText(
                "Almacén seleccionado: " + idSeleccionado
        );
    }

    // =====================================================
    // LIMPIAR FORMULARIO
    // =====================================================

    private void limpiarFormulario() {

        idSeleccionado = 0;

        txtNombre.setText("");
        txtUbicacion.setText("");

        tablaAlmacenes.clearSelection();

        lblEstado.setText(
                "Formulario listo para registrar."
        );

        txtNombre.requestFocus();
    }

    // =====================================================
    // MOSTRAR ERROR
    // =====================================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    // =====================================================
    // MOSTRAR MENSAJE
    // =====================================================

    private void mostrarMensaje(
            String mensaje,
            String titulo,
            int tipo
    ) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                titulo,
                tipo
        );
    }
}
