
package pe.edu.inventario.vista.movimientos;

import pe.edu.inventario.controlador.AlmacenController;
import pe.edu.inventario.controlador.MovimientoController;
import pe.edu.inventario.controlador.ProductoController;
import pe.edu.inventario.modelo.Almacen;
import pe.edu.inventario.modelo.Producto;
import pe.edu.inventario.vista.movimientos.componentes.EstilosMovimiento;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class SalidaView extends JPanel {

    private final MovimientoController movimientoController;
    private final ProductoController productoController;
    private final AlmacenController almacenController;

    private JComboBox<Producto> cmbProducto;
    private JComboBox<Almacen> cmbAlmacen;

    private JTextField txtDocumento;
    private JTextField txtCantidad;

    private JTextArea txtObservacion;

    private JLabel lblCodigo;
    private JLabel lblUnidad;
    private JLabel lblImporte;

    private JButton btnRegistrar;
    private JButton btnLimpiar;

    public SalidaView() {

        movimientoController = new MovimientoController();
        productoController = new ProductoController();
        almacenController = new AlmacenController();

        inicializarComponentes();
        cargarDatos();
        registrarEventos();
    }

    private void inicializarComponentes() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 247, 250));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        encabezado.setOpaque(false);

        JLabel titulo = new JLabel("Registrar salida");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 21));
        titulo.setForeground(new Color(35, 55, 80));

        JLabel descripcion = new JLabel(
                "Registra ventas, consumos, bajas y otros egresos de productos."
        );
        descripcion.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        descripcion.setForeground(new Color(110, 120, 135));

        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(5));
        encabezado.add(descripcion);

        add(encabezado, BorderLayout.NORTH);
        add(crearFormulario(), BorderLayout.CENTER);
        add(crearPanelInferior(), BorderLayout.SOUTH);
    }

    private JPanel crearFormulario() {

        JPanel panel = EstilosMovimiento.crearTarjeta();
        panel.setLayout(new GridBagLayout());

        cmbProducto = new JComboBox<>();
        cmbAlmacen = new JComboBox<>();

        txtDocumento = new JTextField();
        txtCantidad = new JTextField();

        txtObservacion = new JTextArea(4, 20);
        txtObservacion.setLineWrap(true);
        txtObservacion.setWrapStyleWord(true);

        EstilosMovimiento.configurarCombo(cmbProducto);
        EstilosMovimiento.configurarCombo(cmbAlmacen);
        EstilosMovimiento.configurarCampo(txtDocumento);
        EstilosMovimiento.configurarCampo(txtCantidad);
        EstilosMovimiento.configurarArea(txtObservacion);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 12, 10, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        agregarCampo(panel, gbc, 0, "Producto", cmbProducto);
        agregarCampo(panel, gbc, 1, "Almacén", cmbAlmacen);
        agregarCampo(panel, gbc, 2, "Documento de referencia", txtDocumento);
        agregarCampo(panel, gbc, 3, "Cantidad de salida", txtCantidad);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.30;

        panel.add(
                EstilosMovimiento.crearEtiqueta("Observación"),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 0.70;

        JScrollPane scroll = new JScrollPane(txtObservacion);
        scroll.setPreferredSize(new Dimension(300, 90));

        panel.add(scroll, gbc);

        return panel;
    }

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int fila,
            String titulo,
            JComponent componente
    ) {

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.weightx = 0.30;

        panel.add(
                EstilosMovimiento.crearEtiqueta(titulo),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 0.70;

        panel.add(componente, gbc);
    }

    private JPanel crearPanelInferior() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        JPanel resumen = EstilosMovimiento.crearTarjeta();
        resumen.setLayout(new GridLayout(1, 3, 15, 5));

        lblCodigo = crearValor("-");
        lblUnidad = crearValor("-");
        lblImporte = crearValor("Pendiente");

        resumen.add(crearBloque("Código", lblCodigo));
        resumen.add(crearBloque("Unidad de medida", lblUnidad));
        resumen.add(crearBloque("Cantidad solicitada", lblImporte));

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        acciones.setOpaque(false);

        btnLimpiar = new JButton("Limpiar");
        btnRegistrar = new JButton("Registrar salida");

        EstilosMovimiento.configurarBotonSecundario(btnLimpiar);
        EstilosMovimiento.configurarBotonPeligro(btnRegistrar);

        acciones.add(btnLimpiar);
        acciones.add(btnRegistrar);

        panel.add(resumen, BorderLayout.CENTER);
        panel.add(acciones, BorderLayout.SOUTH);

        return panel;
    }

    private JLabel crearValor(String valor) {

        JLabel etiqueta = new JLabel(valor);
        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 15));
        etiqueta.setForeground(new Color(35, 55, 80));

        return etiqueta;
    }

    private JPanel crearBloque(String titulo, JLabel valor) {

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);

        JLabel etiqueta = new JLabel(titulo);
        etiqueta.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        etiqueta.setForeground(new Color(110, 120, 135));

        panel.add(etiqueta);
        panel.add(Box.createVerticalStrut(6));
        panel.add(valor);

        return panel;
    }

    private void cargarDatos() {

        try {

            ArrayList<Producto> productos =
                    productoController.listarProductos();

            ArrayList<Almacen> almacenes =
                    almacenController.listarAlmacenes();

            cmbProducto.removeAllItems();
            cmbAlmacen.removeAllItems();

            for (Producto producto : productos) {
                cmbProducto.addItem(producto);
            }

            for (Almacen almacen : almacenes) {
                cmbAlmacen.addItem(almacen);
            }

        } catch (SQLException e) {

            mostrarError("No se pudieron cargar los datos:\n" + e.getMessage());
        }
    }

    private void registrarEventos() {

        cmbProducto.addActionListener(e -> actualizarProducto());

        txtCantidad.addCaretListener(e -> actualizarCantidad());

        btnLimpiar.addActionListener(e -> limpiar());

        btnRegistrar.addActionListener(e -> registrarSalida());
    }

    private void actualizarProducto() {

        Producto producto = (Producto) cmbProducto.getSelectedItem();

        if (producto == null) {
            lblCodigo.setText("-");
            lblUnidad.setText("-");
            return;
        }

        lblCodigo.setText(producto.getCodigo());
        lblUnidad.setText(producto.getUnidadMedida());
    }

    private void actualizarCantidad() {

        String cantidad = txtCantidad.getText().trim();

        if (cantidad.isEmpty()) {
            lblImporte.setText("Pendiente");
            return;
        }

        try {

            double valor = Double.parseDouble(
                    cantidad.replace(',', '.')
            );

            if (!Double.isFinite(valor) || valor <= 0) {
                lblImporte.setText("Valor inválido");
                return;
            }

            lblImporte.setText(String.valueOf(valor));

        } catch (NumberFormatException e) {

            lblImporte.setText("Valor inválido");
        }
    }

    private void registrarSalida() {

        Producto producto = (Producto) cmbProducto.getSelectedItem();
        Almacen almacen = (Almacen) cmbAlmacen.getSelectedItem();

        String documento = txtDocumento.getText().trim();
        String observacion = txtObservacion.getText().trim();

        if (producto == null || almacen == null) {
            mostrarAdvertencia("Selecciona un producto y un almacén.");
            return;
        }

        if (documento.isBlank()) {
            mostrarAdvertencia("Ingresa el documento de referencia.");
            txtDocumento.requestFocus();
            return;
        }

        double cantidad;

        try {

            cantidad = Double.parseDouble(
                    txtCantidad.getText().trim().replace(',', '.')
            );

            if (!Double.isFinite(cantidad) || cantidad <= 0) {
                mostrarAdvertencia("La cantidad debe ser mayor que cero.");
                return;
            }

        } catch (NumberFormatException e) {

            mostrarAdvertencia("Ingresa una cantidad numérica válida.");
            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Confirmas el registro de esta salida?\n\n"
                + "Producto: " + producto.getNombre() + "\n"
                + "Almacén: " + almacen.getNombre() + "\n"
                + "Cantidad: " + cantidad + "\n\n"
                + "El sistema verificará el stock disponible.",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        btnRegistrar.setEnabled(false);

        try {

            movimientoController.registrarMovimientoSalida(
                    producto.getIdProducto(),
                    almacen.getIdAlmacen(),
                    documento,
                    cantidad,
                    observacion
            );

            JOptionPane.showMessageDialog(
                    this,
                    "La salida se registró correctamente.\n"
                    + "El inventario y el Kardex fueron actualizados.",
                    "Salida registrada",
                    JOptionPane.INFORMATION_MESSAGE
            );

            limpiar();

        } catch (SQLException e) {

            mostrarError("No se pudo registrar la salida:\n" + e.getMessage());

        } finally {

            btnRegistrar.setEnabled(true);
        }
    }

    private void limpiar() {

        cmbProducto.setSelectedIndex(-1);
        cmbAlmacen.setSelectedIndex(-1);

        txtDocumento.setText("");
        txtCantidad.setText("");
        txtObservacion.setText("");

        lblCodigo.setText("-");
        lblUnidad.setText("-");
        lblImporte.setText("Pendiente");
    }

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validación",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
