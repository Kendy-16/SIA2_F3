
package pe.edu.inventario.modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Representa un registro individual del historial de movimientos.
 *
 * Cada objeto corresponde a un detalle de movimiento asociado
 * a un producto y un almacén.
 *
 * La clase es inmutable y no realiza operaciones de base de datos.
 */
public final class MovimientoHistorial {

    // ==================================================
    // 1. CONSTANTES
    // ==================================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final BigDecimal SUBTOTAL_MAXIMO =
            new BigDecimal("1000000000000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;
    private static final int MAX_DECIMALES_COSTO = 6;
    private static final int MAX_DOCUMENTO = 50;
    private static final int MAX_OBSERVACION = 500;
    private static final int MAX_CODIGO = 30;
    private static final int MAX_NOMBRE = 120;

    private static final Set<String> TIPOS_VALIDOS = Set.of(
            "ENTRADA",
            "SALIDA",
            "AJUSTE"
    );

    private static final Set<String> UNIDADES_VALIDAS = Set.of(
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    );

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile("^[A-Z0-9][A-Z0-9._/-]{0,49}$");

    private static final Pattern CODIGO_PATTERN =
            Pattern.compile("^[A-Z0-9][A-Z0-9._/-]{0,29}$");

    private static final DateTimeFormatter FORMATO_FECHA =
            DateTimeFormatter.ofPattern(
                    "uuuu-MM-dd HH:mm:ss",
                    Locale.ROOT
            ).withResolverStyle(ResolverStyle.STRICT);

    // ==================================================
    // 2. ATRIBUTOS INMUTABLES
    // ==================================================

    private final int idDetalle;
    private final int idMovimiento;
    private final int idAlmacen;
    private final int idProducto;

    private final LocalDateTime fecha;

    private final String tipo;
    private final String documento;
    private final String observacion;

    private final String almacen;

    private final String codigoProducto;
    private final String producto;
    private final String unidadMedida;

    private final BigDecimal cantidad;
    private final BigDecimal costoUnitario;

    // ==================================================
    // 3. CONSTRUCTOR
    // ==================================================

    public MovimientoHistorial(
            int idDetalle,
            int idMovimiento,
            int idAlmacen,
            int idProducto,
            String fecha,
            String tipo,
            String documento,
            String observacion,
            String almacen,
            String codigoProducto,
            String producto,
            String unidadMedida,
            BigDecimal cantidad,
            BigDecimal costoUnitario
    ) {

        validarIdentificadores(
                idDetalle,
                idMovimiento,
                idAlmacen,
                idProducto
        );

        this.fecha = validarFecha(fecha);
        this.tipo = validarTipo(tipo);
        this.documento = validarDocumento(documento);
        this.observacion = validarObservacion(observacion);

        this.almacen = validarNombre(
                almacen,
                "El nombre del almacén"
        );

        this.codigoProducto = validarCodigoProducto(
                codigoProducto
        );

        this.producto = validarNombre(
                producto,
                "El nombre del producto"
        );

        this.unidadMedida = validarUnidadMedida(
                unidadMedida
        );

        this.cantidad = validarCantidad(cantidad);

        this.costoUnitario = validarCostoUnitario(
                costoUnitario
        );

        validarSubtotal();

        this.idDetalle = idDetalle;
        this.idMovimiento = idMovimiento;
        this.idAlmacen = idAlmacen;
        this.idProducto = idProducto;
    }

    // ==================================================
    // 4. VALIDAR IDENTIFICADORES
    // ==================================================

    private void validarIdentificadores(
            int idDetalle,
            int idMovimiento,
            int idAlmacen,
            int idProducto
    ) {

        if (idDetalle <= 0) {
            throw new IllegalArgumentException(
                    "El ID del detalle debe ser positivo."
            );
        }

        if (idMovimiento <= 0) {
            throw new IllegalArgumentException(
                    "El ID del movimiento debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacén debe ser positivo."
            );
        }

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }
    }

    // ==================================================
    // 5. VALIDAR FECHA
    // ==================================================

    private LocalDateTime validarFecha(String valor) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    "La fecha del movimiento es obligatoria."
            );
        }

        String normalizado = valor.trim().replace('T', ' ');

        try {

            return LocalDateTime.parse(
                    normalizado,
                    FORMATO_FECHA
            );

        } catch (DateTimeParseException ex) {

            throw new IllegalArgumentException(
                    "La fecha debe tener el formato "
                    + "yyyy-MM-dd HH:mm:ss.",
                    ex
            );
        }
    }

    // ==================================================
    // 6. VALIDAR TIPO DE MOVIMIENTO
    // ==================================================

    private String validarTipo(String valor) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    "El tipo de movimiento es obligatorio."
            );
        }

        String normalizado =
                valor.trim().toUpperCase(Locale.ROOT);

        if (!TIPOS_VALIDOS.contains(normalizado)) {
            throw new IllegalArgumentException(
                    "El tipo debe ser ENTRADA, SALIDA o AJUSTE."
            );
        }

        return normalizado;
    }

    // ==================================================
    // 7. VALIDAR DOCUMENTO
    // ==================================================

    private String validarDocumento(String valor) {

        if (valor == null || valor.isBlank()) {
            return "";
        }

        String normalizado =
                valor.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(normalizado).matches()) {

            throw new IllegalArgumentException(
                    "El documento tiene un formato no válido."
            );
        }

        return normalizado;
    }

    // ==================================================
    // 8. VALIDAR OBSERVACIÓN
    // ==================================================

    private String validarObservacion(String valor) {

        if (valor == null || valor.isBlank()) {
            return "";
        }

        String normalizado =
                valor.trim().replaceAll("\\s+", " ");

        if (normalizado.length() > MAX_OBSERVACION) {
            throw new IllegalArgumentException(
                    "La observación no puede superar "
                    + MAX_OBSERVACION + " caracteres."
            );
        }

        for (int i = 0; i < normalizado.length(); i++) {

            if (Character.isISOControl(normalizado.charAt(i))) {
                throw new IllegalArgumentException(
                        "La observación contiene caracteres "
                        + "de control no permitidos."
                );
            }
        }

        return normalizado;
    }

    // ==================================================
    // 9. VALIDAR NOMBRES
    // ==================================================

    private String validarNombre(
            String valor,
            String nombreCampo
    ) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    nombreCampo + " es obligatorio."
            );
        }

        String normalizado =
                valor.trim().replaceAll("\\s+", " ");

        if (normalizado.length() > MAX_NOMBRE) {
            throw new IllegalArgumentException(
                    nombreCampo + " supera el límite permitido."
            );
        }

        return normalizado;
    }

    // ==================================================
    // 10. VALIDAR CÓDIGO DEL PRODUCTO
    // ==================================================

    private String validarCodigoProducto(String valor) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    "El código del producto es obligatorio."
            );
        }

        String normalizado =
                valor.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_CODIGO
                || !CODIGO_PATTERN.matcher(normalizado).matches()) {

            throw new IllegalArgumentException(
                    "El código del producto tiene un formato no válido."
            );
        }

        return normalizado;
    }

    // ==================================================
    // 11. VALIDAR UNIDAD DE MEDIDA
    // ==================================================

    private String validarUnidadMedida(String valor) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    "La unidad de medida es obligatoria."
            );
        }

        String normalizado =
                valor.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(normalizado)) {
            throw new IllegalArgumentException(
                    "La unidad de medida no está permitida."
            );
        }

        return normalizado;
    }

    // ==================================================
    // 12. VALIDAR CANTIDAD
    // ==================================================

    private BigDecimal validarCantidad(BigDecimal valor) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    "La cantidad no puede ser nula."
            );
        }

        if (valor.signum() <= 0) {
            throw new IllegalArgumentException(
                    "La cantidad debe ser positiva."
            );
        }

        BigDecimal normalizado = valor.stripTrailingZeros();

        if (normalizado.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    "La cantidad supera el límite permitido."
            );
        }

        if (normalizado.scale() > MAX_DECIMALES_CANTIDAD) {
            throw new IllegalArgumentException(
                    "La cantidad admite como máximo 3 decimales."
            );
        }

        // Las unidades indivisibles no admiten fracciones.
        if (unidadEntera()
                && normalizado.scale() > 0) {

            throw new IllegalArgumentException(
                    "La unidad de medida seleccionada "
                    + "no admite cantidades fraccionarias."
            );
        }

        return normalizado.setScale(
                MAX_DECIMALES_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // ==================================================
    // 13. VALIDAR COSTO UNITARIO
    // ==================================================

    private BigDecimal validarCostoUnitario(BigDecimal valor) {

        if (valor == null) {
            throw new IllegalArgumentException(
                    "El costo unitario no puede ser nulo."
            );
        }

        if (valor.signum() < 0) {
            throw new IllegalArgumentException(
                    "El costo unitario no puede ser negativo."
            );
        }

        BigDecimal normalizado = valor.stripTrailingZeros();

        if (normalizado.compareTo(COSTO_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El costo unitario supera el límite permitido."
            );
        }

        if (normalizado.scale() > MAX_DECIMALES_COSTO) {
            throw new IllegalArgumentException(
                    "El costo unitario admite como máximo 6 decimales."
            );
        }

        return normalizado.setScale(
                MAX_DECIMALES_COSTO,
                RoundingMode.UNNECESSARY
        );
    }

    // ==================================================
    // 14. VALIDAR SUBTOTAL
    // ==================================================

    private void validarSubtotal() {

        BigDecimal subtotal =
                cantidad.multiply(costoUnitario);

        if (subtotal.compareTo(SUBTOTAL_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El subtotal del detalle supera el límite permitido."
            );
        }
    }

    // ==================================================
    // 15. MÉTODOS AUXILIARES
    // ==================================================

    private boolean unidadEntera() {

        return unidadMedida.equals("UNIDAD")
                || unidadMedida.equals("CAJA")
                || unidadMedida.equals("PAQUETE");
    }

    public boolean esEntrada() {
        return tipo.equals("ENTRADA");
    }

    public boolean esSalida() {
        return tipo.equals("SALIDA");
    }

    public boolean esAjuste() {
        return tipo.equals("AJUSTE");
    }

    public boolean tieneDocumento() {
        return !documento.isEmpty();
    }

    public boolean tieneObservacion() {
        return !observacion.isEmpty();
    }

    public boolean tieneCosto() {
        return costoUnitario.signum() > 0;
    }

    // ==================================================
    // 16. OBTENER SUBTOTAL
    // ==================================================

    public BigDecimal getSubtotal() {

        return cantidad.multiply(costoUnitario)
                .setScale(
                        MAX_DECIMALES_COSTO,
                        RoundingMode.HALF_UP
                );
    }

    // ==================================================
    // 17. GETTERS
    // ==================================================

    public int getIdDetalle() {
        return idDetalle;
    }

    public int getIdMovimiento() {
        return idMovimiento;
    }

    public int getIdAlmacen() {
        return idAlmacen;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public LocalDateTime getFechaHora() {
        return fecha;
    }

    public String getFecha() {
        return fecha.format(FORMATO_FECHA);
    }

    public String getTipo() {
        return tipo;
    }

    public String getDocumento() {
        return documento;
    }

    public String getObservacion() {
        return observacion;
    }

    public String getAlmacen() {
        return almacen;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public String getProducto() {
        return producto;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public BigDecimal getCantidad() {
        return cantidad;
    }

    public BigDecimal getCostoUnitario() {
        return costoUnitario;
    }

    // ==================================================
    // 18. EQUALS Y HASHCODE
    // ==================================================

    @Override
    public boolean equals(Object objeto) {

        if (this == objeto) {
            return true;
        }

        if (!(objeto instanceof MovimientoHistorial otro)) {
            return false;
        }

        return idDetalle == otro.idDetalle;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idDetalle);
    }

    // ==================================================
    // 19. TOSTRING
    // ==================================================

    @Override
    public String toString() {

        return "MovimientoHistorial{" +
                "idDetalle=" + idDetalle +
                ", idMovimiento=" + idMovimiento +
                ", fecha='" + getFecha() + '\'' +
                ", tipo='" + tipo + '\'' +
                ", documento='" + documento + '\'' +
                ", codigoProducto='" + codigoProducto + '\'' +
                ", producto='" + producto + '\'' +
                ", almacen='" + almacen + '\'' +
                ", cantidad=" + cantidad +
                ", costoUnitario=" + costoUnitario +
                ", subtotal=" + getSubtotal() +
                '}';
    }
}
