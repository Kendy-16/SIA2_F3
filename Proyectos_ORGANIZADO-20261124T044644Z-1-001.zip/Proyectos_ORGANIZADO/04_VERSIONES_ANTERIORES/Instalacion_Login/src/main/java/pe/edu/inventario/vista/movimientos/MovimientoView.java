
package pe.edu.inventario.vista.movimientos;

import pe.edu.inventario.vista.movimientos.componentes.EstilosMovimiento;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MovimientoView extends JPanel {

    private JTabbedPane pestañas;

    public MovimientoView() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {

        setLayout(new BorderLayout());
        setBackground(EstilosMovimiento.FONDO);
        setBorder(new EmptyBorder(15, 18, 15, 18));

        // Encabezado principal
        JPanel encabezado = new JPanel();
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        encabezado.setOpaque(false);
        encabezado.setBorder(new EmptyBorder(5, 5, 15, 5));

        JLabel titulo = new JLabel("Gestión de movimientos");

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 25));
        titulo.setForeground(EstilosMovimiento.TEXTO);

        JLabel descripcion = new JLabel(
                "Administra entradas, salidas, ajustes y consultas del inventario."
        );

        descripcion.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        descripcion.setForeground(EstilosMovimiento.TEXTO_SECUNDARIO);

        encabezado.add(titulo);
        encabezado.add(Box.createVerticalStrut(5));
        encabezado.add(descripcion);

        add(encabezado, BorderLayout.NORTH);

        // Pestañas de navegación
        pestañas = new JTabbedPane();

        pestañas.setFont(new Font("Segoe UI", Font.BOLD, 13));
        pestañas.setBackground(EstilosMovimiento.BLANCO);
        pestañas.setForeground(EstilosMovimiento.TEXTO);

        pestañas.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        // Módulos
        pestañas.addTab(
                "Entradas",
                new EntradaView()
        );

        pestañas.addTab(
                "Salidas",
                new SalidaView()
        );

        pestañas.addTab(
                "Ajustes",
                new AjusteInventarioView()
        );

        pestañas.addTab(
                "Historial",
                new HistorialMovimientosView()
        );

        add(pestañas, BorderLayout.CENTER);
    }

    public void seleccionarPestana(int indice) {

        if (indice >= 0 && indice < pestañas.getTabCount()) {
            pestañas.setSelectedIndex(indice);
        }
    }
}
