package pe.edu.inventario;

import pe.edu.inventario.controlador.LoginController;
import pe.edu.inventario.modelo.ConexionDB;
import pe.edu.inventario.migracion.AdministradorMigraciones;
import pe.edu.inventario.vista.LoginView;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        ConexionDB.inicializar();
        AdministradorMigraciones.ejecutar();
        SwingUtilities.invokeLater(Main::iniciarAplicacion);
    }

    private static void iniciarAplicacion() {
        LoginController controlador = new LoginController();
        try {
            if (!controlador.hayUsuariosRegistrados()
                    && !configurarPrimerAdministrador(controlador)) {
                System.exit(0);
                return;
            }

            LoginView login = new LoginView(controlador);
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        } catch (RuntimeException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "No se pudo iniciar la autenticacion.\nDetalle: " + ex.getMessage(),
                    "Error de inicio",
                    JOptionPane.ERROR_MESSAGE
            );
            ex.printStackTrace();
        }
    }

    /** Crea la primera cuenta administradora si la tabla usuarios esta vacia. */
    private static boolean configurarPrimerAdministrador(LoginController controlador) {
        while (true) {
            JTextField txtUsuario = new JTextField(18);
            JPasswordField txtPassword = new JPasswordField(18);
            JPasswordField txtConfirmacion = new JPasswordField(18);

            JPanel formulario = new JPanel(new GridLayout(0, 1, 5, 5));
            formulario.add(new JLabel(
                    "No existen usuarios registrados. Cree el primer administrador."
            ));
            formulario.add(new JLabel("Usuario (3 a 50 caracteres):"));
            formulario.add(txtUsuario);
            formulario.add(new JLabel("Contrasena (12 a 128 caracteres):"));
            formulario.add(txtPassword);
            formulario.add(new JLabel("Confirmar contrasena:"));
            formulario.add(txtConfirmacion);

            int opcion = JOptionPane.showConfirmDialog(
                    null, formulario,
                    "Configuracion inicial - Administrador",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.INFORMATION_MESSAGE
            );
            if (opcion != JOptionPane.OK_OPTION) return false;

            char[] password = txtPassword.getPassword();
            char[] confirmacion = txtConfirmacion.getPassword();
            try {
                String usuario = txtUsuario.getText().trim();
                if (usuario.length() < 3 || usuario.length() > 50) {
                    JOptionPane.showMessageDialog(null,
                            "El usuario debe tener entre 3 y 50 caracteres.",
                            "Datos no validos", JOptionPane.WARNING_MESSAGE);
                    continue;
                }
                if (password.length < 12 || password.length > 128) {
                    JOptionPane.showMessageDialog(null,
                            "La contrasena debe tener entre 12 y 128 caracteres.",
                            "Datos no validos", JOptionPane.WARNING_MESSAGE);
                    continue;
                }
                if (!Arrays.equals(password, confirmacion)) {
                    JOptionPane.showMessageDialog(null,
                            "Las contrasenas no coinciden.",
                            "Datos no validos", JOptionPane.WARNING_MESSAGE);
                    continue;
                }

                controlador.registrarPrimerAdministrador(usuario, password);
                JOptionPane.showMessageDialog(null,
                        "Administrador creado correctamente. Ahora puede iniciar sesion.",
                        "Configuracion completada", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } catch (RuntimeException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(),
                        "No se pudo crear el administrador", JOptionPane.ERROR_MESSAGE);
            } finally {
                Arrays.fill(password, '\0');
                Arrays.fill(confirmacion, '\0');
            }
        }
    }
}
