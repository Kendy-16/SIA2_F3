
package pe.edu.inventario.modelo;

/**
 * Estados permitidos para un inventario físico.
 */
public enum EstadoInventarioFisico {

    BORRADOR("Borrador"),
    EN_CONTEO("En conteo"),
    FINALIZADO("Finalizado"),
    ANULADO("Anulado");

    private final String descripcion;

    EstadoInventarioFisico(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public boolean permiteModificarDetalles() {
        return this == BORRADOR || this == EN_CONTEO;
    }

    public boolean permiteRegistrarConteo() {
        return this == EN_CONTEO;
    }

    public boolean permiteFinalizar() {
        return this == EN_CONTEO;
    }

    public boolean permiteAnular() {
        return this == BORRADOR || this == EN_CONTEO;
    }

    public boolean estaCerrado() {
        return this == FINALIZADO || this == ANULADO;
    }
}
