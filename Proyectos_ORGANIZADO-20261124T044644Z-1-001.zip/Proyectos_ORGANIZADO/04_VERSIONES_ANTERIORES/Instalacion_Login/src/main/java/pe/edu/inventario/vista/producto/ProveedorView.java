
package pe.edu.inventario.vista.producto;

import pe.edu.inventario.controlador.ProveedorController;
import pe.edu.inventario.modelo.Proveedor;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.util.List;
import java.util.regex.Pattern;

public class ProveedorView extends JPanel {

    // =====================================================
    // COLORES
    // =====================================================

    private static final Color FONDO =
            new Color(244, 247, 251);

    private static final Color BLANCO =
            Color.WHITE;

    private static final Color AZUL =
            new Color(28, 67, 110);

    private static final Color AZUL_CLARO =
            new Color(229, 239, 250);

    private static final Color VERDE =
            new Color(34, 139, 94);

    private static final Color NARANJA =
            new Color(213, 139, 40);

    private static final Color ROJO =
            new Color(190, 65, 65);

    private static final Color GRIS =
            new Color(100, 112, 125);

    private static final Color BORDE =
            new Color(220, 226, 234);

    private static final Color TEXTO =
            new Color(43, 54, 68);

    // =====================================================
    // CONTROLADOR Y COMPONENTES
    // =====================================================

    private final ProveedorController controlador;

    private JTextField txtRuc;
    private JTextField txtRazonSocial;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTextField txtDireccion;
    private JTextField txtBuscar;

    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> ordenador;

    private JButton btnRegistrar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;

    private JLabel lblEstado;
    private JLabel lblTotal;

    private Integer idSeleccionado;

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public ProveedorView() {

        controlador = new ProveedorController();

        inicializarInterfaz();
        configurarEventos();
        cargarProveedores();
        establecerModoRegistro();
    }

    // =====================================================
    // INTERFAZ PRINCIPAL
    // =====================================================

    private void inicializarInterfaz() {

        setLayout(new BorderLayout(15, 15));
        setBackground(FONDO);

        setBorder(new EmptyBorder(18, 20, 18, 20));

        add(crearEncabezado(), BorderLayout.NORTH);

        JPanel centro = new JPanel(new BorderLayout(15, 15));
        centro.setBackground(FONDO);

        centro.add(crearFormulario(), BorderLayout.NORTH);
        centro.add(crearListado(), BorderLayout.CENTER);

        add(centro, BorderLayout.CENTER);
        add(crearPie(), BorderLayout.SOUTH);
    }

    // =====================================================
    // ENCABEZADO SIN CUADRO AZUL
    // =====================================================

    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(FONDO);
        panel.setBorder(new EmptyBorder(5, 2, 8, 2));

        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));

        JLabel titulo = new JLabel("GESTIÓN DE PROVEEDORES");

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 23));
        titulo.setForeground(TEXTO);

        JLabel descripcion = new JLabel(
                "Administración y control de proveedores del inventario"
        );

        descripcion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descripcion.setForeground(GRIS);

        textos.add(titulo);
        textos.add(Box.createVerticalStrut(5));
        textos.add(descripcion);

        panel.add(textos, BorderLayout.WEST);

        return panel;
    }

    // =====================================================
    // FORMULARIO
    // =====================================================

    private JPanel crearFormulario() {

        JPanel panel = crearPanelBase("INFORMACIÓN DEL PROVEEDOR");

        JPanel campos = new JPanel(new GridBagLayout());
        campos.setBackground(BLANCO);

        txtRuc = crearCampo();
        txtRazonSocial = crearCampo();
        txtTelefono = crearCampo();
        txtCorreo = crearCampo();
        txtDireccion = crearCampo();

        txtRuc.setToolTipText("Ingrese los 11 dígitos del RUC");
        txtRazonSocial.setToolTipText("Entre 3 y 200 caracteres");
        txtTelefono.setToolTipText(
                "Celular: 9 dígitos. Teléfono fijo: 7 a 9 dígitos"
        );
        txtCorreo.setToolTipText("Ejemplo: proveedor@empresa.com");
        txtDireccion.setToolTipText(
                "Entre 5 y 250 caracteres si se completa"
        );

        GridBagConstraints c = new GridBagConstraints();

        c.insets = new Insets(9, 10, 9, 10);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;

        agregarCampo(campos, c, "RUC *", txtRuc, 0, 0);
        agregarCampo(campos, c, "Razón social *", txtRazonSocial, 2, 0);

        agregarCampo(campos, c, "Teléfono", txtTelefono, 0, 1);
        agregarCampo(campos, c, "Correo electrónico", txtCorreo, 2, 1);

        agregarCampo(campos, c, "Dirección", txtDireccion, 0, 2);

        panel.add(campos, BorderLayout.CENTER);

        JPanel acciones = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 9, 5)
        );

        acciones.setBackground(BLANCO);

        btnRegistrar = crearBoton("Registrar", VERDE);
        btnActualizar = crearBoton("Actualizar", AZUL);
        btnEliminar = crearBoton("Eliminar", ROJO);
        btnLimpiar = crearBoton("Limpiar", GRIS);

        acciones.add(btnRegistrar);
        acciones.add(btnActualizar);
        acciones.add(btnEliminar);
        acciones.add(btnLimpiar);

        panel.add(acciones, BorderLayout.SOUTH);

        return panel;
    }

    // =====================================================
    // AGREGAR CAMPO AL FORMULARIO
    // =====================================================

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints c,
            String titulo,
            JTextField campo,
            int x,
            int y
    ) {

        JLabel etiqueta = crearEtiqueta(titulo);

        c.gridx = x;
        c.gridy = y;
        c.gridwidth = 1;
        c.weightx = 0;
        c.fill = GridBagConstraints.NONE;

        panel.add(etiqueta, c);

        c.gridx = x + 1;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;

        panel.add(campo, c);
    }

    // =====================================================
    // LISTADO DE PROVEEDORES
    // =====================================================

    private JPanel crearListado() {

        JPanel panel = crearPanelBase("LISTADO DE PROVEEDORES");

        JPanel barra = new JPanel(new BorderLayout(12, 0));
        barra.setBackground(BLANCO);

        JLabel etiqueta = crearEtiqueta("Buscar:");

        txtBuscar = crearCampo();
        txtBuscar.setToolTipText(
                "Buscar por razón social, RUC, teléfono o correo"
        );

        barra.add(etiqueta, BorderLayout.WEST);
        barra.add(txtBuscar, BorderLayout.CENTER);

        lblTotal = new JLabel("Total: 0");

        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTotal.setForeground(AZUL);

        barra.add(lblTotal, BorderLayout.EAST);

        panel.add(barra, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "RUC",
                        "RAZÓN SOCIAL",
                        "TELÉFONO",
                        "CORREO",
                        "DIRECCIÓN"
                },
                0
        ) {

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tabla = new JTable(modeloTabla);

        tabla.setRowHeight(32);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setForeground(TEXTO);
        tabla.setBackground(BLANCO);

        tabla.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tabla.setShowGrid(true);
        tabla.setGridColor(BORDE);
        tabla.setFillsViewportHeight(true);

        tabla.setSelectionBackground(AZUL_CLARO);
        tabla.setSelectionForeground(AZUL);

        tabla.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        tabla.getTableHeader().setBackground(
                new Color(234, 240, 247)
        );

        tabla.getTableHeader().setForeground(AZUL);
        tabla.getTableHeader().setPreferredSize(
                new Dimension(0, 35)
        );

        ordenador = new TableRowSorter<>(modeloTabla);
        tabla.setRowSorter(ordenador);

        configurarColumnas();

        JScrollPane scroll = new JScrollPane(tabla);

        scroll.setBorder(new LineBorder(BORDE));

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // =====================================================
    // CONFIGURAR COLUMNAS
    // =====================================================

    private void configurarColumnas() {

        tabla.getColumnModel().getColumn(0).setPreferredWidth(45);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(105);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(210);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(105);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(175);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(200);

        DefaultTableCellRenderer centrado =
                new DefaultTableCellRenderer();

        centrado.setHorizontalAlignment(SwingConstants.CENTER);

        tabla.getColumnModel().getColumn(0).setCellRenderer(centrado);
        tabla.getColumnModel().getColumn(1).setCellRenderer(centrado);
    }

    // =====================================================
    // PANELES Y COMPONENTES VISUALES
    // =====================================================

    private JPanel crearPanelBase(String titulo) {

        JPanel panel = new JPanel(new BorderLayout(12, 12));

        panel.setBackground(BLANCO);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(BORDE),
                        new EmptyBorder(13, 15, 13, 15)
                )
        );

        JLabel encabezado = new JLabel(titulo);

        encabezado.setFont(new Font("Segoe UI", Font.BOLD, 13));
        encabezado.setForeground(AZUL);

        panel.add(encabezado, BorderLayout.NORTH);

        return panel;
    }

    private JTextField crearCampo() {

        JTextField campo = new JTextField(18);

        campo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        campo.setForeground(TEXTO);
        campo.setBackground(BLANCO);

        campo.setBorder(
                BorderFactory.createCompoundBorder(
                        new LineBorder(BORDE),
                        new EmptyBorder(8, 10, 8, 10)
                )
        );

        return campo;
    }

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 12));
        etiqueta.setForeground(TEXTO);

        return etiqueta;
    }

    private JButton crearBoton(String texto, Color color) {

        JButton boton = new JButton(texto);

        boton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        boton.setForeground(BLANCO);
        boton.setBackground(color);

        boton.setFocusPainted(false);
        boton.setBorderPainted(false);

        boton.setCursor(
                new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setBorder(
                new EmptyBorder(10, 17, 10, 17)
        );

        return boton;
    }

    // =====================================================
    // PIE
    // =====================================================

    private JPanel crearPie() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(FONDO);

        lblEstado = new JLabel("Sistema listo.");

        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblEstado.setForeground(GRIS);

        panel.add(lblEstado, BorderLayout.WEST);

        JLabel ayuda = new JLabel("* Campos obligatorios");

        ayuda.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        ayuda.setForeground(GRIS);

        panel.add(ayuda, BorderLayout.EAST);

        return panel;
    }

    // =====================================================
    // EVENTOS
    // =====================================================

    private void configurarEventos() {

        btnRegistrar.addActionListener(
                e -> registrarProveedor()
        );

        btnActualizar.addActionListener(
                e -> actualizarProveedor()
        );

        btnEliminar.addActionListener(
                e -> eliminarProveedor()
        );

        btnLimpiar.addActionListener(
                e -> limpiarFormulario()
        );

        tabla.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {
                seleccionarProveedor();
            }
        });

        txtBuscar.getDocument().addDocumentListener(
                new DocumentListener() {

                    @Override
                    public void insertUpdate(DocumentEvent e) {
                        filtrarTabla();
                    }

                    @Override
                    public void removeUpdate(DocumentEvent e) {
                        filtrarTabla();
                    }

                    @Override
                    public void changedUpdate(DocumentEvent e) {
                        filtrarTabla();
                    }
                }
        );
    }

    // =====================================================
    // REGISTRAR
    // =====================================================

    private void registrarProveedor() {

        Proveedor proveedor = obtenerDatosFormulario();

        if (proveedor == null) {
            return;
        }

        try {

            boolean resultado =
                    controlador.registrarProveedor(proveedor);

            if (!resultado) {

                mostrarAdvertencia(
                        "No se pudo registrar el proveedor. "
                        + "Comprueba la unicidad del RUC."
                );

                return;
            }

            mostrarExito(
                    "Proveedor registrado correctamente."
            );

            limpiarFormulario();
            cargarProveedores();

        } catch (Exception ex) {

            mostrarError(
                    "No se pudo registrar el proveedor: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // ACTUALIZAR
    // =====================================================

    private void actualizarProveedor() {

        if (idSeleccionado == null) {

            mostrarAdvertencia(
                    "Selecciona un proveedor del listado."
            );

            return;
        }

        Proveedor proveedor = obtenerDatosFormulario();

        if (proveedor == null) {
            return;
        }

        proveedor.setIdProveedor(idSeleccionado);

        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas guardar los cambios del proveedor seleccionado?",
                "Confirmar actualización",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (opcion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean resultado =
                    controlador.actualizarProveedor(proveedor);

            if (!resultado) {

                mostrarAdvertencia(
                        "No se pudo actualizar el proveedor."
                );

                return;
            }

            mostrarExito(
                    "Proveedor actualizado correctamente."
            );

            limpiarFormulario();
            cargarProveedores();

        } catch (Exception ex) {

            mostrarError(
                    "Error al actualizar: " + ex.getMessage()
            );
        }
    }

    // =====================================================
    // ELIMINAR
    // =====================================================

    private void eliminarProveedor() {

        if (idSeleccionado == null) {

            mostrarAdvertencia(
                    "Selecciona un proveedor del listado."
            );

            return;
        }

        int filaVista = tabla.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo = tabla.convertRowIndexToModel(filaVista);

        String razonSocial = modeloTabla.getValueAt(
                filaModelo, 2
        ).toString();

        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de eliminar al proveedor "
                + razonSocial
                + "?\nEsta acción no se puede deshacer.",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (opcion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            boolean resultado =
                    controlador.eliminarProveedor(idSeleccionado);

            if (!resultado) {

                mostrarAdvertencia(
                        "No se pudo eliminar el proveedor.\n"
                        + "Es posible que tenga productos u otros "
                        + "registros asociados.\n"
                        + "Verifica las relaciones de la base de datos "
                        + "y considera desactivar el proveedor."
                );

                return;
            }

            mostrarExito(
                    "Proveedor eliminado correctamente."
            );

            limpiarFormulario();
            cargarProveedores();

        } catch (Exception ex) {

            mostrarError(
                    "Error al eliminar proveedor: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // OBTENER DATOS Y VALIDAR
    // =====================================================

    private Proveedor obtenerDatosFormulario() {

        String ruc = txtRuc.getText().trim();
        String razon = txtRazonSocial.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String correo = txtCorreo.getText().trim();
        String direccion = txtDireccion.getText().trim();

        if (ruc.isEmpty()) {

            mostrarAdvertencia("El RUC es obligatorio.");
            txtRuc.requestFocus();
            return null;
        }

        if (razon.isEmpty()) {

            mostrarAdvertencia("La razón social es obligatoria.");
            txtRazonSocial.requestFocus();
            return null;
        }

        if (!validarRuc(ruc)) {

            mostrarAdvertencia(
                    "RUC inválido. Debe tener 11 dígitos, "
                    + "un prefijo permitido y un dígito verificador válido."
            );

            txtRuc.requestFocus();
            return null;
        }

        if (razon.length() < 3 || razon.length() > 200) {

            mostrarAdvertencia(
                    "La razón social debe tener entre 3 y 200 caracteres."
            );

            txtRazonSocial.requestFocus();
            return null;
        }

        if (!razon.matches(
                "[\\p{L}\\p{N} .&_\\-]+"
        )) {

            mostrarAdvertencia(
                    "La razón social contiene caracteres no permitidos."
            );

            txtRazonSocial.requestFocus();
            return null;
        }

        if (!telefono.isEmpty() && !validarTelefono(telefono)) {

            mostrarAdvertencia(
                    "Teléfono inválido. Celular: 9 dígitos que inician "
                    + "en 9. Fijo: de 7 a 9 dígitos."
            );

            txtTelefono.requestFocus();
            return null;
        }

        if (!correo.isEmpty() && !validarCorreo(correo)) {

            mostrarAdvertencia(
                    "Ingresa un correo electrónico válido."
            );

            txtCorreo.requestFocus();
            return null;
        }

        if (!direccion.isEmpty()
                && (direccion.length() < 5 || direccion.length() > 250)) {

            mostrarAdvertencia(
                    "La dirección debe tener entre 5 y 250 caracteres."
            );

            txtDireccion.requestFocus();
            return null;
        }

        if (!direccion.isEmpty()
                && !direccion.matches(
                        "[\\p{L}\\p{N} #\\x{00B0}.,/\\-]+"
                )) {

            mostrarAdvertencia(
                    "La dirección contiene caracteres no permitidos."
            );

            txtDireccion.requestFocus();
            return null;
        }

        Proveedor proveedor = new Proveedor();

        proveedor.setRuc(ruc);
        proveedor.setRazonSocial(razon);
        proveedor.setTelefono(normalizarTelefono(telefono));
        proveedor.setCorreo(correo);
        proveedor.setDireccion(direccion);

        return proveedor;
    }

    // =====================================================
    // VALIDAR RUC PERUANO
    // =====================================================

    private boolean validarRuc(String ruc) {

        if (ruc == null || !ruc.matches("\\d{11}")) {
            return false;
        }

        String prefijo = ruc.substring(0, 2);

        if (!prefijo.equals("10")
                && !prefijo.equals("15")
                && !prefijo.equals("17")
                && !prefijo.equals("20")) {

            return false;
        }

        int[] pesos = {
                5, 4, 3, 2, 7,
                6, 5, 4, 3, 2
        };

        int suma = 0;

        for (int i = 0; i < 10; i++) {

            suma += Character.getNumericValue(ruc.charAt(i))
                    * pesos[i];
        }

        int resultado = 11 - (suma % 11);
        int digitoEsperado = resultado % 10;

        int ultimoDigito =
                Character.getNumericValue(ruc.charAt(10));

        return digitoEsperado == ultimoDigito;
    }

    // =====================================================
    // VALIDAR TELÉFONO PERUANO
    // =====================================================

    private boolean validarTelefono(String telefono) {

        String limpio = telefono.replaceAll("[\\s()-]", "");

        if (limpio.startsWith("+51")) {
            limpio = limpio.substring(3);
        } else if (limpio.startsWith("51")
                && limpio.length() > 9) {
            limpio = limpio.substring(2);
        }

        if (!limpio.matches("\\d+")) {
            return false;
        }

        if (limpio.length() == 9) {
            return limpio.startsWith("9");
        }

        return limpio.length() >= 7
                && limpio.length() <= 9;
    }

    private String normalizarTelefono(String telefono) {

        String limpio = telefono.trim();

        if (limpio.startsWith("+51")) {
            limpio = limpio.substring(3);
        } else if (limpio.startsWith("51")
                && limpio.replaceAll("\\D", "").length() > 9) {
            limpio = limpio.substring(2);
        }

        return limpio.replaceAll("[\\s()-]", "");
    }

    // =====================================================
    // VALIDAR CORREO
    // =====================================================

    private boolean validarCorreo(String correo) {

        return correo.matches(
                "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
        );
    }

    // =====================================================
    // CARGAR PROVEEDORES
    // =====================================================

    private void cargarProveedores() {

        try {

            List<Proveedor> proveedores =
                    controlador.listarProveedores();

            modeloTabla.setRowCount(0);

            if (proveedores != null) {

                for (Proveedor proveedor : proveedores) {

                    modeloTabla.addRow(
                            new Object[]{
                                    proveedor.getIdProveedor(),
                                    proveedor.getRuc(),
                                    proveedor.getRazonSocial(),
                                    proveedor.getTelefono(),
                                    proveedor.getCorreo(),
                                    proveedor.getDireccion()
                            }
                    );
                }
            }

            lblTotal.setText(
                    "Total: " + modeloTabla.getRowCount()
            );

            lblEstado.setText(
                    "Listado actualizado correctamente."
            );

        } catch (Exception ex) {

            mostrarError(
                    "Error al cargar proveedores: "
                    + ex.getMessage()
            );
        }
    }

    // =====================================================
    // SELECCIONAR PROVEEDOR
    // =====================================================

    private void seleccionarProveedor() {

        int filaVista = tabla.getSelectedRow();

        if (filaVista < 0) {
            return;
        }

        int filaModelo = tabla.convertRowIndexToModel(filaVista);

        idSeleccionado = Integer.parseInt(
                modeloTabla.getValueAt(filaModelo, 0).toString()
        );

        txtRuc.setText(
                obtenerTexto(filaModelo, 1)
        );

        txtRazonSocial.setText(
                obtenerTexto(filaModelo, 2)
        );

        txtTelefono.setText(
                obtenerTexto(filaModelo, 3)
        );

        txtCorreo.setText(
                obtenerTexto(filaModelo, 4)
        );

        txtDireccion.setText(
                obtenerTexto(filaModelo, 5)
        );

        establecerModoEdicion();

        lblEstado.setText(
                "Proveedor seleccionado. ID: " + idSeleccionado
        );
    }

    private String obtenerTexto(int fila, int columna) {

        Object valor = modeloTabla.getValueAt(fila, columna);

        return valor == null ? "" : valor.toString();
    }

    // =====================================================
    // MODO REGISTRO
    // =====================================================

    private void establecerModoRegistro() {

        idSeleccionado = null;

        txtRuc.setEditable(true);
        txtRuc.setBackground(BLANCO);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        lblEstado.setText(
                "Modo registro: ingresa los datos del proveedor."
        );
    }

    // =====================================================
    // MODO EDICIÓN
    // =====================================================

    private void establecerModoEdicion() {

        txtRuc.setEditable(false);
        txtRuc.setBackground(new Color(235, 238, 242));

        btnRegistrar.setEnabled(false);
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);
    }

    // =====================================================
    // BUSCADOR
    // =====================================================

    private void filtrarTabla() {

        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {

            ordenador.setRowFilter(null);

        } else {

            ordenador.setRowFilter(
                    RowFilter.regexFilter(
                            "(?i)" + Pattern.quote(texto)
                    )
            );
        }
    }

    // =====================================================
    // LIMPIAR FORMULARIO
    // =====================================================

    private void limpiarFormulario() {

        txtRuc.setText("");
        txtRazonSocial.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");

        tabla.clearSelection();

        establecerModoRegistro();

        txtRuc.requestFocus();

        lblEstado.setText(
                "Formulario limpio. Modo registro activado."
        );
    }

    // =====================================================
    // MENSAJES
    // =====================================================

    private void mostrarExito(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Operación exitosa",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validación",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

