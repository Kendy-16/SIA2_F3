
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.MovimientoHistorial;
import pe.edu.inventario.modelo.dao.MovimientoDAO;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Servicio encargado de validar y coordinar las operaciones
 * relacionadas con los movimientos del inventario.
 *
 * Responsabilidades:
 * - Validar los datos antes de enviarlos al DAO.
 * - Registrar entradas, salidas y ajustes físicos.
 * - Consultar el historial general de movimientos.
 *
 * No contiene consultas SQL ni lógica de presentación.
 */
public class MovimientoService {

    // =====================================================
    // DEPENDENCIAS
    // =====================================================

    private final MovimientoDAO movimientoDAO;

    // =====================================================
    // CONSTANTES DE VALIDACIÓN
    // =====================================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;
    private static final int MAX_DECIMALES_COSTO = 6;

    private static final int MAX_DOCUMENTO = 50;
    private static final int MAX_OBSERVACION = 500;

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile("^[A-Z0-9][A-Z0-9._/-]{0,49}$");

    // =====================================================
    // CONSTRUCTORES
    // =====================================================

    /**
     * Constructor predeterminado.
     */
    public MovimientoService() {
        this(new MovimientoDAO());
    }

    /**
     * Constructor con inyección de dependencias.
     *
     * @param movimientoDAO DAO encargado del acceso a datos.
     */
    public MovimientoService(MovimientoDAO movimientoDAO) {

        if (movimientoDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de movimientos es obligatorio."
            );
        }

        this.movimientoDAO = movimientoDAO;
    }

    // =====================================================
    // REGISTRAR ENTRADA
    // =====================================================

    /**
     * Registra una entrada de productos al almacén.
     *
     * @param idProducto identificador del producto.
     * @param idAlmacen identificador del almacén.
     * @param documento documento de respaldo.
     * @param cantidad cantidad ingresada.
     * @param costoUnitario costo unitario de entrada.
     * @param observacion observación opcional.
     * @return true si la operación fue registrada.
     * @throws SQLException si ocurre un error en la base de datos.
     */
    public boolean registrarEntrada(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        validarCantidad(cantidad, false);
        validarCosto(costoUnitario);

        String documentoValido = validarDocumento(documento);
        String observacionValida = validarObservacion(observacion);

        return movimientoDAO.registrarEntrada(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidad,
                costoUnitario,
                observacionValida
        );
    }

    // =====================================================
    // REGISTRAR SALIDA
    // =====================================================

    /**
     * Registra una salida de productos del almacén.
     *
     * @param idProducto identificador del producto.
     * @param idAlmacen identificador del almacén.
     * @param documento documento de respaldo.
     * @param cantidad cantidad retirada.
     * @param observacion observación opcional.
     * @return true si la operación fue registrada.
     * @throws SQLException si ocurre un error en la base de datos.
     */
    public boolean registrarSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        validarCantidad(cantidad, false);

        String documentoValido = validarDocumento(documento);
        String observacionValida = validarObservacion(observacion);

        return movimientoDAO.registrarSalida(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidad,
                observacionValida
        );
    }

    // =====================================================
    // REGISTRAR AJUSTE DE INVENTARIO FÍSICO
    // =====================================================

    /**
     * Registra un ajuste según el conteo físico del inventario.
     *
     * Se permite una cantidad física igual a cero.
     *
     * @param idProducto identificador del producto.
     * @param idAlmacen identificador del almacén.
     * @param documento documento de respaldo.
     * @param cantidadFisica cantidad obtenida en el conteo físico.
     * @param observacion observación opcional.
     * @return true si la operación fue registrada.
     * @throws SQLException si ocurre un error en la base de datos.
     */
    public boolean registrarAjuste(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidadFisica,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        validarCantidad(cantidadFisica, true);

        String documentoValido = validarDocumento(documento);
        String observacionValida = validarObservacion(observacion);

        return movimientoDAO.registrarAjuste(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidadFisica,
                observacionValida
        );
    }

    // =====================================================
    // CONSULTAR HISTORIAL GENERAL DE MOVIMIENTOS
    // =====================================================

    /**
     * Obtiene el historial general de movimientos.
     *
     * Cada elemento representa un detalle de movimiento,
     * incluyendo sus datos de producto, almacén y documento.
     *
     * La consulta y el acceso a SQLite corresponden al DAO.
     *
     * @return lista inmodificable de movimientos históricos.
     * @throws SQLException si ocurre un error al consultar la BD.
     */
    public List<MovimientoHistorial> listarHistorial()
            throws SQLException {

        List<MovimientoHistorial> historial =
                movimientoDAO.listarHistorial();

        if (historial == null) {
            throw new SQLException(
                    "El DAO devolvió una lista nula del historial."
            );
        }

        // Devuelve una copia inmodificable para proteger
        // los resultados obtenidos desde la capa DAO.
        return List.copyOf(historial);
    }

    // =====================================================
    // VALIDAR IDENTIFICADORES
    // =====================================================

    /**
     * Comprueba que los identificadores sean positivos.
     */
    private void validarIdentificadores(
            int idProducto,
            int idAlmacen
    ) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacén debe ser positivo."
            );
        }
    }

    // =====================================================
    // VALIDAR CANTIDAD
    // =====================================================

    /**
     * Valida una cantidad de inventario.
     *
     * @param cantidad cantidad que se desea validar.
     * @param permitirCero indica si se permite el valor cero.
     */
    private void validarCantidad(
            double cantidad,
            boolean permitirCero
    ) {

        if (!Double.isFinite(cantidad)) {
            throw new IllegalArgumentException(
                    "La cantidad debe ser un número finito."
            );
        }

        if (cantidad < 0 || (!permitirCero && cantidad == 0)) {
            throw new IllegalArgumentException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(cantidad)
                .stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    "La cantidad supera el límite permitido."
            );
        }

        if (valor.scale() > MAX_DECIMALES_CANTIDAD) {
            throw new IllegalArgumentException(
                    "La cantidad admite como máximo 3 decimales."
            );
        }
    }

    // =====================================================
    // VALIDAR COSTO UNITARIO
    // =====================================================

    /**
     * Valida el costo unitario de un producto.
     *
     * Se permite costo cero, pero no valores negativos.
     */
    private void validarCosto(double costoUnitario) {

        if (!Double.isFinite(costoUnitario)
                || costoUnitario < 0) {

            throw new IllegalArgumentException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo = BigDecimal.valueOf(costoUnitario)
                .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El costo unitario supera el límite permitido."
            );
        }

        if (costo.scale() > MAX_DECIMALES_COSTO) {
            throw new IllegalArgumentException(
                    "El costo admite como máximo 6 decimales."
            );
        }
    }

    // =====================================================
    // VALIDAR DOCUMENTO
    // =====================================================

    /**
     * Normaliza y valida el documento de respaldo.
     *
     * Caracteres permitidos:
     * - Letras de A a Z.
     * - Números del 0 al 9.
     * - Punto, guion, guion bajo y barra.
     */
    private String validarDocumento(String documento) {

        if (documento == null || documento.isBlank()) {
            throw new IllegalArgumentException(
                    "El documento es obligatorio."
            );
        }

        String normalizado = documento.trim()
                .toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(normalizado).matches()) {

            throw new IllegalArgumentException(
                    "El formato del documento no es válido."
            );
        }

        return normalizado;
    }

    // =====================================================
    // VALIDAR OBSERVACIÓN
    // =====================================================

    /**
     * Valida y normaliza una observación.
     *
     * La observación es opcional.
     *
     * @param observacion texto ingresado.
     * @return texto normalizado o null si está vacío.
     */
    private String validarObservacion(String observacion) {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new IllegalArgumentException(
                    "La observación contiene caracteres no permitidos."
            );
        }

        String normalizada = observacion.trim()
                .replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new IllegalArgumentException(
                    "La observación no puede superar 500 caracteres."
            );
        }

        return normalizada;
    }

    // =====================================================
    // DETECTAR CARACTERES DE CONTROL
    // =====================================================

    /**
     * Comprueba si un texto contiene caracteres de control.
     *
     * @param texto texto que se desea comprobar.
     * @return true si contiene caracteres de control.
     */
    private boolean contieneCaracteresDeControl(String texto) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }
}
