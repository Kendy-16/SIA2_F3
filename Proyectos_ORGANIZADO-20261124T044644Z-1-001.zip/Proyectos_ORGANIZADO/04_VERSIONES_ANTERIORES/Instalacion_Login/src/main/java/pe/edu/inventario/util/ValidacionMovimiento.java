package pe.edu.inventario.util;

import java.math.BigDecimal;

public final class ValidacionMovimiento {

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private ValidacionMovimiento() {
    }

    public static String validarDocumento(String documento) {

        if (documento == null || documento.isBlank()) {
            throw new IllegalArgumentException(
                    "El documento de referencia es obligatorio."
            );
        }

        documento = documento.trim();

        if (documento.length() > 50) {
            throw new IllegalArgumentException(
                    "El documento no puede superar los 50 caracteres."
            );
        }

        return documento;
    }

    public static BigDecimal validarCantidad(
            String texto,
            String unidad,
            boolean permitirCero
    ) {

        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException(
                    "Debes ingresar una cantidad."
            );
        }

        BigDecimal cantidad = convertirNumero(texto, "La cantidad");

        if (permitirCero) {

            if (cantidad.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(
                        "La cantidad no puede ser negativa."
                );
            }

        } else {

            if (cantidad.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException(
                        "La cantidad debe ser mayor que cero."
                );
            }
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    "La cantidad supera el límite permitido."
            );
        }

        validarUnidadEntera(cantidad, unidad);

        return cantidad;
    }

    public static BigDecimal validarCosto(String texto) {

        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException(
                    "Debes ingresar el costo unitario."
            );
        }

        BigDecimal costo = convertirNumero(texto, "El costo");

        if (costo.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException(
                    "El costo unitario debe ser mayor que cero."
            );
        }

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El costo unitario supera el límite permitido."
            );
        }

        return costo;
    }

    public static String validarObservacionAjuste(String observacion) {

        if (observacion == null || observacion.isBlank()) {
            throw new IllegalArgumentException(
                    "La justificación del ajuste es obligatoria."
            );
        }

        observacion = observacion.trim();

        if (observacion.length() < 5) {
            throw new IllegalArgumentException(
                    "La justificación debe tener al menos 5 caracteres."
            );
        }

        if (observacion.length() > 500) {
            throw new IllegalArgumentException(
                    "La justificación no puede superar los 500 caracteres."
            );
        }

        return observacion;
    }

    public static String validarObservacionOpcional(String observacion) {

        if (observacion == null) {
            return "";
        }

        observacion = observacion.trim();

        if (observacion.length() > 500) {
            throw new IllegalArgumentException(
                    "La observación no puede superar los 500 caracteres."
            );
        }

        return observacion;
    }

    private static BigDecimal convertirNumero(
            String texto,
            String nombreCampo
    ) {

        try {

            String valor = texto.trim().replace(',', '.');

            if (!valor.matches("\\d+(\\.\\d+)?")) {
                throw new NumberFormatException();
            }

            BigDecimal numero = new BigDecimal(valor);

            if (numero.scale() > 6) {
                throw new IllegalArgumentException(
                        nombreCampo + ": máximo 6 decimales permitidos."
                );
            }

            return numero;

        } catch (NumberFormatException e) {

            throw new IllegalArgumentException(
                    nombreCampo + " debe ser un número válido."
            );
        }
    }

    private static void validarUnidadEntera(
            BigDecimal cantidad,
            String unidad
    ) {

        if (unidad == null || unidad.isBlank()) {
            throw new IllegalArgumentException(
                    "El producto no tiene una unidad de medida definida."
            );
        }

        String unidadNormalizada = unidad.trim().toUpperCase();

        if (unidadNormalizada.equals("UNIDAD")
                || unidadNormalizada.equals("CAJA")
                || unidadNormalizada.equals("PAQUETE")) {

            if (cantidad.stripTrailingZeros().scale() > 0) {
                throw new IllegalArgumentException(
                        "La unidad " + unidadNormalizada
                        + " solamente permite cantidades enteras."
                );
            }
        }

        if (!unidadNormalizada.equals("UNIDAD")
                && !unidadNormalizada.equals("KILOGRAMO")
                && !unidadNormalizada.equals("GRAMO")
                && !unidadNormalizada.equals("LITRO")
                && !unidadNormalizada.equals("METRO")
                && !unidadNormalizada.equals("CAJA")
                && !unidadNormalizada.equals("PAQUETE")) {

            throw new IllegalArgumentException(
                    "La unidad de medida del producto no es válida."
            );
        }
    }
}
