# Versiones anteriores (solo diferencias)

Aquí **no** hay proyectos completos: solo los archivos de `src/` que **difieren** de la versión activa (`01_PROYECTO_ACTIVO`).
Lo idéntico, lo vacío y los `.bak` se eliminaron o se movieron a `03_RESPALDOS`. Las bases de datos están en `03_RESPALDOS/base_de_datos`.

## Instalacion_Login — 10-nov-2026 (rama con más piezas de movimientos, pero con 2 archivos dañados)

Compilación de la versión completa: **117 errores**, todos por dos archivos:

| Archivo | Problema comprobado |
|---|---|
| `modelo/dao/MovimientoDAO.java` | Empieza a mitad de un método (línea 2 es un `if` suelto), repite 3 veces el bloque de utilidades (`validarCosto`, `rollback`, …), tiene 258 `{` y 266 `}`, y **no contiene** `registrarEntrada/Salida/Ajuste`. Su `.bak` es idéntico. |
| `vista/MenuPrincipalView.java` | El archivo termina cortado (“reached end of file while parsing”). |

Piezas útiles para rescatar (ninguna está en la versión activa):

| Pieza | Tamaño | Nota |
|---|---|---|
| `vista/movimientos/HistorialMovimientosView.java` | 23 KB | Vista de historial; solo depende de `MovimientoHistorial`. |
| `modelo/MovimientoHistorial.java` | 18 KB | Modelo del historial. |
| `listarHistorial()` en `MovimientoDAO.java` | ≈ líneas 422–588 | Extraer el método completo; el resto del archivo es inservible. |
| `util/ValidacionMovimiento.java`, `servicio/MovimientoService.java` (13 KB) | — | Validaciones y servicio más extensos, pensados para el DAO de esa rama. |
| `vista/movimientos/{Entrada,Salida,AjusteInventario}View.java` | 12–14 KB c/u | Reemplazadas en la activa por `MovimientoView` (pestañas). |
| `vista/LoginView.java`, `Main.java` | 24 KB / 4 KB | Incluye el asistente “crear primer administrador”. |
| `vista/almacen/AlmacenView.java`, `componentes/EstilosMovimiento.java` | 27 KB / 14 KB | Versiones más grandes que las de la activa. |
| `src/main/resources/imagenes/fondo aplicativo.png` | 1 MB | Fondo no usado por la versión activa. |

Para integrar cualquiera de ellas hay que probar contra el resto del código: varias dependen de métodos de su propio `MovimientoDAO`.

## Instalacion_Temporal — 10-nov-2026 (superada)

Compila, pero es la más antigua: `MenuPrincipalView` de 11 KB (diseño inicial), `Main` mínimo y sin roles. Se conserva solo por historial.
