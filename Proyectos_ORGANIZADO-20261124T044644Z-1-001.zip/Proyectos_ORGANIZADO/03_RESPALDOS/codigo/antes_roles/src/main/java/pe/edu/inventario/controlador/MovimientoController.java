
package pe.edu.inventario.controlador;

import pe.edu.inventario.servicio.MovimientoService;

import java.sql.SQLException;

public class MovimientoController {

    private final MovimientoService movimientoService;

    // Constructor
    public MovimientoController() {
        this.movimientoService = new MovimientoService();
    }

    // Constructor with dependency injection
    public MovimientoController(MovimientoService movimientoService) {

        if (movimientoService == null) {
            throw new IllegalArgumentException(
                    "El servicio de movimientos es obligatorio."
            );
        }

        this.movimientoService = movimientoService;
    }

    // ==========================================
    // REGISTER ENTRY
    // ==========================================

    public boolean registrarMovimientoEntrada(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion
    ) throws SQLException {

        return movimientoService.registrarEntrada(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                costoUnitario,
                observacion
        );
    }

    // ==========================================
    // REGISTER EXIT
    // ==========================================

    public boolean registrarMovimientoSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            String observacion
    ) throws SQLException {

        return movimientoService.registrarSalida(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                observacion
        );
    }

    // ==========================================
    // REGISTER INVENTORY ADJUSTMENT
    // ==========================================

    public boolean registrarMovimientoAjuste(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidadFisica,
            String observacion
    ) throws SQLException {

        return movimientoService.registrarAjuste(
                idProducto,
                idAlmacen,
                documento,
                cantidadFisica,
                observacion
        );
    }

    // ==========================================
    // CALCULATE WEIGHTED AVERAGE COST
    // ==========================================

    public double calcularCostoPromedio(
            double stockActual,
            double costoActual,
            double cantidadEntrada,
            double costoEntrada
    ) {

        if (!Double.isFinite(stockActual)
                || !Double.isFinite(costoActual)
                || !Double.isFinite(cantidadEntrada)
                || !Double.isFinite(costoEntrada)) {

            throw new IllegalArgumentException(
                    "Los valores deben ser numeros finitos."
            );
        }

        if (stockActual < 0
                || costoActual < 0
                || cantidadEntrada <= 0
                || costoEntrada < 0) {

            throw new IllegalArgumentException(
                    "Las cantidades y costos no son validos."
            );
        }

        double nuevoStock = stockActual + cantidadEntrada;

        return (
                (stockActual * costoActual)
                + (cantidadEntrada * costoEntrada)
        ) / nuevoStock;
    }
}
