package pe.edu.inventario.modelo.dao;

import pe.edu.inventario.enums.TipoMovimiento;
import pe.edu.inventario.modelo.ConexionDB;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * DAO encargado de registrar movimientos de inventario.
 *
 * Operaciones:
 * - Entradas.
 * - Salidas.
 * - Ajustes fisicos.
 *
 * Responsabilidades:
 * - Validar productos y almacenes activos.
 * - Comprobar existencias disponibles.
 * - Aplicar el costo promedio ponderado movil.
 * - Actualizar inventario por almacen.
 * - Registrar los movimientos.
 * - Registrar los detalles.
 * - Actualizar el Kardex.
 * - Mantener la atomicidad de las operaciones.
 *
 * IMPORTANTE:
 * La implementacion de concurrencia utiliza las transacciones
 * de escritura de SQLite. No utiliza SELECT FOR UPDATE porque
 * SQLite no admite esa clausula.
 */
public class MovimientoDAO {

    // =========================================================
    // 1. CONSTANTES
    // =========================================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final BigDecimal VALOR_MAXIMO =
            new BigDecimal("1000000000000000000");

    private static final int ESCALA_CANTIDAD = 3;

    private static final int ESCALA_COSTO = 6;

    private static final int MAX_DOCUMENTO = 50;

    private static final int MAX_OBSERVACION = 500;

    private static final int MIN_OBSERVACION_AJUSTE = 5;

    private static final int BUSY_TIMEOUT_MS = 10000;

    private static final Set<String> UNIDADES_VALIDAS = Set.of(
            "UNIDAD",
            "KILOGRAMO",
            "GRAMO",
            "LITRO",
            "METRO",
            "CAJA",
            "PAQUETE"
    );

    private static final Set<String> UNIDADES_ENTERAS = Set.of(
            "UNIDAD",
            "CAJA",
            "PAQUETE"
    );

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile(
                    "^[A-Z0-9][A-Z0-9._/-]{0,49}$"
            );

    // =========================================================
    // 2. REGISTRAR ENTRADA
    // =========================================================

    /**
     * Registra una entrada de mercaderia.
     *
     * El nuevo costo promedio se calcula mediante:
     *
     * ((stock actual * costo actual)
     * + (cantidad entrada * costo entrada))
     * / stock resultante
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacen
     * @param documento documento de referencia
     * @param cantidad cantidad ingresada
     * @param costoUnitario costo unitario de entrada
     * @param observacion observacion del movimiento
     * @return true si la entrada se registro correctamente
     */
    public boolean registrarEntrada(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion
    ) throws SQLException {

        return registrarEntradaOSalida(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                costoUnitario,
                observacion,
                TipoMovimiento.ENTRADA
        );
    }

    // =========================================================
    // 3. REGISTRAR SALIDA
    // =========================================================

    /**
     * Registra una salida de mercaderia.
     *
     * La cantidad solicitada nunca puede superar
     * el stock disponible del producto en el almacen.
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacen
     * @param documento documento de referencia
     * @param cantidad cantidad retirada
     * @param observacion observacion del movimiento
     * @return true si la salida se registro correctamente
     */
    public boolean registrarSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            String observacion
    ) throws SQLException {

        return registrarEntradaOSalida(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                0,
                observacion,
                TipoMovimiento.SALIDA
        );
    }

    // =========================================================
    // 4. PROCESAR ENTRADA O SALIDA
    // =========================================================

    /**
     * Procesa una entrada o una salida dentro de una unica
     * transaccion JDBC.
     *
     * Se adquiere primero el bloqueo de escritura de SQLite
     * mediante una actualizacion de bloqueo del almacen.
     *
     * De esta manera, las validaciones de stock y el posterior
     * registro de la operacion se ejecutan bajo la misma
     * transaccion de escritura.
     */
    private boolean registrarEntradaOSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion,
            TipoMovimiento tipo
    ) throws SQLException {

        // 1. Validaciones iniciales.
        validarIdentificadores(idProducto, idAlmacen);

        if (tipo == null) {
            throw new IllegalArgumentException(
                    "El tipo de movimiento es obligatorio."
            );
        }

        if (!tipo.esEntrada() && !tipo.esSalida()) {
            throw new IllegalArgumentException(
                    "El tipo de operacion no es valido."
            );
        }

        BigDecimal cantidadMovimiento =
                validarCantidad(cantidad, false);

        BigDecimal costoEntrada = BigDecimal.ZERO;

        if (tipo.esEntrada()) {

            costoEntrada = validarCosto(costoUnitario);


        } else if (Double.compare(costoUnitario, 0.0) != 0) {

            throw new IllegalArgumentException(
                    "Una salida no debe recibir un costo unitario externo."
            );
        }

        String documentoNormalizado =
                validarDocumento(documento);

        String observacionNormalizada =
                validarObservacion(observacion);

        // 2. Iniciar transaccion.
        try (Connection conexion = ConexionDB.conectar()) {

            configurarBloqueo(conexion);

            conexion.setAutoCommit(false);

            try {

                // 3. Adquirir el bloqueo de escritura de SQLite.
                adquirirBloqueoEscritura(
                        conexion,
                        idAlmacen
                );

                // 4. Verificar producto y unidad de medida.
                ProductoInfo producto =
                        buscarProducto(conexion, idProducto);

                // 5. Verificar almacen.
                validarAlmacen(conexion, idAlmacen);

                // 6. Impedir movimientos durante un conteo abierto.
                validarSinConteoFisicoAbierto(
                        conexion,
                        idAlmacen
                );

                // 7. Validar cantidad segun unidad.
                validarCantidadUnidad(
                        cantidadMovimiento,
                        producto.unidadMedida
                );

                // 8. Recuperar inventario actual.
                InventarioActual actual =
                        buscarInventario(
                                conexion,
                                idProducto,
                                idAlmacen
                        );

                BigDecimal nuevoStock;

                BigDecimal nuevoCostoPromedio;

                BigDecimal costoMovimiento;

                BigDecimal entrada = BigDecimal.ZERO;

                BigDecimal salida = BigDecimal.ZERO;

                if (tipo.esEntrada()) {

                    // =========================================
                    // PROCESAMIENTO DE ENTRADA
                    // =========================================

                    nuevoStock = actual.cantidad.add(
                            cantidadMovimiento
                    );

                    validarStockMaximo(nuevoStock);

                    // Calcular costo promedio ponderado movil.
                    nuevoCostoPromedio = calcularPromedio(
                            actual.cantidad,
                            actual.costoPromedio,
                            cantidadMovimiento,
                            costoEntrada
                    );

                    validarCostoPromedio(
                            nuevoCostoPromedio
                    );

                    costoMovimiento = costoEntrada;

                    entrada = cantidadMovimiento;

                } else {

                    // =========================================
                    // PROCESAMIENTO DE SALIDA
                    // =========================================

                    if (cantidadMovimiento.compareTo(
                            actual.cantidad
                    ) > 0) {

                        throw new SQLException(
                                "Stock insuficiente. "
                                + "La cantidad solicitada supera "
                                + "las existencias disponibles."
                        );
                    }

                    nuevoStock = actual.cantidad.subtract(
                            cantidadMovimiento
                    );

                    validarStockMaximo(nuevoStock);

                    // Las salidas conservan el costo promedio.
                    nuevoCostoPromedio = actual.costoPromedio;

                    // La salida se valoriza al costo promedio vigente.
                    costoMovimiento = actual.costoPromedio;

                    salida = cantidadMovimiento;
                }

                nuevoStock = normalizarCantidad(nuevoStock);

                // 9. Registrar cabecera.
                int idMovimiento = insertarCabecera(
                        conexion,
                        tipo,
                        documentoNormalizado,
                        observacionNormalizada,
                        idAlmacen
                );

                // 10. Registrar detalle.
                insertarDetalle(
                        conexion,
                        idMovimiento,
                        idProducto,
                        cantidadMovimiento,
                        costoMovimiento
                );

                // 11. Actualizar existencias.
                guardarInventario(
                        conexion,
                        idProducto,
                        idAlmacen,
                        actual.existe,
                        nuevoStock,
                        nuevoCostoPromedio
                );

                // 12. Registrar Kardex.
                insertarKardex(
                        conexion,
                        idProducto,
                        idAlmacen,
                        tipo,
                        documentoNormalizado,
                        entrada,
                        salida,
                        nuevoStock,
                        costoMovimiento,
                        nuevoCostoPromedio
                );

                // 13. Confirmar todas las operaciones.
                conexion.commit();

                return true;

            } catch (SQLException ex) {

                rollback(conexion, ex);

                throw ex;

            } catch (RuntimeException ex) {

                rollback(conexion, ex);

                throw ex;
            }
        }
    }

    // =========================================================
    // 5. REGISTRAR AJUSTE FISICO MANUAL
    // =========================================================

    /**
     * Ajusta las existencias al stock encontrado fisicamente.
     *
     * cantidadFisica representa el stock final contado,
     * por lo que puede ser cero.
     *
     * La diferencia calculada debe ser mayor que cero.
     *
     * La justificacion del ajuste es obligatoria.
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacen
     * @param documento documento de referencia
     * @param cantidadFisica cantidad encontrada
     * @param observacion justificacion del ajuste
     * @return true si se aplico el ajuste; false si no hubo diferencias
     */
    public boolean registrarAjuste(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidadFisica,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        // La cantidad fisica puede ser cero.
        BigDecimal stockFisico =
                validarCantidad(cantidadFisica, true);

        String documentoNormalizado =
                validarDocumento(documento);

        String observacionNormalizada =
                validarObservacionObligatoria(observacion);

        try (Connection conexion = ConexionDB.conectar()) {

            configurarBloqueo(conexion);

            conexion.setAutoCommit(false);

            try {

                // 1. Adquirir bloqueo de escritura.
                adquirirBloqueoEscritura(
                        conexion,
                        idAlmacen
                );

                // 2. Validar producto.
                ProductoInfo producto =
                        buscarProducto(conexion, idProducto);

                // 3. Validar almacen.
                validarAlmacen(conexion, idAlmacen);

                // 4. No permitir ajustes manuales durante
                //    un inventario fisico abierto.
                validarSinConteoFisicoAbierto(
                        conexion,
                        idAlmacen
                );

                // 5. Validar unidad de medida.
                validarCantidadUnidad(
                        stockFisico,
                        producto.unidadMedida
                );

                // 6. Obtener existencias actuales.
                InventarioActual actual =
                        buscarInventario(
                                conexion,
                                idProducto,
                                idAlmacen
                        );

                // 7. Calcular diferencia.
                int comparacion = stockFisico.compareTo(
                        actual.cantidad
                );

                // No se necesita movimiento si no existe diferencia.
                if (comparacion == 0) {

                    conexion.rollback();

                    return false;
                }

                // No se puede valorizar un sobrante sin costo.
                if (comparacion > 0
                        && (!actual.existe
                        || actual.costoPromedio.signum() <= 0)) {

                    throw new SQLException(
                            "No existe un costo promedio valido. "
                            + "Registre primero una entrada con su costo."
                    );
                }

                BigDecimal diferencia;

                BigDecimal entrada = BigDecimal.ZERO;

                BigDecimal salida = BigDecimal.ZERO;

                BigDecimal costoMovimiento =
                        actual.costoPromedio;

                if (comparacion > 0) {

                    // SOBRANTE.
                    diferencia = stockFisico.subtract(
                            actual.cantidad
                    );

                    validarCantidadEstricitamentePositiva(diferencia);

                    entrada = diferencia;

                } else {

                    // FALTANTE.
                    diferencia = actual.cantidad.subtract(
                            stockFisico
                    );

                    validarCantidadEstricitamentePositiva(diferencia);

                    salida = diferencia;
                }

                validarCantidadUnidad(
                        diferencia,
                        producto.unidadMedida
                );

                BigDecimal nuevoStock = stockFisico;

                // El ajuste conserva el costo promedio vigente.
                BigDecimal nuevoCostoPromedio =
                        actual.costoPromedio;

                validarStockMaximo(nuevoStock);

                // 8. Insertar cabecera.
                int idMovimiento = insertarCabecera(
                        conexion,
                        TipoMovimiento.AJUSTE,
                        documentoNormalizado,
                        observacionNormalizada,
                        idAlmacen
                );

                // 9. Registrar detalle con diferencia absoluta.
                insertarDetalle(
                        conexion,
                        idMovimiento,
                        idProducto,
                        diferencia,
                        costoMovimiento
                );

                // 10. Actualizar existencias.
                guardarInventario(
                        conexion,
                        idProducto,
                        idAlmacen,
                        actual.existe,
                        nuevoStock,
                        nuevoCostoPromedio
                );

                // 11. Registrar Kardex.
                insertarKardex(
                        conexion,
                        idProducto,
                        idAlmacen,
                        TipoMovimiento.AJUSTE,
                        documentoNormalizado,
                        entrada,
                        salida,
                        nuevoStock,
                        costoMovimiento,
                        nuevoCostoPromedio
                );

                // 12. Confirmar.
                conexion.commit();

                return true;

            } catch (SQLException ex) {

                rollback(conexion, ex);

                throw ex;

            } catch (RuntimeException ex) {

                rollback(conexion, ex);

                throw ex;
            }
        }
    }

    // =========================================================
    // 6. CONFIGURAR BLOQUEO SQLITE
    // =========================================================

    /**
     * Configura el tiempo de espera de SQLite cuando existe
     * otra transaccion de escritura.
     */
    private void configurarBloqueo(
            Connection conexion
    ) throws SQLException {

        try (Statement sentencia = conexion.createStatement()) {

            sentencia.execute(
                    "PRAGMA busy_timeout = " + BUSY_TIMEOUT_MS
            );
        }
    }

    /**
     * SQLite no admite SELECT FOR UPDATE.
     *
     * Se realiza una actualizacion de bloqueo sobre el almacen
     * para que SQLite adquiera el bloqueo de escritura antes
     * de consultar y modificar las existencias.
     *
     * SQLite serializa las transacciones escritoras.
     * El bloqueo se mantiene hasta COMMIT o ROLLBACK.
     */
    private void adquirirBloqueoEscritura(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "UPDATE almacenes "
                + "SET nombre = nombre "
                + "WHERE id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            int filas = sentencia.executeUpdate();

            if (filas != 1) {
                throw new SQLException(
                        "No se pudo bloquear el almacen seleccionado."
                );
            }
        }
    }

    // =========================================================
    // 7. VALIDAR IDENTIFICADORES
    // =========================================================

    private void validarIdentificadores(
            int idProducto,
            int idAlmacen
    ) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // =========================================================
    // 8. BUSCAR PRODUCTO Y VALIDAR ESTADO ACTIVO
    // =========================================================

    private ProductoInfo buscarProducto(
            Connection conexion,
            int idProducto
    ) throws SQLException {

        String sql =
                "SELECT unidad_medida, activo "
                + "FROM productos "
                + "WHERE id_producto = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idProducto);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {
                    throw new SQLException(
                            "El producto seleccionado no existe."
                    );
                }

                if (resultado.getInt("activo") != 1) {
                    throw new SQLException(
                            "El producto esta inactivo. "
                            + "No se permiten movimientos."
                    );
                }

                String unidad = resultado.getString(
                        "unidad_medida"
                );

                if (unidad == null || unidad.isBlank()) {
                    throw new SQLException(
                            "El producto no tiene unidad de medida."
                    );
                }

                unidad = unidad.trim().toUpperCase(Locale.ROOT);

                if (!UNIDADES_VALIDAS.contains(unidad)) {
                    throw new SQLException(
                            "La unidad de medida del producto no es valida."
                    );
                }

                return new ProductoInfo(unidad);
            }
        }
    }

    // =========================================================
    // 9. VALIDAR ALMACEN ACTIVO
    // =========================================================

    private void validarAlmacen(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT activo "
                + "FROM almacenes "
                + "WHERE id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (!resultado.next()) {
                    throw new SQLException(
                            "El almacen seleccionado no existe."
                    );
                }

                if (resultado.getInt("activo") != 1) {
                    throw new SQLException(
                            "El almacen esta inactivo. "
                            + "No se permiten movimientos."
                    );
                }
            }
        }
    }

    // =========================================================
    // 10. BLOQUEAR MOVIMIENTOS DURANTE CONTEO FISICO
    // =========================================================

    private void validarSinConteoFisicoAbierto(
            Connection conexion,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT 1 "
                + "FROM tomas_inventario_fisico "
                + "WHERE id_almacen = ? "
                + "AND estado = 'ABIERTO' "
                + "LIMIT 1";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (resultado.next()) {
                    throw new SQLException(
                            "No se puede registrar el movimiento. "
                            + "El almacen tiene un inventario fisico "
                            + "en estado ABIERTO."
                    );
                }
            }
        }
    }

    // =========================================================
    // 11. BUSCAR INVENTARIO ACTUAL
    // =========================================================

    private InventarioActual buscarInventario(
            Connection conexion,
            int idProducto,
            int idAlmacen
    ) throws SQLException {

        String sql =
                "SELECT cantidad, costo_promedio "
                + "FROM inventario "
                + "WHERE id_producto = ? "
                + "AND id_almacen = ?";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idProducto);
            sentencia.setInt(2, idAlmacen);

            try (ResultSet resultado =
                         sentencia.executeQuery()) {

                if (resultado.next()) {

                    BigDecimal cantidad = decimal(
                            resultado.getDouble("cantidad")
                    );

                    BigDecimal costoPromedio = decimal(
                            resultado.getDouble("costo_promedio")
                    );

                    validarInventarioActual(
                            cantidad,
                            costoPromedio
                    );

                    return new InventarioActual(
                            normalizarCantidad(cantidad),
                            normalizarCosto(costoPromedio),
                            true
                    );
                }
            }
        }

        return new InventarioActual(
                BigDecimal.ZERO.setScale(ESCALA_CANTIDAD),
                BigDecimal.ZERO.setScale(ESCALA_COSTO),
                false
        );
    }

    /**
     * Valida la informacion recuperada de inventario.
     */
    private void validarInventarioActual(
            BigDecimal cantidad,
            BigDecimal costoPromedio
    ) throws SQLException {

        if (cantidad.signum() < 0
                || cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {

            throw new SQLException(
                    "El inventario contiene una cantidad no valida."
            );
        }

        if (costoPromedio.signum() < 0
                || costoPromedio.compareTo(COSTO_MAXIMO) > 0) {

            throw new SQLException(
                    "El inventario contiene un costo promedio no valido."
            );
        }
    }

    // =========================================================
    // 12. INSERTAR CABECERA DEL MOVIMIENTO
    // =========================================================

    private int insertarCabecera(
            Connection conexion,
            TipoMovimiento tipo,
            String documento,
            String observacion,
            int idAlmacen
    ) throws SQLException {

        if (tipo == null) {
            throw new SQLException(
                    "El tipo de movimiento es obligatorio."
            );
        }

        String sql =
                "INSERT INTO movimientos "
                + "(tipo, fecha, documento, observacion, id_almacen) "
                + "VALUES (?, datetime('now','localtime'), ?, ?, ?)";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setString(1, tipo.getCodigo());

            sentencia.setString(2, documento);

            asignarTextoOpcional(
                    sentencia,
                    3,
                    observacion
            );

            sentencia.setInt(4, idAlmacen);

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar la cabecera del movimiento."
                );
            }
        }

        try (Statement sentencia =
                     conexion.createStatement();
             ResultSet resultado =
                     sentencia.executeQuery(
                             "SELECT last_insert_rowid()"
                     )) {

            if (resultado.next()) {
                return resultado.getInt(1);
            }
        }

        throw new SQLException(
                "No se pudo recuperar el ID del movimiento."
        );
    }

    // =========================================================
    // 13. INSERTAR DETALLE DEL MOVIMIENTO
    // =========================================================

    private void insertarDetalle(
            Connection conexion,
            int idMovimiento,
            int idProducto,
            BigDecimal cantidad,
            BigDecimal costoUnitario
    ) throws SQLException {

        if (cantidad == null
                || cantidad.signum() <= 0) {

            throw new SQLException(
                    "El detalle del movimiento requiere "
                    + "una cantidad mayor que cero."
            );
        }

        if (costoUnitario == null
                || costoUnitario.signum() < 0) {

            throw new SQLException(
                    "El costo unitario no es valido."
            );
        }

        String sql =
                "INSERT INTO detalle_movimientos "
                + "(id_movimiento, id_producto, cantidad, costo_unitario) "
                + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idMovimiento);
            sentencia.setInt(2, idProducto);

            sentencia.setDouble(
                    3,
                    normalizarCantidad(cantidad).doubleValue()
            );

            sentencia.setDouble(
                    4,
                    normalizarCosto(costoUnitario).doubleValue()
            );

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar el detalle del movimiento."
                );
            }
        }
    }

    // =========================================================
    // 14. ACTUALIZAR O INSERTAR INVENTARIO
    // =========================================================

    private void guardarInventario(
            Connection conexion,
            int idProducto,
            int idAlmacen,
            boolean existe,
            BigDecimal cantidad,
            BigDecimal costoPromedio
    ) throws SQLException {

        validarStockMaximo(cantidad);

        validarCostoPromedio(costoPromedio);

        String sql;

        if (existe) {

            sql =
                    "UPDATE inventario "
                    + "SET cantidad = ?, costo_promedio = ? "
                    + "WHERE id_producto = ? AND id_almacen = ?";

        } else {

            sql =
                    "INSERT INTO inventario "
                    + "(cantidad, costo_promedio, id_producto, id_almacen) "
                    + "VALUES (?, ?, ?, ?)";
        }

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setDouble(
                    1,
                    normalizarCantidad(cantidad).doubleValue()
            );

            sentencia.setDouble(
                    2,
                    normalizarCosto(costoPromedio).doubleValue()
            );

            sentencia.setInt(3, idProducto);
            sentencia.setInt(4, idAlmacen);

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo guardar el inventario."
                );
            }
        }
    }

    // =========================================================
    // 15. INSERTAR REGISTRO EN KARDEX
    // =========================================================

    private void insertarKardex(
            Connection conexion,
            int idProducto,
            int idAlmacen,
            TipoMovimiento tipo,
            String documento,
            BigDecimal entrada,
            BigDecimal salida,
            BigDecimal saldo,
            BigDecimal costoUnitario,
            BigDecimal costoPromedio
    ) throws SQLException {

        if (tipo == null) {
            throw new SQLException(
                    "El tipo del Kardex es obligatorio."
            );
        }

        validarCantidadNoNegativa(entrada, "Entrada");
        validarCantidadNoNegativa(salida, "Salida");

        validarStockMaximo(saldo);

        validarCostoPromedio(costoPromedio);

        validarCostoPromedio(costoUnitario);

        // Una entrada o salida debe tener una sola direccion.
        if (entrada.signum() > 0 && salida.signum() > 0) {
            throw new SQLException(
                    "El Kardex no puede registrar entrada y salida "
                    + "simultaneamente en una misma operacion."
            );
        }

        if (tipo.esEntrada() && entrada.signum() <= 0) {
            throw new SQLException(
                    "Una entrada debe registrar una cantidad positiva."
            );
        }

        if (tipo.esSalida() && salida.signum() <= 0) {
            throw new SQLException(
                    "Una salida debe registrar una cantidad positiva."
            );
        }

        if (tipo.esAjuste()
                && entrada.signum() == salida.signum()) {

            throw new SQLException(
                    "El ajuste debe tener una direccion definida."
            );
        }

        String sql =
                "INSERT INTO kardex ("
                + "id_producto, id_almacen, fecha, tipo, documento, "
                + "entrada, salida, saldo, costo_unitario, "
                + "costo_promedio, valor_saldo"
                + ") VALUES (?, ?, datetime('now','localtime'), ?, ?, "
                + "?, ?, ?, ?, ?, ?)";

        BigDecimal valorSaldo = saldo.multiply(costoPromedio)
                .setScale(
                        ESCALA_COSTO,
                        RoundingMode.HALF_UP
                );

        validarValorSaldo(valorSaldo);

        try (PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setInt(1, idProducto);
            sentencia.setInt(2, idAlmacen);

            sentencia.setString(3, tipo.getCodigo());

            sentencia.setString(4, documento);

            sentencia.setDouble(
                    5,
                    normalizarCantidad(entrada).doubleValue()
            );

            sentencia.setDouble(
                    6,
                    normalizarCantidad(salida).doubleValue()
            );

            sentencia.setDouble(
                    7,
                    normalizarCantidad(saldo).doubleValue()
            );

            sentencia.setDouble(
                    8,
                    normalizarCosto(costoUnitario).doubleValue()
            );

            sentencia.setDouble(
                    9,
                    normalizarCosto(costoPromedio).doubleValue()
            );

            sentencia.setDouble(
                    10,
                    valorSaldo.doubleValue()
            );

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                        "No se pudo registrar el movimiento en el Kardex."
                );
            }
        }
    }

    // =========================================================
    // 16. CALCULAR COSTO PROMEDIO PONDERADO MOVIL
    // =========================================================

    /**
     * Calcula el costo promedio despues de una entrada.
     *
     * Formula:
     *
     * ((stockActual * costoActual)
     * + (cantidadEntrada * costoEntrada))
     * / (stockActual + cantidadEntrada)
     *
     * Redondeo:
     * HALF_UP a seis decimales.
     */
    private BigDecimal calcularPromedio(
            BigDecimal stockActual,
            BigDecimal costoActual,
            BigDecimal cantidadEntrada,
            BigDecimal costoEntrada
    ) throws SQLException {

        if (stockActual == null
                || costoActual == null
                || cantidadEntrada == null
                || costoEntrada == null) {

            throw new SQLException(
                    "No se puede calcular el costo promedio con valores nulos."
            );
        }

        if (stockActual.signum() < 0
                || cantidadEntrada.signum() <= 0
                || costoActual.signum() < 0
                || costoEntrada.signum() < 0) {

            throw new SQLException(
                    "Los valores utilizados para calcular "
                    + "el costo promedio no son validos."
            );
        }

        BigDecimal nuevoStock = stockActual.add(
                cantidadEntrada
        );

        if (nuevoStock.signum() <= 0) {
            throw new SQLException(
                    "El stock resultante debe ser mayor que cero."
            );
        }

        BigDecimal valorAnterior = stockActual.multiply(
                costoActual
        );

        BigDecimal valorEntrada = cantidadEntrada.multiply(
                costoEntrada
        );

        BigDecimal nuevoValor = valorAnterior.add(
                valorEntrada
        );

        validarValorSaldo(nuevoValor);

        BigDecimal promedio = nuevoValor.divide(
                nuevoStock,
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );

        validarCostoPromedio(promedio);

        return normalizarCosto(promedio);
    }

    // =========================================================
    // 17. VALIDAR CANTIDAD DE MOVIMIENTO
    // =========================================================

    /**
     * @param permitirCero true solamente para el stock fisico
     *                     final de un ajuste.
     */
    private BigDecimal validarCantidad(
            double cantidad,
            boolean permitirCero
    ) throws SQLException {

        if (!Double.isFinite(cantidad)) {
            throw new SQLException(
                    "La cantidad debe ser un numero finito."
            );
        }

        if (cantidad < 0
                || (!permitirCero && cantidad == 0)) {

            throw new SQLException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor = BigDecimal.valueOf(cantidad)
                .stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La cantidad supera el limite permitido."
            );
        }

        if (valor.scale() > ESCALA_CANTIDAD) {
            throw new SQLException(
                    "La cantidad admite como maximo tres decimales."
            );
        }

        return normalizarCantidad(valor);
    }

    /**
     * Valida una diferencia que necesariamente debe ser positiva.
     */
    private void validarCantidadEstricitamentePositiva(
            BigDecimal cantidad
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() <= 0) {
            throw new SQLException(
                    "La diferencia del ajuste debe ser mayor que cero."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "La diferencia supera el limite permitido."
            );
        }
    }

    /**
     * Comprueba que una cantidad no sea negativa.
     */
    private void validarCantidadNoNegativa(
            BigDecimal cantidad,
            String campo
    ) throws SQLException {

        if (cantidad == null || cantidad.signum() < 0) {
            throw new SQLException(
                    campo + " no puede ser nula ni negativa."
            );
        }

        if (cantidad.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    campo + " supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 18. VALIDAR CANTIDAD SEGUN UNIDAD DE MEDIDA
    // =========================================================

    private void validarCantidadUnidad(
            BigDecimal cantidad,
            String unidad
    ) throws SQLException {

        if (cantidad == null || unidad == null) {
            throw new SQLException(
                    "La cantidad y unidad de medida son obligatorias."
            );
        }

        String unidadNormalizada =
                unidad.trim().toUpperCase(Locale.ROOT);

        if (!UNIDADES_VALIDAS.contains(unidadNormalizada)) {
            throw new SQLException(
                    "La unidad de medida no esta permitida."
            );
        }

        if (UNIDADES_ENTERAS.contains(unidadNormalizada)
                && cantidad.stripTrailingZeros().scale() > 0) {

            throw new SQLException(
                    "La unidad " + unidadNormalizada
                    + " solamente admite cantidades enteras."
            );
        }
    }

    // =========================================================
    // 19. VALIDAR COSTO UNITARIO
    // =========================================================

    private BigDecimal validarCosto(
            double costoUnitario
    ) throws SQLException {

        if (!Double.isFinite(costoUnitario)
                || costoUnitario < 0) {

            throw new SQLException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo = BigDecimal.valueOf(costoUnitario)
                .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo unitario supera el limite permitido."
            );
        }

        if (costo.scale() > ESCALA_COSTO) {
            throw new SQLException(
                    "El costo admite como maximo seis decimales."
            );
        }

        return normalizarCosto(costo);
    }


    // =========================================================
    // VALIDAR COSTO PROMEDIO
    // =========================================================

    /**
     * Valida un costo promedio representado mediante BigDecimal.
     *
     * Comprueba:
     * - Que el valor no sea nulo.
     * - Que no sea negativo.
     * - Que no supere el costo maximo permitido.
     * - Que admita como maximo seis decimales.
     *
     * No modifica ni redondea el valor recibido.
     */
    private void validarCostoPromedio(
            BigDecimal costoPromedio
    ) throws SQLException {

        if (costoPromedio == null) {
            throw new SQLException(
                    "El costo promedio no puede ser nulo."
            );
        }

        if (costoPromedio.signum() < 0) {
            throw new SQLException(
                    "El costo promedio no puede ser negativo."
            );
        }

        if (costoPromedio.compareTo(COSTO_MAXIMO) > 0) {
            throw new SQLException(
                    "El costo promedio supera el limite permitido."
            );
        }

        try {

            costoPromedio.setScale(
                    ESCALA_COSTO,
                    RoundingMode.UNNECESSARY
            );

        } catch (ArithmeticException ex) {

            throw new SQLException(
                    "El costo promedio admite como maximo "
                            + ESCALA_COSTO + " decimales.",
                    ex
            );
        }
    }




    // =========================================================
    // 21. VALIDAR STOCK RESULTANTE
    // =========================================================

    private void validarStockMaximo(
            BigDecimal stock
    ) throws SQLException {

        if (stock == null || stock.signum() < 0) {
            throw new SQLException(
                    "El stock resultante no puede ser nulo ni negativo."
            );
        }

        if (stock.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new SQLException(
                    "El stock resultante supera el limite permitido."
            );
        }

        try {

            stock.setScale(
                    ESCALA_CANTIDAD,
                    RoundingMode.UNNECESSARY
            );

        } catch (ArithmeticException ex) {

            throw new SQLException(
                    "El stock resultante supera la precision permitida.",
                    ex
            );
        }
    }

    // =========================================================
    // 22. VALIDAR VALOR VALORIZADO
    // =========================================================

    private void validarValorSaldo(
            BigDecimal valor
    ) throws SQLException {

        if (valor == null || valor.signum() < 0) {
            throw new SQLException(
                    "El valor valorizado no puede ser negativo."
            );
        }

        if (valor.compareTo(VALOR_MAXIMO) > 0) {
            throw new SQLException(
                    "El valor valorizado supera el limite permitido."
            );
        }
    }

    // =========================================================
    // 23. VALIDAR DOCUMENTO
    // =========================================================

    private String validarDocumento(
            String documento
    ) throws SQLException {

        if (documento == null || documento.isBlank()) {
            throw new SQLException(
                    "El documento es obligatorio."
            );
        }

        String normalizado =
                documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(
                        normalizado
                ).matches()) {

            throw new SQLException(
                    "El formato del documento no es valido."
            );
        }

        return normalizado;
    }

    // =========================================================
    // 24. VALIDAR OBSERVACION OPCIONAL
    // =========================================================

    private String validarObservacion(
            String observacion
    ) throws SQLException {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new SQLException(
                    "La observacion contiene caracteres no permitidos."
            );
        }

        String normalizada =
                observacion.trim().replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new SQLException(
                    "La observacion supera los 500 caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 25. VALIDAR JUSTIFICACION OBLIGATORIA DE AJUSTE
    // =========================================================

    private String validarObservacionObligatoria(
            String observacion
    ) throws SQLException {

        String normalizada = validarObservacion(observacion);

        if (normalizada == null
                || normalizada.length() < MIN_OBSERVACION_AJUSTE) {

            throw new SQLException(
                    "El ajuste requiere una justificacion "
                    + "de al menos cinco caracteres."
            );
        }

        return normalizada;
    }

    // =========================================================
    // 26. ASIGNAR TEXTO OPCIONAL
    // =========================================================

    private void asignarTextoOpcional(
            PreparedStatement sentencia,
            int posicion,
            String valor
    ) throws SQLException {

        if (valor == null || valor.isBlank()) {
            sentencia.setNull(posicion, Types.VARCHAR);
        } else {
            sentencia.setString(posicion, valor);
        }
    }

    // =========================================================
    // 27. DETECTAR CARACTERES DE CONTROL
    // =========================================================

    private boolean contieneCaracteresDeControl(
            String texto
    ) {

        for (int i = 0; i < texto.length(); i++) {

            char caracter = texto.charAt(i);

            if (Character.isISOControl(caracter)) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // 28. NORMALIZAR CANTIDAD
    // =========================================================

    private BigDecimal normalizarCantidad(
            BigDecimal valor
    ) {

        return valor.setScale(
                ESCALA_CANTIDAD,
                RoundingMode.UNNECESSARY
        );
    }

    // =========================================================
    // 29. NORMALIZAR COSTO
    // =========================================================

    private BigDecimal normalizarCosto(
            BigDecimal valor
    ) {

        return valor.setScale(
                ESCALA_COSTO,
                RoundingMode.HALF_UP
        );
    }

    // =========================================================
    // 30. CONVERTIR NUMERO DE SQLITE A BIGDECIMAL
    // =========================================================

    private BigDecimal decimal(
            double valor
    ) throws SQLException {

        if (!Double.isFinite(valor)) {
            throw new SQLException(
                    "La base de datos contiene un valor numerico invalido."
            );
        }

        return BigDecimal.valueOf(valor);
    }

    // =========================================================
    // 31. ROLLBACK
    // =========================================================

    /**
     * Revierte toda la transaccion si falla cualquier operacion.
     *
     * Si tambien falla el rollback, se conserva el error original
     * y se agrega el error secundario como excepcion suprimida.
     */
    private void rollback(
            Connection conexion,
            Exception errorOriginal
    ) {

        try {

            if (conexion != null && !conexion.isClosed()) {
                conexion.rollback();
            }

        } catch (SQLException errorRollback) {

            errorOriginal.addSuppressed(errorRollback);
        }
    }

    // =========================================================
    // 32. CLASE INTERNA: INFORMACION DEL PRODUCTO
    // =========================================================

    private static class ProductoInfo {

        private final String unidadMedida;

        private ProductoInfo(String unidadMedida) {
            this.unidadMedida = unidadMedida;
        }
    }

    // =========================================================
    // 33. CLASE INTERNA: INVENTARIO ACTUAL
    // =========================================================

    private static class InventarioActual {

        private final BigDecimal cantidad;

        private final BigDecimal costoPromedio;

        private final boolean existe;

        private InventarioActual(
                BigDecimal cantidad,
                BigDecimal costoPromedio,
                boolean existe
        ) {

            this.cantidad = cantidad;
            this.costoPromedio = costoPromedio;
            this.existe = existe;
        }
    }
}

