
package pe.edu.inventario.servicio;

import pe.edu.inventario.modelo.dao.MovimientoDAO;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Locale;
import java.util.regex.Pattern;

public class MovimientoService {

    private final MovimientoDAO movimientoDAO;

    // ==========================================
    // CONSTANTS
    // ==========================================

    private static final BigDecimal CANTIDAD_MAXIMA =
            new BigDecimal("1000000000");

    private static final BigDecimal COSTO_MAXIMO =
            new BigDecimal("1000000000");

    private static final int MAX_DECIMALES_CANTIDAD = 3;
    private static final int MAX_DECIMALES_COSTO = 6;

    private static final int MAX_DOCUMENTO = 50;
    private static final int MAX_OBSERVACION = 500;

    private static final Pattern DOCUMENTO_PATTERN =
            Pattern.compile(
                    "^[A-Z0-9][A-Z0-9._/-]{0,49}$"
            );

    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public MovimientoService() {
        this.movimientoDAO = new MovimientoDAO();
    }

    // Dependency injection
    public MovimientoService(MovimientoDAO movimientoDAO) {

        if (movimientoDAO == null) {
            throw new IllegalArgumentException(
                    "El DAO de movimientos es obligatorio."
            );
        }

        this.movimientoDAO = movimientoDAO;
    }

    // ==========================================
    // REGISTER ENTRY
    // ==========================================

    public boolean registrarEntrada(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        validarCantidad(cantidad, false);

        validarCosto(costoUnitario);

        String documentoValido =
                validarDocumento(documento);

        String observacionValida =
                validarObservacion(observacion);

        return movimientoDAO.registrarEntrada(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidad,
                costoUnitario,
                observacionValida
        );
    }

    // ==========================================
    // REGISTER EXIT
    // ==========================================

    public boolean registrarSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        validarCantidad(cantidad, false);

        String documentoValido =
                validarDocumento(documento);

        String observacionValida =
                validarObservacion(observacion);

        return movimientoDAO.registrarSalida(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidad,
                observacionValida
        );
    }

    // ==========================================
    // REGISTER PHYSICAL INVENTORY ADJUSTMENT
    // ==========================================

    public boolean registrarAjuste(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidadFisica,
            String observacion
    ) throws SQLException {

        validarIdentificadores(idProducto, idAlmacen);

        // A physical count may be zero.
        validarCantidad(cantidadFisica, true);

        String documentoValido =
                validarDocumento(documento);

        String observacionValida =
                validarObservacion(observacion);

        return movimientoDAO.registrarAjuste(
                idProducto,
                idAlmacen,
                documentoValido,
                cantidadFisica,
                observacionValida
        );
    }

    // ==========================================
    // VALIDATE IDENTIFIERS
    // ==========================================

    private void validarIdentificadores(
            int idProducto,
            int idAlmacen
    ) {

        if (idProducto <= 0) {
            throw new IllegalArgumentException(
                    "El ID del producto debe ser positivo."
            );
        }

        if (idAlmacen <= 0) {
            throw new IllegalArgumentException(
                    "El ID del almacen debe ser positivo."
            );
        }
    }

    // ==========================================
    // VALIDATE QUANTITY
    // ==========================================

    private BigDecimal validarCantidad(
            double cantidad,
            boolean permitirCero
    ) {

        if (!Double.isFinite(cantidad)) {
            throw new IllegalArgumentException(
                    "La cantidad debe ser un numero finito."
            );
        }

        if (cantidad < 0 || (!permitirCero && cantidad == 0)) {
            throw new IllegalArgumentException(
                    permitirCero
                            ? "La cantidad no puede ser negativa."
                            : "La cantidad debe ser mayor que cero."
            );
        }

        BigDecimal valor =
                BigDecimal.valueOf(cantidad)
                        .stripTrailingZeros();

        if (valor.compareTo(CANTIDAD_MAXIMA) > 0) {
            throw new IllegalArgumentException(
                    "La cantidad supera el limite permitido."
            );
        }

        if (valor.scale() > MAX_DECIMALES_CANTIDAD) {
            throw new IllegalArgumentException(
                    "La cantidad admite como maximo 3 decimales."
            );
        }

        return valor;
    }

    // ==========================================
    // VALIDATE UNIT COST
    // ==========================================

    private BigDecimal validarCosto(double costoUnitario) {

        if (!Double.isFinite(costoUnitario)
                || costoUnitario < 0) {

            throw new IllegalArgumentException(
                    "El costo unitario debe ser finito y no negativo."
            );
        }

        BigDecimal costo =
                BigDecimal.valueOf(costoUnitario)
                        .stripTrailingZeros();

        if (costo.compareTo(COSTO_MAXIMO) > 0) {
            throw new IllegalArgumentException(
                    "El costo unitario supera el limite permitido."
            );
        }

        if (costo.scale() > MAX_DECIMALES_COSTO) {
            throw new IllegalArgumentException(
                    "El costo admite como maximo 6 decimales."
            );
        }

        return costo;
    }

    // ==========================================
    // VALIDATE DOCUMENT
    // ==========================================

    private String validarDocumento(String documento) {

        if (documento == null || documento.isBlank()) {
            throw new IllegalArgumentException(
                    "El documento es obligatorio."
            );
        }

        String normalizado =
                documento.trim().toUpperCase(Locale.ROOT);

        if (normalizado.length() > MAX_DOCUMENTO
                || !DOCUMENTO_PATTERN.matcher(
                        normalizado
                ).matches()) {

            throw new IllegalArgumentException(
                    "El formato del documento no es valido."
            );
        }

        return normalizado;
    }

    // ==========================================
    // VALIDATE OBSERVATION
    // ==========================================

    private String validarObservacion(String observacion) {

        if (observacion == null || observacion.isBlank()) {
            return null;
        }

        if (contieneCaracteresDeControl(observacion)) {
            throw new IllegalArgumentException(
                    "La observacion contiene caracteres no permitidos."
            );
        }

        String normalizada =
                observacion.trim().replaceAll("\\s+", " ");

        if (normalizada.length() > MAX_OBSERVACION) {
            throw new IllegalArgumentException(
                    "La observacion no puede superar 500 caracteres."
            );
        }

        return normalizada;
    }

    // ==========================================
    // CHECK CONTROL CHARACTERS
    // ==========================================

    private boolean contieneCaracteresDeControl(
            String texto
    ) {

        for (int i = 0; i < texto.length(); i++) {

            if (Character.isISOControl(texto.charAt(i))) {
                return true;
            }
        }

        return false;
    }
}
