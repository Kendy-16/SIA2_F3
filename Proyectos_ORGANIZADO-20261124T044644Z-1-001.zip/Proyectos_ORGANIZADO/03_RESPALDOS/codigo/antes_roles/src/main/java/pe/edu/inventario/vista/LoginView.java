
package pe.edu.inventario.vista;

import pe.edu.inventario.controlador.LoginController;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;

/**
 * Vista de autenticacion del sistema de inventario.
 *
 * Captura las credenciales, valida los datos y
 * delega la autenticacion al LoginController.
 */
public class LoginView extends JFrame {

    // ==========================================
    // 1. CONSTANTES
    // ==========================================

    private static final int MIN_USUARIO = 3;
    private static final int MAX_USUARIO = 50;
    private static final int MAX_PASSWORD = 128;

    private static final Color AZUL_PRINCIPAL =
            new Color(31, 78, 121);

    private static final Color VERDE =
            new Color(40, 167, 69);

    private static final Color GRIS =
            new Color(108, 117, 125);

    private static final char CARACTER_OCULTACION = '*';

    // ==========================================
    // 2. ATRIBUTOS
    // ==========================================

    private JTextField txtUsuario;
    private JPasswordField txtPassword;

    private JButton btnIngresar;
    private JButton btnCancelar;

    private JCheckBox chkMostrarPassword;

    private JLabel lblEstado;

    private final LoginController controlador;

    private boolean autenticacionEnCurso = false;

    // ==========================================
    // 3. CONSTRUCTOR
    // ==========================================

    public LoginView() {

        this(new LoginController());
    }

    public LoginView(LoginController controlador) {

        if (controlador == null) {
            throw new IllegalArgumentException(
                    "El controlador de login es obligatorio."
            );
        }

        this.controlador = controlador;

        configurarVentana();
        inicializarComponentes();
    }

    // ==========================================
    // 4. CONFIGURAR VENTANA
    // ==========================================

    private void configurarVentana() {

        setTitle("Acceso al Sistema - Inventario T1");

        setDefaultCloseOperation(
                JFrame.DO_NOTHING_ON_CLOSE
        );

        setResizable(false);

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                confirmarSalida();
            }
        });
    }

    // ==========================================
    // 5. INICIALIZAR COMPONENTES
    // ==========================================

    private void inicializarComponentes() {

        JPanel panelPrincipal =
                new JPanel(new BorderLayout());

        panelPrincipal.setBackground(Color.WHITE);

        // --------------------------------------
        // 5.1. ENCABEZADO
        // --------------------------------------

        JPanel panelNorte =
                new JPanel(new BorderLayout());

        panelNorte.setBackground(AZUL_PRINCIPAL);

        panelNorte.setBorder(
                BorderFactory.createEmptyBorder(
                        22, 15, 22, 15
                )
        );

        JLabel lblTitulo = new JLabel(
                "CONTROL DE INVENTARIO",
                SwingConstants.CENTER
        );

        lblTitulo.setFont(
                new Font("Arial", Font.BOLD, 21)
        );

        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSubtitulo = new JLabel(
                "INVENTARIO FISICO Y VALORADO",
                SwingConstants.CENTER
        );

        lblSubtitulo.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        lblSubtitulo.setForeground(Color.WHITE);

        JPanel panelTitulos =
                new JPanel(new GridLayout(2, 1, 0, 7));

        panelTitulos.setOpaque(false);

        panelTitulos.add(lblTitulo);
        panelTitulos.add(lblSubtitulo);

        panelNorte.add(
                panelTitulos,
                BorderLayout.CENTER
        );

        // --------------------------------------
        // 5.2. FORMULARIO
        // --------------------------------------

        JPanel panelCentro =
                new JPanel(new GridBagLayout());

        panelCentro.setBackground(Color.WHITE);

        panelCentro.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 30, 15, 30
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.anchor = GridBagConstraints.WEST;

        // Titulo del formulario

        JLabel lblAcceso = new JLabel("Iniciar sesion");

        lblAcceso.setFont(
                new Font("Arial", Font.BOLD, 19)
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        panelCentro.add(lblAcceso, gbc);

        // --------------------------------------
        // CAMPO USUARIO
        // --------------------------------------

        JLabel lblUsuario = new JLabel("Usuario:");

        txtUsuario = new JTextField(20);

        txtUsuario.setToolTipText(
                "Ingrese su nombre de usuario."
        );

        lblUsuario.setLabelFor(txtUsuario);

        limitarLongitud(
                txtUsuario,
                MAX_USUARIO
        );

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0;

        panelCentro.add(lblUsuario, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;

        panelCentro.add(txtUsuario, gbc);

        // --------------------------------------
        // CAMPO PASSWORD
        // --------------------------------------

        JLabel lblPassword = new JLabel("Contrasena:");

        txtPassword = new JPasswordField(20);

        txtPassword.setEchoChar(CARACTER_OCULTACION);

        txtPassword.setToolTipText(
                "Ingrese su contrasena."
        );

        lblPassword.setLabelFor(txtPassword);

        limitarLongitud(
                txtPassword,
                MAX_PASSWORD
        );

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;

        panelCentro.add(lblPassword, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;

        panelCentro.add(txtPassword, gbc);

        // --------------------------------------
        // MOSTRAR PASSWORD
        // --------------------------------------

        chkMostrarPassword =
                new JCheckBox("Mostrar contrasena");

        chkMostrarPassword.setBackground(Color.WHITE);

        chkMostrarPassword.addActionListener(e -> {

            if (chkMostrarPassword.isSelected()) {

                txtPassword.setEchoChar((char) 0);

            } else {

                txtPassword.setEchoChar(
                        CARACTER_OCULTACION
                );
            }
        });

        gbc.gridx = 1;
        gbc.gridy = 3;

        panelCentro.add(chkMostrarPassword, gbc);

        // --------------------------------------
        // MENSAJE DE ESTADO
        // --------------------------------------

        lblEstado = new JLabel(
                "Ingrese sus credenciales para continuar."
        );

        lblEstado.setForeground(GRIS);

        lblEstado.setFont(
                new Font("Arial", Font.PLAIN, 11)
        );

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;

        panelCentro.add(lblEstado, gbc);

        // --------------------------------------
        // 5.3. BOTONES
        // --------------------------------------

        JPanel panelSur = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 15, 15)
        );

        panelSur.setBackground(Color.WHITE);

        btnIngresar = new JButton("Ingresar");

        btnCancelar = new JButton("Cancelar");

        btnIngresar.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        btnCancelar.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        btnIngresar.setBackground(VERDE);
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setFocusPainted(false);

        btnCancelar.setBackground(
                new Color(230, 230, 230)
        );

        btnIngresar.setPreferredSize(
                new Dimension(120, 35)
        );

        btnCancelar.setPreferredSize(
                new Dimension(120, 35)
        );

        panelSur.add(btnCancelar);
        panelSur.add(btnIngresar);

        // --------------------------------------
        // 5.4. AGREGAR PANELES
        // --------------------------------------

        panelPrincipal.add(
                panelNorte,
                BorderLayout.NORTH
        );

        panelPrincipal.add(
                panelCentro,
                BorderLayout.CENTER
        );

        panelPrincipal.add(
                panelSur,
                BorderLayout.SOUTH
        );

        setContentPane(panelPrincipal);

        pack();

        setMinimumSize(
                new Dimension(440, 350)
        );

        setLocationRelativeTo(null);

        // --------------------------------------
        // 5.5. REGISTRAR EVENTOS
        // --------------------------------------

        btnIngresar.addActionListener(
                e -> intentarLogin()
        );

        btnCancelar.addActionListener(
                e -> confirmarSalida()
        );

        txtUsuario.addActionListener(e ->
                txtPassword.requestFocusInWindow()
        );

        txtPassword.addActionListener(e ->
                intentarLogin()
        );

        getRootPane().setDefaultButton(btnIngresar);
    }

    // ==========================================
    // 6. VALIDAR USUARIO
    // ==========================================

    private String validarUsuario() {

        String usuario = txtUsuario.getText();

        if (usuario == null || usuario.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Debe ingresar el nombre de usuario."
            );
        }

        usuario = usuario.trim();

        int longitud = usuario.codePointCount(
                0,
                usuario.length()
        );

        if (longitud < MIN_USUARIO
                || longitud > MAX_USUARIO) {

            throw new IllegalArgumentException(
                    "El usuario debe tener entre 3 y 50 caracteres."
            );
        }

        if (usuario.codePoints().anyMatch(
                caracter -> Character.isWhitespace(caracter)
                        || Character.isISOControl(caracter)
        )) {

            throw new IllegalArgumentException(
                    "El usuario no puede contener espacios internos."
            );
        }

        if (!usuario.matches(
                "[\\p{L}\\p{N}._@-]+"
        )) {

            throw new IllegalArgumentException(
                    "El usuario contiene caracteres no permitidos."
            );
        }

        return usuario;
    }

    // ==========================================
    // 7. VALIDAR PASSWORD
    // ==========================================

    private char[] validarPassword() {

        char[] password = txtPassword.getPassword();

        if (password == null || password.length == 0) {

            throw new IllegalArgumentException(
                    "Debe ingresar su contrasena."
            );
        }

        if (password.length > MAX_PASSWORD) {

            Arrays.fill(password, '\0');

            throw new IllegalArgumentException(
                    "La contrasena no puede superar 128 caracteres."
            );
        }

        // No aplicar trim a la contrasena.
        // Los espacios pueden formar parte de ella.

        return password;
    }

    // ==========================================
    // 8. INTENTAR INICIAR SESION
    // ==========================================

    private void intentarLogin() {

        if (autenticacionEnCurso) {
            return;
        }

        // Validar usuario
        final String usuario;

        try {

            usuario = validarUsuario();

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(e.getMessage());

            txtUsuario.requestFocusInWindow();

            return;
        }

        // Validar password
        char[] passwordCaracteres;

        try {

            passwordCaracteres = validarPassword();

        } catch (IllegalArgumentException e) {

            mostrarAdvertencia(e.getMessage());

            txtPassword.requestFocusInWindow();

            return;
        }

        // Mantener compatibilidad con el controlador
        // que recibe String.
        final String passwordTexto =
                new String(passwordCaracteres);

        Arrays.fill(passwordCaracteres, '\0');

        // --------------------------------------
        // DESHABILITAR CONTROLES
        // --------------------------------------

        autenticacionEnCurso = true;

        btnIngresar.setEnabled(false);
        btnCancelar.setEnabled(false);

        txtUsuario.setEnabled(false);
        txtPassword.setEnabled(false);

        chkMostrarPassword.setEnabled(false);

        lblEstado.setText(
                "Verificando credenciales..."
        );

        // --------------------------------------
        // AUTENTICACION EN SEGUNDO PLANO
        // --------------------------------------

        SwingWorker<Boolean, Void> tarea =
                new SwingWorker<>() {

            @Override
            protected Boolean doInBackground() {

                return controlador.verificarCredenciales(
                        usuario,
                        passwordTexto
                );
            }

            @Override
            protected void done() {

                try {

                    boolean autenticado = get();

                    if (autenticado) {

                        JOptionPane.showMessageDialog(
                                LoginView.this,
                                "Bienvenido al sistema, "
                                        + usuario + ".",
                                "Acceso concedido",
                                JOptionPane.INFORMATION_MESSAGE
                        );

                        abrirMenuPrincipal();

                    } else {

                        JOptionPane.showMessageDialog(
                                LoginView.this,
                                "Usuario o contrasena incorrectos.",
                                "Error de autenticacion",
                                JOptionPane.ERROR_MESSAGE
                        );

                        txtPassword.setText("");

                        chkMostrarPassword.setSelected(false);

                        txtPassword.setEchoChar(
                                CARACTER_OCULTACION
                        );

                        lblEstado.setText(
                                "Verifique sus credenciales e intentelo nuevamente."
                        );
                    }

                } catch (InterruptedException e) {

                    Thread.currentThread().interrupt();

                    mostrarError(
                            "La autenticacion fue interrumpida."
                    );

                } catch (ExecutionException e) {

                    // No mostrar detalles internos al usuario.
                    Throwable causa = e.getCause();

                    System.err.println(
                            "Error de autenticacion: "
                                    + (causa == null
                                    ? e.getMessage()
                                    : causa.getMessage())
                    );

                    mostrarError(
                            "No fue posible verificar las credenciales. "
                                    + "Compruebe la conexion con la base de datos."
                    );

                    txtPassword.setText("");

                } finally {

                    autenticacionEnCurso = false;

                    if (isDisplayable()) {

                        btnIngresar.setEnabled(true);
                        btnCancelar.setEnabled(true);

                        txtUsuario.setEnabled(true);
                        txtPassword.setEnabled(true);

                        chkMostrarPassword.setEnabled(true);
                    }
                }
            }
        };

        tarea.execute();
    }

    // ==========================================
    // 9. ABRIR MENU PRINCIPAL
    // ==========================================

    private void abrirMenuPrincipal() {

        MenuPrincipalView menu =
                new MenuPrincipalView();

        menu.setVisible(true);

        dispose();
    }

    // ==========================================
    // 10. LIMITAR LONGITUD DE CAMPOS
    // ==========================================

    private void limitarLongitud(
            JTextField campo,
            int longitudMaxima
    ) {

        AbstractDocument documento =
                (AbstractDocument) campo.getDocument();

        documento.setDocumentFilter(
                new DocumentFilter() {

            @Override
            public void insertString(
                    FilterBypass fb,
                    int offset,
                    String texto,
                    AttributeSet atributos
            ) throws BadLocationException {

                if (texto == null) {
                    return;
                }

                replace(
                        fb,
                        offset,
                        0,
                        texto,
                        atributos
                );
            }

            @Override
            public void replace(
                    FilterBypass fb,
                    int offset,
                    int longitud,
                    String texto,
                    AttributeSet atributos
            ) throws BadLocationException {

                if (texto == null) {
                    texto = "";
                }

                int nuevaLongitud =
                        fb.getDocument().getLength()
                        - longitud
                        + texto.length();

                if (nuevaLongitud <= longitudMaxima) {

                    fb.replace(
                            offset,
                            longitud,
                            texto,
                            atributos
                    );

                } else {

                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    // ==========================================
    // 11. CONFIRMAR SALIDA
    // ==========================================

    private void confirmarSalida() {

        if (autenticacionEnCurso) {

            JOptionPane.showMessageDialog(
                    this,
                    "Espere a que termine la verificacion.",
                    "Autenticacion en curso",
                    JOptionPane.INFORMATION_MESSAGE
            );

            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "Desea salir del sistema?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta == JOptionPane.YES_OPTION) {

            dispose();

            System.exit(0);
        }
    }

    // ==========================================
    // 12. MOSTRAR ADVERTENCIAS
    // ==========================================

    private void mostrarAdvertencia(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Validacion de datos",
                JOptionPane.WARNING_MESSAGE
        );
    }

    // ==========================================
    // 13. MOSTRAR ERRORES
    // ==========================================

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

