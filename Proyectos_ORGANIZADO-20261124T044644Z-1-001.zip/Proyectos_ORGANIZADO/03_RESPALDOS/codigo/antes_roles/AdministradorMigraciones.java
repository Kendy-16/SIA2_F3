package pe.edu.inventario.migracion;

import pe.edu.inventario.modelo.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Ejecuta las migraciones de la base SQLite en orden y dentro
 * de una única transacción. Las migraciones son idempotentes.
 */
public final class AdministradorMigraciones {

    private AdministradorMigraciones() {
    }

    public static void ejecutar() {
        try (Connection conexion = ConexionDB.conectar()) {
            boolean autoCommitAnterior = conexion.getAutoCommit();
            conexion.setAutoCommit(false);

            try {
                crearTablaVersiones(conexion);

                if (!estaAplicada(conexion, "V001")) {
                    migracionV001(conexion);
                    registrar(conexion, "V001", "Inventario físico");
                }

                if (!estaAplicada(conexion, "V002")) {
                    migracionV002(conexion);
                    registrar(conexion, "V002", "Control de estado de catálogos");
                }

                if (!estaAplicada(conexion, "V003")) {
                    migracionV003(conexion);
                    registrar(conexion, "V003", "Una toma abierta por almacén");
                }

                if (!estaAplicada(conexion, "V004")) {
                    MigracionV004ImagenesProductos.ejecutar(conexion);
                    registrar(conexion, "V004", "Imágenes de productos y caché Pixabay");
                }

                verificarIntegridad(conexion);
                conexion.commit();

                System.out.println("Migraciones V001–V004 aplicadas o verificadas correctamente.");
            } catch (SQLException | RuntimeException ex) {
                conexion.rollback();
                throw ex;
            } finally {
                conexion.setAutoCommit(autoCommitAnterior);
            }
        } catch (SQLException ex) {
            throw new IllegalStateException(
                    "No se pudieron aplicar las migraciones de SQLite. "
                    + "No se confirmó ningún cambio de esta ejecución: "
                    + ex.getMessage(), ex
            );
        }
    }

    private static void crearTablaVersiones(Connection conexion) throws SQLException {
        try (Statement st = conexion.createStatement()) {
            st.execute("""
                    CREATE TABLE IF NOT EXISTS schema_migrations (
                        version TEXT PRIMARY KEY,
                        descripcion TEXT NOT NULL,
                        aplicada_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                    )
                    """);
        }
    }

    private static boolean estaAplicada(Connection conexion, String version)
            throws SQLException {
        try (PreparedStatement ps = conexion.prepareStatement(
                "SELECT 1 FROM schema_migrations WHERE version = ?")) {
            ps.setString(1, version);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static void registrar(
            Connection conexion, String version, String descripcion
    ) throws SQLException {
        try (PreparedStatement ps = conexion.prepareStatement("""
                INSERT INTO schema_migrations(version, descripcion)
                VALUES (?, ?)
                """)) {
            ps.setString(1, version);
            ps.setString(2, descripcion);
            ps.executeUpdate();
        }
    }

    private static void migracionV001(Connection conexion) throws SQLException {
        exigirTabla(conexion, "almacenes");
        exigirTabla(conexion, "productos");

        try (Statement st = conexion.createStatement()) {
            st.execute("""
                    CREATE TABLE IF NOT EXISTS tomas_inventario_fisico (
                        id_toma INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_almacen INTEGER NOT NULL,
                        fecha TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                        modo TEXT NOT NULL CHECK (modo IN ('GENERAL','PARCIAL','CICLICO')),
                        estado TEXT NOT NULL DEFAULT 'ABIERTO'
                            CHECK (estado IN ('ABIERTO','PROCESADO','ANULADO')),
                        observacion TEXT,
                        creado_en TEXT NOT NULL DEFAULT (datetime('now','localtime')),
                        procesado_en TEXT,
                        FOREIGN KEY (id_almacen) REFERENCES almacenes(id_almacen)
                    )
                    """);
            st.execute("""
                    CREATE TABLE IF NOT EXISTS detalle_toma_inventario (
                        id_detalle INTEGER PRIMARY KEY AUTOINCREMENT,
                        id_toma INTEGER NOT NULL,
                        id_producto INTEGER NOT NULL,
                        stock_sistema REAL NOT NULL DEFAULT 0 CHECK (stock_sistema >= 0),
                        cantidad_fisica REAL CHECK (
                            cantidad_fisica IS NULL OR cantidad_fisica >= 0
                        ),
                        diferencia REAL,
                        costo_promedio REAL NOT NULL DEFAULT 0 CHECK (costo_promedio >= 0),
                        impacto_valorizado REAL,
                        observacion TEXT,
                        FOREIGN KEY (id_toma)
                            REFERENCES tomas_inventario_fisico(id_toma),
                        FOREIGN KEY (id_producto)
                            REFERENCES productos(id_producto),
                        UNIQUE (id_toma, id_producto)
                    )
                    """);
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_toma_almacen_fecha
                    ON tomas_inventario_fisico(id_almacen, fecha)
                    """);
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_detalle_toma
                    ON detalle_toma_inventario(id_toma)
                    """);
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_detalle_producto
                    ON detalle_toma_inventario(id_producto)
                    """);
        }
    }

    private static void migracionV002(Connection conexion) throws SQLException {
        exigirTabla(conexion, "productos");
        exigirTabla(conexion, "almacenes");

        agregarColumnaActivoSiFalta(conexion, "productos");
        agregarColumnaActivoSiFalta(conexion, "almacenes");

        try (Statement st = conexion.createStatement()) {
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_productos_activo
                    ON productos(activo)
                    """);
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_almacenes_activo
                    ON almacenes(activo)
                    """);
        }
    }

    private static void agregarColumnaActivoSiFalta(
            Connection conexion, String tabla
    ) throws SQLException {
        boolean existe = false;
        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA table_info(" + tabla + ")")) {
            while (rs.next()) {
                if ("activo".equalsIgnoreCase(rs.getString("name"))) {
                    existe = true;
                    break;
                }
            }
        }

        if (!existe) {
            try (Statement st = conexion.createStatement()) {
                st.execute("ALTER TABLE " + tabla
                        + " ADD COLUMN activo INTEGER NOT NULL DEFAULT 1 "
                        + "CHECK (activo IN (0, 1))");
            }
        }
    }

    private static void migracionV003(Connection conexion) throws SQLException {
        exigirTabla(conexion, "tomas_inventario_fisico");

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery("""
                     SELECT id_almacen, COUNT(*) AS cantidad
                     FROM tomas_inventario_fisico
                     WHERE estado = 'ABIERTO'
                     GROUP BY id_almacen
                     HAVING COUNT(*) > 1
                     """)) {
            if (rs.next()) {
                throw new SQLException(
                        "No se puede aplicar V003: el almacén "
                        + rs.getLong("id_almacen") + " tiene "
                        + rs.getInt("cantidad")
                        + " tomas abiertas. Resuelva esos duplicados "
                        + "conservando el historial y vuelva a iniciar."
                );
            }
        }

        try (Statement st = conexion.createStatement()) {
            st.execute("""
                    CREATE UNIQUE INDEX IF NOT EXISTS
                    idx_toma_abierta_unica_por_almacen
                    ON tomas_inventario_fisico(id_almacen)
                    WHERE estado = 'ABIERTO'
                    """);
            st.execute("""
                    CREATE INDEX IF NOT EXISTS idx_tomas_estado_fecha
                    ON tomas_inventario_fisico(estado, fecha)
                    """);
        }
    }

    private static void exigirTabla(Connection conexion, String tabla)
            throws SQLException {
        try (PreparedStatement ps = conexion.prepareStatement(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?")) {
            ps.setString(1, tabla);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new SQLException(
                            "Falta la tabla requerida '" + tabla
                            + "'. Inicialice primero el esquema base."
                    );
                }
            }
        }
    }

    private static void verificarIntegridad(Connection conexion)
            throws SQLException {
        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery("PRAGMA foreign_key_check")) {
            if (rs.next()) {
                throw new SQLException(
                        "La base presenta una inconsistencia de claves foráneas."
                );
            }
        }
    }
}
