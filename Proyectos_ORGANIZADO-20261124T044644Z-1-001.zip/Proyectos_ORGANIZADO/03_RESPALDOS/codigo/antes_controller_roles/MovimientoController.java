

package pe.edu.inventario.controlador;

import pe.edu.inventario.servicio.MovimientoService;

import java.sql.SQLException;
import java.util.Locale;

/**
 * Controlador encargado de gestionar las operaciones
 * del módulo de movimientos de inventario.
 *
 * Permisos:
 *
 * ADMINISTRADOR:
 * - Registrar entradas.
 * - Registrar salidas.
 * - Registrar ajustes físicos.
 *
 * USUARIO:
 * - No puede registrar ni modificar movimientos.
 *
 * Las validaciones de cantidades, documentos, costos,
 * existencias y transacciones se mantienen en
 * MovimientoService y MovimientoDAO.
 */
public class MovimientoController {

    // =========================================================
    // 1. CONSTANTES
    // =========================================================

    private static final String ROL_ADMINISTRADOR = "ADMINISTRADOR";
    private static final String ROL_USUARIO = "USUARIO";

    // =========================================================
    // 2. ATRIBUTOS
    // =========================================================

    private final MovimientoService movimientoService;

    private final String rolActual;

    // =========================================================
    // 3. CONSTRUCTORES
    // =========================================================

    /**
     * Constructor seguro por defecto.
     *
     * Si no se proporciona un rol, se asigna USUARIO.
     * No se conceden permisos administrativos por defecto.
     */
    public MovimientoController() {
        this(new MovimientoService(), ROL_USUARIO);
    }

    /**
     * Constructor con inyección del servicio.
     *
     * Sin un rol explícito, se asigna USUARIO.
     */
    public MovimientoController(
            MovimientoService movimientoService
    ) {
        this(movimientoService, ROL_USUARIO);
    }

    /**
     * Constructor con rol.
     */
    public MovimientoController(String rol) {
        this(new MovimientoService(), rol);
    }

    /**
     * Constructor con inyección del servicio y rol.
     *
     * El rol debe proceder de la sesión autenticada.
     */
    public MovimientoController(
            MovimientoService movimientoService,
            String rol
    ) {

        if (movimientoService == null) {
            throw new IllegalArgumentException(
                    "El servicio de movimientos es obligatorio."
            );
        }

        this.movimientoService = movimientoService;
        this.rolActual = normalizarRol(rol);
    }

    // =========================================================
    // 4. NORMALIZAR Y VALIDAR ROL
    // =========================================================

    private static String normalizarRol(String rol) {

        if (rol == null || rol.isBlank()) {
            throw new IllegalArgumentException(
                    "No se recibió un rol válido para el controlador."
            );
        }

        String rolNormalizado =
                rol.trim().toUpperCase(Locale.ROOT);

        switch (rolNormalizado) {

            case "ADMIN":
            case "ADMINISTRADOR":
                return ROL_ADMINISTRADOR;

            case "USER":
            case "USUARIO":
                return ROL_USUARIO;

            default:
                throw new IllegalArgumentException(
                        "Rol no reconocido: " + rol
                );
        }
    }

    // =========================================================
    // 5. CONSULTAR PERMISOS
    // =========================================================

    public String getRolActual() {
        return rolActual;
    }

    public boolean esAdministrador() {
        return ROL_ADMINISTRADOR.equals(rolActual);
    }

    /**
     * Verifica si el usuario tiene autorización
     * para modificar el inventario.
     */
    private void verificarPermisoAdministrador() {

        if (!esAdministrador()) {
            throw new SecurityException(
                    "Acceso denegado. Solo el administrador "
                    + "puede registrar movimientos de inventario."
            );
        }
    }

    // =========================================================
    // 6. REGISTRAR MOVIMIENTO DE ENTRADA
    // =========================================================

    /**
     * Registra una entrada de productos.
     *
     * Operación exclusiva del administrador.
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacén
     * @param documento documento de referencia
     * @param cantidad cantidad ingresada
     * @param costoUnitario costo unitario de compra
     * @param observacion observación opcional
     * @return true si se registró correctamente
     * @throws SQLException si ocurre un error de base de datos
     * @throws SecurityException si el usuario no tiene permiso
     */
    public boolean registrarMovimientoEntrada(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            double costoUnitario,
            String observacion
    ) throws SQLException {

        verificarPermisoAdministrador();

        return movimientoService.registrarEntrada(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                costoUnitario,
                observacion
        );
    }

    // =========================================================
    // 7. REGISTRAR MOVIMIENTO DE SALIDA
    // =========================================================

    /**
     * Registra una salida de productos.
     *
     * Operación exclusiva del administrador.
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacén
     * @param documento documento de referencia
     * @param cantidad cantidad retirada
     * @param observacion observación opcional
     * @return true si se registró correctamente
     * @throws SQLException si ocurre un error de base de datos
     * @throws SecurityException si el usuario no tiene permiso
     */
    public boolean registrarMovimientoSalida(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidad,
            String observacion
    ) throws SQLException {

        verificarPermisoAdministrador();

        return movimientoService.registrarSalida(
                idProducto,
                idAlmacen,
                documento,
                cantidad,
                observacion
        );
    }

    // =========================================================
    // 8. REGISTRAR AJUSTE FÍSICO
    // =========================================================

    /**
     * Registra un ajuste según la cantidad física contada.
     *
     * Operación exclusiva del administrador.
     *
     * @param idProducto identificador del producto
     * @param idAlmacen identificador del almacén
     * @param documento documento de referencia
     * @param cantidadFisica cantidad física encontrada
     * @param observacion justificación del ajuste
     * @return true si se registró correctamente
     * @throws SQLException si ocurre un error de base de datos
     * @throws SecurityException si el usuario no tiene permiso
     */
    public boolean registrarMovimientoAjuste(
            int idProducto,
            int idAlmacen,
            String documento,
            double cantidadFisica,
            String observacion
    ) throws SQLException {

        verificarPermisoAdministrador();

        return movimientoService.registrarAjuste(
                idProducto,
                idAlmacen,
                documento,
                cantidadFisica,
                observacion
        );
    }

    // =========================================================
    // 9. CALCULAR COSTO PROMEDIO PONDERADO
    // =========================================================

    /**
     * Calcula el nuevo costo promedio ponderado móvil.
     *
     * Fórmula:
     *
     * ((stock actual * costo actual)
     * + (cantidad entrada * costo entrada))
     * / (stock actual + cantidad entrada)
     *
     * Este método realiza el cálculo, pero no modifica
     * directamente la base de datos.
     */
    public double calcularCostoPromedio(
            double stockActual,
            double costoActual,
            double cantidadEntrada,
            double costoEntrada
    ) {

        // -----------------------------------------------------
        // Validar números finitos
        // -----------------------------------------------------

        if (!Double.isFinite(stockActual)
                || !Double.isFinite(costoActual)
                || !Double.isFinite(cantidadEntrada)
                || !Double.isFinite(costoEntrada)) {

            throw new IllegalArgumentException(
                    "Los valores deben ser números finitos."
            );
        }

        // -----------------------------------------------------
        // Validar valores no negativos
        // -----------------------------------------------------

        if (stockActual < 0
                || costoActual < 0
                || cantidadEntrada <= 0
                || costoEntrada < 0) {

            throw new IllegalArgumentException(
                    "Las cantidades y los costos ingresados "
                    + "no son válidos."
            );
        }

        // -----------------------------------------------------
        // Calcular nuevo stock
        // -----------------------------------------------------

        double nuevoStock =
                stockActual + cantidadEntrada;

        if (!Double.isFinite(nuevoStock)
                || nuevoStock <= 0) {

            throw new IllegalArgumentException(
                    "El nuevo stock calculado no es válido."
            );
        }

        // -----------------------------------------------------
        // Calcular valor total
        // -----------------------------------------------------

        double valorActual =
                stockActual * costoActual;

        double valorEntrada =
                cantidadEntrada * costoEntrada;

        double valorTotal =
                valorActual + valorEntrada;

        if (!Double.isFinite(valorTotal)) {

            throw new IllegalArgumentException(
                    "El valor total calculado supera el límite permitido."
            );
        }

        // -----------------------------------------------------
        // Calcular costo promedio
        // -----------------------------------------------------

        double nuevoCostoPromedio =
                valorTotal / nuevoStock;

        if (!Double.isFinite(nuevoCostoPromedio)
                || nuevoCostoPromedio < 0) {

            throw new IllegalArgumentException(
                    "El costo promedio calculado no es válido."
            );
        }

        return nuevoCostoPromedio;
    }
}
