package pe.edu.inventario.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

import pe.edu.inventario.vista.producto.ProductoView;
import pe.edu.inventario.vista.producto.ProveedorView;
import pe.edu.inventario.vista.almacen.AlmacenView;

public class MenuPrincipalView extends JFrame {

    // ==================================================
    // 1. COLORES DEL SISTEMA
    // ==================================================

    private static final Color COLOR_FONDO =
            new Color(17, 19, 25);

    private static final Color COLOR_SIDEBAR =
            new Color(22, 25, 33);

    private static final Color COLOR_PANEL =
            new Color(29, 33, 43);

    private static final Color COLOR_PANEL_SECUNDARIO =
            new Color(36, 41, 52);

    private static final Color COLOR_BORDE =
            new Color(52, 59, 73);

    private static final Color COLOR_TEXTO =
            new Color(238, 241, 247);

    private static final Color COLOR_TEXTO_SECUNDARIO =
            new Color(153, 163, 181);

    private static final Color COLOR_ACENTO =
            new Color(129, 140, 248);

    private static final Color COLOR_VERDE =
            new Color(34, 197, 94);

    private static final Color COLOR_AMARILLO =
            new Color(245, 158, 11);

    private static final Font FUENTE_NORMAL =
            new Font("Segoe UI", Font.PLAIN, 13);

    private static final Font FUENTE_TITULO =
            new Font("Segoe UI", Font.BOLD, 23);

    private static final Font FUENTE_SUBTITULO =
            new Font("Segoe UI", Font.PLAIN, 13);

    private static final Font FUENTE_SECCION =
            new Font("Segoe UI", Font.BOLD, 15);

    private static final Font FUENTE_INDICADOR =
            new Font("Segoe UI", Font.BOLD, 25);

    // ==================================================
    // 2. ATRIBUTOS
    // ==================================================

    private JPanel panelPrincipal;
    private JPanel panelContenido;
    private JPanel panelSidebar;

    private CardLayout administradorContenido;

    private JLabel etiquetaTitulo;
    private JLabel etiquetaUsuario;

    private JButton botonActivo;

    // ==================================================
    // 3. CONSTRUCTOR
    // ==================================================

    public MenuPrincipalView() {

        configurarVentana();
        inicializarComponentes();
    }

    // ==================================================
    // 4. CONFIGURACIÓN DE VENTANA
    // ==================================================

    private void configurarVentana() {

        setTitle("Sistema de Inventario");

        setSize(1350, 820);

        setMinimumSize(new Dimension(1050, 650));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        setResizable(true);
    }

    // ==================================================
    // 5. INICIALIZACIÓN GENERAL
    // ==================================================

    private void inicializarComponentes() {

        panelPrincipal = new JPanel(new BorderLayout());

        panelPrincipal.setBackground(COLOR_FONDO);

        // Barra lateral.

        panelSidebar = crearSidebar();

        // Área de trabajo.

        JPanel areaTrabajo = new JPanel(new BorderLayout());

        areaTrabajo.setBackground(COLOR_FONDO);

        // Encabezado superior.

        JPanel encabezado = crearEncabezado();

        // Contenido dinámico.

        administradorContenido = new CardLayout();

        panelContenido = new JPanel(administradorContenido);

        panelContenido.setBackground(COLOR_FONDO);

        registrarPaneles();

        // Pie de página.

        JPanel pie = crearPiePagina();

        areaTrabajo.add(encabezado, BorderLayout.NORTH);

        areaTrabajo.add(panelContenido, BorderLayout.CENTER);

        areaTrabajo.add(pie, BorderLayout.SOUTH);

        panelPrincipal.add(panelSidebar, BorderLayout.WEST);

        panelPrincipal.add(areaTrabajo, BorderLayout.CENTER);

        setContentPane(panelPrincipal);

        mostrarPanel("Inicio", null);
    }

    // ==================================================
    // 6. BARRA LATERAL
    // ==================================================

    private JPanel crearSidebar() {

        JPanel sidebar = new JPanel(new BorderLayout());

        sidebar.setPreferredSize(new Dimension(245, 0));

        sidebar.setBackground(COLOR_SIDEBAR);

        sidebar.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 0, 1, COLOR_BORDE
                )
        );

        // ----------------------------------------------
        // LOGOTIPO Y NOMBRE
        // ----------------------------------------------

        JPanel encabezado = new JPanel(new BorderLayout(10, 0));

        encabezado.setBackground(COLOR_SIDEBAR);

        encabezado.setBorder(
                new EmptyBorder(22, 18, 22, 15)
        );

        JPanel icono = new JPanel(new GridBagLayout());

        icono.setPreferredSize(new Dimension(40, 40));

        icono.setBackground(new Color(55, 61, 90));

        icono.setBorder(
                BorderFactory.createLineBorder(
                        new Color(86, 96, 150)
                )
        );

        JLabel iconoTexto = new JLabel("SI");

        iconoTexto.setForeground(COLOR_ACENTO);

        iconoTexto.setFont(
                new Font("Segoe UI", Font.BOLD, 17)
        );

        icono.add(iconoTexto);

        JPanel textos = new JPanel(new GridLayout(2, 1, 0, 3));

        textos.setOpaque(false);

        JLabel nombre = new JLabel("INVENTARIO");

        nombre.setForeground(COLOR_TEXTO);

        nombre.setFont(
                new Font("Segoe UI", Font.BOLD, 15)
        );

        JLabel version = new JLabel("Sistema empresarial");

        version.setForeground(COLOR_TEXTO_SECUNDARIO);

        version.setFont(
                new Font("Segoe UI", Font.PLAIN, 10)
        );

        textos.add(nombre);
        textos.add(version);

        encabezado.add(icono, BorderLayout.WEST);

        encabezado.add(textos, BorderLayout.CENTER);

        // ----------------------------------------------
        // MENÚ DE NAVEGACIÓN
        // ----------------------------------------------

        JPanel menu = new JPanel();

        menu.setLayout(
                new BoxLayout(menu, BoxLayout.Y_AXIS)
        );

        menu.setBackground(COLOR_SIDEBAR);

        menu.setBorder(
                new EmptyBorder(5, 12, 15, 12)
        );

        agregarTituloMenu(menu, "GENERAL");

        agregarBotonMenu(
                menu,
                "Inicio",
                "IN",
                "Inicio"
        );

        agregarTituloMenu(menu, "GESTIÓN");

        agregarBotonMenu(
                menu,
                "Productos",
                "PR",
                "Productos"
        );

        agregarBotonMenu(
                menu,
                "Proveedores",
                "PV",
                "Proveedores"
        );

        agregarBotonMenu(
                menu,
                "Almacenes",
                "AL",
                "Almacenes"
        );

        agregarTituloMenu(menu, "INVENTARIO");

        agregarBotonMenu(
                menu,
                "Movimientos",
                "MV",
                "Movimientos"
        );

        agregarBotonMenu(
                menu,
                "Inventario físico",
                "IF",
                "Inventario físico"
        );

        agregarBotonMenu(
                menu,
                "Costo promedio",
                "CP",
                "Costo promedio"
        );

        agregarBotonMenu(
                menu,
                "Kardex",
                "KD",
                "Kardex"
        );

        agregarTituloMenu(menu, "INFORMACIÓN");

        agregarBotonMenu(
                menu,
                "Reportes",
                "RP",
                "Reportes"
        );

        JScrollPane scroll = new JScrollPane(menu);

        scroll.setBorder(null);

        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );

        scroll.getVerticalScrollBar().setUnitIncrement(15);

        scroll.getViewport().setBackground(COLOR_SIDEBAR);

        // ----------------------------------------------
        // INFORMACIÓN INFERIOR
        // ----------------------------------------------

        JPanel inferior = new JPanel(new BorderLayout());

        inferior.setBackground(COLOR_SIDEBAR);

        inferior.setBorder(
                new EmptyBorder(15, 18, 20, 18)
        );

        inferior.add(
                new JSeparator(),
                BorderLayout.NORTH
        );

        JLabel proyecto = new JLabel(
                "<html><b>Proyecto T1</b><br>"
                + "<span style='color:#99A3B5'>"
                + "Sistema de inventario"
                + "</span></html>"
        );

        proyecto.setForeground(COLOR_TEXTO);

        proyecto.setFont(FUENTE_NORMAL);

        proyecto.setBorder(
                new EmptyBorder(13, 0, 0, 0)
        );

        inferior.add(proyecto, BorderLayout.CENTER);

        sidebar.add(encabezado, BorderLayout.NORTH);

        sidebar.add(scroll, BorderLayout.CENTER);

        sidebar.add(inferior, BorderLayout.SOUTH);

        return sidebar;
    }

    // ==================================================
    // 7. TÍTULOS DEL MENÚ
    // ==================================================

    private void agregarTituloMenu(
            JPanel menu,
            String texto
    ) {

        JLabel titulo = new JLabel(texto);

        titulo.setForeground(COLOR_TEXTO_SECUNDARIO);

        titulo.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        titulo.setBorder(
                new EmptyBorder(17, 10, 8, 5)
        );

        titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        menu.add(titulo);
    }

    // ==================================================
    // 8. BOTONES DE NAVEGACIÓN
    // ==================================================

    private void agregarBotonMenu(
            JPanel menu,
            String texto,
            String abreviatura,
            String identificador
    ) {

        JButton boton = new JButton();

        boton.setLayout(new BorderLayout(10, 0));

        boton.setText(null);

        boton.setFocusPainted(false);

        boton.setBorderPainted(false);

        boton.setContentAreaFilled(false);

        boton.setOpaque(true);

        boton.setBackground(COLOR_SIDEBAR);

        boton.setForeground(COLOR_TEXTO_SECUNDARIO);

        boton.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        boton.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 42)
        );

        boton.setPreferredSize(
                new Dimension(210, 42)
        );

        boton.setAlignmentX(Component.LEFT_ALIGNMENT);

        boton.setBorder(
                new EmptyBorder(5, 10, 5, 10)
        );

        JLabel icono = new JLabel(abreviatura);

        icono.setPreferredSize(new Dimension(27, 25));

        icono.setHorizontalAlignment(SwingConstants.CENTER);

        icono.setForeground(COLOR_TEXTO_SECUNDARIO);

        icono.setFont(
                new Font("Segoe UI", Font.BOLD, 10)
        );

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setForeground(COLOR_TEXTO_SECUNDARIO);

        etiqueta.setFont(FUENTE_NORMAL);

        boton.add(icono, BorderLayout.WEST);

        boton.add(etiqueta, BorderLayout.CENTER);

        boton.addActionListener(e -> {

            mostrarPanel(identificador, boton);

        });

        boton.addMouseListener(
                new java.awt.event.MouseAdapter() {

                    @Override
                    public void mouseEntered(
                            java.awt.event.MouseEvent e
                    ) {

                        if (boton != botonActivo) {

                            boton.setBackground(
                                    COLOR_PANEL_SECUNDARIO
                            );
                        }
                    }

                    @Override
                    public void mouseExited(
                            java.awt.event.MouseEvent e
                    ) {

                        if (boton != botonActivo) {

                            boton.setBackground(COLOR_SIDEBAR);
                        }
                    }
                }
        );

        menu.add(boton);

        menu.add(Box.createVerticalStrut(3));
    }

    // ==================================================
    // 9. CAMBIO DE PANEL
    // ==================================================

    private void mostrarPanel(
            String identificador,
            JButton boton
    ) {

        administradorContenido.show(
                panelContenido,
                identificador
        );

        etiquetaTitulo.setText(identificador);

        if (botonActivo != null) {

            botonActivo.setBackground(COLOR_SIDEBAR);

            botonActivo.setForeground(COLOR_TEXTO_SECUNDARIO);
        }

        if (boton != null) {

            botonActivo = boton;

            botonActivo.setBackground(
                    new Color(43, 48, 70)
            );

            botonActivo.setForeground(COLOR_ACENTO);
        }
    }

    // ==================================================
    // 10. ENCABEZADO SUPERIOR
    // ==================================================

    private JPanel crearEncabezado() {

        JPanel encabezado = new JPanel(new BorderLayout());

        encabezado.setBackground(COLOR_PANEL);

        encabezado.setBorder(
                BorderFactory.createMatteBorder(
                        0, 0, 1, 0, COLOR_BORDE
                )
        );

        encabezado.setPreferredSize(
                new Dimension(0, 75)
        );

        JPanel izquierda = new JPanel();

        izquierda.setLayout(
                new BoxLayout(izquierda, BoxLayout.Y_AXIS)
        );

        izquierda.setOpaque(false);

        izquierda.setBorder(
                new EmptyBorder(13, 25, 12, 10)
        );

        etiquetaTitulo = new JLabel("Inicio");

        etiquetaTitulo.setForeground(COLOR_TEXTO);

        etiquetaTitulo.setFont(FUENTE_TITULO);

        JLabel descripcion = new JLabel(
                "Administración y control de inventario"
        );

        descripcion.setForeground(COLOR_TEXTO_SECUNDARIO);

        descripcion.setFont(FUENTE_SUBTITULO);

        izquierda.add(etiquetaTitulo);

        izquierda.add(Box.createVerticalStrut(3));

        izquierda.add(descripcion);

        // Usuario.

        JPanel derecha = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 15, 17)
        );

        derecha.setOpaque(false);

        JLabel estado = new JLabel("Sistema activo");

        estado.setForeground(COLOR_VERDE);

        estado.setFont(FUENTE_NORMAL);

        etiquetaUsuario = new JLabel("Administrador");

        etiquetaUsuario.setForeground(COLOR_TEXTO);

        etiquetaUsuario.setFont(
                new Font("Segoe UI", Font.BOLD, 12)
        );

        JPanel avatar = new JPanel(new GridBagLayout());

        avatar.setPreferredSize(new Dimension(35, 35));

        avatar.setBackground(new Color(55, 61, 90));

        avatar.setBorder(
                BorderFactory.createLineBorder(
                        new Color(86, 96, 150)
                )
        );

        JLabel inicial = new JLabel("AD");

        inicial.setForeground(COLOR_ACENTO);

        inicial.setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        avatar.add(inicial);

        derecha.add(estado);

        derecha.add(etiquetaUsuario);

        derecha.add(avatar);

        encabezado.add(izquierda, BorderLayout.WEST);

        encabezado.add(derecha, BorderLayout.EAST);

        return encabezado;
    }

    // ==================================================
    // 11. REGISTRO DE PANELES
    // ==================================================

    private void registrarPaneles() {

        panelContenido.add(
                crearPanelInicio(),
                "Inicio"
        );

        panelContenido.add(
                new ProductoView(),
                "Productos"
        );

        panelContenido.add(
                new ProveedorView(),
                "Proveedores"
        );

        panelContenido.add(
                new AlmacenView(),
                "Almacenes"
        );

        panelContenido.add(
                crearPanelModulo("MOVIMIENTOS"),
                "Movimientos"
        );

        panelContenido.add(
                crearPanelModulo("INVENTARIO FÍSICO"),
                "Inventario físico"
        );

        panelContenido.add(
                crearPanelModulo("COSTO PROMEDIO PONDERADO"),
                "Costo promedio"
        );

        panelContenido.add(
                crearPanelModulo("KARDEX VALORIZADO"),
                "Kardex"
        );

        panelContenido.add(
                crearPanelModulo("REPORTES DEL INVENTARIO"),
                "Reportes"
        );
    }

    // ==================================================
    // 12. PANEL DE INICIO
    // ==================================================

    private JPanel crearPanelInicio() {

        JPanel panel = new JPanel(new BorderLayout(20, 20));

        panel.setBackground(COLOR_FONDO);

        panel.setBorder(
                new EmptyBorder(25, 25, 25, 25)
        );

        JPanel contenido = new JPanel();

        contenido.setLayout(
                new BoxLayout(contenido, BoxLayout.Y_AXIS)
        );

        contenido.setBackground(COLOR_FONDO);

        // ----------------------------------------------
        // BIENVENIDA
        // ----------------------------------------------

        JLabel bienvenida = new JLabel(
                "Bienvenido al sistema"
        );

        bienvenida.setForeground(COLOR_TEXTO);

        bienvenida.setFont(
                new Font("Segoe UI", Font.BOLD, 24)
        );

        JLabel descripcion = new JLabel(
                "Resumen general de la gestión de inventario."
        );

        descripcion.setForeground(COLOR_TEXTO_SECUNDARIO);

        descripcion.setFont(FUENTE_NORMAL);

        contenido.add(bienvenida);

        contenido.add(Box.createVerticalStrut(6));

        contenido.add(descripcion);

        contenido.add(Box.createVerticalStrut(25));

        // ----------------------------------------------
        // TARJETAS DE INDICADORES
        // ----------------------------------------------

        JPanel tarjetas = new JPanel(
                new GridLayout(1, 4, 15, 15)
        );

        tarjetas.setOpaque(false);

        tarjetas.add(
                crearTarjeta(
                        "Productos",
                        "Gestión del catálogo",
                        "PR",
                        COLOR_ACENTO
                )
        );

        tarjetas.add(
                crearTarjeta(
                        "Proveedores",
                        "Gestión de proveedores",
                        "PV",
                        COLOR_VERDE
                )
        );

        tarjetas.add(
                crearTarjeta(
                        "Almacenes",
                        "Control de almacenes",
                        "AL",
                        COLOR_AMARILLO
                )
        );

        tarjetas.add(
                crearTarjeta(
                        "Movimientos",
                        "Entradas y salidas",
                        "MV",
                        new Color(56, 189, 248)
                )
        );

        tarjetas.setMaximumSize(
                new Dimension(Integer.MAX_VALUE, 130)
        );

        contenido.add(tarjetas);

        contenido.add(Box.createVerticalStrut(25));

        // ----------------------------------------------
        // PANEL INFORMATIVO
        // ----------------------------------------------

        JPanel informacion = crearPanelInformativo();

        contenido.add(informacion);

        contenido.add(Box.createVerticalStrut(20));

        // ----------------------------------------------
        // MÓDULOS DEL SISTEMA
        // ----------------------------------------------

        JLabel tituloModulos = new JLabel(
                "Módulos disponibles"
        );

        tituloModulos.setForeground(COLOR_TEXTO);

        tituloModulos.setFont(FUENTE_SECCION);

        contenido.add(tituloModulos);

        contenido.add(Box.createVerticalStrut(12));

        JPanel modulos = new JPanel(
                new GridLayout(2, 3, 12, 12)
        );

        modulos.setOpaque(false);

        modulos.add(
                crearModuloInformativo(
                        "Productos",
                        "Administración de productos"
                )
        );

        modulos.add(
                crearModuloInformativo(
                        "Proveedores",
                        "Administración de proveedores"
                )
        );

        modulos.add(
                crearModuloInformativo(
                        "Almacenes",
                        "Gestión de almacenes"
                )
        );

        modulos.add(
                crearModuloInformativo(
                        "Inventario físico",
                        "Conteo y conciliación"
                )
        );

        modulos.add(
                crearModuloInformativo(
                        "Kardex",
                        "Historial de movimientos"
                )
        );

        modulos.add(
                crearModuloInformativo(
                        "Reportes",
                        "Información del inventario"
                )
        );

        contenido.add(modulos);

        JScrollPane scroll = new JScrollPane(contenido);

        scroll.setBorder(null);

        scroll.setBackground(COLOR_FONDO);

        scroll.getViewport().setBackground(COLOR_FONDO);

        scroll.getVerticalScrollBar().setUnitIncrement(15);

        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // ==================================================
    // 13. TARJETAS DE INDICADORES
    // ==================================================

    private JPanel crearTarjeta(
            String titulo,
            String descripcion,
            String abreviatura,
            Color color
    ) {

        JPanel tarjeta = new JPanel(new BorderLayout(10, 10));

        tarjeta.setBackground(COLOR_PANEL);

        tarjeta.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDE),
                        new EmptyBorder(15, 15, 15, 15)
                )
        );

        JPanel superior = new JPanel(new BorderLayout());

        superior.setOpaque(false);

        JLabel nombre = new JLabel(titulo);

        nombre.setForeground(COLOR_TEXTO);

        nombre.setFont(FUENTE_SECCION);

        JLabel icono = new JLabel(abreviatura);

        icono.setForeground(color);

        icono.setFont(
                new Font("Segoe UI", Font.BOLD, 13)
        );

        superior.add(nombre, BorderLayout.WEST);

        superior.add(icono, BorderLayout.EAST);

        JLabel texto = new JLabel(descripcion);

        texto.setForeground(COLOR_TEXTO_SECUNDARIO);

        texto.setFont(
                new Font("Segoe UI", Font.PLAIN, 11)
        );

        tarjeta.add(superior, BorderLayout.NORTH);

        tarjeta.add(texto, BorderLayout.CENTER);

        return tarjeta;
    }

    // ==================================================
    // 14. PANEL INFORMATIVO
    // ==================================================

    private JPanel crearPanelInformativo() {

        JPanel panel = new JPanel(new BorderLayout(15, 5));

        panel.setBackground(COLOR_PANEL);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDE),
                        new EmptyBorder(17, 20, 17, 20)
                )
        );

        JLabel titulo = new JLabel(
                "Sistema de inventario físico y valorizado"
        );

        titulo.setForeground(COLOR_TEXTO);

        titulo.setFont(FUENTE_SECCION);

        JLabel texto = new JLabel(
                "<html>Control de existencias, movimientos de almacén "
                + "y valorización mediante el método de "
                + "costo promedio ponderado.</html>"
        );

        texto.setForeground(COLOR_TEXTO_SECUNDARIO);

        texto.setFont(FUENTE_NORMAL);

        JPanel textos = new JPanel();

        textos.setOpaque(false);

        textos.setLayout(
                new BoxLayout(textos, BoxLayout.Y_AXIS)
        );

        textos.add(titulo);

        textos.add(Box.createVerticalStrut(6));

        textos.add(texto);

        JLabel estado = new JLabel("ACTIVO");

        estado.setForeground(COLOR_VERDE);

        estado.setFont(
                new Font("Segoe UI", Font.BOLD, 11)
        );

        panel.add(textos, BorderLayout.CENTER);

        panel.add(estado, BorderLayout.EAST);

        return panel;
    }

    // ==================================================
    // 15. TARJETAS INFORMATIVAS DE MÓDULOS
    // ==================================================

    private JPanel crearModuloInformativo(
            String titulo,
            String descripcion
    ) {

        JPanel panel = new JPanel(new BorderLayout(5, 8));

        panel.setBackground(COLOR_PANEL);

        panel.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDE),
                        new EmptyBorder(13, 15, 13, 15)
                )
        );

        JLabel nombre = new JLabel(titulo);

        nombre.setForeground(COLOR_TEXTO);

        nombre.setFont(FUENTE_SECCION);

        JLabel detalle = new JLabel(descripcion);

        detalle.setForeground(COLOR_TEXTO_SECUNDARIO);

        detalle.setFont(
                new Font("Segoe UI", Font.PLAIN, 11)
        );

        panel.add(nombre, BorderLayout.NORTH);

        panel.add(detalle, BorderLayout.CENTER);

        return panel;
    }

    // ==================================================
    // 16. PANELES PROVISIONALES
    // ==================================================

    private JPanel crearPanelModulo(String nombre) {

        if (nombre == null || nombre.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "El nombre del módulo es obligatorio."
            );
        }

        if (nombre.trim().length() > 100) {

            throw new IllegalArgumentException(
                    "El nombre del módulo no puede superar 100 caracteres."
            );
        }

        JPanel panel = new JPanel(new BorderLayout(15, 15));

        panel.setBackground(COLOR_FONDO);

        panel.setBorder(
                new EmptyBorder(30, 30, 30, 30)
        );

        JPanel contenido = new JPanel(
                new GridBagLayout()
        );

        contenido.setBackground(COLOR_PANEL);

        contenido.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDE),
                        new EmptyBorder(30, 30, 30, 30)
                )
        );

        JPanel textos = new JPanel();

        textos.setOpaque(false);

        textos.setLayout(
                new BoxLayout(textos, BoxLayout.Y_AXIS)
        );

        JLabel titulo = new JLabel(nombre);

        titulo.setForeground(COLOR_TEXTO);

        titulo.setFont(
                new Font("Segoe UI", Font.BOLD, 23)
        );

        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel mensaje = new JLabel(
                "Este módulo se encuentra pendiente de implementación."
        );

        mensaje.setForeground(COLOR_TEXTO_SECUNDARIO);

        mensaje.setFont(FUENTE_NORMAL);

        mensaje.setAlignmentX(Component.CENTER_ALIGNMENT);

        textos.add(titulo);

        textos.add(Box.createVerticalStrut(12));

        textos.add(mensaje);

        contenido.add(textos);

        panel.add(contenido, BorderLayout.CENTER);

        return panel;
    }

    // ==================================================
    // 17. PIE DE PÁGINA
    // ==================================================

    private JPanel crearPiePagina() {

        JPanel pie = new JPanel(new BorderLayout());

        pie.setBackground(COLOR_PANEL);

        pie.setBorder(
                BorderFactory.createMatteBorder(
                        1, 0, 0, 0, COLOR_BORDE
                )
        );

        pie.setPreferredSize(new Dimension(0, 32));

        JLabel texto = new JLabel(
                "Sistema de Inventario | Proyecto T1"
        );

        texto.setForeground(COLOR_TEXTO_SECUNDARIO);

        texto.setFont(
                new Font("Segoe UI", Font.PLAIN, 10)
        );

        texto.setBorder(
                new EmptyBorder(0, 18, 0, 0)
        );

        pie.add(texto, BorderLayout.WEST);

        return pie;
    }
}

   
