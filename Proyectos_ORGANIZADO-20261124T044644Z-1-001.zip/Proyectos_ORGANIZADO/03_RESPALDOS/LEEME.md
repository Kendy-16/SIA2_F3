# Respaldos

| Carpeta | Contenido |
|---|---|
| `base_de_datos/` | `inventario_antes_V002.db`, `inventario_antes_inventario_fisico.db`, `inventario_antes_migraciones.db`, y las BD de las versiones `Login` y `Temporal` (esta última sin usuarios). |
| `esquemas/` | `schema_antes_V002.sql`, `schema_antes_inventario_fisico.sql`. |
| `codigo/antes_roles/` | Instantánea del proyecto antes de agregar roles (completa, salvo los archivos de 0 bytes). |
| `codigo/antes_controller_roles/`, `antes_integracion_movimientos/` | `MovimientoController` y `MenuPrincipalView` previos a esos cambios. |
| `codigo/menu_principal/`, `menu_principal_login/` | Todas las variantes históricas de `MenuPrincipalView` (`_antes_logo`, `_antes_diseno`, `_antes_ajuste`, `.bak`, …). |
| `codigo/modulos_movimientos_login/` | `EntradaView` e `InventarioFisicoView` de la rama Login. |

Los archivos vacíos dentro de estos respaldos no se conservaron (no tenían contenido).
